# RemoteControl 长期备忘（电脑鼠蓝牙上位机）

> 过程细节见 `.workbuddy/memory/YYYY-MM-DD.md`；协议细节见 `docs/传输模式接口设计.md` + `传输模式重构设计方案.md`。**项目不是 git 仓库。**

## 构建 / 环境
- 固件 `code_stm32f1_mouse/`：STM32F103RB、Keil MDK V5.06 / ARMCC V5、**C90**、-O0、OneElfS=1。`HARDWARE/link.c|h` = 链路模块，不动业务逻辑与红线数值。
- `host/` 上位机；`Control/` 是**工作区外的兄弟前端项目**；`release/` 归档。
- 编译 `"/c/Keil_v5/UV4/UV4.exe" -b "<绝对路径>\USER\Mouse.uvprojx" -o "<绝对日志>"`（必须绝对路径；exit=1 可能仅告警）；五档批量重编 = 仓库根 `build_all_modes.py`。符号 = `fromelf.exe --text -s USER/Object/Mouse.axf`。
- Python 用 `C:/ProgramData/anaconda3/python.exe`（有 numpy+pyserial）；测试在 `host/` 跑；PySide6 未装。
- ⚠️ 改 `link.c` 防**注释提前闭合**（`doTask*/LESSON_ISR`），踩过两次；`contract_test [S5]` 有扫描断言。

## 链路
USART1(PA9/PA10)↔蓝牙透传↔CH340→COM7；115200-8-N-1 无流控，天花板 11520 B/s；不做配对。固件**上电静默**须 `STREAM ON`。
上行 `AA55|LEN(2,LE)|TYPE|SEQ|PAYLOAD|CRC16-MODBUS`（开销 8B）；下行 ASCII `<CMD> [args] [#seq] *CRC16`；参数 Q16.16。
⚠️ 真机稳态往返 ≈230ms → `TIMEOUT_S=0.50`；首条可能 ~750ms；偶发行位错回 `ACK -1 ERR_CRC`（幂等重发自愈）。

## v2.0 传输重构（已实施，已归档 `v2.0.0` / 2026-10-05）
> **本节取代一切旧帧/双流描述。** 三原则：① 上行只有"持续流 + 异常事件"；② 下行一律请求-响应；③ 上位机能算的不传。
- **砍双流**：`SCOPE`+`DUMP`、`SNAP`/`RATE`/`VER`、`MAZE EV` 全删（`VER` 并入 `PING`）。**1kHz 红外采样保留**（`doWallDetect()` 在 SysTick，比赛依赖，一行不动）。只剩一种帧 `LINK_TYPE_UNIFIED=0x0A`：payload 45B（测量 35 + 状态位打包 3 + 其余 7）、总 53B ≈217 Hz；`UNIFIED_CHANNELS` 展平 39 通道。
- **自时钟**：`link_DmaIdle() && (linkTxHead==linkTxTail)` 才组"当前最新值"一帧（不是"环有空就发"，那会灌满 512B 环）。无 Hz 上限。
- **时间锚**：`STREAM ON` 应答 `ACK <seq> OK <upMs>`；每帧 `ms8`，主机 `resolve_ms8` 同余还原（模 256ms 容 55 帧）。⚠️ `STREAM ON` **不参与幂等重放**（应答后清 `linkLastSeq=-1`），否则失锁后重发只能拿到旧锚。
- **命令 41→23**（`registry.COMMANDS` 实测；设计稿的"18"是早期目标，落地含别名后为 23）；上行事件只留 `STOPPED <reason>` / `ESTOP TRIP`，**带 `#n`**（与帧 SEQ 共用计数器，不 ACK 不重发）；空间门 `LINK_EV_NEED_SPACE=64`，不足丢弃 + `linkEvDrop` + flags `LINK_FLAG_EVQ 0x80`。
- **标定改请求-响应**：`CAL <item> {START|SAMPLE|ABORT}` 采完才 ACK；`CAL` 归 `no_retry`、超时 10s；`ARMED` 并入 `ARM` 应答；`PING`→`PONG <proto> <fw> <mazetype> <txbuf> <rst>`。
- **IWDG** LSI/64=625Hz、RLR=1249→~2.0s，喂狗在 `LINK_Tick()`；复位原因读 `RCC->CSR`（IWDG>SW>POR>PIN）后清 `RCC_CSR_RMVF`。
- **直接替换**，`API_VERSION` → **2.0.0**。v2.0 各档 ROM 均 0 Error：[1]27784 [2]28336 [3]32856 [4]75912 [5]90936（[5] 比 v1.5.5 省 5792 B）。
- 上位机八套件 **483 项全绿**（`selftest` 45 / `contract_test` 208 / `facade` 36 / `lesson` 38 / `maze` 34 / `monitor` 32 / `motor_lab` 38 / `timesync` 52；`snap_smoke` 已删）。
- 已归档：`release/RemoteControl-v2.0.0-20261005.zip`（182 文件，40 必需项齐全，182/182 与工作区逐字节一致）。
- ⚠️ **整个 v2.0 从未上真机**；未验证边界逐条列在 `release/归档说明.md` §5.2（自时钟帧率、`ms8` 失锁、IWDG、标定时序全是模拟器结论）。
- ⚠️ 下游 `Control/` 前端**本轮明确不动**（用户决定）：它依赖 `SNAP`/`SCOPE`/迷宫三通道，连 v2.0 固件时这些功能会失效。
- 遗留小瑕：`host/api/events.py` 的 `Event.MOVE` 已无任何发送方（死枚举成员），未清。
- 路口 8 类不再上报（帧里只有 `wallL/F/R` 原语）→ 主机侧 `classify_road(wL,wF,wR)` 复刻（wall 语义 **1=有墙**）。

### 不可再生的查证结论
- ⚠️ `trackL/trackR` 单位是 **mm 不是 pulse**（`odom.c:96-101` 已除）；s16 覆盖 ±32.7m，不需 s32。
- ⚠️ `wallSns.wallThresh` **不可由参数推导**：运行时被 `state.c:225`→140、`motion.c:418`→110 改写，参数 `IRTHRWALL`=160 → **必须进帧**。
- 决策量只能传结果：`EXPLORE_CrosswayChoice()` 首行 `FLOODFILL_Open()` 全图重算且有副作用 → 不传。

## 固件五档（`USER/main.h`，五宏互斥，≥2 个 `#error`）
[1] `MOUSE_TEST_NO_MOTOR` 电机物理禁用；[2] `MOUSE_TEST_MOTOR_LAB` 可控无自走（MOVE+护栏）；[3] `MOUSE_LESSON_LAB` 可控无自走+课程剖面；[4] `MOUSE_DATA_LOG` 可控**含自走**，**不派生 `MOUSE_TEST_MODE`**；[5] 全不定义 = 比赛固件。入口 `python -m host.motor_test|host.lesson|host.datalog COM7`。
⚠️ **档位门控必须用具名派生宏**：`MOUSE_TEST_MODE`=[1][2][3]，`MOUSE_ESTOP_RECOVERABLE`=[1][2][3]**+[4]**。绝不重复裸 `#ifdef MOUSE_TEST_MODE` —— 漏一处不报错，只在真机行为不一致。已发生：[4] 急停锁死 + 进 sleepmode 而链路照发帧 → **链路活着、数据冻结**（`upMs` 涨而采样不变）。`[S5]` 已钉死。

## Flash 分区 / ROM
0..100 程序区（101KB，IROM1 `0x19400`）／101 `DATA_NUM`／102..114 `DATA`（擦除正好 13 页）／115 `SYSCALIB`／116 `LESSONPARAM`／118..127 迷宫墙·起终点·90°路径·`IRDATA`·常规路径·陀螺零偏（**地址未变，不需重标定**）。
⚠️ 标定页原取 99/100，正落在 `FLASH_EraseRunData` 擦除范围 89..101 内 → 已移 115/116。改 `saveNum`/页地址须重核（`[S5]` 4 条断言）。
⚠️ **`sizeof` 陷阱**：`motion.c` 的 `TurnParam_t.length = sizeof(表)` 却按 `length/2` 当元素数用（元素宽 2B 写死）→ 查表收窄到 1B 就会"转弯只走一半表"。修法：`length` 改点数语义，3 处类型同步（`speedtable.h`/`motion.c`/`core.h`，`isr.c` 9 处解引用）。"表内容不变"只能逐值比对。ROM 最大单耗 `speedtable.o` 20280B。

## 参数（38 个；Q16.16）
生产 1–7（TRACKL/R、SPEEDL/R、GYRORATIO、ENCANGLE、WALLDIST，Flash 115）／课程 8–21（仅 [3]，Flash 116）／红外电源 22–38（含 BATTKV=2417、BATTLOWMV=7000、BATTHIGHMV=**7960**）。**`LINK_P_NUM`=24**（1–7+22–38）。
- `SPEEDL/R ≡ TRACKL/R ÷ 100`（派生，不独立标定）。TRACKL/TRACKR/GYRORATIO 属生产命名空间 → 不能用 `mc.lesson.set_params()`，须 `mc.params.set()`。
- ⚠️ **固件读侧只有生产表**：`GET ALL` 只遍历 24 项，课程 14 项一律 `ERR_NAME`；写侧有课程分支。模拟器早期回全部 38 项 → 掩盖了它（`[D2]` 已钉死）。
- ⚠️ Flash 扩容陷阱（用户决定不修）：`link_CalibLoad` 校验 `cnt != LINK_P_NUM` 即判无效 → 表扩容旧页作废、标定回落默认值；刷固件后要重标，现场表现是"读到默认值"。

## [2] 电机远程 / 标定边界
- ⚠️ **运动互斥**：`MOVE` 启动把 `motionCtrl.task` 置 NULL → 只看 `task` 查不出"正在跑 MOVE"，统一走 `link_MotionBusy()`（task + linkMove/linkSrv.state + linkCal.active）。回归 `[D3]/[D4]`。
- `MOVE RUN <spL> <spR> [ms] [ir_mm]`：时间护栏默认 2000ms/上限 60000；红外默认 10mm（负=关）；±300 上限。完成回 `STOPPED <REASON> #n`（v2.0 起无 MOVEDONE）。`ESTOP` 锁存，**只有 `STOP` 能解锁**（[1]–[4]；[5] 刻意锁死到断电）。
- 5 项 `CAL <item>`：GYRO/WALLDIST/IRDATA/GYRORATIO/ENCANGLE。[1] 只能静态 3 项：GYRO（Flash 127）、WALLDIST（仅 RAM，`SAVE`→115）、IRDATA（写 123）。需电机 2 项 → 切 [2] 重编译或 [3] 课程剖面。上位机护栏 `mc.motor_disabled`/`mc.motor_guard()`。

## 归档（`release/`）与用户偏好
非 git → 白名单+排除 `make_archive.py`。⚠️ **顺序固定**：跑绿并重编 → 接口审计 → 修过期文档（历史 CHANGELOG 不动）→ 写说明 → **写记忆** → 打包 → 抽查。`registry.API_VERSION` 必须与 CHANGELOG 一致。
偏好：一步到位、直接产出可用成果；**不需要**版本匹配/向后兼容机制。用户自己负责烧录与真机测试。
