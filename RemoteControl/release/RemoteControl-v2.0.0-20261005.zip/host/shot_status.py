"""截取真机下的新界面: 实时状态页 + 停车后拉取页。"""

from __future__ import annotations

import os
import sys
import time

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PySide6.QtWidgets import QApplication  # noqa: E402

from host.ui.main_window import MainWindow  # noqa: E402

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "docs")


def pump(app, sec: float) -> None:
    t0 = time.time()
    while time.time() - t0 < sec:
        app.processEvents()
        time.sleep(0.01)


def main() -> int:
    app = QApplication.instance() or QApplication(sys.argv)
    w = MainWindow()
    w.resize(1560, 980)
    pump(app, 0.5)

    # 连接真机
    w._toggle_connect()
    pump(app, 1.0)
    print("state:", w.link.state, w.link.state_detail)
    print("静置 8 秒让模块缓冲排空 ...")
    pump(app, 8.0)
    print("采集 15 秒 ...")
    pump(app, 15.0)
    st = w.link.stats()
    print(f"帧: 统一={st['unified']} 墙图={st['map']} 文本={st['text']}  {st['rx_bps']:.0f} B/s")

    p1 = os.path.join(OUT, "ui_status.png")
    w.grab().save(p1)
    print("已截图", p1)

    # 切到"统一帧查看"页
    w.right_tabs.setCurrentWidget(w.fetch)
    pump(app, 0.4)
    p2 = os.path.join(OUT, "ui_fetch.png")
    w.grab().save(p2)
    print("已截图", p2)

    w._toggle_connect()
    pump(app, 0.5)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
