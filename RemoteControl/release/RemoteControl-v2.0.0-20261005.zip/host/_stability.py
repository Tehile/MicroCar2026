"""长期稳定性测试: 验证 v2.0 单一自时钟遥测流能否【持续】不饱和。

背景: 老方案(可变分频 fast/mid/slow 三路帧)下短时能过到 1508 B/s, 但持续发送
      时 511 B/s 也会饱和 —— 说明该链路的"可持续吞吐"低于"短时突发吞吐"。
      v2.0 改为**单一统一帧自时钟发送(~217 Hz, 53 B/帧)**, 速率不可调, 因此
      本脚本只剩一件事: 持续读 30 秒, 把时间切成小段统计, 看是否中途归零。

流程: 复位(让模块缓冲清空) -> 等 1s -> 置 linkStreamOn=1 -> 持续读 -> 分段统计
      地址取自 v2.0 固件的 USER/Mouse.map; v2.0 已删除 RATE / linkFastDiv。
"""

from __future__ import annotations

import os
import subprocess
import tempfile
import time

import serial

JL = r"C:\Program Files\SEGGER\JLink_V976a\JLink.exe"
PORT = "COM7"
STREAMON_ADDR = 0x2000082C  # linkStreamOn (u8): 遥测总开关
FRAME_BYTES = 53            # 统一帧线长 = 6B 头(SYNC0/SYNC1/len/type/seq) + 45B 载荷 + 2B CRC
FRAME_HZ = 217.0            # 自时钟发送频率


def jl(lines) -> str:
    script = "si SWD\nspeed 4000\ndevice STM32F103RB\nconnect\n" + "\n".join(lines) + "\nq\n"
    fd, path = tempfile.mkstemp(suffix=".jlink", text=True)
    os.close(fd)
    with open(path, "w", encoding="ascii") as f:
        f.write(script)
    try:
        p = subprocess.run([JL, "-CommanderScript", path, "-ExitOnError", "1"],
                           capture_output=True, text=True, timeout=120,
                           encoding="utf-8", errors="replace")
    finally:
        try:
            os.unlink(path)
        except OSError:
            pass
    return p.stdout or ""


def run_case(sec: float = 30.0) -> None:
    bps = FRAME_HZ * FRAME_BYTES
    print(f"\n--- 统一帧自时钟 (约 {FRAME_HZ:.0f}Hz, {FRAME_BYTES}B/帧, 合计约 {bps:.0f} B/s) ---")

    # 复位让模块缓冲清空, 再开流
    jl(["r", "go"])
    time.sleep(1.2)
    jl([f"w1 0x{STREAMON_ADDR:08X}, 0x01",
        f"mem8 0x{STREAMON_ADDR:08X}, 1"])
    time.sleep(0.5)

    try:
        s = serial.Serial(PORT, 115200, bytesize=8, parity="N", stopbits=1, timeout=0.15)
    except Exception as e:
        print(f"    打开失败: {e}")
        return
    try:
        buckets = []
        b0 = time.time()
        n = 0
        while time.time() - b0 < sec:
            d = s.read(4096)
            if d:
                n += len(d)
            if time.time() - b0 >= (len(buckets) + 1) * 5.0:
                buckets.append(n)
        buckets.append(n)
    finally:
        s.close()

    prev = 0
    parts = []
    for tot in buckets:
        seg = tot - prev
        prev = tot
        parts.append(f"{seg:5d}")
    print(f"    每 5 秒收到的字节: {' | '.join(parts)}")
    print(f"    总计 {buckets[-1]} 字节, 平均 {buckets[-1] / sec:.0f} B/s")
    # 判据: 后半段是否仍在持续收
    if len(buckets) >= 4:
        half = buckets[len(buckets) // 2]
        if buckets[-1] > half and (buckets[-1] - half) > 0.2 * thresholds_scale(bps):
            print("    => 持续通过")
        else:
            print("    => ★ 后半段基本停滞(已饱和)")


def thresholds_scale(bps: float) -> float:
    return max(bps * 5.0, 100.0)


def main() -> int:
    print("=" * 78)
    print("长期稳定性测试 (复位清缓冲 -> 开流 -> 跑 30 秒分段统计)")
    print("=" * 78)
    run_case()
    jl(["r", "go"])
    print("\n已复位恢复默认(静默)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
