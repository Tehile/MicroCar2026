"""遥测流控制: `STREAM` 开关(唯一的人工刹车)。

v2.0(2026-10-05): **速率不再是可调项**。固件改自时钟发送 —— 每 1ms 检查链路
是否空闲, 够空就组"当前最新值"一帧, 因此帧率由物理链路能力自动决定(≈217 Hz
@115200-8-N-1)。旧的 `RATE` 命令与其"152 B/s 上限"假设已删除(该假设在真机上
被证伪)。

硬约束(实机踩坑): 固件**上电默认静默**, 连接后必须 `STREAM ON` 才会收到遥测
(门面 `auto_stream=True` 已自动处理), 断开前先 `STREAM OFF`。

**时间锚**: `STREAM ON` 的应答体里带一次完整 u32 设备时基
(`ACK <seq> OK <upMs>`) —— 统一帧每帧只带 ms8(低 8 位), 靠这个锚做同余还原,
才能把每帧唯一地定位到绝对设备时刻(见 `api/timesync.py`)。
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Optional

from .errors import Result

if TYPE_CHECKING:  # pragma: no cover
    from .client import MouseClient


class StreamAPI:
    """遥测流开关。方法会等待设备应答。"""

    def __init__(self, mc: "MouseClient") -> None:
        self._mc = mc

    # ------------------------------------------------------------ 开关

    def on(self, timeout: float = 3.0) -> Result:
        """开启遥测流(应答带时间锚, 会被自动存进 store)。"""
        r = self._mc.send_cmd("stream.on", timeout=timeout)
        if r.ok:
            self._absorb_anchor(r.status)
        return r

    def off(self, timeout: float = 3.0) -> Result:
        """关闭遥测流。断开前建议先关, 避免下次连接时缓冲里压着旧数据。"""
        return self._mc.send_cmd("stream.off", timeout=timeout)

    def toggle(self, on: bool, timeout: float = 3.0) -> Result:
        return self.on(timeout=timeout) if on else self.off(timeout=timeout)

    @property
    def is_on(self) -> bool:
        """按"最近是否还在收到帧"判断流是否开启(启发式, 非设备状态)。"""
        return self._mc.telemetry.is_streaming()

    # ------------------------------------------------------------ 时间锚

    def _absorb_anchor(self, status: str) -> Optional[int]:
        """从 `ACK <seq> OK <upMs>` 的状态串里取锚并写入 store。"""
        parts = str(status or "").split()
        if len(parts) >= 2 and parts[0].upper() == "OK":
            try:
                up = int(parts[1])
            except ValueError:
                return None
            self._mc.store.set_anchor(up)
            return up
        return None

    def anchor(self):
        """当前时间锚 `(本机单调秒, 设备 ms)`; 未建立时 None。"""
        return self._mc.store.get_anchor()
