# RemoteControl 长期备忘（电脑鼠蓝牙上位机）

> 当前基线：固件 `code_competition/` + 上位机 `host/` v2.11.0；旧 `code_stm32f1_mouse/` 仅历史参考。档位判据 = `PONG` 的 `fw`（新 300/迷宫16；课程 222/7），`host/host/fwprofile.py`。细节见 `.workbuddy/memory/YYYY-MM-DD.md` 与 `docs/`。

## 一、状态
- **待做：P3 真机联调**（发车/收车/中止 + 容量复测 + CAL 家族）；前置 `safe_stop_smoke.py` 桩扩到新 `LP_*` 签名。
- **参数工具链 v3.0 已跑通**（2026-10-16）：72 项 / 185 套 / derived 40 / dropped 40 / bss 5 / gaps 0；真树 `apply3 --commit` = 0 行/0 文件、双档重编 0 Error、比赛 hex 红线 PASS。冻结点 = git tag `paramgen-v3-freeze-20261016`。**G5 已完成**：`render3` 子命令 + `docs/参数名称-功能-调整表.md` 第八节 `param-v3` 标记区（标题 v3.0、幂等注入；`inject` 双标记缺陷已修）；**v2 不退役**（在线契约 C1/C2/C4/C12 唯一守卫 + legacy 档 + 镜像写入口）。**已归档 v3.0.0**（十套件 701 复跑全绿后打包）。
- 十套件新档 701 全绿 / legacy 702 全绿；另 `safe_stop_smoke` 13 + `test_evt_trigger_logic`；`timesync_smoke` 偶发失败单独复跑。

## 二、红线铁律
- 判"没动比赛代码"**只比 hex 哈希**（`.axf` 含 DWARF）。红线 `68ad6be2…8141`（ROM 82040/RAM 20480）；校验 `python build_competition_modes.py`。远程档基线 ROM 96512/RAM 13560 hex `a71b5e9d…`。
- **`MOUSE_REMOTE` 由 Keil `-D` 注入**，源码只有 `#ifdef`；新声明/分支/宏必须门控（含仅远程局部变量，扰动 literal pool 实测 −8B）；`REMOTE/*.c` 整文件门控。
- 当前档位看 `USER/TEST.uvoptx` 的 `<IsCurrentTarget>`；Target 顺序绝不可调换（`contract_test.py` 正则依赖）。**烧错档症状 = PING 无 PONG**。
- RAM 100% 满（RW+ZI=20480）⇒ 远程档靠 3 处 `#ifndef MOUSE_REMOTE` 关飞行记录（save_num 1200→1，释放 9592B）。再超优先缩 TX 环，绝不动比赛数据结构。
- GBK 纪律：14 个 GBK 文件只能 python 字节级替换；`REMOTE/` 4 文件全 GBK+CRLF。Edit 工具写 py 会转 LF ⇒ 改完 `git ls-files --eol` 复核 w/crlf。
- 工程无 main.c（`main()` 在 `USER/test.c`）。远程层 Flash 自用 115 SYSCALIB。

## 三、环境/构建陷阱
- Keil V5.06 + STM32F103RB + **C90**；UV4 exit code 不可靠看日志 "N Error(s)"。**Keil 开着 = 命令行抢不到资源**（改 uvprojx 被回写、J-Link 连不上）⇒ 用前 `tasklist | grep UV4` 必须空。
- **SWJ_CFG**：`timer.c` `Timer2_Init()` 原 `0x04000000` 关 JTAG+SWD ⇒ J-Link 永久失联；正解 `0x02000000`。判据 `ORR r0,r0,#0x2000000`。
- **上电陀螺标定是阻塞死循环**（车不静止永久自旋，标定完成前 COM7 全程 0 字节）⇒ 真机联调必须绝对静止上电。`LINK_Init()` 会 `link_RateStop()` ⇒ 上电静默是设计行为，探活发 `PING`/`TELEM`。
- 串口：真机 **COM7**（CH340↔蓝牙）；COM4=蓝牙传出（须真正连接）；COM5=空壳。J-Link 只读诊断定式见 `2026-10-16.md`；本机 2012 克隆 OB 反复 reset 卡死需拔插 USB。
- git 仓库=父目录，分支 `develop-lrz`，提交 `[feat] RemoteControl: …`，只 commit 不 push。host 测试：`cd RemoteControl/host && python <套件>.py`（`-m host.x` 会 No module named 'host.api'）。

## 四、链路/收车铁律
- 严格停等（在途 ≤1，1ms tick 吃一行）；命令在 SysTick ISR ⇒ 严禁 DELAY/while；关键值必须进 ACK 附加字段（首 token "OK"）。
- **`MAZE STOP` 阻塞等待里不可靠** ⇒ 可靠收车 = `MCU RESET`。定式 `force_idle()`：`MAZE STOP`→`ESTOP`→`MCU RESET`，每步新鲜帧验证。
- **判状态必须用新鲜帧**（记帧计数→发 TELEM→等变化）；空帧 ≠ 待命；**安全出口宁可报失败，绝不谎报成功**；刚发过车 `assume_busy=True`。收车判据 `rst=SW`；首帧遥测 ~3.2s；低电硬闸 `LAUNCH_MIN_MV=7000`。
- **USART1 NVIC 铁律**：`uart_init` 只开 RXNEIE，NVIC 位必须 `LINK_Init` 显式写（`REMOTE/link.c`）。漏了 = 烧录成功但串口完全静默。两种静默先区分：① NVIC 未使能 ② 陀螺标定未完成。
- `ERR_ESTOP` 死锁已修（`52dde76`，待实机复测）：`LINK_EStopTrip()` 加 `if (isemergency != 1) return;`；STOP/MAZE STOP 各补 `isemergency=0`。协作式中止：`linkRunAbort` 期间 SysTick 强制 task=0/step=1/tick=60000/track=0x7FFFFFFF/setvl=setvr=0（故意不碰 freemode）；`LINK_MazeStarted()` 必须 `LP_AbortClear()`。
- `setvl/setvr` 绝不能回写（PID 每 tick 输出量）；`LINK_Tick()` 必须在 SysTick_Handler 函数级末尾（`if(sleepmode)` 之外）。
- 远程档声明冲突三型：类型不同（setvl/setvr int vs long）、数组长度（dataf1[240] vs [250]）、spurt_flag u8 vs int；宏逐 token 一致。

## 五、参数工具链
- **v3.0**（方案 `docs/参数全量整定常量化-方案v3.0.md`，提交 `2d054cb`）：数据模型 `sets:[{phase,value,expr,kind,anchor}]`，`default_phase` 默认 search；赋值点四形态 `init/phase/override/derived(不算套)`；A/B/C 降级为每套 `writable`+`runtime_overwritten_by`。
- B1–B6：B1 全量整定常量（≈72 值位/7 文件）｜B2 命名 `<参数名>@<时期>`｜B3 只做固件侧｜B4 初值算一个时期｜B5 冻结→抽取→零变更回写→双档重编→比红线｜B6 先不管远程档。
- Q1–Q4：Q1=多套各自保留/写入，**远程档与比赛档冲突留比赛档**（远程套进 `dropped[]` 永不写）｜Q2=`@`｜Q3 开关 `group:"switch"`｜Q4 卡尔曼辅助量 `group:"kalman"`。
- 时期命名自动：`init/search/spurt/spurt.low|medium|high/menu/mouse` + `<函数名>#<序号>`（s90#/wall45#/main#/t180#）。
- ★ 唯一不可写锚点 `UTILITY/utility.c:936`（行内两次 `decdistance=10`）⇒ 自动 `writable:false`。
- ★ I14：`LINK_P_NUM 24` 是死代码（`REMOTE/link.h` 整文件 `#ifdef MOUSE_REMOTE`）⇒ "比赛档保持 24" 是 host/page115 契约，非固件可达常量。
- **v2**（仍有效）：真源 `tools/params/params.competition.json`（41 项）；`fw`=固件只读快照 / `store`=人工受管值（含 `expr`，幂等的根）/ `policy ∈ {pinned, apply, report}`；"存储与固件不一致"是合法状态。仲裁 A14+B9+C18 自动算。写回三护栏：行指纹 sha16 + 单行唯一 + 只切值域；默认 dry-run。
- 链路名以 host `PARAM_IDS` 为准。文档偏差清单见 `docs/参数JSON化-一致性核查报告.md`（以固件为准）。

## 六、偏好/方法论
- 用户：一步到位直接产出；自己负责烧录与真机；conda 优先 `general_env`。证明"没动比赛代码" = 改前改后各编一次**比 hex 哈希**，用户会追问要给证据。
- 诊断脚本绝不发运动命令；验争用必须持续拉取+持续运动工况。归档顺序：跑绿重编→审计→文档→**记忆→归档说明→打包**→抽查→哈希（`sha256sum -c`）→提交；**记忆必须在打包前写**（v1.4.0 踩过：包内记忆是旧的）。
- **归档基线已换（2026-10-16）**：`release/make_archive.py`+`verify_archive.py` 重写为 v3.0.0 基线（旧版只收 `code_stm32f1_mouse`，会漏比赛固件/tools/新文档）；白名单 252 文件、排除 sessions/顶层抓取现场/副本/Keil 中间产物；`TEST.hex`=红线、`Remote/TEST.hex`=`a71b5e9d…` 均现场验过；`release/SHA256SUMS.txt` 台账整本重生成。版本命名改按里程碑（v3.0.0），host API 仍 2.11.0。
- 历史基线：旧课程固件按键极性 `BUTTON1` idle=0/按下=1（写反 ⇒ 永不发车）；旧比赛档 hex `f0a5f863…dc4a`、`LINK_P_NUM` 41/24、`LINK_FW_VER` 221/216。
