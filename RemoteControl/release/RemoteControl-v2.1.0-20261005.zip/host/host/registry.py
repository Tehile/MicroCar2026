"""命令与帧的单一登记点(E1)。

扩展规约 —— 新增一项功能时只允许改本文件的表:

    新增一条下行命令  ->  COMMANDS 里加一个 CommandSpec
    新增一种上行帧    ->  FRAMES   里加一个 FrameSpec
    新增一个参数      ->  protocol/commands.py 的 PARAM_IDS / PARAM_META

两条由 contract_test.py 静态断言、由 CI 强制:

    a) transport/link.py 的帧分派必须走 FRAMES, 不得出现 `type == TYPE_*` 比较
       或 decode_* 直调(否则新增帧要改两处, 迟早漂移)
    b) 每个登记项都必须能被模拟器实际执行(契约测试逐条跑)

本模块只**描述**命令, 不实现传输。执行走 run(), 由调用者传入 CommandClient。

v2.0(2026-10-05): 命令集由 41 条精简到 18 条, 帧由 9 种精简到 2 种。
    删除: SNAP(全部域) / SCOPE(3 条) / RATE / VER / MAZE EV / MAZE RST。
    理由见《传输模式重构设计方案》§7.2 / §8.4。
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Dict, Tuple

from .protocol.codec import (
    TYPE_MAP,
    TYPE_UNIFIED,
    decode_map,
    decode_unified,
)
from .protocol.commands import CommandClient

API_VERSION = "2.1.0"


# ---------------------------------------------------------------- 命令表

def _move_fwd(pulses: int, speed: int = 0) -> str:
    """speed 为 0 时省略 —— 固件据此走默认速度。与 commands.move_fwd 行为一致。"""
    return f"MOVE FWD {int(pulses)}" + (f" {int(speed)}" if speed else "")


def _move_rot(pwm: int, ms: int = 0) -> str:
    return f"MOVE ROT {int(pwm)}" + (f" {int(ms)}" if ms else "")


def _move_run(sp_l: int, sp_r: int, ms: int = 0, ir_mm: int = 0) -> str:
    """受"时间 + 红外"双护栏约束的远程运动(电机远程控制实验)。

    ms / ir_mm 为 0 时省略该参数, 由固件取默认值(2000 ms / 10 mm);
    ir_mm 传负值 (-1) 表示**关闭红外护栏**, 只验证时间护栏。
    """
    s = f"MOVE RUN {int(sp_l)} {int(sp_r)}"
    if ms or ir_mm:
        s += f" {int(ms)}"
        if ir_mm:
            s += f" {int(ir_mm)}"
    return s


def _cal(item: str, act: Any = "START") -> str:
    """`CAL <item> <act>` —— act 可为 START / ABORT, 或 IRDATA 的相位号(0..3)。

    v2.0: 标定是**请求-响应**的 —— GYRO/WALLDIST/IRDATA 的 START 不立刻回 ACK,
    而是等这一步采集完成才回(ACK 即"请摆下一个位置"), 见《方案》§9。
    """
    return f"CAL {str(item).upper()} {act}"


def _lesson_start(exp: int, a: int = 0, b: int = 0, c: int = 0, d: int = 0) -> str:
    """`LESSON START <exp> [a] [b] [c] [d]` —— 尾部为 0 的参数省略。

    固件用同一个整数解析器逐项取参, 取不到就按 0 处理, 因此"少写尾部 0"是安全的。
    参数含义随实验而定(见 host/host/api/lesson.py 的 LESSON_EXPS)。
    """
    vals = [int(a), int(b), int(c), int(d)]
    while vals and vals[-1] == 0:
        vals.pop()
    return " ".join([f"LESSON START {int(exp)}"] + [str(v) for v in vals])


@dataclass(frozen=True)
class CommandSpec:
    """一条下行命令。

    name  : API 名(点分层级), 也是 CLI 子命令与(将来)JSON-RPC 方法名的来源
    build : 由关键字参数拼出线上命令文本
    args  : build 接受的参数名(顺序即位置参数顺序), 供文档与参数校验使用
    ack   : 设备是否回 `ACK <seq> <status>`(全部为真, 保留字段以备将来单向命令)
    since : 引入该命令的 API 版本
    note  : 一句话说明, 会进自动生成的接口文档
    """

    name: str
    build: Callable[..., str]
    args: Tuple[str, ...] = ()
    ack: bool = True
    since: str = "1.0"
    note: str = ""
    #: 超时后是否重发。仅对"一发就已产生持续性副作用"的命令置 False:
    #: 重发不会让效果更快, 反而会往正在进行的流程里插命令。
    #: v2.0: `CAL` 整条归入 no_retry(采完才 ACK, 可能数秒) —— 见《方案》§9.3。
    no_retry: bool = False
    #: 该命令的应答等待时长(秒)。None = 用 CommandClient 的默认超时。
    timeout: float = None


COMMANDS: Dict[str, CommandSpec] = {
    # ---- 设备与协议 ----
    "ping": CommandSpec(
        "ping", lambda: "PING",
        note="心跳; 回 `PONG <proto> <fw> <mazetype> <txbuf> <rst>`, "
             "rst ∈ {POR,SW,IWDG,PIN} 是**上次复位原因**(连上后第一条就该发它)",
    ),
    # ---- 参数 ----
    "params.get": CommandSpec("params.get", lambda name: f"GET {name}", ("name",), note="回读单个参数(Q16.16)"),
    "params.get_all": CommandSpec("params.get_all", lambda: "GET ALL", note="回读全部生产参数(24 项)"),
    "params.setq": CommandSpec(
        "params.setq", lambda name, q: f"SETQ {name} {int(q)}", ("name", "q"),
        note="写精确 Q16.16 定点(推荐路径)",
    ),
    "params.set": CommandSpec(
        "params.set", lambda name, v: f"SET {name} {v}", ("name", "v"),
        note="写十进制(精度低, 仅供手工调试)",
    ),
    "params.save": CommandSpec("params.save", lambda: "SAVE", note="参数表写入 Flash"),
    "params.reset": CommandSpec("params.reset", lambda: "RESET", note="擦参数页并复位为源码默认值"),
    # ---- 运动控制 ----
    "tare": CommandSpec("tare", lambda: "TARE", note="陀螺角累加器与里程基准清零"),
    "stop": CommandSpec(
        "stop", lambda: "STOP",
        note="正常停车 + **解急停锁存**(测试/采集档); 这是重新获得控制权的唯一入口",
    ),
    "estop.clear": CommandSpec(
        "estop.clear", lambda: "STOP",
        note="`stop` 的同义入口(语义即「停车 + 解急停锁存」), 保留以便书写直观",
    ),
    "estop": CommandSpec("estop", lambda: "ESTOP", note="急停(置 freemode, 并锁存直到 STOP)"),
    "move.fwd": CommandSpec("move.fwd", _move_fwd, ("pulses", "speed"), note="固定脉冲直线(开环)"),
    "move.rot": CommandSpec("move.rot", _move_rot, ("pwm", "ms"), note="固定 PWM 定长原地转(开环)"),
    "move.run": CommandSpec(
        "move.run", _move_run, ("sp_l", "sp_r", "ms", "ir_mm"),
        note=(
            "受双护栏约束的远程运动: 左右轮速度(cm/s) + 最长运行时间(默认2000ms) "
            "+ 红外停车阈值(默认10mm, 负值=关闭)。停止后上行 `STOPPED <REASON> #n`"
        ),
    ),
    # ---- 遥测(拉取式) ----
    "telem": CommandSpec(
        "telem", lambda: "TELEM", no_retry=True, timeout=3.0,
        note=(
            "**拉取一帧遥测**: 回一帧统一帧(53B) + `ACK <seq> OK <upMs>`(带时间锚)。"
            "v2.1 起遥测是**请求-响应**式的 —— 固件不再自时钟发送, 发多少帧完全由上位机决定。"
            "⚠️ 必须**一次只发一条**(严格停等): 固件每 1ms tick 只消费一行命令, 成串发必丢"
            "(实测回收率: 背靠背 2 条仅 50%)。上位机的 `api/stream.py` 已按停等实现，会自动调用它。"
            "不重发: 每次请求都必须真的产生一帧, 重发只会多要一帧。"
        ),
    ),
    # ---- 标定(请求-响应) ----
    "calib.cal": CommandSpec(
        "calib.cal", _cal, ("item", "act"), no_retry=True, timeout=10.0,
        note=(
            "标定项控制: item ∈ {GYRO,WALLDIST,IRDATA,GYRORATIO,ENCANGLE}。"
            "act ∈ {START,ABORT}, 或 IRDATA 的相位号 0..3。"
            "**采完才回 ACK**(ACK 即「这一步完成, 请摆下一个位置」); 最坏可能数秒, "
            "故超时 10s 且不重发。结果值用 `GET` 回读"
        ),
    ),
    # ---- 墙图 ----
    "maze.dump": CommandSpec("maze.dump", lambda: "MAP DUMP", no_retry=True, note="墙图整块回传(98B)"),
    # ---- 时间同步 / 数据收集 ----
    "arm": CommandSpec(
        "arm", lambda: "ARM",
        note=(
            "发车: 固件记下发车时刻 + 点亮 1Hz 时间基准灯(50% 占空比), "
            "并回 `ACK <seq> OK <armMs>`(发车时基随 ACK 回, 不再单发 ARMED 行)"
        ),
    ),
    "maze.run": CommandSpec(
        "maze.run", lambda: "MAZE RUN",
        note=(
            "远程发车跑无记忆走迷宫(**仅 MOUSE_DATA_LOG 档**; 其余固件回 ERR_VALUE)。 "
            "固件只置请求位, 真正的 while(1) 迷宫由主循环执行 —— "
            "所以下达后命令通道与遥测都不会被阻塞"
        ),
    ),
    # ---- 课程调参实验(仅 MOUSE_LESSON_LAB 固件; 生产固件回 ERR_VALUE) ----
    "lesson.start": CommandSpec(
        "lesson.start", _lesson_start, ("exp", "a", "b", "c", "d"),
        note=(
            "启动课程实验并自带时间护栏。exp: 2=编码器测距 3=匀变速直行 "
            "5=陀螺标定 6=多传感器直行; 结束时固件上行 `LESSON DONE ...`"
        ),
    ),
    "lesson.stop": CommandSpec(
        "lesson.stop", lambda: "LESSON STOP", note="中止课程实验(停车并回 LESSON DONE ... STOP)",
    ),
    "lesson.status": CommandSpec(
        "lesson.status", lambda: "LESSON STATUS",
        note="回一行 `LESSON STATUS <exp> <running>` 异步状态",
    ),
}


def run(client: CommandClient, cmd: str, wait: bool = True, **kw: Any):
    """按名字执行一条登记在册的命令。返回 Pending。

    这是"逃生舱"之上的**唯一**命令执行入口 —— CLI、契约测试、子 API 都走它,
    所以登记表就是命令的全集。
    """
    spec = COMMANDS.get(cmd)
    if spec is None:
        raise KeyError(f"未登记的命令: {cmd!r} (可用的见 registry.COMMANDS)")
    line = spec.build(**kw)
    to = {}
    if spec.timeout is not None:
        to["timeout"] = spec.timeout
    return client.send(line, wait=wait, no_retry=spec.no_retry, **to)


def command_line(cmd: str, **kw: Any) -> str:
    """只拼命令文本, 不发送(供文档、日志、测试比对)。"""
    spec = COMMANDS[cmd]
    return spec.build(**kw)


def spec_of(cmd: str) -> CommandSpec:
    return COMMANDS[cmd]


def names(prefix: str = "") -> list:
    return sorted(n for n in COMMANDS if n.startswith(prefix))


# ---------------------------------------------------------------- 帧表

def _decode_map_auto(p: bytes) -> dict:
    """墙图帧的 mazetype 由载荷长度反推(墙图 + 访问图各 n² 字节)。

    固件不重复发 mazetype, 所以这里必须自己算 —— 做成统一签名后, FRAMES 的
    decoder 全部是 `Callable[[bytes], dict]`, 分派代码不必为某一种帧开特例。
    """
    n = int(((len(p) - 4) // 2) ** 0.5 + 0.5)
    return decode_map(p, n)


@dataclass(frozen=True)
class FrameSpec:
    """一种上行帧。

    sink  : `TelemetryStore` 上的累积方法名。帧分派**完全由表驱动** ——
            新增一种帧不需要改 link.py 一行代码。
    count : 计入 `Link.counts` 的键名(None = 该帧不单独计数)
    """

    type: int
    name: str
    decoder: Callable[[bytes], dict]
    stream: str
    sink: str
    count: "str | None" = None
    since: str = "1.0"


FRAMES: Dict[int, FrameSpec] = {
    TYPE_UNIFIED: FrameSpec(TYPE_UNIFIED, "UNIFIED", decode_unified, "unified", "push_unified", "unified"),
    TYPE_MAP: FrameSpec(TYPE_MAP, "MAP", _decode_map_auto, "map", "push_map", "map"),
}


def frame_spec(ftype: int) -> "FrameSpec | None":
    return FRAMES.get(ftype)


# ---------------------------------------------------------------- 静态断言

#: link.py 里出现这些即说明帧分派被硬编码了 —— 新增帧就会漏改, 由契约测试报红。
FRAME_DISPATCH_FORBIDDEN = (
    "decode_unified(",
    "decode_map(",
)


def check_frame_dispatch_is_table_driven(link_source: str) -> list:
    """检查 link.py 的帧分派是否走表。返回违规行说明列表(空 = 通过)。

    允许 `import` 行出现这些名字吗? 不允许 —— 改表之后 link.py 根本不需要导入它们。
    """
    bad = []
    for i, line in enumerate(link_source.splitlines(), 1):
        s = line.strip()
        if s.startswith("#") or s.startswith("//"):
            continue
        for pat in FRAME_DISPATCH_FORBIDDEN:
            if pat in line:
                bad.append(f"link.py:{i}: 出现 {pat.rstrip('(')} —— 帧分派应走 registry.FRAMES")
    return bad
