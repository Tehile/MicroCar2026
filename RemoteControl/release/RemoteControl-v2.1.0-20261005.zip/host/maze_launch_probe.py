"""例程 8（[4] 档无记忆走迷宫）**发车行为诊断** —— 定位"发车瞬间快速后退"。

先说结论性的设计前提（已由代码核查确认）:
  · v2.0/v2.1 的重构**只改过 `HARDWARE/link.c` 与 `link.h`**（本项目自己的链路模块）
    + 4 处纯注释。其余 59 个 .c/.h 与 v1.5.5 基线**剥离注释后逐字节相同**。
  · `MAZE RUN` 在固件里**只置一个请求标志**(`linkMazeReq = 1`)并回 ACK, **完全不碰速度/电机**。
  · `link.c` 里所有写 `speedSt.speedTarget*` 的地方都在 MOVE / CAL / SERVO / STOP / ESTOP
    这些**显式命令**路径上; 状态机初始值为 `LINK_MOVE_NONE == 0`(BSS 清零), 上电安全。
  所以"后退"不是"把原有程序改坏了"造成的。本脚本用来找出它到底来自哪一类原因。

三类嫌疑, 本脚本逐一给证据:
  A. **标定丢失** —— v1.5.4 把标定页从 99/100 搬到 115/116, 刷固件后**板上旧标定读不到**
     会回落到源码默认值(`TRACKL≈53.2015` 等)。里程/速度环系数不对 -> 自走行为异常。
     [查] 读 `GET ALL`, 与源码默认值逐项比对。
  B. **链路负载干扰控制周期** —— `LINK_Init` 把 USART1 RX 抢占优先级提到 0、
     SysTick 降到 1(这条 **v1.5.5 就有**, 但那时遥测默认静默、自走时链路几乎无流量)。
     v2.1 改成 PC 持续拉取后, RX 中断会**频繁抢占 1ms 控制循环**。
     [查] `--pull-load low`(发车后每 500ms 才拉一帧) 与 `high`(满速拉取) 两次对比。
  C. **本来就是这套自走逻辑的行为**(或硬件/机械) —— `LESSON_Blind8` 首状态是
     `MOTION_Acc()` + `MOTION_SetTrack(95)`, 且 START 状态会按**Flash 里的地图**
     判断发车位置(↙/↗)并可能转换坐标。地图数据不对也会导致发车方向异常。
     [查] 若 A、B 都排除, 基本就是这一类; 那就得对照 [5] 比赛固件的手动菜单自走。

⚠️ 安全: **本脚本默认只做只读检查, 绝不发车。**
   只有显式加 `--launch` 才会发 `MAZE RUN` —— 那会让电脑鼠**真的开始自走**。
   发车前请确认: 轮子悬空, 或场地足够大且没人在动线上。

用法:
    python maze_launch_probe.py COM7                      # 只读: 标定 + 标志位体检
    python maze_launch_probe.py COM7 --launch             # 发车, 低链路负载(默认)
    python maze_launch_probe.py COM7 --launch --pull-load high   # 发车, 满速拉取对照
"""

from __future__ import annotations

import argparse
import sys
import time

sys.path.insert(0, ".")

#: 会驱动电机的命令 —— 未经 --launch 一律拒绝
MOTOR_CMDS = ("MOVE", "MAZE RUN", "LESSON START", "CAL", "TARE", "ARM")

#: 固件源码里的生产参数默认值(见 ISR_Init / mouse_sim.PARAM_DEFAULTS)。
#: 读到的值与这些**完全相同** => 板上没有有效标定, 回落到了默认值。
SRC_DEFAULTS = {
    1: 62.59 * 0.85,   # TRACKL
    2: 62.68 * 0.85,   # TRACKR
    3: 62.59 * 0.85 / 100,  # SPEEDL (= TRACKL/100)
    4: 62.68 * 0.85 / 100,  # SPEEDR (= TRACKR/100)
}


def main() -> int:
    ap = argparse.ArgumentParser(prog="maze_launch_probe.py")
    ap.add_argument("port", nargs="?", default="COM7")
    ap.add_argument("--launch", action="store_true",
                    help="真的发 ARM + MAZE RUN(会让电脑鼠自走!)")
    ap.add_argument("--pull-load", choices=("low", "high"), default="low",
                    help="发车后的链路负载: low=每 500ms 一帧(默认), high=满速拉取")
    ap.add_argument("--watch-s", type=float, default=4.0, help="发车后观察秒数")
    args = ap.parse_args()

    from host.api import MouseClient

    print("=" * 78)
    print(f"例程8 发车行为诊断   端口={args.port}"
          f"{'  【会发车!】' if args.launch else '  (只读模式)'}")
    print("=" * 78)

    mc = MouseClient(auto_session=False, auto_stream=False)
    if not mc.connect(args.port):
        print("连接失败:", mc.state_detail)
        return 1

    # ---------------- 0) 设备体检 ----------------
    r = mc.send_cmd("ping", timeout=5.0)
    print(f"\n[0] 设备指纹  PING ok={r.ok}  device={mc.device}")
    proto = mc.device.get("proto")
    if proto != 3:
        print(f"    ⚠ 协议号 {proto} != 3 —— 板上可能不是 v2.1 固件"
              f"（v2.1 应为 PONG 3 210 7 256 <rst>）")
    print(f"    上次复位原因 = {mc.reset_cause}")

    # ---------------- A) 标定是否丢失 ----------------
    print("\n[A] 标定体检（关键）：读生产参数, 与源码默认值比对")
    vals = mc.params.get_all(refresh=True)
    if not vals:
        print("    !! 没读到参数（GET ALL 无应答？）")
    else:
        print(f"    {'名称':<12}{'板上值':>14}{'源码默认':>14}   判定")
        default_hits = 0
        for pid, name in ((1, "TRACKL"), (2, "TRACKR"), (3, "SPEEDL"), (4, "SPEEDR")):
            got = vals.get(name)
            if got is None:
                continue
            dflt = SRC_DEFAULTS.get(pid)
            same = dflt is not None and abs(got - dflt) < 1e-3
            if same:
                default_hits += 1
            print(f"    {name:<12}{got:>14.5f}{(dflt if dflt else 0):>14.5f}   "
                  f"{'**= 源码默认值**' if same else '已标定(与默认不同)'}")
        print(f"\n    另有全部 {len(vals)} 项生产参数已读出。")
        if default_hits >= 3:
            print("    >>> **强烈指向 [A] 标定丢失**：TRACKL/TRACKR/SPEEDL/SPEEDR 都等于源码默认值。")
            print("        v1.5.4 把标定页从 99/100 搬到 115/116，刷固件后板上旧标定读不到，")
            print("        会回落默认值（这是**预期行为**，不是 bug）。")
            print("        处理：连通上位机后重做一次标定并 `SAVE`（`mc.params.save()`），再试发车。")
        else:
            print("    >>> 标定看起来是有效值（未回落到默认）—— 嫌疑 [A] 排除。")

    # ---------------- 1) 发车前标志位 ----------------
    print("\n[1] 发车前状态（读 1 帧统一帧）")
    mc.stream.on()
    got = mc.telemetry.wait_first_frame(timeout=6.0)
    mc.stream.off()
    if not got:
        print("    !! 拉不到帧 —— 链路或固件有问题")
        mc.close()
        return 1
    f = mc.telemetry.latest()
    print(f"    freemode={f.get('freemode')}  irSwitch={f.get('irSwitch')}  "
          f"motionTask={f.get('motionTask')}  mazeTask={f.get('mazeTask')}  "
          f"wallThresh={f.get('wallThresh')}")
    print(f"    speedL={f.get('speedL')}  speedR={f.get('speedR')}  "
          f"battMv={f.get('battMv')}")
    if f.get("freemode"):
        print("    freemode=1 —— 与 [4] 档「未发车前电机输出恒 0」一致 ✓")
    else:
        print("    ⚠ freemode=0 —— 发车前电机就**没有被锁**，这不正常")

    # ---------------- 2) 发车（可选） ----------------
    if not args.launch:
        print("\n[2] 未指定 --launch —— 到此为止，不发车。")
        print("    要定位发车行为，请按下面两步各跑一次并对比：")
        print(f"      python maze_launch_probe.py {args.port} --launch --pull-load low")
        print(f"      python maze_launch_probe.py {args.port} --launch --pull-load high")
        mc.close()
        return 0

    print("\n[2] ⚠ 发车：ARM + MAZE RUN —— 电脑鼠将开始自走")
    print("    (3 秒后执行; 现在按 Ctrl-C 可以中止)")
    try:
        time.sleep(3)
    except KeyboardInterrupt:
        print("    已中止, 未发车。")
        mc.close()
        return 0

    ra = mc.send_cmd("arm", timeout=5.0)
    print(f"    ARM      -> ok={ra.ok} status={ra.status!r}")
    rm = mc.send_cmd("maze.run", timeout=5.0)
    print(f"    MAZE RUN -> ok={rm.ok} status={rm.status!r}")
    if not rm.ok:
        print("    !! 发车被拒（是否已在跑？档位不对？）")
        mc.close()
        return 1

    # ---------------- 3) 观察 ----------------
    load = args.pull_load
    hz = 2.0 if load == "low" else 0.0        # low: 2 Hz;  high: 交给拉取器全速
    print(f"\n[3] 观察 {args.watch_s:.0f}s  链路负载 = {load}"
          f"{'（每 500ms 一帧）' if load == 'low' else '（满速拉取，对照）'}")
    print(f"    {'t(s)':>6}{'speedL':>9}{'speedR':>9}{'pidErr':>9}{'gyro':>8}"
          f"{'task':>6}{'free':>6}   判读")
    print("    " + "-" * 72)

    t0 = time.time()
    if load == "high":
        mc.stream.on()
    last = 0.0
    bad_neg = 0
    n = 0
    while time.time() - t0 < args.watch_s:
        if load == "low":
            if time.time() - last < 0.5:
                time.sleep(0.05)
                continue
            last = time.time()
            mc.send_cmd("telem", timeout=5.0)
        f = mc.telemetry.latest()
        if not f:
            time.sleep(0.1)
            continue
        n += 1
        sl = float(f.get("speedL", 0) or 0)
        sr = float(f.get("speedR", 0) or 0)
        note = ""
        if sl < -3 or sr < -3:
            bad_neg += 1
            note = "**轮速为负(后退方向)**"
        print(f"    {time.time()-t0:>6.2f}{sl:>9.1f}{sr:>9.1f}"
              f"{float(f.get('pidErr', 0) or 0):>9.1f}"
              f"{float(f.get('gyroAngle', 0) or 0):>8.1f}"
              f"{int(f.get('motionTask', 0) or 0):>6}"
              f"{int(bool(f.get('freemode'))):>6}   {note}")
        time.sleep(0.05)

    if load == "high":
        mc.stream.off()

    print("    " + "-" * 72)
    print(f"\n    共 {n} 个样点, 其中「轮速为负」{bad_neg} 个")
    print("\n    判读指引：")
    print("      · freemode 发车后应为 0。若一直是 1 -> 有东西把电机锁着,")
    print("        查是否误发了 STOP/ESTOP（link_StopMotion 会置 freemode=1）。")
    print("      · speedL/speedR 明显为负 -> 目标速度就是负的, 指向标定/地图数据（嫌疑 A/C）。")
    print("      · speedL 与 speedR **符号相反且幅值相近** -> 那是原地转（MOVE ROT 风格）。")
    print("      · `--pull-load low` 与 `high` 表现不同 -> 指向链路负载干扰控制周期（嫌疑 B）:")
    print("        可临时把 `LINK_Init` 里 `SCB->SHP[11] = 0x40` 改回 0x00（SysTick 恢复最高抢占）")
    print("        再烧录验证 ---- 代价是 USART1 可能丢字节（那是它当初被改的原因）。")

    mc.close()
    print("\n" + "=" * 78)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
