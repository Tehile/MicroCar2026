"""门面(MouseClient)冒烟测试 —— P1 验收基线。

验证 N1–N4 与功能组 A–J:
    N1 headless:  import host.api 不引入 Qt
    N2 线程安全:  多线程并发调用不异常、不死锁
    N3 push/pull:  on() 订阅回调 与 events_queue() 拉取 双模式
    N4 可阻塞:    wait() / wait_event() / 各 wait=True 方法

v2.0(2026-10-05): `SNAP`/`SCOPE`/`RATE`/`DUMP` 已随协议精简删除 ——
    · "三帧(fast/mid/slow)" 改为单路统一帧(`telemetry.latest()` 返回单个 dict);
    · "1kHz 波形回传" 改为直接从统一帧环形缓冲取(`telemetry.history_dict()`);
    · `RATE` 删除, 改为验证自时钟(无需调档)与时间锚;
    · `calib.gyro()` 的零偏不再回读(写入 Flash, 非参数), 原断言已删。

用法:
    python facade_smoke.py               # 自动拉起模拟器
    python facade_smoke.py --port 5556   # 连已运行的模拟器
"""

from __future__ import annotations

import argparse
import socket
import subprocess
import sys
import threading
import time

PASS = 0
FAIL = 0


def check(name: str, cond: bool, detail: str = "") -> None:
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"  [OK]   {name}")
    else:
        FAIL += 1
        print(f"  [FAIL] {name}  {detail}")


def _free_port() -> int:
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    return port


def test_n1_headless() -> None:
    print("\n[N1] headless(不 import Qt)")
    import host.api  # noqa: F401

    qt = [m for m in sys.modules if "PySide" in m or "pyqtgraph" in m]
    check("import host.api 后无 PySide6/pyqtgraph", not qt, str(qt))


def _run_impl(port: int) -> None:
    from host.api import Event, MouseClient

    # ------------------------------------------------------------ 连接(A)
    print("\n[A] 连接管理 + 遥测(B)")
    with MouseClient.connect_to(f"tcp://127.0.0.1:{port}") as mc:
        check("连接成功(is_connected)", mc.is_connected, mc.state_detail)
        check("设备自述 mazetype==7", mc.device.get("mazetype") == 7, str(mc.device))
        check("设备自述含 proto", "proto" in mc.device, str(mc.device))

        check("等待首帧(N4)", mc.telemetry.wait_first_frame(timeout=5.0))
        f = mc.telemetry.latest()
        check("统一帧有数据", bool(f), str(f))
        check("统一帧含左右轮速", "speedL" in f and "speedR" in f, str(f))

        # ------------------------------------------------------------ 事件(N3 push)
        print("\n[N3] 事件 push/pull")
        seen: list = []
        off = mc.on(Event.TELEMETRY, lambda m: seen.append(m))
        q = mc.events_queue()
        mc.wait(lambda: len(seen) > 0, timeout=3.0)
        check("on() 订阅回调收到 TELEMETRY", len(seen) > 0)
        off()
        time.sleep(0.3)
        # pull 模式: 队列里应已积累事件
        try:
            q.get_nowait()
            pulled = True
        except Exception:
            pulled = False
        check("events_queue() 拉取到事件", pulled)

        # ------------------------------------------------------------ 参数(E/D)
        print("\n[E] 参数 + [D] 可靠传输(回读校验)")
        got = mc.params.get_all()
        # 7 项生产标定 + 17 项红外/电源 = 24 项生产参数。v2.0 起固件 `GET ALL` **只遍历
        # 生产命名空间**(与 linkParam[] 一致); 课程 14 项在独立表里, 读侧读不回。
        check("GET ALL 回读 24 项生产参数", len(got) == 24, str(len(got)))
        check("生产命名空间 24 项齐备", set(mc.params.production_names()) <= set(got),
              str(sorted(set(mc.params.production_names()) - set(got))))
        r = mc.params.set("TRACKL", 53.2015)
        check("set() ACK+回读校验通过", r.ok, r.status)
        check("回读值一致", abs(mc.params.get("TRACKL") - 53.2015) < 1e-4,
              str(mc.params.get("TRACKL")))
        # 派生: speedRatio = trackRatio / 100
        rs = mc.params.set_many({"TRACKL": 53.2, "TRACKR": 53.2}, derive_speed=True)
        check("set_many+derive_speed 两项成功", all(x.ok for x in rs), str([x.status for x in rs]))
        check("SPEEDL 已派生为 TRACKL/100", abs(mc.params.get("SPEEDL") - 0.532) < 1e-3,
              str(mc.params.get("SPEEDL")))
        bad = mc.params.set("NOPE", 1.0)
        check("非法参数名返回 ERR_NAME", not bad.ok and bad.status == "ERR_NAME", bad.status)

        # ------------------------------------------------------------ 流控
        print("\n[C] 遥测拉取(stream)")
        r = mc.stream.on()
        check("stream.on -> OK", r.ok, r.status)
        # v2.1: 遥测是**拉取式**的 —— stream.on() 启动本机循环请求 TELEM,
        # 每条应答都带**完整 u32 时基**(时间锚), 供逐帧同余还原。
        check("stream.on 建立时间锚", mc.stream.anchor() is not None, str(mc.stream.anchor()))
        check("按'最近有帧'判定流已开启", mc.stream.is_on, str(mc.stream.is_on))

        # ------------------------------------------------------------ 标定(F)
        print("\n[F] 标定(阻塞式)")
        r = mc.calib.gyro()
        check("calib.gyro() 完成(请求-响应: ACK 即已落盘)", r.ok, r.status)
        # v2.0 起零偏写在 FLASH_ADDR_GYRO0(**不是参数**), 没有回读 —— 原
        # "gyro 有零偏值" 断言失去目标, 统一帧里也没有该量, 故删除。

        r = mc.calib.wall_distance()
        check("calib.wall_distance() 完成", r.ok, r.status)

        # IRDATA 逐点: 4 个摆位各发一条 `CAL IRDATA <i>`, 固件采完才回 ACK。
        # (v1.5.5 靠 `CALDONE`/`CALSTEP` 事件行, 那些行会被 TX 空间门静默丢弃。)
        r = mc.calib.ir_data()
        check("calib.ir_data() 采满 4 点", r.ok and r.data.get("points") == 4, str(r.data))
        check("ir_data 未降级回退(无 note 告警)", "note" not in r.data, str(r.data))

        # ------------------------------------------------------------ 动作 + 运动波形(G)
        print("\n[G] 动作 + 统一帧运动波形(≈217Hz 自时钟)")
        import numpy as np

        r = mc.move.forward(pulses=20000, speed=40)
        check("move.forward 回报 STOPPED", r.ok, f"{r.status} {r.data}")
        check("forward 带回停止原因", r.data.get("reason") is not None, str(r.data))
        # v2.0: 运动结束只剩 `STOPPED <reason> #n` 一条事件行; 波形不再靠 SCOPE
        # "停车后整块回传", 而是直接从统一帧环形缓冲取 —— 运动期间本就全速在流。
        h = mc.telemetry.history_dict()
        t_ms = h.get("t", [])
        check("统一帧历史非空", len(t_ms) > 0, str(len(t_ms)))
        nonzero = int((np.asarray(h.get("speedL", [])) != 0).sum())
        check("波形含非零轮速", nonzero > 0, f"nonzero={nonzero}")

        # ------------------------------------------------------------ 迷宫(H)
        print("\n[H] 迷宫")
        m = mc.maze.fetch(timeout=10.0)
        check("maze.fetch 返回墙图", bool(m), str(type(m).__name__))
        if m:
            check("墙图 7x7", m.get("mazetype") == 7 and len(m["mapWall"]) == 7, str(m.get("mazetype")))
            check("position 返回坐标", mc.maze.position() is not None, str(mc.maze.position()))

        # ------------------------------------------------------------ 分析(J)
        print("\n[J] 离线分析")
        # ⚠️ 单位约定: `analyze` 的分段阈值按**毫秒**轴设计(见
        # `analysis/metrics.segment_by_task` 的 duration_ms>=5 过滤), 而
        # `telemetry.history_dict()["t"]` 是宿主的 **epoch 秒**轴 —— 故这里把
        # 时间轴换算成"相对毫秒"再喂给它, 否则几秒的会话会被整段过滤掉。
        h_an = dict(h)
        h_an["t"] = (np.asarray(h["t"]) - h["t"][0]) * 1000.0
        segs = mc.analyze.summary(h_an)
        check("analyze.summary 产出动作段", len(segs) > 0, str(len(segs)))
        check("explain() 返回人可读文本", bool(mc.analyze.explain(h_an)), mc.analyze.explain(h_an))

        # ------------------------------------------------------------ 会话(I)
        print("\n[I] 会话记录")
        check("会话已自动开启", mc.session.is_open)
        mc.session.note("门面冒烟测试")
        c = mc.session.counts()
        check("会话计数含 unified", c.get("unified", 0) > 0, str(c))

        # ------------------------------------------------------------ N2 线程安全
        print("\n[N2] 线程安全(并发调用)")
        errors: list = []

        def worker(i: int) -> None:
            try:
                for _ in range(20):
                    mc.telemetry.latest()
                    mc.params.snapshot()
                    mc.stats()
                if i == 0:
                    mc.params.set("WALLDIST", 42.0, readback=False)
            except Exception as e:  # pragma: no cover
                errors.append(f"{type(e).__name__}: {e}")

        ths = [threading.Thread(target=worker, args=(i,)) for i in range(3)]
        for t in ths:
            t.start()
        for t in ths:
            t.join()
        check("3 线程并发调用无异常", not errors, str(errors))

        check("断开前状态可读(state_detail)", isinstance(mc.state_detail, str))
    # with 退出自动断开 + 收会话


def main() -> int:
    ap = argparse.ArgumentParser(description="MouseClient 门面冒烟测试")
    ap.add_argument("--port", type=int, default=0, help="已运行模拟器的端口(默认自动拉起)")
    args = ap.parse_args()

    print("=" * 66)
    print("电脑鼠上位机 门面冒烟测试")
    print("=" * 66)
    test_n1_headless()

    port = args.port or _free_port()
    proc = None
    if not args.port:
        proc = subprocess.Popen(
            [sys.executable, "-m", "host.sim.mouse_sim", "--port", str(port), "--no-auto"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        time.sleep(1.2)

    try:
        _run_impl(port)
    finally:
        if proc is not None:
            proc.terminate()
            try:
                proc.wait(timeout=3)
            except subprocess.TimeoutExpired:
                proc.kill()

    print("\n" + "=" * 66)
    print(f"通过 {PASS} / 失败 {FAIL}")
    print("=" * 66)
    return 1 if FAIL else 0


if __name__ == "__main__":
    sys.exit(main())
