"""拉取模式(v2.1)冒烟测试 —— 验证 `TELEM` 请求-响应链路与**停等**不变量。

为什么单独一个文件: v2.1 把遥测从"固件自时钟持续流"换成了"PC 循环拉取",
这条链路的正确性(是否会 burst、锚是否刷新、停止后是否真的不再收帧)
是旧套件完全没覆盖的, 而它正是真机上出过事故的地方。

核心不变量(真机实测得出): **任何时刻最多 1 条 `TELEM` 在途**。
固件每 1ms tick 只消费一行命令, 一次发两条会丢第二条(实测回收率 N=2 仅 50%)。

用法(在 host/ 目录下):
    python pull_smoke.py
"""

from __future__ import annotations

import socket
import subprocess
import sys
import time
from typing import List

PASS = 0
FAIL = 0
FAILED: List[str] = []


def check(name: str, cond: bool, detail: str = "") -> None:
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"  [OK] {name}")
    else:
        FAIL += 1
        FAILED.append(name)
        print(f"  [FAIL] {name}" + (f"  <- {detail}" if detail else ""))


def _free_port() -> int:
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    p = s.getsockname()[1]
    s.close()
    return p


class _Sim:
    def __init__(self, *extra: str) -> None:
        self.port = _free_port()
        self.cmd = [sys.executable, "-m", "host.sim.mouse_sim",
                    "--port", str(self.port), "--no-auto", *extra]
        self.proc: subprocess.Popen | None = None

    @property
    def target(self) -> str:
        return f"tcp://127.0.0.1:{self.port}"

    def __enter__(self) -> "_Sim":
        self.proc = subprocess.Popen(self.cmd, stdout=subprocess.DEVNULL,
                                     stderr=subprocess.DEVNULL)
        time.sleep(1.2)
        return self

    def __exit__(self, *exc) -> None:
        if self.proc is not None:
            self.proc.terminate()
            try:
                self.proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self.proc.kill()


def main() -> int:
    from host.api import MouseClient
    from host.registry import COMMANDS

    print("=" * 66)
    print("拉取模式(v2.1) 冒烟测试")
    print("=" * 66)

    # ---------------------------------------------------------------- 静态
    print("\n[P0] 命令集: TELEM 在, STREAM 不在")
    check("TELEM 已登记", "telem" in COMMANDS)
    check("STREAM ON 已删除", "stream.on" not in COMMANDS and "stream.off" not in COMMANDS)
    check("TELEM 标为不重发", COMMANDS["telem"].no_retry is True)
    check("TELEM 命令文本 = TELEM", COMMANDS["telem"].build() == "TELEM")

    with _Sim("--safe") as sim:
        # ------------------------------------------------------------ 拉取
        print("\n[P1] 连接即开始拉取(auto_stream), 并收到统一帧")
        mc = MouseClient(auto_session=False, auto_stream=True)
        if not mc.connect(sim.target):
            check("连接模拟器", False, mc.state_detail)
            return 1
        check("连接成功", mc.is_connected)
        check("拉取器已在跑", mc.stream.is_on is True)
        got = mc.telemetry.wait_first_frame(timeout=6.0)
        check("等到首帧", got, f"hz={mc.telemetry.hz():.2f}")
        f = mc.telemetry.latest()
        check("帧字段齐全(39 通道)", len(f) >= 30, f"got {len(f)}")

        print("\n[P2] 时间锚由 TELEM 应答建立")
        a = mc.stream.anchor()
        check("锚已建立", a is not None, str(a))
        if a is not None:
            check("锚的设备时基 > 0", a[1] > 0, str(a))

        print("\n[P3] 持续拉取 3 s: 帧数递增, 严格停等(在途恒 <= 1)")
        n0 = mc.stats().get("unified", 0)
        time.sleep(3.0)
        n1 = mc.stats().get("unified", 0)
        st = mc.stream.stats()
        print(f"     3s 收到 {n1-n0} 帧 | 拉取器 = {st}")
        check("持续有帧", (n1 - n0) > 3, f"{n1-n0} 帧")
        check("模式为 stop-and-wait", st.get("mode") == "stop-and-wait", str(st))
        # ⚠️ 这一条是 v2.1 真机实测后的核心不变量: 固件每 1ms 只消费一行命令,
        # 一次发两条就会丢第二条(回收率 N=2 时仅 50%)。所以任何时刻最多 1 条在途。
        check("在途恒不超过 1 条(绝不 burst)", st["inflight"] <= 1, str(st))
        check("丢帧很少", st["lost"] * 4 <= max(1, st["sent"]), str(st))

        print("\n[P4] 命令通道在拉取期间照常可用")
        r = mc.send_cmd("ping", timeout=3.0)
        check("PING 仍 OK", r.ok, r.status)
        check("设备指纹 proto=3", mc.device.get("proto") == 3, str(mc.device))

        print("\n[P5] 停流后必须**彻底不再收帧**(这是蓝牙缓冲排空的前提)")
        mc.stream.off()
        check("拉取器已停", mc.stream.is_on is False)
        time.sleep(0.6)          # 让在途的最后一帧落地
        n2 = mc.stats().get("unified", 0)
        time.sleep(1.5)          # 静默期
        n3 = mc.stats().get("unified", 0)
        check("停流后不再有帧到达", n3 == n2, f"{n2} -> {n3}")

        print("\n[P6] 再开流能恢复")
        mc.stream.on()
        got = mc.telemetry.wait_first_frame(timeout=6.0)
        time.sleep(0.5)
        n4 = mc.stats().get("unified", 0)
        check("重开后恢复收帧", n4 > n3, f"{n3} -> {n4}")

        print("\n[P7] 断开时自动停拉取")
        mc.close()
        check("close 后拉取器已停", mc.stream.is_on is False)

    # ---------------------------------------------------------------- 反例
    print("\n[P8] 反例: auto_stream=False 时不该有任何帧")
    with _Sim("--safe") as sim:
        mc = MouseClient(auto_session=False, auto_stream=False)
        mc.connect(sim.target)
        check("拉取器未启动", mc.stream.is_on is False)
        time.sleep(1.5)
        check("确实没收到帧(设备只在被请求时才发)", mc.stats().get("unified", 0) == 0,
              str(mc.stats().get("unified", 0)))
        # 手动拉一帧应立刻有
        mc.stream.on()
        check("手动开流后收到帧", mc.telemetry.wait_first_frame(timeout=6.0))
        mc.close()

    print("\n" + "=" * 66)
    print(f"通过 {PASS} / 失败 {FAIL}")
    if FAILED:
        print("失败项:", FAILED)
    print("=" * 66)
    return 1 if FAIL else 0


if __name__ == "__main__":
    sys.exit(main())
