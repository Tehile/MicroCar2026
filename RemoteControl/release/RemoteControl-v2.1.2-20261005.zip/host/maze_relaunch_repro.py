"""复现：例程8「发车 → 停止 → 再次发车」被拒（ERR_BUSY）。

## 现象（用户报告）
发车跑起来后停止，再发 `MAZE RUN` 会回 `ERR_BUSY`，**只能断电**。

## 待验证的假设链
1. 发车后程序会**停在探索中途**（速度归 0、坐标不再变化）。
2. 此时 `MAZE STOP` / `STOP` **回 OK 但不起作用** —— 因为 `LESSON_Blind8()` 的
   "退出迷宫"检查在 `while(1)` **顶部**, 而程序卡在 `switch` **内部**的函数里
   （`STATE_MazeSearch()` → `EXPLORE_CrosswayChoice()` → `FLOODFILL_Open()` 的
   扩散 `while (n)`）, 轮不到那次检查。
3. 于是 `linkMazeRun` 永远停在 1 ⇒ 之后每次 `MAZE RUN` 都 `ERR_BUSY`。
4. 但**运动状态机是空闲的**（卡的是纯计算, 不是运动）⇒ 短时 `MOVE RUN` 应回 `OK`。
   这是"卡在计算"与"卡在运动"的判别点。

## 顺带查一件事：为什么设备没被看门狗复位
IWDG 的喂狗在 `link.c` 的 `LINK_Tick()` 里, 而 `LINK_Tick()` 由 **SysTick 中断**调用
⇒ **主循环死循环不会触发看门狗**(中断照常喂狗)。用 `PING` 的 `rst` 字段验证:
若卡住期间发生 IWDG 复位, `rst` 会从 `POR` 变成 `IWDG`。

## 安全
- 会让电脑鼠自走（这就是要复现的）。**请把它放在迷宫/空旷处并留出空间。**
- `MOVE RUN` 探针极短(200 ms, ±15)且预期**被拒**, 不会真跑。
- 全程可 Ctrl-C；脚本结束会尽量收车。

用法:
    python maze_relaunch_repro.py COM7
    python maze_relaunch_repro.py COM7 --stuck-s 12   # 判定"卡住"所需的静止秒数
"""
from __future__ import annotations

import argparse
import sys
import time

sys.path.insert(0, ".")


def snap(mc):
    f = mc.telemetry.latest()
    if not f:
        return None
    return {
        "task": f.get("mazeTaskName"),
        "motion": f.get("motionTaskName"),
        "pos": (f.get("posX"), f.get("posY")),
        "dir": f.get("dir"),
        "spd": (f.get("speedL"), f.get("speedR")),
        "free": f.get("freemode"),
        "emerg": f.get("emerg"),
        "lock": f.get("estop_lock"),
        "stack": f.get("stackIdx"),
    }


def fmt(s):
    if not s:
        return "(无帧)"
    return (f"task={s['task']:<9} motion={s['motion']:<18} pos={s['pos']} dir={s['dir']} "
            f"spd={s['spd']} free={s['free']} emerg={s['emerg']} stack={s['stack']}")


def main() -> int:
    ap = argparse.ArgumentParser(prog="maze_relaunch_repro.py")
    ap.add_argument("port", nargs="?", default="COM7")
    ap.add_argument("--stuck-s", type=float, default=12.0,
                    help="坐标与速度持续不变的秒数达到该值即判为『卡住』")
    ap.add_argument("--max-s", type=float, default=45.0, help="观察上限(秒)")
    args = ap.parse_args()

    from host.api import MouseClient

    print("=" * 78)
    print(f"例程8「停止后无法再次发车」复现   端口={args.port}")
    print("=" * 78)

    mc = MouseClient(auto_session=False, auto_stream=False)
    if not mc.connect(args.port):
        print("连接失败:", mc.state_detail)
        return 1

    results: list[tuple[str, str]] = []

    def rec(name, value, expect=""):
        results.append((name, value))
        flag = ""
        if expect:
            flag = "   <= 预期 " + expect
        print(f"  {name:34s} = {value}{flag}")

    try:
        mc.stream.on()
        mc.telemetry.wait_first_frame(timeout=6.0)

        r = mc.send_cmd("ping", timeout=5)
        print(f"\n[0] 起始状态  fw={mc.device.get('fw')}  rst={mc.device.get('rst')}")
        print(f"    {fmt(snap(mc))}")

        # 先要求空闲(否则本脚本的前提不成立)
        s0 = snap(mc)
        if s0 and s0["task"] != "WAIT":
            print(f"\n    ⚠ 设备当前不在 WAIT(={s0['task']})，说明它还停在上一次发车里。")
            print("       本脚本需要一台**已断电重启**的设备才能干净复现。")
            print("       先试一次 MAZE RUN，看是否已经是 ERR_BUSY（那本身就是复现）：")
            rr = mc.send_cmd("maze.run", timeout=6)
            rec("MAZE RUN(残留状态)", rr.status, "ERR_BUSY = 已复现")
            if rr.ok:
                print("       （居然 OK，说明状态是干净的，继续正常流程）")
            else:
                print("\n       若想完整复现，请给设备断电重启后再跑本脚本。")
                return 0

        # ---------------- 1) 发车 ----------------
        print("\n[1] 发车 ARM + MAZE RUN")
        print("    5 秒后发车；现在 Ctrl-C 可中止")
        try:
            time.sleep(5)
        except KeyboardInterrupt:
            print("    已中止。")
            return 0
        mc.send_cmd("arm", timeout=5)
        rr = mc.send_cmd("maze.run", timeout=6)
        rec("MAZE RUN #1", rr.status, "OK")
        if not rr.ok:
            print("    发车被拒，无法继续。")
            return 1

        # ---------------- 2) 观察，直到判定卡住 ----------------
        print(f"\n[2] 观察（{args.max_s:.0f}s 上限；坐标+速度连续 "
              f"{args.stuck_s:.0f}s 不变即判定卡住）")
        t0 = time.time()
        last_change = t0
        prev = None
        stuck_at = None
        trail: list[str] = []
        while time.time() - t0 < args.max_s:
            s = snap(mc)
            if s:
                key = (s["pos"], s["spd"], s["task"])
                if key != prev:
                    prev = key
                    last_change = time.time()
                    el = time.time() - t0
                    print(f"    t={el:5.1f}s  task={s['task']:<9} motion={s['motion']:<18} "
                          f"pos={s['pos']} spd={s['spd']} stack={s['stack']}")
                    if s["task"] not in trail:
                        trail.append(s["task"])
                elif time.time() - last_change >= args.stuck_s:
                    stuck_at = time.time() - t0
                    break
            time.sleep(0.05)

        s_now = snap(mc)
        rec("mazeTask 迁移序列", " → ".join(trail))
        if stuck_at is None:
            rec("是否卡住", f"否（{args.max_s:.0f}s 内一直在变）")
            print("    没有复现到『卡住』。")
            return 0
        rec("卡住时刻(t≈)", f"{stuck_at:.0f}s（之后 {args.stuck_s:.0f}s 无任何变化）")
        rec("卡住时状态", fmt(s_now))
        rec("卡住时 speed", str(s_now["spd"]), "0 —— 车已停")
        rec("卡住时 motionTask", str(s_now["motion"]), "NULL —— 不是在跑运动")

        # ---------------- 3) 停止命令有效吗 ----------------
        print("\n[3] 发停止命令（关键：能否把程序带出迷宫？）")
        for cmd in ("estop.clear", "maze.stop"):
            r = mc.send_cmd(cmd, timeout=6)
            time.sleep(0.6)
            s_after = snap(mc)
            rec(f"{cmd} 应答", r.status)
            rec(f"{cmd} 之后的 mazeTask", str(s_after["task"]),
                "WAIT = 有效 / 仍 SEARCH = 无效")
        s_after = snap(mc)
        stopped_ok = s_after["task"] == "WAIT"
        rec("停止命令是否真的收车", "是" if stopped_ok else "**否**")

        # ---------------- 4) 再次发车 ----------------
        print("\n[4] 再次发车")
        r2 = mc.send_cmd("maze.run", timeout=6)
        rec("MAZE RUN #2", r2.status, "ERR_BUSY = 复现成功")

        # ---------------- 5) 判别：卡在计算 还是 卡在运动 ----------------
        print("\n[5] 判别：卡在纯计算 还是 卡在运动？")
        r3 = mc.send_cmd("move.run", sp_l=15, sp_r=15, ms=200, ir_mm=-1, timeout=6)
        rec("MOVE RUN 探针(200ms)", r3.status,
            "OK = 运动状态机空闲 ⇒ 卡在纯计算")
        if r3.ok:
            time.sleep(0.5)
            mc.send_cmd("stop", timeout=6)

        # ---------------- 6) 看门狗有没有介入 ----------------
        print("\n[6] 看门狗：卡住期间是否发生过 IWDG 复位？")
        rp = mc.send_cmd("ping", timeout=5)
        rst = mc.device.get("rst")
        rec("PING rst", str(rst), "POR = 没被看门狗复位")
        print("      注: IWDG 的喂狗在 link.c 的 LINK_Tick() 里, 而 LINK_Tick 由")
        print("          **SysTick 中断**调用 ⇒ 主循环死循环**不会**触发看门狗。")

        # ---------------- 7) 后台是否还在推进 ----------------
        print("\n[7] 卡住期间链路与传感器是否正常")
        n0 = mc.stats().get("unified", 0)
        time.sleep(1.5)
        n1 = mc.stats().get("unified", 0)
        rec("1.5s 内收到帧数", str(n1 - n0), ">0 = 链路正常")
        s_end = snap(mc)
        rec("再次确认 mazeTask", str(s_end["task"]))
        rec("再次确认 speed", str(s_end["spd"]))

        # ---------------- 结论 ----------------
        print("\n" + "=" * 78)
        print("结论")
        print("=" * 78)
        for k, v in results:
            print(f"    {k:34s} {v}")
        print()
        busy = any("ERR_BUSY" in v for k, v in results if "MAZE RUN #2" in k)
        calc = any("OK" == v for k, v in results if "MOVE RUN" in k)
        if busy and not stopped_ok:
            print("    >>> **复现成功**：停止命令回 OK 却不起作用，程序卡在探索内部的")
            print("        纯计算里（`FLOODFILL_Open` 的扩散循环未返回），")
            print("        `LESSON_Blind8()` 顶部的『退出迷宫』检查轮不到；")
            print("        `linkMazeRun` 停在 1 ⇒ `MAZE RUN` 永久 `ERR_BUSY`。")
            if calc:
                print("        MOVE RUN 回 OK 进一步证明**运动状态机是空闲的**，")
                print("        卡住的不是运动，而是探路计算。")
            print("        期间链路正常、看门狗不介入 ⇒ **只能断电恢复**。")
        return 0
    finally:
        try:
            mc.send_cmd("stop", timeout=4)
        except Exception:
            pass
        try:
            mc.stream.off()
            mc.close()
        except Exception:
            pass
        print("\n（脚本已退出；若设备仍在迷宫中，断电重启即可恢复）")


if __name__ == "__main__":
    raise SystemExit(main())
