# RemoteControl 长期备忘（电脑鼠蓝牙上位机）

> 过程细节见 `.workbuddy/memory/YYYY-MM-DD.md`；协议细节见 `docs/传输模式接口设计.md` + `传输模式重构设计方案.md`。**项目不是 git 仓库。**

## 构建 / 环境
- 固件 `code_stm32f1_mouse/`：STM32F103RB、Keil MDK V5.06 / ARMCC V5、**C90**、-O0、OneElfS=1。`HARDWARE/link.c|h` = 链路模块，不动业务逻辑与红线数值。
- `host/` 上位机；`Control/` 是**工作区外的兄弟前端项目**；`release/` 归档。
- 编译 `"/c/Keil_v5/UV4/UV4.exe" -b "<绝对路径>\USER\Mouse.uvprojx" -o "<绝对日志>"`（必须绝对路径；exit=1 可能仅告警）；五档批量重编 = 仓库根 `build_all_modes.py`。符号 = `fromelf.exe --text -s USER/Object/Mouse.axf`。
- Python 用 `C:/ProgramData/anaconda3/python.exe`（有 numpy+pyserial）；测试在 `host/` 跑；PySide6 未装。
- ⚠️ 改 `link.c` 防**注释提前闭合**（`doTask*/LESSON_ISR`），踩过两次；`contract_test [S5]` 有扫描断言。

## 链路
USART1(PA9/PA10)↔蓝牙透传↔CH340→COM7；115200-8-N-1 无流控；不做配对。
上行 `AA55|LEN(2,LE)|TYPE|SEQ|PAYLOAD|CRC16-MODBUS`（开销 8B）；下行 ASCII `<CMD> [args] [#seq] *CRC16`；参数 Q16.16。
⚠️ v2.1 起固件**默认静默且只在被 `TELEM` 请求时才发**（v2.0 的"须 `STREAM ON` 才开流"已废除）。
⚠️ 真机稳态往返 **≈1.21 s** → `TIMEOUT_S=2.5`（旧记录 230ms/0.50 已作废）；偶发行位错回 `ACK -1 ERR_CRC`（幂等重发自愈）。

## 链路容量（**真机实测，v2.1 的立命之本**）
- 这条链路 = USART1(PA9/PA10) ↔ **蓝牙透传** ↔ CH340 → COM7；115200-8-N-1 无流控。
- ⚠️ **实测承载只有约 100~200 B/s**，单条命令往返 **≈1.21 s**（不是早期记录的 230 ms）。
- ⚠️ **蓝牙模块内部缓冲一旦被灌满就停止转发且不自恢复**（必须重新上电）。这条约束
  **v1.5.5 就写在 `link.c` 里**（因此把常驻压到 152 B/s）；v2.0 重写时把它删了，于是出事。
- 事故表现（v2.0）：`PING`/`ARM`/`GET ALL`/`MAP DUMP` 等**小突发全正常**，但一收
  `STREAM ON` 就 **0 字节**，之后连 `PING` 都不应答，**只有断电才恢复**。
  已逐项排除：应答函数坏（`ARM` 同函数正常）、TX 环/DMA 坏（`MAP DUMP` 120B 正常）、
  MCU 卡死（IWDG 在跑，若卡死 2s 内必复位）、端口掉线（COM7 始终在）。
- **推论（用户提出并被采纳为设计前提）**：之前"永久失联"其实只是**缓冲一直是满的** ——
  电脑鼠一直在发。改为 PC 拉取后，停止请求 → 设备停发 → 缓冲排空 → **无需断电即自愈**。

## v2.1 传输（拉取模式；**真机已验证 2026-10-05**）／v2.1.1（发车状态复位）
> **本节取代 v2.0 的自时钟描述。** 三原则：① 上行=应答帧+异常事件；② 下行一律请求-响应；③ 上位机能算的不传。
- **`TELEM` 请求-响应**：`PC -> TELEM`，设备回 **一帧统一帧(53B) + `ACK <seq> OK <upMs>`**。
  命令 23→**22**（删 `STREAM ON/OFF`，加 `telem`）、**v2.1.1 再加 `MAZE STOP` → 23**；帧仍 2 种（`UNIFIED` 0x0A、`MAP`）。
  统一帧 payload 45B、`UNIFIED_CHANNELS` 展平 39 通道。
- ⚠️ **必须严格停等（在途恒 <=1），不是滑动窗口！** 固件**每 1ms tick 只消费一行命令**
  （`link.c`: `if (USART_RX_STA & 0x80) {...}`；bit7 未清时 `usart.c` 直接丢弃后续字节）。
  真机实测"背靠背发 N 条 `TELEM`"回收率：N=1→**100%**，N=2→50%，N=3→33%，N=4→25%，N=8→12%；
  **间隔 300ms 逐条→100%**。窗口扫描：窗口 1 = 6.50 Hz（=1/RTT，已满速）、窗口 4 = 7.15 Hz（只多 10% 却开始丢）。
  → 最初的 AIMD 滑动窗口(1→16)是**错误设计**，已删除。
- **可达帧率 = 1/RTT ≈ 4.4~6.5 Hz**（RTT 实测 143~527 ms 波动；停等 12s 得 4.41 Hz ≈234 B/s 载荷，丢 0、bad_crc 0）。
- ⚠️ **提高串口波特率不会提高帧率**：RTT≈224ms 中一帧 53B@115200 只占 4.6ms，
  其余全是**蓝牙模块转发延迟**。要提速得换掉蓝牙透传。设计稿 §13.2 原判断已划掉标注证伪。
- **停发自愈**（用户假设，已证实）：PC 停请求 → 固件停发 → 缓冲自然排空 → **无需断电即恢复**。
- **时间锚**：由 `TELEM` 应答携带，每次拉取都刷新（失锁即自愈）。
- ⚠️ **`TELEM` 必须绕开幂等重放簿记**（在 `link_HandleLine` 里提前拦截，既不查也不写
  `linkLastSeq/linkLastCrc`）。否则持续流量会把"待重放的真实命令"冲掉 → `MOVE`/`CAL`
  的 ACK 丢失后重发会**重新执行**而非重放。这是本轮抓到的真 bug。
- ⚠️ **`TIMEOUT_S` 0.50 → 2.5**（实测往返 >1 s；旧值必然误判超时并误重发）。
- ⚠️ **发车状态必须可复位（v2.1.1 真机缺陷，已修）**：`MAZE RUN` 的忙判据是
  `linkMazeReq || linkMazeRun`，而 **`linkMazeReq` 置位后只有上电才清零**（`LINK_MazeStarted`
  当时只置 `linkMazeRun`），`LESSON_Blind8()` 又是 `while(1)` 不返回 ⇒
  **发过一次车后 `MAZE RUN` 永久 `ERR_BUSY`，连 `STOP` 也救不回，只能断电**（真机复现）。
  修法：① 请求位改**边沿信号**（`LINK_MazeStarted` 里清零）；② 新增 **`MAZE STOP`**
  （带出迷宫+复位发车状态+解锁急停），`STOP`/`ESTOP` 也带出迷宫；③ `LESSON_Blind8` 加
  退出检查（`#ifdef MOUSE_DATA_LOG` 守卫）+ `main()` 等待循环改为可重复。
  ⚠️ **教训：边沿信号（有一次请求）与电平信号（当前在跑）不能塞进同一个变量；
  "停车"与"退出主循环"是两件事**——只停电机不退出循环，状态永远复位不了。
- ⚠️ **⚠️ 更靠前的真根因（同日第二轮真机实测揪出）：`main()` 在发车等待循环**之前**就被卡死。**
  `main()` 的 [4] 分支调用 `STATE_LoadMapAndSelectSpeed()`（APP/state.c）与
  `STATE_DetermineGoaheadNum()`，**两者各有一个 `while(1)` 等"前方红外 <20mm"**
  （`irDist.f1/f2 < 20`，比赛时电脑鼠鼻尖顶墙才算就位）。远程发车场景下前方无近物
  ⇒ **永久卡死** ⇒ `MAZE RUN` 被链路层接受（`linkMazeReq=1`）却**永不被消费**
  ⇒ 之后每次 `MAZE RUN` 都 `ERR_BUSY`、`STOP` 救不回。**这才是"发车/急停后繁忙"的首因**。
  这两步的产物（`goaheadnum`/`spurtSpd`/`spurtmode`/`mouseTask=SPURT_*`）只被
  `STATE_MainLoop` 的**冲刺**流程读，而 [4] 只跑 `LESSON_Blind8()`（纯探索）**一个都不读**。
  修法：[4] 档 `STATE_DetermineGoaheadNum` 整段跳过；`STATE_LoadMapAndSelectSpeed`
  **保留地图载入、跳过冲刺选档段**（均 `return;` + `#else` 保住原逻辑）。
- ⚠️ **第三个死锁**：`LESSON_Blind8` 的 `START` 靠起点格方向位 `0x08`(右上角)/`0x02`(左下角)
  分流；**无有效 Flash 地图时 `mapWall[mousePos]` 是 `MAZE_Init()` 的默认值 `0x11`，两位都不成立**
  ⇒ 一个分支都不进 ⇒ `mouseTask` 永远 START、车不动，且 `stackIdx` 停在 0
  ⇒ `while (--mazeState.stackIdx)` 下溢到 255 越界。修法：[4] 档给"左下角"分支条件加 `|| 1`
  （默认 `mousePos=(0,0)` 本就等价左下角）。
- 🔧 **可复用的"反推 main() 卡在哪"手法（比重烧加打印快得多）**：
  ① telemetry 里的**下游副作用当探针** —— `freemode=True`(main.c:147) 与 `battMv!=0`(:152)
  成立即证明 main() 已过全部硬件初始化；
  ② **`MAP DUMP` 区分"Flash 地图"与 `MAZE_Init()` 默认值** —— 默认值是
  `mapWall[0][0]=0x11, [1][0]=0x70, 其余全 0xF0`（**这三值是"无地图"的指纹**）；
  ③ `posX=posY=0` 亦为旁证。
- ⚠️ **[4] 档若无有效 Flash 地图**：`goalX/goalY` 停在 `MAZE_Init()` 的占位值 **7/7**
  （7×7 合法格是 0..6），探索能否收敛到目标格 **(6,6)** 尚未真机确认。
  ⚠️ 新增代码**全部**在 `#ifdef MOUSE_DATA_LOG` 之下 ⇒ `[5]` 比赛固件 ROM **90872 B
  与改动前逐字节同尺寸**，且 `fromelf` 符号表里新符号**一个都不存在**（双重验证法）。
- 版本：`API_VERSION` **2.1.1**；固件 `LINK_PROTO_VER` **3** / `LINK_FW_VER` **211**（v2.1.0 为 210）；
  `PONG 3 211 7 256 <rst>`。各档 ROM（**0 Error**）：[1]27720 [2]28272 [3]32784 [4]76012 [5]90872。
- 九套件 **516 项全绿**（`selftest`45 / `contract_test`210 / `facade`36 / `lesson`38 / `maze`42 /
  `monitor`32 / `motor_lab`38 / `timesync`52 / `pull`23）。
- 已归档 **`release/RemoteControl-v2.1.1-20261005.zip`**（**184 文件**，184/184 逐字节一致，54 条 SHA256 OK）。
- ⚠️ **未决：课程实验的波形采样密度**。真机 4.4 Hz ⇒ 实验三(100mm≈200ms) 只采到 **≈1 个点**
  （600mm≈5、1000mm≈9）。v2.0 的"217 Hz 够算 σ%/ts/tp"不成立 ⇒ 阶跃指标在真机不可信。
  **v1.5.5 的 `SCOPE`（1kHz 本地录制+停车后回传）正是为此**；是否恢复最小化版本**待用户决定**。
- ⚠️ **`lab.run()` 的采样循环必须"先采一拍再判结束"**：红外贴脸在第一个控制周期(1ms)就触发，
  `STOPPED` 在 `move.run` 的 ACK 等待期间就到 ⇒ 若先判结束就 `break`，`samples` 恒为空。已修。
- 固件**刻意保留不动**：IWDG、事件（`STOPPED`/`ESTOP TRIP` 带 `#n`）、`CAL` 请求-响应、`ARM`、
  **1kHz 红外采样**（`doWallDetect()` 在 SysTick，比赛依赖，一行未动）。
- 路口 8 类不再上报（帧里只有 `wallL/F/R` 原语）→ 主机侧 `classify_road(wL,wF,wR)` 复刻（wall 语义 **1=有墙**）。
- ⚠️ 下游 `Control/` 前端**用户明确决定不动**：它依赖 `SNAP`/`SCOPE`/迷宫三通道，连新固件时这些功能会失效。
- 遗留小瑕：`host/api/events.py` 的 `Event.MOVE` 已无发送方（死枚举成员），未清。
- ⚠️ 解析真机字节流时：**ACK 行是夹在二进制帧之间的**，不能用 `split(b"\r\n")`+`startswith`，
  必须用正则 `re.findall(rb"ACK (\d+) ", buf)`（我在这上面误判过一次"全部丢失"）。

### 不可再生的查证结论
- ⚠️ `trackL/trackR` 单位是 **mm 不是 pulse**（`odom.c:96-101` 已除）；s16 覆盖 ±32.7m，不需 s32。
- ⚠️ `wallSns.wallThresh` **不可由参数推导**：运行时被 `state.c:225`→140、`motion.c:418`→110 改写，参数 `IRTHRWALL`=160 → **必须进帧**。
- 决策量只能传结果：`EXPLORE_CrosswayChoice()` 首行 `FLOODFILL_Open()` 全图重算且有副作用 → 不传。

## 固件五档（`USER/main.h`，五宏互斥，≥2 个 `#error`）
[1] `MOUSE_TEST_NO_MOTOR` 电机物理禁用；[2] `MOUSE_TEST_MOTOR_LAB` 可控无自走（MOVE+护栏）；[3] `MOUSE_LESSON_LAB` 可控无自走+课程剖面；[4] `MOUSE_DATA_LOG` 可控**含自走**，**不派生 `MOUSE_TEST_MODE`**；[5] 全不定义 = 比赛固件。入口 `python -m host.motor_test|host.lesson|host.datalog COM7`。
⚠️ **档位门控必须用具名派生宏**：`MOUSE_TEST_MODE`=[1][2][3]，`MOUSE_ESTOP_RECOVERABLE`=[1][2][3]**+[4]**。绝不重复裸 `#ifdef MOUSE_TEST_MODE` —— 漏一处不报错，只在真机行为不一致。已发生：[4] 急停锁死 + 进 sleepmode 而链路照发帧 → **链路活着、数据冻结**（`upMs` 涨而采样不变）。`[S5]` 已钉死。

## Flash 分区 / ROM
0..100 程序区（101KB，IROM1 `0x19400`）／101 `DATA_NUM`／102..114 `DATA`（擦除正好 13 页）／115 `SYSCALIB`／116 `LESSONPARAM`／118..127 迷宫墙·起终点·90°路径·`IRDATA`·常规路径·陀螺零偏（**地址未变，不需重标定**）。
⚠️ 标定页原取 99/100，正落在 `FLASH_EraseRunData` 擦除范围 89..101 内 → 已移 115/116。改 `saveNum`/页地址须重核（`[S5]` 4 条断言）。
⚠️ **`sizeof` 陷阱**：`motion.c` 的 `TurnParam_t.length = sizeof(表)` 却按 `length/2` 当元素数用（元素宽 2B 写死）→ 查表收窄到 1B 就会"转弯只走一半表"。修法：`length` 改点数语义，3 处类型同步（`speedtable.h`/`motion.c`/`core.h`，`isr.c` 9 处解引用）。"表内容不变"只能逐值比对。ROM 最大单耗 `speedtable.o` 20280B。

## 参数（38 个；Q16.16）
生产 1–7（TRACKL/R、SPEEDL/R、GYRORATIO、ENCANGLE、WALLDIST，Flash 115）／课程 8–21（仅 [3]，Flash 116）／红外电源 22–38（含 BATTKV=2417、BATTLOWMV=7000、BATTHIGHMV=**7960**）。**`LINK_P_NUM`=24**（1–7+22–38）。
- `SPEEDL/R ≡ TRACKL/R ÷ 100`（派生，不独立标定）。TRACKL/TRACKR/GYRORATIO 属生产命名空间 → 不能用 `mc.lesson.set_params()`，须 `mc.params.set()`。
- ⚠️ **固件读侧只有生产表**：`GET ALL` 只遍历 24 项，课程 14 项一律 `ERR_NAME`；写侧有课程分支。模拟器早期回全部 38 项 → 掩盖了它（`[D2]` 已钉死）。
- ⚠️ Flash 扩容陷阱（用户决定不修）：`link_CalibLoad` 校验 `cnt != LINK_P_NUM` 即判无效 → 表扩容旧页作废、标定回落默认值；刷固件后要重标，现场表现是"读到默认值"。

## [2] 电机远程 / 标定边界
- ⚠️ **运动互斥**：`MOVE` 启动把 `motionCtrl.task` 置 NULL → 只看 `task` 查不出"正在跑 MOVE"，统一走 `link_MotionBusy()`（task + linkMove/linkSrv.state + linkCal.active）。回归 `[D3]/[D4]`。
- `MOVE RUN <spL> <spR> [ms] [ir_mm]`：时间护栏默认 2000ms/上限 60000；红外默认 10mm（负=关）；±300 上限。完成回 `STOPPED <REASON> #n`（v2.0 起无 MOVEDONE）。`ESTOP` 锁存，**只有 `STOP` 能解锁**（[1]–[4]；[5] 刻意锁死到断电）。
- 5 项 `CAL <item>`：GYRO/WALLDIST/IRDATA/GYRORATIO/ENCANGLE。[1] 只能静态 3 项：GYRO（Flash 127）、WALLDIST（仅 RAM，`SAVE`→115）、IRDATA（写 123）。需电机 2 项 → 切 [2] 重编译或 [3] 课程剖面。上位机护栏 `mc.motor_disabled`/`mc.motor_guard()`。

## 归档（`release/`）与用户偏好
非 git → 白名单+排除 `make_archive.py`。⚠️ **顺序固定**：跑绿并重编 → 接口审计 → 修过期文档（历史 CHANGELOG 不动）→ 写说明 → **写记忆** → 打包 → 抽查。
⚠️ **改文件必须在算哈希之前**（踩过：先算台账后改归档说明 → `sha256sum -c` 报 FAILED）。顺序 = 改完所有文件 → 打包 → 算哈希。
`registry.API_VERSION` 必须与 CHANGELOG 一致。当前归档 **183 文件 / 46 条 SHA256**。

## ⚠️ 改动归因：如何证明"没动业务代码"（方法论，可复用）
- **参照物必须选上一个归档**（如 `release/RemoteControl-v1.5.5-*.zip`），**不要用
  `code_stm32f1_mouse - 副本/`** —— 那是更早的上游，差异里掺了 v1.x 时代的有意改动，
  分不清责任。
- **必须剥离注释后再比**：只比原始文本会因注释改动误报。做法：
  `re.sub(r"/\*.*?\*/", " ", t, flags=re.S)` + 去 `//` + 压空白，再逐文件比对。
- 结论示例（2026-10-05）：59 个 .c/.h **剥离注释后完全相同**，业务逻辑一行未动；
  全部改动只在 `link.c/link.h` + 4 处纯注释。

## 诊断脚本的纪律（用户纠正过我一次）
- ⚠️ **诊断脚本绝不能发运动命令**：`MAZE RUN` 会让 [4] 档自走迷宫。
  一律加 `MOTOR_CMDS` 黑名单 + 需显式 `--launch` 才发车 + 可中止倒计时。
- 解析真机字节流时：**ACK 行夹在二进制帧之间**，不能用 `split(b"\r\n")`+`startswith`，
  必须 `re.findall(rb"ACK (\d+) ", buf)`。
- `host/` 现有诊断脚本：`real_v21`（综合验证+自愈）、`real_burst`（成串回收率）、
  `real_discriminate`（非运动探活）、`real_throughput`、`real_lesson_sampling`、
  `maze_launch_probe`（例程8 发车诊断，默认只读）。

## 用户偏好
追求一步到位、直接产出可用成果；**不需要**版本匹配/向后兼容机制。v2.0 直接替换，不做兼容层。
用户自己负责烧录与真机测试；**会追问"是否动过原程序"** → 回答要给出可比对的证据，不要只说"没动"。

## ⚠️ 链路层已独立验收通过（2026-10-05，fw=212）—— `host/link_check.py`
用户把工作重心明确划到链路层。三项**全部通过**（真机 COM7）：
- **L1 往返顺畅**：`PING` 12/12、seq 回显 12/12；RTT 最小 290 / **中位 301** / P90 309 / 最大 357 ms。
- **L2 重复指令**：同 (seq, crc) 重发 → **幂等重放**（回同一条应答，不重新执行）；
  换 seq 或换内容 → 幂等失效、正常执行；`TELEM` 重发 → **每次新帧且锚新鲜**（两次 `upMs` 差 300ms = RTT）。
- **L3 停止原因**：`MOVE RUN` 时间护栏 → `STOPPED TIME #n`；`STOP` → `USER`；`ESTOP` → `ESTOP`。
- ⚠️ 口径：`STOPPED`/`ESTOP TRIP` 是**主动上行事件**，**不拉遥测也能收到**；所以脚本里
  "转速 0 帧"是预期的（v2.1 默认静默），**不是故障**。
- ★ **关键分离结论**：电脑鼠在迷宫里"卡住"时链路**依然完全正常**
  （`PING`/`GET ALL`/`TELEM`/`STOP` 全部 OK，`TELEM` 照旧换新帧），且 **`MOVE RUN` 回 OK**
  ⇒ `link_MotionBusy()==0` ⇒ 程序卡在**纯计算**（`STATE_MazeSearch`/floodfill）里，**不是链路问题**。
  ⇒ 卡住时可用 `MOVE RUN` 远程把车开回来（不必只能断电）。
- ⚠️ 但**卡住后 `MAZE RUN` 仍永久 `ERR_BUSY`**（`linkMazeRun` 停在 1、`LINK_MazeFinished` 走不到）
  ⇒ **仍只能断电**。表现同旧 bug，**归因已变**：应用层卡死，非链路/停车逻辑。
- ⚠️ **用户明确决定不改**目标格越界（`goalX=8`/默认 `7`，7×7 合法格 0..6）—— 指出
  **"和发车位置有关"**、属原有代码行为。⇒ 实操：**必须提供有效地图 + 把车放在算法认可的起点角**。
  我据此**撤销了 lesson.c 的越界相关改动**（START 分支已与上游逐行相同）；
  `state.c` 的解阻塞改动保留（否则发车无法启动）。
- `host/link_check.py` 三段式（L1/L2 默认安全；L3 需 `--motor`，会动车）；
  命令构造与 `CommandClient._build` **逐字节一致**（`*` 前无空格）。
