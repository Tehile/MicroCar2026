"""迷宫状态机回传(实验8 无记忆走迷宫) 冒烟测试。

覆盖四层:
  1. **纯函数层**: 路口分类判据、事件行解析(`parse_maze_event`)、状态帧解码(`decode_maze`) —— 离线可跑;
  2. **协议层**: 命令拼装(`maze.ev`)、`FRAMES` 登记、`SNAP_FIELDS["MAZE"]` 字段数;
  3. **端到端**: 起模拟器 → `MAZE RUN` → 收事件流 → 1Hz 状态帧 → `SNAP MAZE` → summary/explain;
  4. **不变量**: 事件掩码开关真的生效; 状态帧只在**迷宫态**才发(空闲零带宽)。

设计要点(针对本项目已经踩过的坑):
  · 固件的"路口类型"判据必须与 `wallSns` 同源, 否则回传的状态与代码里决策的状态不是一回事;
  · 事件是**迁移驱动**的: 必须验"同一状态不重复报", 这正是模拟器曾经把 BEGIN 每 20ms
    重发一次的原因(边沿状态被 reset 清掉了)。所以这里专门有一条"BEGIN 只出现一次"。

用法: python maze_smoke.py [--port N]
"""

from __future__ import annotations

import argparse
import socket
import struct
import subprocess
import sys
import time

sys.path.insert(0, ".")

from host.api.client import MouseClient
from host.protocol.codec import (
    MAZE_EV_DEF,
    MAZE_FLAG_GOAL,
    MAZE_FLAG_JUNC,
    ROAD_KINDS,
    ROAD_NAMES,
    SNAP_FIELDS,
    TYPE_MAZE,
    decode_maze,
    parse_maze_event,
)
from host.registry import COMMANDS, FRAMES, command_line, spec_of

PASS = 0
FAIL = 0

#: 固件 link_RoadKind() 的判据(wallSns 置位 = 有墙) -> 期望的路口码
_ROAD_CASES = [
    # (front, left, right 是否有墙, 期望码)
    (1, 1, 1, 8),   # DEAD
    (0, 1, 1, 1),   # THRU
    (1, 0, 1, 2),   # CORNER_L
    (1, 1, 0, 3),   # CORNER_R
    (0, 0, 1, 4),   # TEE_FL
    (0, 1, 0, 5),   # TEE_FR
    (1, 0, 0, 6),   # TEE_LR
    (0, 0, 0, 7),   # CROSS
]


def check(name: str, ok: bool, detail: str = "") -> bool:
    global PASS, FAIL
    if ok:
        PASS += 1
        print(f"  [ok]   {name}")
    else:
        FAIL += 1
        print(f"  [FAIL] {name}  {detail}")
    return bool(ok)


def _free_port() -> int:
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    p = s.getsockname()[1]
    s.close()
    return p


def _road_of(f: int, l: int, r: int) -> int:
    """纯函数复刻固件 link_RoadKind() —— 用于离线核对判据表。"""
    if f == 0 and l == 0 and r == 0:
        return 7
    if f == 0 and l == 0:
        return 4
    if f == 0 and r == 0:
        return 5
    if l == 0 and r == 0:
        return 6
    if f == 0:
        return 1
    if l == 0:
        return 2
    if r == 0:
        return 3
    return 8


# ---------------------------------------------------------------- 离线

def test_offline() -> None:
    print("\n[1] 离线: 路口判据 / 事件解析 / 帧解码")

    ok = all(_road_of(f, l, r) == want for f, l, r, want in _ROAD_CASES)
    check("路口分类判据 8 种组合全覆盖且互不重叠", ok, str(_ROAD_CASES))
    check("路口名表与判据表一一对应", set(ROAD_NAMES) == set(range(9)), str(sorted(ROAD_NAMES)))
    check("每个路口名都有中文大类", all(n in ROAD_KINDS for n in ROAD_NAMES.values()))

    # 事件解析
    e = parse_maze_event("MAZE EV TASK START SEARCH")
    check("TASK 事件解析出 from/to", bool(e) and e.get("from") == "START" and e.get("to") == "SEARCH", str(e))
    e = parse_maze_event("MAZE EV ROAD TEE_FL 4")
    check("ROAD 事件解析出路口名与码", bool(e) and e.get("roadName") == "TEE_FL" and e.get("road") == 4, str(e))
    e = parse_maze_event("MAZE EV ROAD CORNER_L 2")
    check("ROAD 事件带中文大类", bool(e) and "弯" in str(e.get("roadKind")), str(e))
    e = parse_maze_event("MAZE EV JUNC 5")
    check("JUNC 事件解析出栈深", bool(e) and e.get("stack") == 5, str(e))
    e = parse_maze_event("MAZE EV TURN TURNAROUND 4")
    check("TURN 事件解析出动作名与码", bool(e) and e.get("motion") == "TURNAROUND" and e.get("motionCode") == 4, str(e))
    e = parse_maze_event("MAZE EV GOAL 7 6")
    check("GOAL 事件解析出坐标", bool(e) and e.get("x") == "7" and e.get("y") == "6", str(e))
    e = parse_maze_event("MAZE EV CELL 3 4 1")
    check("CELL 事件解析出坐标+朝向", bool(e) and e.get("dir") == "1", str(e))
    e = parse_maze_event("MAZE EV BEGIN 0 0")
    check("BEGIN 事件可解析", bool(e) and e.get("event") == "BEGIN", str(e))

    # 容错: 短行/未知事件 不抛异常
    check("未知事件名返回 None(交给普通文本处理)", parse_maze_event("MAZE EV WHO_KNOWS 1") is None)
    check("参数不足不抛异常", parse_maze_event("MAZE EV TASK") is not None)
    check("非 MAZE 行返回 None", parse_maze_event("SNAP MAZE 1 2 3") is None)
    check("空行返回 None", parse_maze_event("") is None)

    # 状态帧解码
    pl = bytes([2, 4, 3, 101, 6, 5, 1, 9, MAZE_FLAG_GOAL | MAZE_FLAG_JUNC,
                MAZE_EV_DEF, 0x2A, 0x00, 0x03, 0x00, 7, 1])
    d = decode_maze(pl)
    check("decode_maze 16B 逐字段正确",
          d["task"] == 2 and d["road"] == 4 and d["opens"] == 3 and d["motion"] == 101
          and d["posX"] == 6 and d["posY"] == 5 and d["dir"] == 1 and d["stack"] == 9,
          str(d))
    check("decode_maze 解 u16 计数字段(evCount=42)", d["evCount"] == 42, str(d["evCount"]))
    check("decode_maze 解 u16 计数字段(juncCnt=3)", d["juncCnt"] == 3, str(d["juncCnt"]))
    check("decode_maze 译名 + 标志位", d["taskName"] == "SEARCH" and d["roadName"] == "TEE_FL"
          and d["goal"] and d["seenJunc"], str({k: d[k] for k in ("taskName", "roadName", "goal", "seenJunc")}))
    check("decode_maze 容错: 短载荷不抛异常", decode_maze(b"\x01\x02")["task"] == 1)

    # 协议登记
    check("FRAMES 登记了 MAZE 帧", TYPE_MAZE in FRAMES and FRAMES[TYPE_MAZE].name == "MAZE")
    check("MAZE 帧登记的 sink 方法正确", FRAMES[TYPE_MAZE].sink == "push_maze", FRAMES[TYPE_MAZE].sink)
    check("命令表有 maze.ev / maze.rst", "maze.ev" in COMMANDS and "maze.rst" in COMMANDS)
    check("maze.ev 无参数时 = 查询", command_line("maze.ev") == "MAZE EV", command_line("maze.ev"))
    check("maze.ev 带 OFF", command_line("maze.ev", mask="OFF") == "MAZE EV OFF")
    check("maze.rst = MAZE RST", command_line("maze.rst") == "MAZE RST")
    check("maze.ev 是 ack 命令(非 no_retry)", not spec_of("maze.ev").no_retry)
    check("SNAP MAZE 域登记 16 个字段", len(SNAP_FIELDS.get("MAZE", [])) == 16,
          str(len(SNAP_FIELDS.get("MAZE", []))))
    check("SNAP MAZE 首字段是 task / 末字段是 atGoal",
          SNAP_FIELDS["MAZE"][0] == "task" and SNAP_FIELDS["MAZE"][-1] == "atGoal",
          str(SNAP_FIELDS["MAZE"]))


# ---------------------------------------------------------------- 端到端

def test_e2e(port: int) -> None:
    print("\n[2] 端到端: 发车 → 事件流 → 1Hz 状态帧 → SNAP MAZE")

    mc = MouseClient(auto_stream=False)
    if not mc.connect(f"tcp://127.0.0.1:{port}"):
        check("连接模拟器", False, "connect failed")
        return
    try:
        # 掩码默认值
        m = mc.maze.set_events()
        check("事件掩码默认 = 31(TASK|ROAD|JUNC|TURN|GOAL)", m == MAZE_EV_DEF, str(m))

        # 空闲时不该有状态帧(零带宽约定)
        check("未发车时没有迷宫状态帧", mc.maze.state() is None, str(mc.maze.state()))

        mc.send_cmd("arm")
        mc.send_cmd("stream.on")
        r = mc.send_cmd("maze.run")
        check("MAZE RUN 被接受", r.ok, r.status)

        evs = mc.maze.watch(dur=8.0)
        kinds = {}
        for e in evs:
            kinds[e.get("event")] = kinds.get(e.get("event"), 0) + 1
        check(f"收到事件流({len(evs)} 条)", len(evs) >= 8, str(kinds))
        check("含 BEGIN(进入迷宫态) 事件", kinds.get("BEGIN", 0) >= 1, str(kinds))
        check("含 TASK 状态机迁移", kinds.get("TASK", 0) >= 1, str(kinds))
        check("含 ROAD 路口识别", kinds.get("ROAD", 0) >= 3, str(kinds))
        check("含 TURN 转向/掉头动作", kinds.get("TURN", 0) >= 1, str(kinds))

        # 迁移驱动: 同一状态不得反复上报(BEGIN 曾是每 20ms 一条)
        check("BEGIN 只报一次(迁移驱动, 不是周期上报)", kinds.get("BEGIN", 0) == 1, str(kinds))

        # ROAD 事件必须是"变化才报": 相邻两条不应同名
        roads = [str(e.get("roadName")) for e in evs if e.get("event") == "ROAD"]
        dup = any(roads[i] == roads[i + 1] for i in range(len(roads) - 1))
        check("ROAD 事件相邻不重复(去抖动+变化才报)", not dup, str(roads[:12]))
        check("ROAD 事件至少覆盖到弯道或岔路口",
              any(r.startswith("CORNER") or r.startswith("TEE") or r == "CROSS" for r in roads),
              str(sorted(set(roads))))

        # 1Hz 状态帧
        st = mc.maze.state()
        check("收到 1Hz 迷宫状态帧", st is not None)
        if st:
            check("状态帧: 处于搜索态(task=SEARCH)", st["taskName"] == "SEARCH", str(st["taskName"]))
            check("状态帧: 位置是合法格坐标", 0 <= st["posX"] < 7 and 0 <= st["posY"] < 7,
                  f"({st['posX']},{st['posY']})")
            check("状态帧: 朝向 0..3", 0 <= st["dir"] <= 3, str(st["dir"]))
            check("状态帧: evCount 与收到的事件数同量级", abs(st["evCount"] - len(evs)) <= len(evs) + 3,
                  f"frame={st['evCount']} local={len(evs)}")
            check("状态帧: 标志位里有遇到过岔路口/死路或还没遇到",
                  isinstance(st["flags"], int), str(st["flags"]))

        # SNAP MAZE 点查(阻塞问答, 迷宫 while(1) 挡不住)
        sn = mc.maze.snap(timeout=3.0)
        check("SNAP MAZE 有回话", sn is not None)
        if sn:
            check("SNAP MAZE: 带 cellCnt(周期帧里没有的量)", "cellCnt" in sn and int(sn["cellCnt"]) >= 1,
                  str(sn.get("cellCnt")))
            check("SNAP MAZE: taskName 已译名", sn.get("taskName") == "SEARCH", str(sn.get("taskName")))
            check("SNAP MAZE: atGoal 已转 bool", isinstance(sn.get("goal"), bool), str(sn.get("goal")))

        # summary / explain
        s = mc.maze.summary()
        check("summary: taskSeq 非空", bool(s["taskSeq"]), str(s["taskSeq"]))
        check("summary: roads 分布非空", bool(s["roads"]), str(s["roads"]))
        check("summary: 未误报事件丢弃", not s["evDropped"], str(s["evDropped"]))
        lines = mc.maze.explain()
        check("explain 输出多行", len(lines) >= 5, str(lines))

        # 掩码开关真的生效
        mc.maze.clear_events()
        mc.maze.set_events("OFF")
        mc.maze.watch(dur=2.0)
        off_evs = mc.maze.events()
        check("掩码 OFF 后不再产生事件", len(off_evs) == 0, str(len(off_evs)))
        mc.maze.set_events("DEF")
        mc.maze.clear_events()
        mc.maze.watch(dur=3.0)
        on_evs = mc.maze.events()
        check("掩码恢复 DEF 后事件流恢复", len(on_evs) >= 1, str(len(on_evs)))

        # 清统计
        ok = mc.maze.reset()
        check("MAZE RST 被接受", ok)
        mc.maze.watch(dur=1.5)
        s2 = mc.maze.summary()
        check("RST 后固件侧计数已归零(小于 RST 前)",
              int(s2["counters"]["evCount"]) < int(s["counters"]["evCount"]) + 20,
              f"before={s['counters']['evCount']} after={s2['counters']['evCount']}")
    finally:
        mc.close()


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=0, help="已有模拟器端口(省略则自己起一个)")
    args = ap.parse_args()

    test_offline()

    port = args.port or _free_port()
    proc = None
    if not args.port:
        proc = subprocess.Popen(
            [sys.executable, "-m", "host.sim.mouse_sim", "--port", str(port), "--no-auto"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        time.sleep(1.2)
    try:
        test_e2e(port)
    finally:
        if proc is not None:
            proc.terminate()
            try:
                proc.wait(timeout=3)
            except subprocess.TimeoutExpired:
                proc.kill()

    print("\n" + "=" * 66)
    print(f"通过 {PASS} / 失败 {FAIL}")
    print("=" * 66)
    return 1 if FAIL else 0


if __name__ == "__main__":
    raise SystemExit(main())
