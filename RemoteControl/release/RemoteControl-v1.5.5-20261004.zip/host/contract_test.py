"""注册表契约测试 —— 扩展性保证(E1/E3)的机器强制。

回答一个问题: **"新增一项功能, 接口有没有自动覆盖?"**

静态断言(不连设备):
    S1  link.py 的帧分派必须走 registry.FRAMES 表, 不得硬编码 decode_*/TYPE_*
    S2  每条 CommandSpec 都能拼出非空命令文本, 且 args 与 build 签名一致
    S3  每条 FrameSpec 都能"打包 -> 解析 -> 解码"往返并产出 dict
    S4  登记表数量不低于基线(防止误删)

动态断言(连模拟器):
    D1  每条 CommandSpec 用示例参数发一次, 收到 ACK ... OK
    D2  每个 PARAM_IDS 可读写, 且回读值与写入一致(Q16.16)

用法:
    python contract_test.py              # 自动拉起模拟器
    python contract_test.py --port 5556 # 连已运行模拟器
"""

from __future__ import annotations

import argparse
import socket
import struct
import subprocess
import sys
import time

import numpy as np

from host.protocol.codec import (
    TYPE_DUMP_BLK,
    TYPE_DUMP_END,
    TYPE_DUMP_HDR,
    TYPE_FAST,
    TYPE_MAP,
    TYPE_MAZE,
    TYPE_MID,
    TYPE_SLOW,
    TYPE_TIME,
    float_to_q1616,
    pack_frame,
    FrameStreamParser,
)
from host.protocol.commands import LESSON_PARAM_IDS, PARAM_IDS, PRODUCTION_PARAM_IDS
from host.registry import (
    COMMANDS,
    FRAMES,
    command_line,
    check_frame_dispatch_is_table_driven,
    spec_of,
)

PASS = 0
FAIL = 0


def check(name: str, cond: bool, detail: str = "") -> None:
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"  [OK]   {name}")
    else:
        FAIL += 1
        print(f"  [FAIL] {name}  {detail}")


def _free_port() -> int:
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    return port


# ---------------------------------------------------------------- 静态

def test_static() -> None:
    print("\n[S] 静态断言")

    # S1: link.py 分派必须查表
    import os

    from host.transport import link as link_mod

    src = open(link_mod.__file__, encoding="utf-8").read()
    bad = check_frame_dispatch_is_table_driven(src)
    check("link.py 帧分派走 registry.FRAMES(无硬编码 decode_*)", not bad, "\n".join(bad))

    # S4: 数量基线(与固件实际命令集一致: 29 条命令 / 8 种帧 / 38 参数)
    check(f"COMMANDS 登记 {len(COMMANDS)} 条(基线 29)", len(COMMANDS) >= 29, str(len(COMMANDS)))
    check(f"FRAMES 登记 {len(FRAMES)} 种(基线 8)", len(FRAMES) >= 8, str(len(FRAMES)))
    check(f"PARAM_IDS 登记 {len(PARAM_IDS)} 项(基线 38)", len(PARAM_IDS) >= 38, str(len(PARAM_IDS)))
    check(f"PRODUCTION_PARAM_IDS 生产段 {len(PRODUCTION_PARAM_IDS)} 项(基线 24)",
          len(PRODUCTION_PARAM_IDS) >= 24, str(len(PRODUCTION_PARAM_IDS)))

    _test_firmware_mode_gates()


def _test_firmware_mode_gates() -> None:
    """S5: 固件档位门控一致性(真机实测缺陷的静态回归, 2026-10-04)。

    背景: `MOUSE_TEST_MODE` 只由 [1][2][3] 派生, **[4] MOUSE_DATA_LOG 刻意不派生**
    (它要跑 doTask*/LESSON_ISR 自走)。当"实验档共同行为"被写成裸
    `#ifdef MOUSE_TEST_MODE` 时, [4] 会静默退化成比赛固件语义:
      · 急停锁存无法用 `STOP` 解除 -> 一次急停废掉整场采集;
      · 急停 200ms 后 sleepmode=1 -> isr.c 跳过全部采样, 但 LINK_Tick() 在门外
        照发帧 -> "链路活着、数据冻结", 现场极难察觉。
    这类错误**不会有编译错误**, 而且档位无关的模拟器抓不到 —— 只能静态查源码。
    故这里断言: 实验档共同行为必须走**具名派生宏** `MOUSE_ESTOP_RECOVERABLE`。
    """
    print("\n[S5] 固件档位门控一致性")

    import os
    import re

    fw = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "code_stm32f1_mouse")
    main_h = open(os.path.join(fw, "USER", "main.h"), encoding="utf-8").read()
    link_c = open(os.path.join(fw, "HARDWARE", "link.c"), encoding="utf-8").read()
    isr_c = open(os.path.join(fw, "HARDWARE", "isr.c"), encoding="utf-8").read()

    # S5a: 具名派生宏存在, 且明确覆盖 [4]
    derived = re.search(
        r"#if defined\(MOUSE_TEST_MODE\) \|\| defined\(MOUSE_DATA_LOG\)\s*\n"
        r"#define MOUSE_ESTOP_RECOVERABLE 1", main_h)
    check("main.h: MOUSE_ESTOP_RECOVERABLE = MOUSE_TEST_MODE || MOUSE_DATA_LOG",
          bool(derived), "未找到派生定义")

    # S5b: link.c 的 STOP 解锁块 —— 只认具名宏, 不许残留裸 MOUSE_TEST_MODE
    #      注意 anchor 必须用 link_StopMotion(...)：`link_TokIs(&p, "STOP")` 在
    #      link.c 里出现两次(LESSON STOP / 顶层 STOP), 用后者会抓错块。
    i = link_c.find("link_StopMotion(LINK_RUN_REASON_STOP)")
    stop_blk = link_c[max(0, i - 260):i + 900] if i >= 0 else ""
    check("link.c: 找到顶层 STOP 处理块", bool(stop_blk))
    check("link.c: STOP 解锁走 MOUSE_ESTOP_RECOVERABLE",
          "MOUSE_ESTOP_RECOVERABLE" in stop_blk, stop_blk[:120])
    check("link.c: STOP 块内无裸 MOUSE_TEST_MODE",
          "MOUSE_TEST_MODE" not in stop_blk)

    # S5c: isr.c 的急停休眠块(窗口止于块末尾的 LINK_EStopTrip(); —— 再往后
    #      还有一处合法的 `#ifndef MOUSE_TEST_MODE` 用于 LESSON_ISR, 不能框进来)
    i = isr_c.find("if (emergMon.active == 1)")
    j = isr_c.find("LINK_EStopTrip();", i) if i >= 0 else -1
    em_blk = isr_c[i:j] if (i >= 0 and j > i) else ""
    check("isr.c: 找到急停处理块", bool(em_blk))
    check("isr.c: 急停休眠走 MOUSE_ESTOP_RECOVERABLE",
          "MOUSE_ESTOP_RECOVERABLE" in em_blk, em_blk[:160])
    check("isr.c: 急停块内无裸 MOUSE_TEST_MODE", "MOUSE_TEST_MODE" not in em_blk)

    # S5d: 残留裸门控的**清点基线** —— 将来新加一处会立刻报红
    #      isr.c 余 3 处: 779 #ifdef(运动状态机停用) / 881 #endif / 902 #ifndef(LESSON_ISR)
    check("link.c 已无裸 MOUSE_TEST_MODE(基线 0)", link_c.count("MOUSE_TEST_MODE") == 0,
          str(link_c.count("MOUSE_TEST_MODE")))
    check("isr.c 裸 MOUSE_TEST_MODE 仅剩 3 处(基线 3)", isr_c.count("MOUSE_TEST_MODE") == 3,
          str(isr_c.count("MOUSE_TEST_MODE")))

    # S5e: 程序区上界必须与 Flash 数据区起始页严格对齐。
    #      uvprojx 内 0x8000000 出现多次(全芯片描述 + 实际启用的 IROM1),
    #      故取其中**最小**的 Size 作为"程序区上界"; 它若越过 FLASH_ADDR_DATA_NUM,
    #      擦写标定/迷宫数据会覆盖代码区(现场表现为"标定莫名丢失"), 故钉住此不变量。
    uv = open(os.path.join(fw, "USER", "Mouse.uvprojx"), encoding="utf-8").read()
    flash_h = open(os.path.join(fw, "HARDWARE", "flash.h"), encoding="utf-8").read()
    flash_c = open(os.path.join(fw, "HARDWARE", "flash.c"), encoding="utf-8").read()
    link_h = open(os.path.join(fw, "HARDWARE", "link.h"), encoding="utf-8").read()
    sizes = [int(sz, 16) for addr, sz in
             re.findall(r"<StartAddress>(0x[0-9a-fA-F]+)</StartAddress>\s*<Size>(0x[0-9a-fA-F]+)</Size>", uv)
             if int(addr, 16) == 0x08000000]
    m_data = re.search(r"#define\s+FLASH_ADDR_DATA_NUM\s+(0X[0-9a-fA-F]+)", flash_h)
    check("uvprojx: 找到 0x08000000 的程序区描述", bool(sizes), str(sizes))
    check("flash.h: 找到 FLASH_ADDR_DATA_NUM", bool(m_data))
    if sizes and m_data:
        data_start = int(m_data.group(1), 16) - 0x08000000
        check(f"程序区上界 0x{min(sizes):X} == 数据区起始 0x{data_start:X}(不越界)",
              min(sizes) == data_start, f"sizes={[hex(x) for x in sizes]} data=0x{data_start:X}")

    # S5f: Flash 页布局不得互相踩踏。
    #      背景(2026-10-04 实测): 链路模块原先把标定页取在 page 99/100, 而运行数据区的
    #      **擦除范围**是 `saveNum/100+1 = 13 页` = page 89..101 —— 两个标定页正落在里面,
    #      一次 FLASH_EraseRunData()(calibrate.c / menu.c / state.c 共 3 处调用)
    #      就会把生产标定与课程参数一起擦掉。现已上移到 115/116。此断言钉死这件事。
    def addr_of(macro: str, text: str):
        mm = re.search(r"#define\s+" + macro + r"\s+(0[xX][0-9a-fA-F]+)", text)
        return int(mm.group(1), 16) if mm else None

    # 注意 flash.c 里 saveNum 有两处: `#ifndef FLASHSAVE` 分支的 =1 与
    # `#ifdef FLASHSAVE` 分支的 =1200。**生效的是后者**(flash.c 顶部无条件 `#define FLASHSAVE`),
    # 故必须从 `#ifdef FLASHSAVE` 之后开始找, 否则会取到 1 → 页数算成 1。
    i_fs = flash_c.find("#ifdef FLASHSAVE")
    m_save = re.search(r"const\s+u16\s+saveNum\s*=\s*(\d+)",
                       flash_c[i_fs:] if i_fs >= 0 else flash_c)
    check("flash.c: 找到生效的 saveNum(=1200)", bool(m_save) and m_save.group(1) == "1200",
          m_save.group(0) if m_save else "未找到")
    d_data = addr_of("FLASH_ADDR_DATA", flash_h)
    check("flash.h: 找到 FLASH_ADDR_DATA", d_data is not None)
    if m_save and d_data and m_data:
        pages = int(m_save.group(1)) // 100 + 1          # FLASH_EraseRunData 的页数
        erase_lo, erase_hi = d_data, d_data + pages * 0x400
        check(f"运行数据区擦除范围 = {pages} 页 (page "
              f"{(erase_lo - 0x08000000)//0x400}..{(erase_hi - 0x08000000)//0x400 - 1})",
              pages == 13, f"pages={pages}")
        for macro_name in ("FLASH_ADDR_SYSCALIB", "FLASH_ADDR_LESSONPARAM"):
            a = addr_of(macro_name, link_h)
            check(f"link.h: 找到 {macro_name}", a is not None)
            if a is None:
                continue
            in_data_area = a >= int(m_data.group(1), 16)
            in_erase = erase_lo <= a < erase_hi
            aligned = (a - 0x08000000) % 0x400 == 0
            below_maze = a < int(re.search(r"#define\s+FLASH_ADDR_BLOCK_STACK\s+(0[xX][0-9a-fA-F]+)",
                                          flash_h).group(1), 16)
            check(f"{macro_name}(page {(a - 0x08000000)//0x400}) 位于数据区", in_data_area)
            check(f"{macro_name} **不在运行数据擦除范围内**", not in_erase,
                  f"erase=0x{erase_lo:X}..0x{erase_hi:X} addr=0x{a:X}")
            check(f"{macro_name} 1KB 对齐", aligned)
            check(f"{macro_name} 不越过迷宫页(118)", below_maze)

    # S5g: 源码"注释提前闭合"扫描。
    #      场景: 在 `/* ... */` 块注释里写了形如 `doTask*/LESSON_ISR` 或 `TEE_*/CROSS` 的文本,
    #      其中的 `*/` 会**提前结束注释**, 后面的文字被当成代码 → 报出一堆看似无关的错误
    #      (上次是 main.h 869 个 error, 这次是 link.c 的 "struct has no field")。
    #      本项目已踩两次, 故做成自动检查: 跨行块注释内部的 `*/` 之后不得再有内容。
    bad: list = []
    for dirpath, _dirs, files in os.walk(fw):
        if "tools" in dirpath.replace("\\", "/"):
            continue
        for fn in sorted(files):
            if not fn.endswith((".c", ".h")):
                continue
            path = os.path.join(dirpath, fn)
            try:
                lines = open(path, encoding="utf-8", errors="replace").read().splitlines()
            except OSError:
                continue
            block_line = 0
            for ln, text in enumerate(lines, 1):
                rest = text
                while True:
                    if block_line == 0:
                        o = rest.find("/*")
                        if o < 0:
                            break
                        e = rest.find("*/", o + 2)
                        if e < 0:
                            block_line = ln
                            break
                        rest = rest[e + 2:]
                    else:
                        e = rest.find("*/")
                        if e < 0:
                            break
                        if ln > block_line and rest[e + 2:].strip():
                            bad.append(f"{os.path.relpath(path, fw)}:{ln}: {rest[e + 2:].strip()[:50]}")
                        block_line = 0
                        rest = rest[e + 2:]
    check("固件源码无'注释提前闭合'(跨行注释内的 */ 之后不得再有内容)",
          not bad, " | ".join(bad[:5]))

    # S5h: 每个帧 sink 必须用**自己的** stream 名去 notify。
    #      背景(2026-10-04 实测踩过): 往 ring.py 里插新 sink 时, 锚点选在
    #      `push_time` 的最后一行之前, 结果把它的 `self._notify("time", rec)`
    #      挤进了新函数的末尾 —— 于是 TIME 帧不再通知(时间同步样本恒为 0),
    #      而新帧冒名通知成 "time"。**编译与 import 都不会报错**, 只有跑起来才现形。
    import inspect as _inspect

    from host.model import ring as _ring

    #      判据: 只要这个 sink 里出现了 _notify, 就必须是**自己的** stream 名,
    #      且不得出现别人的; 另外下列"逐帧遥测"流必须确实 notify
    #      (dump_hdr/blk/end 是整块回传的三个阶段, 本就逐块不发帧通知, 不在必查集里)。
    MUST_NOTIFY = {"fast", "mid", "slow", "time", "maze", "map"}
    streams = {sp.stream for sp in FRAMES.values()}
    sink_bad = []
    for spec in FRAMES.values():
        if not spec.sink.startswith("push_"):
            continue
        fn = getattr(_ring.TelemetryStore, spec.sink, None)
        if fn is None:
            sink_bad.append(f"{spec.sink}: 不存在")
            continue
        body = _inspect.getsource(fn)
        mine = f'self._notify("{spec.stream}", rec)'
        if mine not in body:
            if spec.stream in MUST_NOTIFY or "_notify(" in body:
                sink_bad.append(f"{spec.sink} 缺少 {mine}")
        for other in streams - {spec.stream}:
            if f'self._notify("{other}", rec)' in body:
                sink_bad.append(f"{spec.sink} 误用 {other}")
    check("每个帧 sink 只 notify 自己的 stream(防插错位置)", not sink_bad, " | ".join(sink_bad[:5]))
    # 生产段必须是全集的子集, 且课程段不混入(否则 get_all 的等待集合会算错)
    check("生产段 ∩ 课程段 = ∅",
          not (set(PRODUCTION_PARAM_IDS) & set(LESSON_PARAM_IDS)),
          str(sorted(set(PRODUCTION_PARAM_IDS) & set(LESSON_PARAM_IDS))))

    # FRAMES 覆盖全部 TYPE_* 常量
    all_types = {TYPE_FAST, TYPE_MID, TYPE_SLOW, TYPE_DUMP_HDR, TYPE_DUMP_BLK, TYPE_DUMP_END,
                 TYPE_MAP, TYPE_TIME}
    check("FRAMES 覆盖全部 8 种帧类型", all_types.issubset(set(FRAMES)),
          str(all_types - set(FRAMES)))

    # S5: CLI 必须能导入并构建 parser
    #     它的教训很直接: cli.py 曾经因为"两条语句挤在一行"而语法错误,
    #     但没有任何测试 import 它 -> 错误一路潜行到生成文档时才炸。
    try:
        import argparse

        from host import cli as _cli

        parser = _cli._build_parser()
        choices: set = set()
        for act in parser._actions:
            if isinstance(act, argparse._SubParsersAction):
                choices = set(act.choices)
                break
        need = {"ports", "connect", "get", "get-all", "set", "calib", "save", "scope",
                "maze", "monitor", "motor-test", "estop", "diagnose", "scan-baud", "replay",
                "lesson", "datalog"}
        missing = need - choices
        check(f"CLI 可导入且子命令齐备({len(choices)} 个, 含 motor-test/lesson/datalog)",
              not missing, f"缺 {sorted(missing)}")
    except Exception as e:  # noqa: BLE001
        check("CLI 可导入并构建 parser", False, f"{type(e).__name__}: {e}")


def test_command_build() -> None:
    print("\n[S2] 命令构建")
    for name, spec in COMMANDS.items():
        # 用示例参数拼一条命令
        args = {k: _EXAMPLE_ARGS[k] for k in spec.args}
        try:
            line = command_line(name, **args)
        except Exception as e:
            check(f"{name}: 可拼命令", False, f"{type(e).__name__}: {e}")
            continue
        ok = bool(line) and "\n" not in line and "\r" not in line and line == line.strip()
        check(f"{name}: 产出非空单行命令 '{line}'", ok, repr(line))
        # 命令必须是大写关键字开头(与固件 token 解析一致)
        head = line.split()[0].upper()
        check(f"{name}: 关键字大写 '{head}'", head == line.split()[0], repr(line))


def test_frames_roundtrip() -> None:
    print("\n[S3] 帧打包/解析/解码往返")
    parser = FrameStreamParser()
    for ftype, spec in FRAMES.items():
        payload = _PAYLOAD_BUILDERS[ftype]()
        frame = pack_frame(ftype, payload, 1)
        frames, _ = parser.feed(frame)
        if not frames:
            check(f"{spec.name}: 解析出帧", False)
            continue
        rec = spec.decoder(frames[0].payload)
        check(f"{spec.name}: 解码产出 dict", isinstance(rec, dict) and bool(rec),
              str(type(rec).__name__))


# ---------------------------------------------------------------- 动态

def test_commands_e2e(port: int) -> None:
    print("\n[D1] 每条命令在模拟器上收到 ACK OK")
    from host.api import MouseClient

    with MouseClient.connect_to(f"tcp://127.0.0.1:{port}") as mc:
        check("连接成功", mc.is_connected, mc.state_detail)

        # 按顺序执行, 覆盖所有登记命令; 顺序照顾副作用(先无副作用, 后动作)
        order = [
            "ping", "ver", "params.get", "params.get_all", "params.setq", "params.set",
            "params.save", "params.reset", "snap.get",
            "tare", "stream.on", "stream.off", "stream.on",
            "rate", "calib.cal", "scope.start", "scope.stop", "scope.dump",
            # 每条运动命令前先 stop: 设备现在会正确拒绝"运动中的第二条 MOVE"(见 D4),
            # 不清场就会误报 ERR_BUSY。
            "maze.dump", "maze.ev", "maze.rst", "stop", "move.fwd", "stop", "move.rot", "stop", "move.run",
            "stop", "estop", "estop.clear",
            # ---- 课程调参实验(放最后: start 会启动一段剖面, status 应见 running=1, stop 收尾) ----
            "lesson.start", "lesson.status", "lesson.stop",
            # ---- 时间同步 / 数据收集 ----
            "arm", "maze.run",
        ]
        covered = set()
        for name in order:
            args = {k: _EXAMPLE_ARGS[k] for k in spec_of(name).args}
            r = mc.send_cmd(name, timeout=5.0, **args)
            covered.add(name)
            check(f"{name}: ACK OK", r.ok, f"{r.status} cmd={r.data.get('cmd')!r}")
            # 运动类命令要留出真实结束时间, 否则下一条会被 ERR_BUSY 拒掉(这是正确行为)
            time.sleep(0.25 if name.startswith("move.") else 0.02)

        # 覆盖率: 所有登记命令都必须被跑到
        missing = set(COMMANDS) - covered
        check("覆盖全部登记命令", not missing, f"未覆盖: {missing}")
        # 反向: 顺序里不得有未登记的命令
        unknown = covered - set(COMMANDS)
        check("顺序里无未登记命令", not unknown, str(unknown))


def test_motion_mutex_e2e(port: int) -> None:
    """[D4] 运动互斥: 第二条 MOVE 必须被 ERR_BUSY 拒掉, **且不得重置护栏**。

    真机实测揪出的缺陷(2026-10-04): 固件 `MOVE RUN/FWD/ROT` 启动时都把
    `motionCtrl.task` 置 NULL(它们由 `link_MoveService` 驱动, 不走任务状态机),
    于是四处 busy 检查只查 `motionCtrl.task` 是**查不出正在跑 MOVE 的**。
    后果: 第二条 `MOVE RUN` 被接受并覆盖 `linkMove.elapsed/limit` ——
    **时间护栏被重置**, 连续发就能把电机运行时间无限延长(真机: 首条 1500ms,
    0.48s 处再发一条, 实际跑到 ~1.98s)。

    模拟器当时也没查, 所以整套测试盖不住。现在两边都按 `link_MotionBusy()` 对齐,
    本用例就是那条防线。
    """
    print("\n[D4] 运动互斥: 第二条 MOVE 被拒且不重置护栏")
    from host.api import MouseClient
    from host.api.events import Event

    with MouseClient.connect_to(f"tcp://127.0.0.1:{port}") as mc:
        moves: list = []
        mc.on(Event.MOVE, lambda m: moves.append(m.data.get("raw", "")))

        # 先回到空闲: 前面的用例跑过 MAZE RUN, 会把设备留在"探索中"——
        # 那正是互斥判据该拦的状态, 所以这里先 STOP 建立干净起点。
        mc.send_cmd("stop")
        time.sleep(0.3)

        r1 = mc.send_cmd("move.run", sp_l=30, sp_r=30, ms=1200, ir_mm=10)
        check("第 1 条 MOVE RUN 被接受", r1.ok, r1.status)
        r2 = mc.send_cmd("move.run", sp_l=30, sp_r=30, ms=1200, ir_mm=10)
        check("第 2 条(仍在跑)被拒 ERR_BUSY", (not r2.ok) and r2.status == "ERR_BUSY", r2.status)

        # 换一种运动形式也应被拒(三种 MOVE 共用同一判据)
        r3 = mc.send_cmd("move.rot", pwm=200, ms=500)
        check("运动中的 MOVE ROT 也被拒", (not r3.ok) and r3.status == "ERR_BUSY", r3.status)
        r4 = mc.send_cmd("move.fwd", pulses=3000, speed=40)
        check("运动中的 MOVE FWD 也被拒", (not r4.ok) and r4.status == "ERR_BUSY", r4.status)
        r5 = mc.send_cmd("params.save")
        check("运动中的 SAVE 也被拒(擦写停顿会打断 1kHz 环)",
              (not r5.ok) and r5.status == "ERR_BUSY", r5.status)

        # 等这次运动真正结束
        mc.wait(lambda: len([m for m in moves if m.startswith("MOVEDONE")]) >= 1, timeout=6.0)
        done = [m for m in moves if m.startswith("MOVEDONE")]
        check("只有 1 次运动被执行(1 条 MOVEDONE)", len(done) == 1, str(done))
        if done:
            f = done[0].split()
            check("护栏时长未被重置(仍为第 1 条的 1200ms)",
                  len(f) > 3 and f[3] == "1200", done[0])

        # 空下来以后应恢复可接受
        time.sleep(0.4)
        r6 = mc.send_cmd("move.run", sp_l=30, sp_r=30, ms=200, ir_mm=10)
        check("空闲后 MOVE RUN 恢复可接受", r6.ok, r6.status)
        mc.wait(lambda: len([m for m in moves if m.startswith("MOVEDONE")]) >= 2, timeout=4.0)


def test_estop_recoverable_e2e(port: int) -> None:
    """[D5] 急停必须可恢复: ESTOP 锁存 -> 拒绝运动 -> STOP 解锁 -> 恢复可动。

    真机实测的缺陷(2026-10-04, [4] 数据收集档): "STOP 兼作解急停"整段被包在
    `#ifdef MOUSE_TEST_MODE` 里, 而 [4] 不派生该宏 -> `STOP` 回 OK 但
    `linkEStop` 不复位, 之后的 MOVE/CAL 全部 ERR_ESTOP,**只能断电重启**。
    同时急停 200ms 后 sleepmode=1 -> 采样全停但链路照发 -> 数据冻结。

    本用例钉住"可恢复"这一半(冻结那半边靠 S5 的静态断言)。
    """
    print("\n[D5] 急停可恢复: 锁存 -> 拒绝 -> STOP 解锁 -> 恢复")
    from host.api import MouseClient

    with MouseClient.connect_to(f"tcp://127.0.0.1:{port}") as mc:
        mc.send_cmd("stop")
        time.sleep(0.3)

        r1 = mc.send_cmd("move.run", sp_l=20, sp_r=20, ms=1500, ir_mm=10)
        check("急停前 MOVE RUN 被接受", r1.ok, r1.status)

        r2 = mc.send_cmd("estop")
        check("ESTOP 被接受", r2.ok, r2.status)
        time.sleep(0.4)

        # 锁存期间: 运动命令被拒, 且快帧 flags 明确标出 ESTOP_LOCK
        r3 = mc.send_cmd("move.run", sp_l=20, sp_r=20, ms=300, ir_mm=10)
        check("锁存中 MOVE RUN 被拒 ERR_ESTOP",
              (not r3.ok) and r3.status == "ERR_ESTOP", r3.status)
        snap = mc.snap.read(["MOTION"])
        flags = snap.get("MOTION", {}).get("flags", 0)
        check("快帧/SNAP flags 置 ESTOP_LOCK(0x40)", bool(flags & 0x40), f"flags=0x{flags:02X}")

        # STOP 解锁(上位机 estop.clear 映射到 STOP)
        r4 = mc.send_cmd("estop.clear")
        check("STOP(estop.clear) 被接受", r4.ok, r4.status)
        time.sleep(0.4)

        snap = mc.snap.read(["MOTION"])
        flags = snap.get("MOTION", {}).get("flags", 0)
        check("解锁后 ESTOP_LOCK 已清", not (flags & 0x40), f"flags=0x{flags:02X}")

        r5 = mc.send_cmd("move.run", sp_l=20, sp_r=20, ms=300, ir_mm=10)
        check("解锁后 MOVE RUN 恢复可接受", r5.ok, r5.status)
        time.sleep(1.0)
        mc.send_cmd("stop")


def test_idempotency_e2e(port: int) -> None:
    """[D3] 命令幂等语义: 同字节重发 = 重放应答, 不重执行; 不同 seq = 各执行一次。

    这两条是"连续发相同运动命令"能安全工作的前提, 也解释了主机为什么敢在超时后
    原样重发(命令层 `CommandClient.poll()` 的字节不变重发)。
    以前**没有任何测试覆盖它** —— 因为上层 API 从不会发出重复命令,
    所以只能直接构造同一份字节从链路灌进去。

    判据用固件的异步行 `MOVEDONE RUN ...`: 它只在运动真正结束时发一次,
    于是"发几次 / 执行几次"一眼可数。
    """
    print("\n[D3] 幂等: 同字节重发不重执行 / 不同 seq 各执行一次")
    from host.api import MouseClient
    from host.api.events import Event

    with MouseClient.connect_to(f"tcp://127.0.0.1:{port}") as mc:
        got: list = []
        mc.on(Event.TEXT, lambda m: got.append(m.data.get("line", "")))
        # 前序用例跑过自走/运动, 先回到空闲再测幂等
        mc.send_cmd("stop")
        time.sleep(0.3)

        def _run_once(seq: int, times: int, text: str = "MOVE RUN 30 30 1") -> None:
            line = mc.cmd._build(text, seq)
            for _ in range(times):
                mc.link.write(line)
                time.sleep(0.35)

        # (1) 同一份字节发 3 次 -> 应答 3 条(重放), MOVEDONE 只 1 条
        # 注意: ACK 行会被命令层就地匹配掉、**不会**变成 TEXT 事件,
        # 所以应答条数要从命令层日志里数(它记录了每一行收发)。
        got.clear()
        n_log = len(mc.cmd.log)
        _run_once(77, 3)
        time.sleep(0.8)
        acks = [t for _ts, d, t in mc.cmd.log[n_log:] if d == "<-" and t.startswith("ACK 77 ")]
        moves = [l for l in got if l.startswith("MOVEDONE")]
        check("同字节 x3: 每条都得到应答(重放)", len(acks) == 3, str(acks))
        check("同字节 x3: 只执行一次(1 条 MOVEDONE)", len(moves) == 1, str(moves))

        # (2) 相同文本但不同 seq -> 是两条独立命令, 各执行一次
        got.clear()
        _run_once(78, 1)
        time.sleep(0.2)
        _run_once(79, 1)
        time.sleep(0.8)
        moves2 = [l for l in got if l.startswith("MOVEDONE")]
        check("不同 seq x2: 两条都执行(2 条 MOVEDONE)", len(moves2) == 2, str(moves2))
        check("不同 seq x2: 两次运行都带完整明细",
              all(len(m.split()) >= 9 for m in moves2), str(moves2))


def test_params_e2e(port: int) -> None:
    print("\n[D2] 每个参数读写往返一致")
    from host.api import MouseClient

    with MouseClient.connect_to(f"tcp://127.0.0.1:{port}") as mc:
        for name, nid in sorted(PARAM_IDS.items(), key=lambda kv: kv[1]):
            # 读原始值, 写回同一个值, 再读校验(用 SETQ 保证无精度损失)
            before = mc.params.get_raw(name)
            if before is None:
                check(f"{name}: 可回读", False)
                continue
            r = mc.params.set_raw(name, before, readback=True)
            check(f"{name}: 写回并校验", r.ok, r.status)
            check(f"{name}: 回读与写入一致", r.ok and r.data.get("readback") == before,
                  str(r.data.get("readback")))


# ---------------------------------------------------------------- 示例参数

_EXAMPLE_ARGS = {
    "name": "TRACKL",
    "q": float_to_q1616(53.2),
    "v": "53.2",
    "hz": 5,
    "item": "GYRO",
    "act": "START",
    "pulses": 3000,
    "speed": 40,
    "pwm": 40,
    "ms": 100,
    "cond": "TASK",
    "sp_l": 40,
    "sp_r": -40,
    "ir_mm": 10,
    # ---- 课程调参实验 ----
    "exp": 3,           # lesson.start
    "a": 50,            # v  (实验三/四/七) 或 angle (实验六)
    "b": 200,           # dist (实验三/七) 或 t_acc (实验四) 或 v (实验六)
    "c": 800,           # ms (实验三/六/七) 或 t_cruise (实验四)
    "d": 200,           # t_dec (实验四)
    # ---- 迷宫状态机回传 ----
    "mask": "DEF",      # maze.ev: 事件掩码 OFF/DEF/ALL/0..63(省略=查询)
    # ---- SNAP 阻塞式快照 ----
    "dom": "ALL",       # snap.get 的数据域; ALL/MOTION/ODOM/SENSE/POWER/TIME/MAZE
    # ---- SCOPE 录制剖面 ----
    "prof": "A",        # scope.start 的录制剖面; A/B/C/D/E
}


def _payload_fast() -> bytes:
    return struct.pack("<hhhhhhBBBB", 68, -12, 90, 5, 68, -12, 32, 76, 0x01, 0)


def _payload_mid() -> bytes:
    return struct.pack("<hhhhhh", 120, 300, 301, 2048, 12, 45)


def _payload_slow() -> bytes:
    return struct.pack("<hhhhBBbbHBB", 232, 231, 42, 43, 0x05, 2, 3, 4, 762, 21, 0)


def _payload_dump_hdr() -> bytes:
    return struct.pack("<HBBHHI", 1200, 60, 4, 900, 300, 55555)


def _payload_time() -> bytes:
    # upMs(u32) | armMs(u32) | led(u8) | flags(u8) | rsvd(u16)
    return struct.pack("<IIBBH", 12345, 10000, 1, 0x07, 0)


def _payload_maze() -> bytes:
    # task road opens motion x y dir stack flags evMask evCount(u16) juncCnt(u16) turnCnt deadCnt
    return struct.pack("<BBBBBBBBBBHHBB", 2, 4, 3, 101, 6, 5, 1, 9, 0x09, 0x1F, 42, 3, 7, 1)


def _payload_dump_blk() -> bytes:
    body = bytearray()
    for i in range(4):
        body += struct.pack("<BBhhh", 32, 0, 90 + i, 40 + i, -40 - i)
    return struct.pack("<H", 3) + bytes(body)


def _payload_dump_end() -> bytes:
    return struct.pack("<i", 123456)


def _payload_map() -> bytes:
    n = 7
    wall = bytes([0x03] * (n * n))
    vis = bytes([1] * (n * n))
    return struct.pack("<bbBB", 3, 4, 1, 2) + wall + vis


_PAYLOAD_BUILDERS = {
    TYPE_FAST: _payload_fast,
    TYPE_MID: _payload_mid,
    TYPE_SLOW: _payload_slow,
    TYPE_DUMP_HDR: _payload_dump_hdr,
    TYPE_DUMP_BLK: _payload_dump_blk,
    TYPE_DUMP_END: _payload_dump_end,
    TYPE_MAP: _payload_map,
    TYPE_TIME: _payload_time,
    TYPE_MAZE: _payload_maze,
}


def main() -> int:
    ap = argparse.ArgumentParser(description="注册表契约测试")
    ap.add_argument("--port", type=int, default=0, help="已运行模拟器端口(默认自动拉起)")
    args = ap.parse_args()

    print("=" * 66)
    print("电脑鼠上位机 注册表契约测试")
    print("=" * 66)
    test_static()
    test_command_build()
    test_frames_roundtrip()

    port = args.port or _free_port()
    proc = None
    if not args.port:
        proc = subprocess.Popen(
            [sys.executable, "-m", "host.sim.mouse_sim", "--port", str(port), "--no-auto"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        time.sleep(1.2)

    try:
        test_commands_e2e(port)
        test_idempotency_e2e(port)
        test_motion_mutex_e2e(port)
        test_estop_recoverable_e2e(port)
        test_params_e2e(port)
    finally:
        if proc is not None:
            proc.terminate()
            try:
                proc.wait(timeout=3)
            except subprocess.TimeoutExpired:
                proc.kill()

    print("\n" + "=" * 66)
    print(f"通过 {PASS} / 失败 {FAIL}")
    print("=" * 66)
    return 1 if FAIL else 0


if __name__ == "__main__":
    sys.exit(main())
