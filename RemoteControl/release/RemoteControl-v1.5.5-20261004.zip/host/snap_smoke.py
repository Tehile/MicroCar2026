"""SNAP 阻塞式测量快照 冒烟测试。

覆盖三件事:
  1. **纯函数层**: `parse_snap_line` / `decode_ir_sat` 的字段序、容错、位域拆分 —— 离线可跑;
  2. **协议层**: `SNAP` 命令拼装、`SNAP_FIELDS` 与固件 link_SnapLine 的字段数一致性;
  3. **端到端**: 起模拟器 → `mc.snap.read()` 各域 → 派生视图(ir_channels/battery/as_frames/check_battery)。

设计要点: SNAP 是"非数据采集阶段获取全部可测量量"的唯一入口, 所以这里必须验到
"既有遥测帧里的量也能通过 SNAP 拿到"(MOTION/ODOM/SENSE 三域与 fast/mid/slow 同字段名),
否则 monitor 就得为它单开一条显示分支。

用法: python snap_smoke.py [--port N]
"""

from __future__ import annotations

import argparse
import socket
import struct
import subprocess
import sys
import time

sys.path.insert(0, ".")

from host.api.client import MouseClient
from host.protocol.codec import (
    DUMP_PROFILE_CHANNELS,
    DUMP_PROFILE_NOTES,
    IR_SAT_FAR,
    IR_SAT_NEAR,
    IR_SAT_NORMAL,
    SNAP_FIELDS,
    decode_dump_blk,
    decode_ir_sat,
    dump_profile,
    parse_snap_line,
)
from host.protocol.commands import PARAM_IDS, PRODUCTION_PARAM_IDS
from host.registry import COMMANDS, command_line

PASS = 0
FAIL = 0


def check(name: str, ok: bool, detail: str = "") -> bool:
    global PASS, FAIL
    if ok:
        PASS += 1
        print(f"  [ok]   {name}")
    else:
        FAIL += 1
        print(f"  [FAIL] {name}  {detail}")
    return bool(ok)


def _free_port() -> int:
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    p = s.getsockname()[1]
    s.close()
    return p


# ---------------------------------------------------------------- 离线: 解析层

def test_parse_offline() -> None:
    print("\n[P1] parse_snap_line / decode_ir_sat(离线)")

    line = "SNAP SENSE 830 854 2474 158 180 178 43 236 179 0 5 0 0 2 1 160"
    rec = parse_snap_line(line)
    check("SENSE 行可解析", bool(rec) and rec["domain"] == "SENSE", repr(rec))
    fields = rec["fields"]
    check("字段数 = 16", len(fields) == 16, str(len(fields)))
    check("字段序正确(adcF1..wallThresh)",
          fields["adcF1"] == 830 and fields["irF1"] == 180 and fields["irF"] == 179
          and fields["irSat"] == 0 and fields["wallBits"] == 5
          and fields["mouseTask"] == 2 and fields["wallThresh"] == 160,
          repr(fields))
    check("全部值都是 int", all(isinstance(v, int) for v in fields.values()), repr(fields))

    check("字段名与 SNAP_FIELDS 声明一致",
          set(fields) == set(SNAP_FIELDS["SENSE"]), str(set(SNAP_FIELDS["SENSE"]) - set(fields)))

    # 容错: 短行不抛异常, 缺的字段就不出现(与 parse_movedone_run 同策略)
    short = parse_snap_line("SNAP POWER 3155 7626")
    check("短行不抛异常且只给已有字段",
          bool(short) and short["fields"] == {"adcBatt": 3155, "battMv": 7626}, repr(short))

    # 多字段(固件领先)也不报错
    long_line = "SNAP TIME 1 2 3 4 5 6 7 8 9 10"
    lg = parse_snap_line(long_line)
    check("超长行只取声明的字段数",
          bool(lg) and len(lg["fields"]) == len(SNAP_FIELDS["TIME"]), repr(lg))

    check("非 SNAP 行返回 None", parse_snap_line("P 1 100") is None)
    check("未知域返回 None", parse_snap_line("SNAP NOPE 1 2 3") is None)
    check("字段名非法时容忍(非整数原样保留)",
          parse_snap_line("SNAP TIME x 2 3 4 5 6 7")["fields"]["upMs"] == "x")

    # 位域: bit0-1=F1, bit2-3=F2, bit4-5=L, bit6-7=R
    sat = decode_ir_sat(0b11_10_01_00)
    check("irSat 位域拆分正确",
          sat == {"F1": 0, "F2": 1, "L": 2, "R": 3}, repr(sat))
    check("饱和常量语义正确",
          (IR_SAT_NORMAL, IR_SAT_NEAR, IR_SAT_FAR) == (0, 1, 2))
    check("全量程内 -> 全 0", all(v == 0 for v in decode_ir_sat(0).values()))

    # 各域的字段数与"与既有帧同名字段"的检查(MAZE 是后加的第六个域)
    check("六个域都有字段表", set(SNAP_FIELDS) == {"MOTION", "ODOM", "SENSE", "POWER", "TIME", "MAZE"},
          str(sorted(SNAP_FIELDS)))
    check("MOTION 含既有快帧的全部键",
          {"speedL", "speedR", "gyroAngle", "pidErr", "speedTargetL", "speedTargetR",
           "task", "flags"} <= set(SNAP_FIELDS["MOTION"]), str(SNAP_FIELDS["MOTION"]))
    check("ODOM 含既有中帧的全部键",
          {"cellOdom", "trackL", "trackR", "gyroRaw", "gyroDiff", "encAngle"}
          <= set(SNAP_FIELDS["ODOM"]), str(SNAP_FIELDS["ODOM"]))
    check("SENSE 含既有慢帧的全部键",
          {"irF1", "irF2", "irL", "irR", "posX", "posY"} <= set(SNAP_FIELDS["SENSE"]),
          str(SNAP_FIELDS["SENSE"]))


# ---------------------------------------------------------------- 离线: 协议层

def test_protocol_offline() -> None:
    print("\n[P2] 命令拼装与登记表")

    check("snap.get 已登记", "snap.get" in COMMANDS, str(sorted(COMMANDS)))
    check("无参数 -> SNAP", command_line("snap.get") == "SNAP", command_line("snap.get"))
    check("dom=None -> SNAP", command_line("snap.get", dom=None) == "SNAP")
    check("dom=POWER -> SNAP POWER",
          command_line("snap.get", dom="POWER") == "SNAP POWER",
          command_line("snap.get", dom="POWER"))
    check("dom 小写会规范成大写",
          command_line("snap.get", dom="sense") == "SNAP SENSE",
          command_line("snap.get", dom="sense"))

    # 参数分段
    check("PARAM_IDS 共 38 项", len(PARAM_IDS) == 38, str(len(PARAM_IDS)))
    check("生产段 24 项", len(PRODUCTION_PARAM_IDS) == 24, str(len(PRODUCTION_PARAM_IDS)))
    check("id 22-38 全部登记在案",
          all(PARAM_IDS[n] in range(22, 39)
              for n in ("IRTHRWALL", "IRTHR45", "IRTHRCRIT", "IRTHRFLO", "IRTHRFMID",
                        "IRTHRFHI", "IRTHRFNEAR", "IRKALQ", "IRKALP", "IRKALSW",
                        "IRFRONTMODE", "BATTKV", "BATTLOWMV", "BATTHIGHMV",
                        "BATTALPHA", "BATTMAXPCT", "BATTMINPCT")),
          str(sorted(PRODUCTION_PARAM_IDS)))
    check("id -> 名字 反向表自洽",
          all(PARAM_IDS[n] == i for n, i in PARAM_IDS.items() if n in PRODUCTION_PARAM_IDS))


# ---------------------------------------------------------------- 离线: 剖面

def test_profiles_offline() -> None:
    print("\n[P4] SCOPE 录制剖面(离线)")

    check("五个剖面都有通道名", set(DUMP_PROFILE_CHANNELS) == {"A", "B", "C", "D", "E"},
          str(sorted(DUMP_PROFILE_CHANNELS)))
    check("每个剖面都是 4 个 u16 通道(8B/点)",
          all(len(v) == 4 for v in DUMP_PROFILE_CHANNELS.values()), str(DUMP_PROFILE_CHANNELS))
    check("剖面 A 通道名 = 旧 RunData 布局",
          DUMP_PROFILE_CHANNELS["A"] == ["motionTask", "gangle", "speedl", "speedr"],
          str(DUMP_PROFILE_CHANNELS["A"]))
    check("剖面 B 是四路红外距离",
          DUMP_PROFILE_CHANNELS["B"] == ["irF1", "irF2", "irL", "irR"],
          str(DUMP_PROFILE_CHANNELS["B"]))
    check("剖面 C 是四路红外原始 ADC",
          DUMP_PROFILE_CHANNELS["C"] == ["adcF1", "adcF2", "adcL", "adcR"],
          str(DUMP_PROFILE_CHANNELS["C"]))
    check("剖面 D 含电池 mV/ADC",
          "battMv" in DUMP_PROFILE_CHANNELS["D"] and "adcBatt" in DUMP_PROFILE_CHANNELS["D"],
          str(DUMP_PROFILE_CHANNELS["D"]))
    check("每个剖面都有人话说明",
          all(DUMP_PROFILE_NOTES.get(p) for p in DUMP_PROFILE_CHANNELS), str(DUMP_PROFILE_NOTES))

    # channels 字节 -> 剖面: A 报 4(兼容旧值), B..E 报 ASCII
    check("channels=4 -> 剖面 A(向后兼容)", dump_profile(4) == "A", dump_profile(4))
    check("channels='B' -> 剖面 B", dump_profile(ord("B")) == "B", dump_profile(ord("B")))
    check("channels='E' -> 剖面 E", dump_profile(ord("E")) == "E", dump_profile(ord("E")))
    check("未知 channels 一律当 A(向前兼容)", dump_profile(0x99) == "A", dump_profile(0x99))

    # 命令拼装
    check("SCOPE START 不带剖面 = 旧行为",
          command_line("scope.start") == "SCOPE START", command_line("scope.start"))
    check("scope.start(prof='B') -> SCOPE START B",
          command_line("scope.start", prof="B") == "SCOPE START B",
          command_line("scope.start", prof="B"))
    check("scope.start(prof='b') 由上位机规范成大写",
          command_line("scope.start", prof="b") == "SCOPE START B",
          command_line("scope.start", prof="b"))

    # dump 块解码: records(旧) 与 words(新) 必须同时给出
    body = struct.pack("<H", 3) + struct.pack("<HHHH", 100, 200, 300, 400) * 2
    rec = decode_dump_blk(body)
    check("dump 块同时解出 records 与 words",
          len(rec["records"]) == 2 and len(rec["words"]) == 2, repr(rec))
    check("words 是原始 4×u16",
          rec["words"][0] == (100, 200, 300, 400), repr(rec["words"][0]))
    check("records 仍是旧语义(剖面 A)",
          len(rec["records"][0]) == 4, repr(rec["records"][0]))


# ---------------------------------------------------------------- 端到端

def _profile_checks(mc) -> None:
    print("\n[P5] SCOPE 剖面端到端(模拟器)")
    for prof, key in (("A", "speedl"), ("B", "irF1"), ("C", "adcF1"),
                      ("D", "battMv"), ("E", "battMv")):
        got = mc.scope.fetch_data(prof, collect_s=0.25, timeout=90.0)
        if not check(f"剖面 {prof}: 采集+回传成功", got is not None, "fetch_data 返回 None"):
            continue
        p, t, ch = got
        check(f"剖面 {prof}: 剖面标识正确", p == prof, f"got {p}")
        check(f"剖面 {prof}: 通道名与声明一致",
              list(ch) == DUMP_PROFILE_CHANNELS[prof], str(list(ch)))
        check(f"剖面 {prof}: 拿到 {len(t)} 点且长度对齐",
              len(t) > 0 and all(len(v) == len(t) for v in ch.values()),
              f"t={len(t)} " + str({k: len(v) for k, v in ch.items()}))
        check(f"剖面 {prof}: 含关键通道 {key}", key in ch, str(list(ch)))

    # 剖面 A 的旧接口必须仍然可用(回归保护)
    arr = mc.store.dump_arrays()
    check("剖面 A 的 dump_arrays() 旧接口仍可用",
          arr is not None and len(arr) == 5, str(None if arr is None else len(arr)))

    r = mc.scope.start("Z")
    check("非法剖面回 ERR_VALUE", (not r.ok) and r.status == "ERR_VALUE", r.status)
    r = mc.scope.start("b")
    check("小写剖面被接受(与固件一致)", r.ok, r.status)


def _snap_checks(port: int) -> None:
    print("\n[P3] 端到端(模拟器)")
    mc = MouseClient()
    if not check("连接模拟器", mc.connect(f"tcp://127.0.0.1:{port}"), "connect failed"):
        return
    try:
        snap = mc.snap.read()
        check("read() 取回 6 个域", len(snap) == 6, str(sorted(snap)))
        check("域名正确", set(snap) == set(SNAP_FIELDS), str(sorted(snap)))
        check("每个域字段齐备(按 SNAP_FIELDS 声明长度)",
              all(len(snap[d]) == len(SNAP_FIELDS[d]) for d in SNAP_FIELDS),
              str({d: len(snap[d]) for d in snap}))
        check("last_status = OK", mc.snap.last_status() == "OK", mc.snap.last_status())

        # 单域读取: 只发 1 行, 缓存里就只有那一个域
        only = mc.snap.read(["POWER"])
        check("单域读取只回 1 个域", set(only) == {"POWER"}, str(sorted(only)))
        check("单域读取也成功", mc.snap.last_status() == "OK", mc.snap.last_status())

        # 既有遥测量确实能通过 SNAP 拿到(这是本功能的存在理由)
        flat = mc.snap.read_flat()
        for k in ("speedL", "speedR", "gyroAngle", "cellOdom", "trackL", "irF1", "posX", "posY"):
            check(f"SNAP 覆盖既有量 {k}", k in flat, str(sorted(flat)))

        # as_frames: 映射成遥测帧视角, 且与读到的域一致
        frames = mc.snap.as_frames(snap)
        check("as_frames 产出 fast/mid/slow/time/maze",
              set(frames) == {"fast", "mid", "slow", "time", "maze"}, str(sorted(frames)))
        check("fast 视图含 speedL", "speedL" in frames["fast"], repr(frames["fast"]))
        check("slow 视图是 SENSE+POWER 合并",
              "irF1" in frames["slow"] and "battMv" in frames["slow"], repr(sorted(frames["slow"])))
        check("slow 视图补出 volt 派生键(与慢帧同名, 便于复用显示代码)",
              abs(float(frames["slow"].get("volt", -1)) - int(frames["slow"]["battMv"]) / 1000.0) < 1e-9,
              repr(frames["slow"].get("volt")))

        # 红外合并视图
        ch = mc.snap.ir_channels(snap)
        check("ir_channels 给全四路 + 前向综合",
              set(ch) == {"F1", "F2", "L", "R", "F"}, str(sorted(ch)))
        check("每路含 adc/mm/sat/sat_text/trustworthy",
              all({"adc", "mm", "sat", "sat_text", "trustworthy"} <= set(ch[k])
                  for k in ("F1", "F2", "L", "R")), str(ch))
        check("adm 与 mm 同时存在(测距 + 原始值)",
              all(ch[k]["adc"] is not None and ch[k]["mm"] is not None for k in ("F1", "F2", "L", "R")),
              str(ch))
        check("饱和文字是人话",
              all(ch[k]["sat_text"] in ("正常", "近端饱和", "远端超量程") for k in ("F1", "F2", "L", "R")),
              str(ch))

        # 电源视图 + 可判定结论
        bat = mc.snap.battery(snap)
        check("battery 含 adc/mv/volt/pct/low/enabled",
              set(bat) == {"adc", "mv", "volt", "pct", "low", "enabled"}, str(bat))
        check("volt == mv/1000", abs(bat["volt"] - bat["mv"] / 1000.0) < 1e-9, str(bat))
        r = mc.snap.check_battery(snap)
        check("check_battery 给出结论", r.status in ("OK", "LOW_BATTERY", "BATT_DISABLED"), r.status)
        check("check_battery 带回阈值(用固件参数 BATTLOWMV)",
              "threshold_mv" in r.data or r.status != "OK", repr(r))

        # explain 是人可读的
        lines = mc.snap.explain(snap)
        check("explain 输出 5 行(运动/里程/红外/电源/时基)", len(lines) == 5, str(len(lines)))
        check("explain 含电压与红外", any("V" in l for l in lines) and any("mm" in l for l in lines),
              str(lines))

        # 轮询: 主机侧定时器, 2 Hz 跑 1 秒应拿到 >=1 个样本
        t0 = time.time()
        samples = mc.snap.poll(hz=2.0, dur=1.0, domains=["POWER"])
        el = time.time() - t0
        check("poll 定时执行(~1s)", len(samples) >= 1 and 0.6 <= el <= 2.5,
              f"n={len(samples)} el={el:.2f}")
        check("poll 样本都是 POWER 域",
              all("POWER" in s for s in samples), str([sorted(s) for s in samples]))

        # 未读过时的 age
        check("age_ms 有值", mc.snap.age_ms() is not None, str(mc.snap.age_ms()))

        # 坏域名 -> 固件回 ERR_VALUE, 上位机不应崩
        r2 = mc.send_cmd("snap.get", dom="NOPE")
        check("非法域名回 ERR_VALUE", (not r2.ok) and r2.status == "ERR_VALUE", r2.status)

        # 参数: 新增 17 项必须可读可写(真机路径同构)
        got = mc.params.get_all()
        missing = [n for n in PRODUCTION_PARAM_IDS if n not in got]
        check("新增生产参数全部能回读", not missing, str(missing))
        ok, st = False, ""
        for name, val in (("IRTHRWALL", 175.0), ("IRKALQ", 150.0), ("BATTKV", 2500.0),
                          ("BATTLOWMV", 6900.0), ("IRFRONTMODE", 1.0), ("IRKALSW", 0.0)):
            r3 = mc.params.set(name, val, readback=True)
            check(f"{name} 写+回读校验", r3.ok, f"{r3.status} {r3.data}")
            back = mc.params.get(name)
            check(f"{name} 回读值一致", back is not None and abs(back - val) < 1e-6,
                  f"got {back} want {val}")
    finally:
        mc.close()


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=0)
    args = ap.parse_args()

    print("=" * 66)
    print("SNAP 阻塞式测量快照 冒烟测试")
    print("=" * 66)

    test_parse_offline()
    test_protocol_offline()
    test_profiles_offline()

    port = args.port or _free_port()
    proc = None
    if not args.port:
        proc = subprocess.Popen(
            [sys.executable, "-m", "host.sim.mouse_sim", "--port", str(port), "--no-auto"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        time.sleep(1.2)
    try:
        _snap_checks(port)
        mc = MouseClient()
        if mc.connect(f"tcp://127.0.0.1:{port}"):
            try:
                _profile_checks(mc)
            finally:
                mc.close()
        else:
            check("连接模拟器(剖面测试)", False, "connect failed")
    finally:
        if proc is not None:
            proc.terminate()
            try:
                proc.wait(timeout=3)
            except subprocess.TimeoutExpired:
                proc.kill()

    print("\n" + "=" * 66)
    print(f"通过 {PASS} / 失败 {FAIL}")
    print("=" * 66)
    return 1 if FAIL else 0


if __name__ == "__main__":
    raise SystemExit(main())
