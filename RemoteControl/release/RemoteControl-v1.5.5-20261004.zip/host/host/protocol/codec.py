"""字节级编解码: CRC16 / Q16.16 / 上行二进制帧 / 流式分流解析器。

帧格式(与固件 link.c 完全一致):
    AA 55 | LEN(2, LE) | TYPE | SEQ | PAYLOAD(LEN) | CRC16(2, LE)

CRC16 覆盖 TYPE/SEQ/PAYLOAD, 采用 MODBUS 多项式 0xA001、初值 0xFFFF。
校验向量: crc16(b"123456789") == 0x4B37

与 printf 文本共存的依据:
    printf 只产出 0x09-0x7E + CR/LF, 永远不可能产出 0xAA,
    因此见到 0xAA 即尝试按帧解析, 校验失败则回退当作文本。
"""

from __future__ import annotations

import struct
from dataclasses import dataclass
from typing import Iterator, List, Optional

# ---------------------------------------------------------------- 常量

SYNC0 = 0xAA
SYNC1 = 0x55
FRAME_OVERHEAD = 8  # 同步2 + LEN2 + TYPE1 + SEQ1 + CRC2

TYPE_FAST = 0x01
TYPE_MID = 0x02
TYPE_SLOW = 0x03
TYPE_DUMP_HDR = 0x04
TYPE_DUMP_BLK = 0x05
TYPE_DUMP_END = 0x06
TYPE_MAP = 0x07
TYPE_TIME = 0x08  # 时间同步帧 @1Hz: upMs(u32) | armMs(u32) | led(u8) | flags(u8) | rsvd(u16)
TYPE_MAZE = 0x09  # 迷宫状态机帧 @1Hz(仅迷宫态): 见 decode_maze

FAST_LEN = 16
MID_LEN = 12
SLOW_LEN = 16
DUMPHDR_LEN = 12  # totalPts(u16) ptsPerBlk(u8) channels(u8) filled(u16) start(u16) startMs(u32)
TIME_LEN = 12
SCOPE_PTS_PER_BLK = 60
DUMPBLK_LEN = 2 + SCOPE_PTS_PER_BLK * 8  # 482
DUMPEND_LEN = 4

# 环形缓冲深度(固件复用 run_data[1200], 1kHz -> 1.2s)
SCOPE_LEN = 1200
SCOPE_BLKS = SCOPE_LEN // SCOPE_PTS_PER_BLK  # 20

# 快帧 flags 位
FLAG_FREEMODE = 0x01
FLAG_SLEEP = 0x02
FLAG_EMERG = 0x04
FLAG_SCOPING = 0x08
FLAG_DUMPING = 0x10
FLAG_MOTOR_OFF = 0x20  # 固件安全测试模式: 电机被物理禁用(不启用 PWM, 引脚恒低)
FLAG_ESTOP_LOCK = 0x40  # 急停**锁存**中: 新的 MOVE/CAL 会被拒(ERR_ESTOP), 须 STOP 解锁
FLAG_RUNLOG = 0x80  # 运动详细日志已就绪: 1kHz 环已冻结, 可直接 SCOPE DUMP

# 时间同步帧 flags 位
TIME_FLAG_ARMED = 0x01  # 已发车(固件已收到 ARM)
TIME_FLAG_MAZERUN = 0x02  # 无记忆走迷宫正在跑
TIME_FLAG_BEACON = 0x04  # 当前 1Hz 时间基准灯电平

# 墙位编码(mapWall 低四位: bit0=上 bit1=右 bit2=下 bit3=左; 置位表示"无墙/可通行")
WALL_UP_OPEN = 0x01
WALL_RIGHT_OPEN = 0x02
WALL_DOWN_OPEN = 0x04
WALL_LEFT_OPEN = 0x08
WALL_LOW_NIBBLE = 0x0F

# 任务码(maze.h): WAIT/START/MAZESEARCH/SPURT/SPURT_45/SPURT_90
TASK_NAMES = {
    0: "WAIT",
    1: "START",
    2: "MAZESEARCH",
    3: "SPURT",
    4: "SPURT_45",
    5: "SPURT_90",
}

# 运动任务码(core.h MotionTask_t), 仅列常用的, 其余显示数字
MOTION_TASK_NAMES = {
    0: "NULL",
    1: "GOSTRAIGHT",
    2: "TURN",
    4: "TURNAROUND",
    5: "STOP",
    17: "STRAIGHT45",
    27: "BEFORE90TURN",
    28: "BEFORE180TURN",
    30: "SMARTSTRAIGHT",
    32: "SMARTSTRAIGHTFAST",
    33: "STRAIGHTEYECLOSECOORADJ",
    34: "STRAIGHTPOLE",
    35: "ACC",
    36: "SLOWDOWN",
    37: "SPEEDUP",
    38: "KEEPWALLDISTANCE",
    39: "POINTTURN90",
    41: "FORWARDIRTEST",
    42: "SPURT90BLIND",
    43: "SPURT90IR",
    44: "SMARTSTRAIGHTSPURT",
    45: "SMARTSTRAIGHTSPURTL",
    46: "TURNLEFTFAST",
    47: "TURNRIGHTFAST",
    48: "EMERGENCY",
    49: "SUPERSTRAIGHT",
    50: "INFRSTRAIGHT",
    51: "FASTSTRAIGHT",
    52: "EDGESTRAIGHT",
    53: "CHANGESPEED",
    # ---- 搜索/冲刺转弯(与固件 core.h 的 MotionTask_t 101-107 一致) ----
    101: "LT90SEARCH",
    102: "RT90SEARCH",
    103: "POINTR90",
    104: "POINTL90",
    105: "STRAIGHT_SPURT_90",
    106: "LT90SPURT",
    107: "RT90SPURT",
}


# ---------------------------------------------------------------- CRC16

def _build_crc_table() -> List[int]:
    table = []
    for i in range(256):
        crc = i
        for _ in range(8):
            crc = (crc >> 1) ^ 0xA001 if crc & 1 else crc >> 1
        table.append(crc)
    return table


_CRC_TABLE = _build_crc_table()


def crc16_modbus(data: bytes) -> int:
    """CRC16/MODBUS, 与固件 link_Crc16 输出逐位一致。"""
    crc = 0xFFFF
    for b in data:
        crc = (crc >> 8) ^ _CRC_TABLE[(crc ^ b) & 0xFF]
    return crc


# ---------------------------------------------------------------- Q16.16

def q1616_to_float(q: int) -> float:
    return q / 65536.0


def float_to_q1616(v: float) -> int:
    """四舍五入到最近的可表示值(与固件 link_F2Q/link_D2Q 的取整方向一致)。"""
    scaled = v * 65536.0
    return int(scaled + 0.5) if scaled >= 0 else -int(-scaled + 0.5)


# ---------------------------------------------------------------- 帧

@dataclass
class Frame:
    type: int
    seq: int
    payload: bytes

    @property
    def type_name(self) -> str:
        return {
            TYPE_FAST: "FAST",
            TYPE_MID: "MID",
            TYPE_SLOW: "SLOW",
            TYPE_DUMP_HDR: "DUMP_HDR",
            TYPE_DUMP_BLK: "DUMP_BLK",
            TYPE_DUMP_END: "DUMP_END",
            TYPE_MAP: "MAP",
            TYPE_TIME: "TIME",
        }.get(self.type, f"0x{self.type:02X}")


def pack_frame(ftype: int, payload: bytes, seq: int = 0) -> bytes:
    """构造一个完整帧(固件与模拟器共用, 保证两侧字节级一致)。"""
    head = struct.pack("<BBHBB", SYNC0, SYNC1, len(payload), ftype, seq & 0xFF)
    body = head[4:] + payload  # TYPE/SEQ/PAYLOAD
    return head + payload + struct.pack("<H", crc16_modbus(body))


# ---------------------------------------------------------------- 载荷解码

def decode_fast(p: bytes) -> dict:
    (sl, sr, ang, perr, tl, tr, task, volt, flags, rsvd) = struct.unpack("<hhhhhhBBBB", p)
    return {
        "speedL": sl,
        "speedR": sr,
        "gyroAngle": ang,
        "pidErr": perr,
        "speedTargetL": tl,
        "speedTargetR": tr,
        "task": task,
        "volt": volt / 10.0,
        "flags": flags,
        "freemode": bool(flags & FLAG_FREEMODE),
        "sleep": bool(flags & FLAG_SLEEP),
        "emerg": bool(flags & FLAG_EMERG),
        "scoping": bool(flags & FLAG_SCOPING),
        "dumping": bool(flags & FLAG_DUMPING),
        "motors_off": bool(flags & FLAG_MOTOR_OFF),
        "estop_lock": bool(flags & FLAG_ESTOP_LOCK),
        "runlog": bool(flags & FLAG_RUNLOG),
        # 时间同步: 原来恒 0 的保留字节, 现在是"设备毫秒时基的低 8 位"。
        # 单看它只能定位到 256ms 窗口, 配合 1Hz 的 TIME 帧(带完整 u32)就能把
        # 每个快帧钉到准确时刻 —— 见 host/host/api/timesync.py。
        "ms8": rsvd,
    }


def decode_mid(p: bytes) -> dict:
    (cell, tl, tr, graw, gdiff, eang) = struct.unpack("<hhhhhh", p)
    return {
        "cellOdom": cell,
        "trackL": tl,
        "trackR": tr,
        "gyroRaw": graw,
        "gyroDiff": gdiff,
        "encAngle": eang,
    }


def decode_slow(p: bytes) -> dict:
    (f1, f2, l, r) = struct.unpack("<hhhh", p[:8])
    wall, mtask, px, py = struct.unpack("<BBbb", p[8:12])
    (volt100,) = struct.unpack("<H", p[12:14])
    cpu, drop = struct.unpack("<BB", p[14:16])
    return {
        "irF1": f1,
        "irF2": f2,
        "irL": l,
        "irR": r,
        "wallBits": wall,
        "wallLeft": bool(wall & 0x01),
        "wallRight": bool(wall & 0x02),
        "wallFront": bool(wall & 0x04),
        "wallLeft45": bool(wall & 0x08),
        "wallRight45": bool(wall & 0x10),
        "mouseTask": mtask,
        "mouseTaskName": TASK_NAMES.get(mtask, str(mtask)),
        "posX": px,
        "posY": py,
        "volt": volt100 / 100.0,
        "cpu": cpu,
        "drop": drop,
    }


def decode_map(p: bytes, mazetype: int) -> dict:
    """墙图帧: cX,cY,dir,task + mapWall[n*n] + mapVisited[n*n] (行主序 x 外层)。"""
    n = mazetype
    cx, cy, direction, task = struct.unpack("<bbBB", p[:4])
    wall = list(p[4 : 4 + n * n])
    visited = list(p[4 + n * n : 4 + 2 * n * n])
    grid = [[wall[x * n + y] for y in range(n)] for x in range(n)]
    vis = [[visited[x * n + y] for y in range(n)] for x in range(n)]
    return {
        "posX": cx,
        "posY": cy,
        "direction": direction,
        "mouseTask": task,
        "mapWall": grid,
        "mapVisited": vis,
        "mazetype": n,
    }


#: dump 的 `channels` 字节 -> 录制剖面。
#: **固件约定**: A 报 4(与旧版逐字节一致), B..E 报 ASCII 'B'..'E'。
#: 于是同一块 9600B 环能在不扩 RAM 的前提下分别记录运动学 / 红外 mm / 红外 ADC / 电压。
DUMP_PROFILES: Dict[int, str] = {
    4: "A",           # 运动学(默认, 旧行为)
    ord("B"): "B",    # 四路红外距离 mm
    ord("C"): "C",    # 四路红外原始 ADC
    ord("D"): "D",    # 前向综合 mm + 电池 mV + 电池 ADC + 预留
    ord("E"): "E",    # 前右/前左 mm + 电池 mV + 运动任务码
}

#: 剖面 -> 4 个 u16 通道的**字段名**(顺序即内存顺序)。
#: A 的 4 项与 `decode_dump_blk` 的 records 同义, 只是走 words 通道统一处理。
DUMP_PROFILE_CHANNELS: Dict[str, List[str]] = {
    "A": ["motionTask", "gangle", "speedl", "speedr"],
    "B": ["irF1", "irF2", "irL", "irR"],
    "C": ["adcF1", "adcF2", "adcL", "adcR"],
    "D": ["distF", "battMv", "adcBatt", "rsvd"],
    "E": ["irF2", "irF1", "battMv", "motionTask"],
}

#: 剖面 -> 人话(CLI / 文档用)
DUMP_PROFILE_NOTES: Dict[str, str] = {
    "A": "运动学: 任务码/航向角/左右轮速度(与 SCOPE 原行为一致)",
    "B": "四路红外距离 mm(1kHz 红外测距)",
    "C": "四路红外原始 ADC(标定表拟合用)",
    "D": "前向综合 mm + 电池 mV/ADC(看电机启停瞬间的跌落)",
    "E": "前右/前左 mm + 电池 mV + 任务码(混合)",
}


def dump_profile(channels: int) -> str:
    """把 DUMP_HDR 的 channels 字节翻成剖面字母; 不认识的一律当 A(向前兼容)。"""
    return DUMP_PROFILES.get(int(channels), "A")


def decode_dump_hdr(p: bytes) -> dict:
    """dump 头。

    filled = 本次实际采集到的点数(<= totalPts); start = 环缓冲写指针。
    二者决定主机如何把"块 0 起"的线性回传还原成时间正序(见 TelemetryStore.dump_arrays)。

    startMs = 回传数组中**最早一点**的绝对设备毫秒时基。有了它, 1kHz 数据就能
    直接画在绝对时间轴上(t = startMs + i), 与 ARM 发车时刻、1Hz 基准灯完全对齐 ——
    这是"高分辨率数据也要能对时"的落点。旧固件/模拟器若不填, 该字段为 0。
    """
    (total, per_blk, ch, filled, start, start_ms) = struct.unpack("<HBBHHI", p)
    return {
        "totalPts": total,
        "ptsPerBlk": per_blk,
        "channels": ch,
        "filled": filled,
        "start": start,
        "startMs": start_ms,
    }


def decode_time(p: bytes) -> dict:
    """时间同步帧: upMs(u32 LE) | armMs(u32 LE) | led(u8) | flags(u8) | rsvd(u16,LE)。

    upMs   : 固件上电以来的毫秒时基(u32, 49 天不回绕)
    armMs  : 发车(ARM)时刻在 upMs 上的读数; 0 = 尚未武装
    led    : 当前 1Hz 时间基准灯电平(0/1)
    flags  : bit0=已武装 bit1=迷宫在跑 bit2=基准灯亮
    """
    up_ms, arm_ms = struct.unpack("<II", p[:8])
    led, flags = struct.unpack("<BB", p[8:10])
    return {
        "upMs": up_ms,
        "armMs": arm_ms,
        "devMs": (up_ms - arm_ms) if arm_ms else 0,
        "led": led,
        "flags": flags,
        "armed": bool(flags & TIME_FLAG_ARMED),
        "mazeRun": bool(flags & TIME_FLAG_MAZERUN),
        "beaconOn": bool(flags & TIME_FLAG_BEACON),
    }


def decode_dump_blk(p: bytes) -> dict:
    """dump 数据块: blkIdx u16 + N x 8B。

    这 8 字节就是固件 RunData 结构体的原生布局, DMA 直接搬运, 无任何转换。
    但 **8B 的含义取决于本次的"录制剖面"**(见 DUMP_HDR.channels):
      A(4) 运动学 → (motionTask, pad, gangle, speedl, speedr)  —— `records`
      B..E       → 四个 u16, 各自的物理量由剖面名决定           —— `words`

    所以这里**两种都解**: `records` 保持旧语义(剖面 A 的消费方零改动),
    `words` 额外给出原始 4×u16, 由 `TelemetryStore.dump_profile_arrays()` 按剖面命名。
    """
    (blk,) = struct.unpack("<H", p[:2])
    body = p[2:]
    n = len(body) // 8
    recs = []
    words = []
    for i in range(n):
        mt, _pad, ang, sl, sr = struct.unpack_from("<BBhhh", body, i * 8)
        recs.append((mt, ang, sl, sr))
        words.append(struct.unpack_from("<HHHH", body, i * 8))
    return {"blkIdx": blk, "records": recs, "words": words}


def decode_dump_end(p: bytes) -> dict:
    (chk,) = struct.unpack("<i", p[:4])
    return {"chksum": chk}


# ---------------------------------------------------------------- MOVE RUN

#: `MOVEDONE RUN` 的停止原因 -> 人话
RUN_REASON_NAMES = {
    "TIME": "到时停止(时间护栏)",
    "IR": "红外贴脸停止(红外护栏)",
    "ESTOP": "急停",
    "STOP": "STOP 命令",
    "USER": "其它",
}

#: 红外通道代号 -> 人话
IR_CHANNEL_NAMES = {"F1": "前左", "F2": "前右", "L": "左", "R": "右"}


def parse_movedone_run(fields: list) -> dict:
    """解析 `MOVEDONE RUN <REASON> <ms> <ir_min> <chan> <dL> <dR> <vpkL> <vpkR>`。

    `fields` 是设备异步行按空格切分后**从 "RUN" 开始**的那一段
    (即 `line.split()[1:]`, 见 MouseClient._on_async_line)。

    字段缺失时对应项为 None, 不抛异常 —— 设备固件版本可能领先/落后于上位机,
    解析器必须能容忍短行, 否则一条新固件的老行会让整个事件流中断。
    """

    def _num(i: int):
        try:
            return int(fields[i])
        except (IndexError, TypeError, ValueError):
            return None

    reason = str(fields[1]).upper() if len(fields) > 1 else ""
    return {
        "reason": reason,
        "reason_text": RUN_REASON_NAMES.get(reason, reason),
        "elapsed_ms": _num(2),
        "ir_min": _num(3),
        "ir_chan": str(fields[4]).upper() if len(fields) > 4 else None,
        "ir_chan_text": IR_CHANNEL_NAMES.get(
            str(fields[4]).upper() if len(fields) > 4 else "", ""
        ),
        "dL": _num(5),
        "dR": _num(6),
        "peak_l": _num(7),
        "peak_r": _num(8),
    }


# ---------------------------------------------------------------- SNAP 快照(阻塞式)

#: SNAP 各数据域的字段顺序。**必须与固件 link.c 的 link_SnapLine() 逐项一致**。
#: 命名刻意与 decode_fast / decode_mid / decode_slow 的字典键同名 ——
#: 于是 monitor / analyze 可以直接复用既有字段, 不需要为 SNAP 单开显示分支。
SNAP_FIELDS: Dict[str, List[str]] = {
    "MOTION": [
        "speedL", "speedR", "speedTargetL", "speedTargetR",
        "pidErr", "pwmMotorL", "pwmMotorR", "gyroAngle", "task", "flags",
    ],
    "ODOM": [
        "cellOdom", "trackL", "trackR", "gyroRaw", "gyroDiff",
        "encAngle", "gyroBias", "angleAbs",
    ],
    "SENSE": [
        "adcF1", "adcF2", "adcL", "adcR",
        "irF1", "irF2", "irL", "irR", "irF",
        "irSat", "wallBits", "posX", "posY", "mouseTask", "irSwitch", "wallThresh",
    ],
    "POWER": [
        "adcBatt", "battMv", "battPct", "battLow", "battEnabled",
        "cpu", "drop", "emergActive", "emergCounter",
    ],
    "TIME": ["upMs", "armMs", "devMs", "armed", "mazeRun", "led", "streamOn"],
    # 迷宫状态机(实验8): 与固件 link_MazeSnapLine() 的字段顺序逐项一致
    "MAZE": [
        "task", "road", "opens", "motion", "posX", "posY", "dir", "stack",
        "flags", "evCount", "evDrop", "juncCnt", "turnCnt", "deadCnt", "cellCnt", "atGoal",
    ],
}

#: SNAP 数据域 -> 对应的既有帧解码器(语义等价的那一帧)。用于 `as_frames()`。
SNAP_FRAME_OF: Dict[str, str] = {
    "MOTION": "fast",
    "ODOM": "mid",
    "SENSE": "slow",
    "POWER": "slow",
    "TIME": "time",
    "MAZE": "maze",
}

#: SENSE 行的 irSat 位域: 每通道 2 bit
IR_SAT_NORMAL = 0  # 落在标定表量程内
IR_SAT_NEAR = 1  # 近端饱和(ADC > 表头, 查表返回 0mm —— 只是"太近了", 不是真的 0)
IR_SAT_FAR = 2  # 远端超量程(ADC < 表尾, 查表返回 249mm —— 实际可能远得多)

IR_SAT_NAMES = {IR_SAT_NORMAL: "正常", IR_SAT_NEAR: "近端饱和", IR_SAT_FAR: "远端超量程"}


# ---------------------------------------------------------------- 迷宫状态机(实验8 无记忆走迷宫)

#: 迷宫任务状态(mazeState.mouseTask) —— 与固件 STRATEGY/maze.h 的枚举一致
MAZE_TASK_NAMES: Dict[int, str] = {
    0: "WAIT", 1: "START", 2: "SEARCH", 3: "SPURT", 4: "SPURT45", 5: "SPURT90",
}

#: 路口类型(LINK_ROAD_*) —— 由 wallSns 的前/左/右开口相对当前朝向分类
ROAD_NAMES: Dict[int, str] = {
    0: "NONE", 1: "THRU", 2: "CORNER_L", 3: "CORNER_R",
    4: "TEE_FL", 5: "TEE_FR", 6: "TEE_LR", 7: "CROSS", 8: "DEAD",
}

#: 路口"大类"(对人显示用)
ROAD_KINDS: Dict[str, str] = {
    "NONE": "未判定",
    "THRU": "直道",
    "CORNER_L": "左弯",
    "CORNER_R": "右弯",
    "TEE_FL": "岔路口(T型,缺右)",
    "TEE_FR": "岔路口(T型,缺左)",
    "TEE_LR": "岔路口(T型,前方封死)",
    "CROSS": "十字路口",
    "DEAD": "死路",
}

#: MAZE 帧 flags
MAZE_FLAG_GOAL = 0x01  # 本次已到过终点区
MAZE_FLAG_BACK = 0x02  # 已进入回程
MAZE_FLAG_SPURT = 0x04  # 处于冲刺态
MAZE_FLAG_JUNC = 0x08  # 本次识别到过岔路口
MAZE_FLAG_EVQ = 0x10  # 有事件因 TX 空间不足被丢弃(事件流不完整!)
MAZE_FLAG_DEAD = 0x20  # 本次识别到过死路

MAZE_FLAG_NAMES: Dict[int, str] = {
    MAZE_FLAG_GOAL: "已到终点",
    MAZE_FLAG_BACK: "回程",
    MAZE_FLAG_SPURT: "冲刺中",
    MAZE_FLAG_JUNC: "遇到过岔路口",
    MAZE_FLAG_EVQ: "事件有丢弃",
    MAZE_FLAG_DEAD: "遇到过死路",
}

#: 事件掩码位(`MAZE EV <mask>`)
MAZE_EV_TASK = 0x01
MAZE_EV_ROAD = 0x02
MAZE_EV_JUNC = 0x04
MAZE_EV_TURN = 0x08
MAZE_EV_GOAL = 0x10
MAZE_EV_CELL = 0x20
MAZE_EV_DEF = 0x1F

MAZE_EV_BITS: Dict[str, int] = {
    "TASK": MAZE_EV_TASK, "ROAD": MAZE_EV_ROAD, "JUNC": MAZE_EV_JUNC,
    "TURN": MAZE_EV_TURN, "GOAL": MAZE_EV_GOAL, "CELL": MAZE_EV_CELL,
}

#: `MAZE EV <NAME> ...` 的事件类型 -> 说明
MAZE_EVENT_NAMES: Dict[str, str] = {
    "BEGIN": "进入迷宫态",
    "EXIT": "退出迷宫态",
    "TASK": "任务状态机迁移",
    "ROAD": "路口类型识别",
    "JUNC": "岔路口栈深度",
    "TURN": "转弯/掉头动作",
    "GOAL": "到达终点",
    "CELL": "进入新格",
}


def decode_maze(p: bytes) -> dict:
    """迷宫状态机帧(16B) —— 见固件 `link_SendMazeFrame()`。

    偏移: 0 task | 1 road | 2 opens | 3 motion | 4 posX | 5 posY | 6 dir | 7 stack
          8 flags | 9 evMask | 10-11 evCount(u16,LE) | 12-13 juncCnt(u16,LE)
          14 turnCnt | 15 deadCnt

    `opens` = 前/左/右开口数(0..3), 与固件 LESSON_Blind8 里 `lessonStr.roadStat` 同义。
    """
    b = p[:16] + b"\x00" * 16
    task, road, opens, motion, px, py, d, stack, flags, evmask = struct.unpack("<BBBBBBBBBB", b[:10])
    ev_count, junc_cnt = struct.unpack("<HH", b[10:14])
    turn_cnt, dead_cnt = b[14], b[15]
    rname = ROAD_NAMES.get(road, f"?{road}")
    return {
        "task": task,
        "taskName": MAZE_TASK_NAMES.get(task, f"?{task}"),
        "road": road,
        "roadName": rname,
        "roadKind": ROAD_KINDS.get(rname, "未判定"),
        "opens": opens,
        "motion": motion,
        "posX": px,
        "posY": py,
        "dir": d,
        "stack": stack,
        "flags": flags,
        "evMask": evmask,
        "evCount": ev_count,
        "juncCnt": junc_cnt,
        "turnCnt": turn_cnt,
        "deadCnt": dead_cnt,
        "goal": bool(flags & MAZE_FLAG_GOAL),
        "back": bool(flags & MAZE_FLAG_BACK),
        "spurt": bool(flags & MAZE_FLAG_SPURT),
        "seenJunc": bool(flags & MAZE_FLAG_JUNC),
        "seenDead": bool(flags & MAZE_FLAG_DEAD),
        "evDropped": bool(flags & MAZE_FLAG_EVQ),
    }


def parse_maze_event(line: str) -> Optional[dict]:
    """解析一行 `MAZE EV <NAME> [args...]` → {"event", "args", "text", "raw", ...}。

    容错策略与 `parse_movedone_run` / `parse_snap_line` 一致: **短行不抛异常**,
    参数个数不足就把解释性字段留空 —— 固件版本可能领先/落后于上位机,
    一条不认识的新事件不该让整条事件流断掉(未知事件名返回 None, 由调用方当普通文本处理)。
    """
    parts = line.split()
    if len(parts) < 3 or parts[0].upper() != "MAZE" or parts[1].upper() != "EV":
        return None
    name = parts[2].upper()
    if name not in MAZE_EVENT_NAMES:
        return None
    args = parts[3:]
    out: Dict[str, object] = {
        "event": name,
        "args": args,
        "text": MAZE_EVENT_NAMES[name],
        "raw": line,
    }
    if name == "TASK" and len(args) >= 2:
        out["from"], out["to"] = args[0], args[1]
        out["summary"] = f"{args[0]} → {args[1]}"
    elif name == "ROAD" and len(args) >= 1:
        out["roadName"] = args[0]
        out["roadKind"] = ROAD_KINDS.get(args[0], "未判定")
        if len(args) >= 2:
            try:
                out["road"] = int(args[1])
            except ValueError:
                pass
        out["summary"] = f"识别到 {out['roadKind']}({args[0]})"
    elif name == "TURN" and len(args) >= 1:
        out["motion"] = args[0]
        if len(args) >= 2:
            try:
                out["motionCode"] = int(args[1])
            except ValueError:
                pass
        out["summary"] = f"动作 {args[0]}"
    elif name == "JUNC" and len(args) >= 1:
        out["stack"] = int(args[0]) if args[0].lstrip("-").isdigit() else None
        out["summary"] = f"岔路口栈深度 {args[0]}"
    elif name in ("GOAL", "BEGIN", "CELL") and len(args) >= 2:
        out["x"], out["y"] = args[0], args[1]
        if len(args) >= 3:
            out["dir"] = args[2]
        out["summary"] = f"({args[0]},{args[1]})"
    else:
        out["summary"] = " ".join(args)
    return out


def decode_ir_sat(mask: int) -> Dict[str, int]:
    """把 SENSE 行的 2bit×4 饱和掩码拆成 {"F1":0/1/2, "F2":..., "L":..., "R":...}。"""
    m = int(mask) & 0xFF
    return {"F1": m & 0x03, "F2": (m >> 2) & 0x03, "L": (m >> 4) & 0x03, "R": (m >> 6) & 0x03}


def parse_snap_line(line: str) -> Optional[dict]:
    """解析一行 SNAP 快照 → {"domain": "SENSE", "fields": {...}}; 无法识别返回 None。

    容错策略与 `parse_movedone_run` 一致: **短行不抛异常**, 缺的字段直接不出现。
    理由相同 —— 固件版本可能领先/落后于上位机, 一条新固件的老行不该让整条事件流断掉。
    反过来多出来的字段也不报错(便于固件先行加字段)。
    """
    parts = line.split()
    if len(parts) < 3 or parts[0].upper() != "SNAP":
        return None
    dom = parts[1].upper()
    names = SNAP_FIELDS.get(dom)
    if names is None:
        return None
    out: Dict[str, object] = {}
    for name, raw in zip(names, parts[2:]):
        try:
            out[name] = int(raw)
        except ValueError:
            out[name] = raw  # 非整数就原样留着, 上层自行判断
    return {"domain": dom, "fields": out, "raw": line}


# ---------------------------------------------------------------- 流式解析器

class FrameStreamParser:
    """把任意切分的字节流切分为二进制帧与文本行。

    设计要点(与固件 link.h 的共存策略对应):
      见到 0xAA 才尝试按帧解析; 长度不足则等待更多数据;
      CRC 校验失败则把该 0xAA 当普通文本字节吐出并前移一位,
      这样即使偶发错帧也不会卡死解析器(自恢复)。
    """

    def __init__(self) -> None:
        self._buf = bytearray()
        self._text = bytearray()
        self.stats = {"frames": 0, "bad_crc": 0, "bad_sync": 0, "text_lines": 0, "bytes": 0}

    def feed(self, data: bytes):
        """投喂字节, 返回 (frames, text_lines) 两个列表。"""
        self._buf += data
        self.stats["bytes"] += len(data)
        frames: List[Frame] = []
        lines: List[str] = []

        while self._buf:
            aa = self._buf.find(SYNC0)
            if aa < 0:
                # 整段都是文本。必须在这里也排空行缓冲 —— 否则当数据被切成
                # 逐字节投喂时(串口就会这样), 纯文本段永远走不到 aa>0 分支,
                # 文本行会一直积压在 _text 里发不出来。
                self._text += self._buf
                self._buf.clear()
                self._drain_lines(lines)
                break
            if aa > 0:
                self._text += self._buf[:aa]
                del self._buf[:aa]
                self._drain_lines(lines)
                continue

            # aa == 0, 尝试解析帧
            if len(self._buf) < FRAME_OVERHEAD:
                break
            if self._buf[1] != SYNC1:
                self.stats["bad_sync"] += 1
                self._text.append(SYNC0)
                del self._buf[:1]
                self._drain_lines(lines)
                continue
            ln = self._buf[2] | (self._buf[3] << 8)
            total = FRAME_OVERHEAD + ln
            if len(self._buf) < total:
                break  # 等更多数据
            body = bytes(self._buf[4 : 6 + ln])
            crc_rx = self._buf[6 + ln] | (self._buf[7 + ln] << 8)
            if crc16_modbus(body) != crc_rx:
                self.stats["bad_crc"] += 1
                self._text.append(SYNC0)
                del self._buf[:1]
                self._drain_lines(lines)
                continue
            frames.append(Frame(type=self._buf[4], seq=self._buf[5], payload=bytes(self._buf[6 : 6 + ln])))
            self.stats["frames"] += 1
            del self._buf[:total]

        return frames, lines

    def _drain_lines(self, lines: List[str]) -> None:
        while True:
            nl = self._text.find(b"\n")
            if nl < 0:
                break
            raw = bytes(self._text[:nl])
            del self._text[: nl + 1]
            line = raw.rstrip(b"\r").decode("utf-8", "replace")
            if line:
                lines.append(line)
                self.stats["text_lines"] += 1
