"""离线分析: 阶跃指标、跟踪误差、按运动任务分段。

对应功能清单的 J 组。**不需要连接设备** —— 输入是 numpy 数组或
`scope.fetch()` 的返回值, 所以随时可用(含离线回放)。

dump 数组的约定(与 `TelemetryStore.dump_arrays()` 一致)::

    (t_ms, motionTask, gangle, speedl, speedr)
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Dict, List, Optional, Sequence

import numpy as np

from ..analysis.metrics import (
    format_metrics,
    segment_by_task,
    step_metrics,
    tracking_error,
)
from ..protocol.codec import MOTION_TASK_NAMES

if TYPE_CHECKING:  # pragma: no cover
    from .client import MouseClient

#: dump 数组各列的含义, 顺序与固件 RunData 结构体一致。
DUMP_FIELDS = ("t_ms", "motionTask", "gangle", "speedl", "speedr")


class AnalyzeAPI:
    """纯计算, 无副作用, 可反复调用。"""

    def __init__(self, mc: Optional["MouseClient"] = None) -> None:
        self._mc = mc

    # ------------------------------------------------------------ 基本指标

    def step(
        self, t: Sequence[float], y: Sequence[float], target: float, band: float = 0.02
    ) -> Dict[str, float]:
        """阶跃响应指标: rise_s / overshoot_pct / settle_s / sse / peak / final。"""
        return step_metrics(np.asarray(t, dtype=float), np.asarray(y, dtype=float), target, band)

    def tracking(
        self, t: Sequence[float], y: Sequence[float], ref: Sequence[float], tail_frac: float = 0.2
    ) -> Dict[str, float]:
        """跟踪误差: rms / maxabs / tail_mean / tail_rms。"""
        return tracking_error(np.asarray(t), np.asarray(y), np.asarray(ref), tail_frac)

    def segments(self, t_ms: Sequence[float], task: Sequence[int]) -> List[Dict[str, Any]]:
        """按 `motionTask` 变化切段。一次动作就是一段。"""
        return segment_by_task(np.asarray(t_ms), np.asarray(task))

    def format(self, m: Dict[str, float]) -> str:
        return format_metrics(m)

    def task_name(self, code: int) -> str:
        return MOTION_TASK_NAMES.get(int(code), str(int(code)))

    # ------------------------------------------------------------ dump 数组

    def channels(self, arr) -> Dict[str, Any]:
        """把 dump 数组拆成具名通道, 便于按名字取用。"""
        if arr is None:
            return {}
        t, task, ang, sl, sr = arr
        return {
            "t_ms": t,
            "t_s": np.asarray(t, dtype=float) / 1000.0,
            "motionTask": task,
            "gangle": ang,
            "speedl": sl,
            "speedr": sr,
        }

    def dump_segments(self, arr) -> List[Dict[str, Any]]:
        """把一次 dump 按运动任务切段(段内带各通道切片)。"""
        if arr is None:
            return []
        ch = self.channels(arr)
        segs = self.segments(ch["t_ms"], ch["motionTask"])
        for s in segs:
            i0, i1 = int(s["i0"]), int(s["i1"])
            s["task_name"] = self.task_name(s["task"])
            s["slices"] = {
                "t_s": ch["t_s"][i0 : i1 + 1],
                "speedl": ch["speedl"][i0 : i1 + 1],
                "speedr": ch["speedr"][i0 : i1 + 1],
                "gangle": ch["gangle"][i0 : i1 + 1],
            }
        return segs

    def summary(self, arr, band: float = 0.02) -> List[Dict[str, Any]]:
        """对每一段算左右轮速的阶跃指标。

        target 取该段最后 5% 的均值 —— 比取"理论目标值"更稳: dump 里没有下发
        的目标转速, 而段尾通常已进入稳态。
        """
        out: List[Dict[str, Any]] = []
        for s in self.dump_segments(arr):
            sl = np.asarray(s["slices"]["speedl"], dtype=float)
            sr = np.asarray(s["slices"]["speedr"], dtype=float)
            t_s = np.asarray(s["slices"]["t_s"], dtype=float)
            if len(t_s) < 3:
                continue
            tail = max(1, len(sl) // 20)
            item: Dict[str, Any] = {
                "task": s["task"],
                "task_name": s["task_name"],
                "duration_ms": s["duration_ms"],
                "points": len(t_s),
            }
            for name, y in (("speedl", sl), ("speedr", sr)):
                target = float(np.mean(y[-tail:]))
                item[name] = self.step(t_s, y, target, band) if abs(target) > 1e-6 else {}
            out.append(item)
        return out

    def explain(self, arr) -> str:
        """把 summary 变成一段人可读的文本(CLI 与日志用)。"""
        rows = self.summary(arr)
        if not rows:
            return "（无有效动作段）"
        lines = []
        for r in rows:
            lines.append(
                f"#{r['task']:<3}{r['task_name']:<22}{r['duration_ms']:>7.0f}ms  "
                f"L[{self.format(r.get('speedl', {}))}]  R[{self.format(r.get('speedr', {}))}]"
            )
        return "\n".join(lines)

    # ============================================================ 红外测距分析
    #
    # 输入是 `mc.snap` / `mc.scope` 给的量, **不是** 遥测帧 —— 这正是"红外测距
    # 可分析"的落点: 帧里只有 0.5Hz 的距离, 分析不出任何东西。
    # 配合关系:
    #   `mc.snap.ir_channels()`          -> 当前值 + 饱和状态(阻塞问答)
    #   `mc.scope.fetch_data("B"/"C")`   -> 1kHz 距离序列 / 原始 ADC 序列

    def ir_saturation_stats(
        self,
        series: Any = None,
        sat: Any = None,
    ) -> Dict[str, Any]:
        """统计各通道的**饱和占比**与量程使用情况。

        `series` 可以是:
          - `mc.snap` 的 SENSE 字段 dict(单点, 此时只报状态不报占比);
          - 或一个 4 列数组/`{通道名: 序列}`(通常是剖面 B 的 1kHz 距离)。

        **为什么必须看饱和**: 查表测距在两端被夹紧 —— 贴太近返回 0mm、超出量程
        返回 249mm。单看距离会把"近得查不出"误当成"贴住了", 据此调参必然跑偏。
        """
        out: Dict[str, Any] = {"channels": {}, "any_saturated": False, "worst": None}
        chans = ("F1", "F2", "L", "R")
        if series is None:
            return out

        # 单点(SNAP SENSE 视角)
        if isinstance(series, dict) and "irSat" in series:
            from ..protocol.codec import decode_ir_sat

            m = decode_ir_sat(int(series["irSat"]))
            for k in chans:
                s = int(m.get(k, 0))
                out["channels"][k] = {"sat": s, "n": 1, "frac_sat": float(s != 0),
                                      "mm": series.get("ir" + k)}
                out["any_saturated"] = out["any_saturated"] or s != 0
            return out

        # 时间序列(剖面 B 的数组 / dict)
        if isinstance(series, dict):
            cols = {k: np.asarray(series[k], dtype=float) for k in chans if k in series}
        else:
            a = np.asarray(series, dtype=float)
            if a.ndim != 2 or a.shape[1] < 4:
                return out
            cols = {k: a[:, i] for i, k in enumerate(chans)}
        for k, y in cols.items():
            if y.size == 0:
                continue
            near = float(np.mean(y <= 0.0)) if y.size else 0.0
            far = float(np.mean(y >= 249.0)) if y.size else 0.0
            frac = near + far
            out["channels"][k] = {
                "n": int(y.size),
                "min": float(np.min(y)),
                "max": float(np.max(y)),
                "mean": float(np.mean(y)),
                "frac_near_sat": near,
                "frac_far_sat": far,
                "frac_sat": frac,
            }
            if frac > 0:
                out["any_saturated"] = True
            if out["worst"] is None or frac > out["channels"][out["worst"]]["frac_sat"]:
                out["worst"] = k
        return out

    def ir_range_curve(
        self,
        adc: Any,
        mm: Any,
        bins: int = 24,
    ) -> Dict[str, Any]:
        """从"原始 ADC ↔ 距离"配对序列里拟合标定曲线(幂律 `ADC = a * d^b`)。

        这是剖面 C(1kHz 原始 ADC) + 剖面 B(1kHz 距离) 的真实用途:
        把鼠标推着走一遍, 就能得到每个通道的整条测距曲线, 用来**校验或重建**
        `irs.c` 里的 250 点标定表, 而不是靠手工摆两次(近点/远点)。

        返回 `{ok, a, b, r2, n, note}`; `r2` 是拟合优度, 低于 0.9 就别用。
        幂律是红外反比平方关系的经验拟合, 与 `IR_CurveFit` 的双对数直线一致。
        """
        x = np.asarray(mm, dtype=float)
        y = np.asarray(adc, dtype=float)
        n = int(min(x.size, y.size))
        out: Dict[str, Any] = {"ok": False, "a": None, "b": None, "r2": None, "n": n,
                               "note": ""}
        if n < 8:
            out["note"] = "样本太少(<8), 拟合无意义"
            return out
        x, y = x[:n], y[:n]
        keep = (x > 1.0) & (y > 1.0) & (x < 400.0)  # 剔掉 0/饱和/离谱点
        x, y = x[keep], y[keep]
        if x.size < 8:
            out["note"] = "有效样本太少(去掉饱和点后 <8)"
            return out
        lx, ly = np.log(x), np.log(y)
        b, loga = np.polyfit(lx, ly, 1)
        pred = loga + b * lx
        ss_res = float(np.sum((ly - pred) ** 2))
        ss_tot = float(np.sum((ly - np.mean(ly)) ** 2))
        r2 = 1.0 - ss_res / ss_tot if ss_tot > 0 else 0.0
        out.update({"ok": bool(r2 > 0.9), "a": float(np.exp(loga)), "b": float(b),
                    "r2": float(r2), "n": int(x.size)})
        if not out["ok"]:
            out["note"] = f"拟合优度偏低(r2={r2:.3f}), 检查采样是否覆盖足够量程"
        return out

    # ============================================================ 电源分析

    def batt_low_events(self, mv: Any, low_mv: float = 7000.0) -> List[Dict[str, Any]]:
        """从 mV 序列里找出**低电区间**(用于"跑到一半掉电"的复盘)。

        入参通常是剖面 D 的 1kHz `battMv`(或 `mc.snap.poll()` 采到的 mV 序列)。
        返回 `[{start_i, end_i, n, min_mv, mean_mv}]`。
        """
        y = np.asarray(mv, dtype=float)
        if y.size == 0:
            return []
        below = y < float(low_mv)
        out: List[Dict[str, Any]] = []
        i = 0
        n = y.size
        while i < n:
            if not below[i]:
                i += 1
                continue
            j = i
            while j < n and below[j]:
                j += 1
            seg = y[i:j]
            out.append({"start_i": int(i), "end_i": int(j - 1), "n": int(j - i),
                        "min_mv": float(np.min(seg)), "mean_mv": float(np.mean(seg))})
            i = j
        return out

    def batt_discharge(self, mv: Any, t_ms: Any = None) -> Dict[str, Any]:
        """电池放电/跌落分析: 起止电压、总跌落、最大瞬时跌落速率(内阻的间接指标)。

        **最大瞬时跌落速率**是判断"电池够不够劲"的关键数: 电机启动瞬间电流陡增,
        若内阻偏大, mV 会在一两个毫秒内掉一大截 —— 那种掉法会把 MCU 拉到复位,
        而用 0.5Hz 的遥测帧根本看不见(这正是 1kHz 剖面 D 存在的理由)。
        """
        y = np.asarray(mv, dtype=float)
        out: Dict[str, Any] = {"n": int(y.size), "v_start_mv": None, "v_end_mv": None,
                               "v_min_mv": None, "drop_total_mv": None,
                               "max_slope_mv_per_ms": None, "max_slope_at": None}
        if y.size == 0:
            return out
        out["v_start_mv"] = float(y[0])
        out["v_end_mv"] = float(y[-1])
        out["v_min_mv"] = float(np.min(y))
        out["drop_total_mv"] = float(y[0] - y[-1])
        if y.size >= 2:
            d = np.diff(y)
            k = int(np.argmin(d))
            out["max_slope_mv_per_ms"] = float(d[k])
            if t_ms is not None:
                tt = np.asarray(t_ms, dtype=float)
                out["max_slope_at"] = float(tt[k]) if k < tt.size else None
            else:
                out["max_slope_at"] = k
        return out
