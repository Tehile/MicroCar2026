"""示波器与 1kHz 完整波形回传。

对应功能清单的 G 组。

分工由实测链路能力决定(见设计文档附录 F):

    实时流    ≈ 152 B/s  ->  只够传状态
    完整波形  9600 B      ->  停车后一次性回传, 约 60 秒

所以**不要**靠提高实时流速率来换波形分辨率 —— 那条链路超过阈值后会一个字节
都收不到(模块缓冲被永久按在饱和态)。要看细节就用 `fetch()`。
"""

from __future__ import annotations

import time
from typing import TYPE_CHECKING, Any, Callable, Dict, List, Optional, Tuple

from ..protocol.codec import SCOPE_BLKS, SCOPE_LEN, SCOPE_PTS_PER_BLK
from .errors import Result, clamp_timeout
from .events import Event

if TYPE_CHECKING:  # pragma: no cover
    from .client import MouseClient

#: 一次完整回传的字节数: 1200 点 × 8B + 20 块 × 8B(帧开销)
DUMP_BYTES = SCOPE_LEN * 8 + SCOPE_BLKS * 8


class ScopeAPI:
    """固件侧的 1kHz 滚动环缓冲(深度 1200 点 = 1.2 秒)。"""

    def __init__(self, mc: "MouseClient") -> None:
        self._mc = mc
        self._last: Optional[tuple] = None

    # ------------------------------------------------------------ 采集控制

    def start(self, profile: str = "A", timeout: float = 3.0) -> Result:
        """开始采集。采集在固件里以 1kHz 滚动进行, 采满 1200 点会覆盖最早的点。

        `profile` 决定这块 9600B 环里每 8B 点装什么物理量(**一次只录一种**, 零新增 RAM):

            A  运动学: 任务码/航向角/左右轮速度(默认, = SCOPE 原行为)
            B  四路红外距离 mm      —— 治"红外只在 0.5Hz 慢帧上"
            C  四路红外原始 ADC     —— 拟合/校验 IR 标定表的一手数据
            D  前向综合 mm + 电池 mV/ADC —— 看电机启停瞬间的电压跌落
            E  前右/前左 mm + 电池 mV + 任务码(混合)

        用 `dump_profile_arrays()` 按剖面取名取数组; `fetch()` 仍是剖面 A 的旧接口。
        """
        p = (profile or "A").strip().upper()
        return self._mc.send_cmd("scope.start", prof=p, timeout=timeout)

    def start_data(self, profile: str = "B", **kw: Any) -> Result:
        """`start()` 的语义化别名: 明确"这次是来录测量数据的"(剖面 B/C/D/E)。"""
        return self.start(profile, **kw)

    def stop(self, timeout: float = 3.0) -> Result:
        return self._mc.send_cmd("scope.stop", timeout=timeout)

    # ------------------------------------------------------------ 回传

    def dump(self, timeout: float = 3.0) -> Result:
        """只发回传请求, 不等待。进度与完成通过事件给出。"""
        self._mc.store.reset_dump()
        self._mc._note_dump_request()
        return self._mc.send_cmd("scope.dump", timeout=timeout)

    def fetch(
        self,
        timeout: float = 300.0,
        on_progress: Optional[Callable[[float, Optional[float], Optional[float]], None]] = None,
        stop_first: bool = True,
    ) -> Optional[tuple]:
        """停车后拉取完整 1kHz 波形, **阻塞**直到回传完成。

        参数:
            on_progress(frac, eta_s, rate_bps)  进度回调。**运行在调度线程**,
                因此里面不能调阻塞 API —— 只适合更新界面/打印。
            stop_first  先发 STOP + SCOPE STOP。固件要求停车后再回传;
                已经停好的话可以传 False 省一次往返。

        返回 `dump_arrays()` 的 `(t_ms, motionTask, gangle, speedl, speedr)`,
        失败或超时返回 None。原始数据同时已落盘到会话目录(若会话开着)。
        """
        mc = self._mc
        mc._check_reentrancy("scope.fetch()")

        if stop_first:
            mc.send_cmd("stop", timeout=2.0)
            mc.send_cmd("scope.stop", timeout=2.0)

        mc.store.reset_dump()
        mc._note_dump_request()

        done: List[Any] = []
        offs: List[Callable[[], None]] = []
        if on_progress is not None:
            def _p(msg) -> None:
                d = msg.data
                try:
                    on_progress(float(d.get("frac", 0.0)), d.get("eta_s"), d.get("rate_bps"))
                except Exception:
                    pass

            offs.append(mc.on(Event.DUMP_PROGRESS, _p))
        offs.append(mc.on(Event.DUMP_DONE, lambda m: done.append(m)))
        try:
            r = mc.send_cmd("scope.dump", timeout=3.0)
            # **ACK 超时不等于 dump 失败**, 这是真机实测出来的(2026-10-04):
            # `SCOPE DUMP` 一开始, 固件就连续发 20 块 × 490B 的 dump 帧, 而应答文本
            # 与这些帧争用同一条 TX 环/DMA —— ACK 实测会被挤后约 1 秒, 超过命令层
            # 的重发窗口 → 上位机报 TIMEOUT, 而**设备那边 dump 照常跑完**。
            # 所以只有"设备明确拒绝"(ERR_BUSY 等)才提前放弃; TIMEOUT 一律继续等 DUMP_DONE,
            # 那才是"数据到了没有"的唯一判据。
            if not r.ok and r.status != "TIMEOUT":
                return None
            if not mc.wait(lambda: bool(done), timeout=clamp_timeout(timeout, 300.0)):
                return None
            self._last = mc.store.dump_arrays()
            return self._last
        finally:
            for off in offs:
                off()

    def last(self) -> Optional[tuple]:
        """最近一次成功回传的波形(不发命令)。"""
        if self._last is not None:
            return self._last
        try:
            return self._mc.store.dump_arrays()
        except Exception:
            return None

    # ------------------------------------------------------------ 剖面视图

    def profile(self) -> str:
        """本次(或最近一次)dump 的录制剖面字母 A..E。"""
        return self._mc.store.dump_profile()

    def profile_channels(self) -> List[str]:
        """本次剖面 4 个 8B 通道的字段名。"""
        return self._mc.store.dump_profile_channels()

    def last_data(self):
        """按**任意剖面**取回最近一次 dump: `(t_ms, {通道名: np.array})`。

        `fetch()` 只认剖面 A(运动学); 要取红外/电压的高分辨率波形用这个:
            `mc.scope.start("B"); mc.scope.fetch(); t, ch = mc.scope.last_data()`
        或用 `fetch_data()` 一步到位。
        """
        try:
            return self._mc.store.dump_profile_arrays()
        except Exception:
            return None

    def fetch_data(
        self,
        profile: str = "B",
        collect_s: float = 0.0,
        timeout: float = 300.0,
        on_progress: Optional[Callable[[float, Optional[float], Optional[float]], None]] = None,
        stop_first: bool = True,
    ):
        """一次跑完"开采集(指定剖面) -> 停车 -> 回传 -> 取名取数组"。

        返回 `(profile, t_ms, {通道名: np.array})`; 失败返回 None。

        `collect_s > 0` 时先采这么久再停车(环深 1200 点 = 1.2s, 所以想拿满环就传 1.2)。
        要"边运动边录 1kHz"的话别用本方法, 用两步式:
            `mc.scope.start("B")` -> 跑动作 -> `mc.scope.fetch()` -> `mc.scope.last_data()`

        典型用法(1kHz 红外测距波形):
            `prof, t, ch = mc.scope.fetch_data("B", collect_s=1.2)`  → `ch["irF1"]` 是 1kHz 序列
        """
        mc = self._mc
        mc._check_reentrancy("scope.fetch_data()")
        r = self.start(profile)
        if not r.ok:
            return None
        if collect_s and collect_s > 0:
            time.sleep(float(collect_s))
        if not self.fetch(timeout=timeout, on_progress=on_progress, stop_first=stop_first):
            return None
        got = self.last_data()
        if got is None:
            return None
        t, ch = got
        return self.profile(), t, ch

    def progress(self) -> Dict[str, Any]:
        store = self._mc.store
        frac = float(store.dump_progress())
        elapsed = None
        w = self._mc._dump_watch
        if w is not None:
            elapsed = time.time() - w["t0"]
        eta = (elapsed / frac - elapsed) if (frac > 0.02 and elapsed) else None
        return {
            "frac": frac,
            "points": len(store.dump_records),
            "blocks": len(store.dump_blocks),
            "total_blocks": SCOPE_BLKS,
            "bytes": store.dump_bytes_received(),
            "eta_s": eta,
            "done": bool(store.dump_done),
        }

    # ------------------------------------------------------------ 元信息

    @staticmethod
    def points() -> int:
        return SCOPE_LEN

    @staticmethod
    def points_per_block() -> int:
        return SCOPE_PTS_PER_BLK

    @staticmethod
    def estimate_seconds(bps: float = 152.0) -> float:
        """按给定吞吐估算回传耗时(默认取实测的可持续吞吐上限)。"""
        return DUMP_BYTES / max(bps, 1.0)
