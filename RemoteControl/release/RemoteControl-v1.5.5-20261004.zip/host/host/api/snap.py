"""阻塞式测量快照(SNAP): 非数据采集阶段获取「全部可测量量」的唯一入口。

**为什么要有这一层**（与遥测帧的分工，别混用）:

    遥测帧   固件**周期性推**  → 需 `STREAM ON`、占常驻带宽、受链路丢帧影响
    SNAP     主机**按需来问**  → 不需要开流、零常驻带宽、拿到的一定是"此刻"的值

于是阶段划分很干净:
    - 日常确认 / 实验 / 标定   → `mc.snap.read()`（本模块）
    - 数据采集（高分辨率波形） → 既有双流式: `mc.stream` 实时帧 + 停止后 `mc.scope.dump()`

SNAP 覆盖的域（字段名与 `codec.decode_fast/mid/slow` 的字典键**同名**）:

    MOTION  转速/目标/pidErr/PWM/角度/任务/状态位      ← 对应快帧
    ODOM    里程/编码器角/陀螺原始/零偏/绝对角          ← 对应中帧
    SENSE   四路原始 ADC + 四路 mm + 前向综合 + 饱和 +
            墙位/坐标/任务/红外开关/侧墙阈值            ← 对应慢帧 + **新增 ADC/饱和**
    POWER   电池 ADC/mV/电量档/低电/使能 + CPU/丢包/过流  ← **全新**
    TIME    设备时基/发车时刻/已武装/基准灯/流开关        ← 与 TIME 帧同源

"饱和"是本模块引入的关键信息: 查表测距在量程两端会被**夹紧**成 0mm / 249mm,
单看距离无法区分"真的贴住了"与"近得查不出"。`ir_sat()` 把这件事显式拆出来。
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Callable, Dict, List, Optional

from ..protocol.codec import (
    IR_SAT_FAR,
    IR_SAT_NAMES,
    IR_SAT_NEAR,
    IR_SAT_NORMAL,
    SNAP_FIELDS,
    decode_ir_sat,
)
from .errors import Result

if TYPE_CHECKING:  # pragma: no cover
    from .client import MouseClient

#: 全部数据域(顺序即固件发出顺序)
SNAP_DOMAINS = ("MOTION", "ODOM", "SENSE", "POWER", "TIME", "MAZE")

#: 域 -> 语义等价的遥测帧名(mc.telemetry 的流名)。供 as_frames() 复用显示代码。
FRAME_OF_DOMAIN = {"MOTION": "fast", "ODOM": "mid", "SENSE": "slow", "POWER": "slow",
                   "TIME": "time", "MAZE": "maze"}


class SnapAPI:
    """`mc.snap` —— 阻塞式全量测量快照。"""

    def __init__(self, mc: "MouseClient") -> None:
        self._mc = mc
        self._last_status = ""
        self._last_ts = 0.0

    # ------------------------------------------------------------ 元数据

    def domains(self) -> List[str]:
        return list(SNAP_DOMAINS)

    def fields(self, domain: str) -> List[str]:
        return list(SNAP_FIELDS.get(domain.upper(), []))

    def last_status(self) -> str:
        """最近一次 `read()` 的结果状态(``OK``/``ERR_BUSY``/``TIMEOUT``/``NO_DATA``)。"""
        return self._last_status

    # ------------------------------------------------------------ 读

    def read(
        self,
        domains: Optional[Any] = None,
        timeout: float = 3.0,
    ) -> Dict[str, Dict[str, Any]]:
        """**阻塞**取一次快照。返回 ``{域: {字段: 值}}``；失败返回 ``{}``。

        `domains` 传 ``None``/``"ALL"`` 取全部；也可传 ``"SENSE"`` 或 ``["SENSE","POWER"]``
        只取关心的域（窄带宽场景下少发几行文本）。

        实现与 `ParamsAPI.get_raw()` 同构: 先清掉本地缓存，再发命令、
        等读取线程把行解析进缓存 —— 这样拿到的必然是**本次**的回话，不会读到上一次的陈旧值。
        """
        cmd = self._mc.cmd
        want = self._normalize(domains)

        # 清缓存, 保证"等到的"就是这一次的回话
        with cmd._lock:
            for d in want:
                cmd.snap.pop(d, None)

        r = self._mc.send_cmd("snap.get", dom=("ALL" if len(want) == len(SNAP_DOMAINS) else
                                              (want[0] if len(want) == 1 else None)),
                              timeout=timeout)
        if not r.ok:
            self._last_status = r.status
            return {}

        want_set = set(want)
        self._mc.wait(lambda: want_set.issubset(set(cmd.snap)), timeout=max(0.4, timeout))

        with cmd._lock:
            got = {d: dict(cmd.snap[d]) for d in want if d in cmd.snap}
        if got:
            self._last_status = "OK"
            import time as _t

            self._last_ts = _t.time()
        else:
            self._last_status = "NO_DATA"
        return got

    def read_flat(self, domains: Optional[Any] = None, timeout: float = 3.0) -> Dict[str, Any]:
        """同 `read()`，但把各域字段**合并成一个 dict**（字段名跨域不冲突）。"""
        out: Dict[str, Any] = {}
        for d in SNAP_DOMAINS:
            out.update(self.read(domains, timeout=timeout).get(d, {}))
        return out

    def latest(self, domain: Optional[str] = None) -> Dict[str, Any]:
        """**本地缓存**的快照（不发命令）。要强制刷新请先 `read()`。"""
        with self._mc.cmd._lock:
            if domain is None:
                return {d: dict(v) for d, v in self._mc.cmd.snap.items()}
            return dict(self._mc.cmd.snap.get(domain.upper(), {}))

    def age_ms(self) -> Optional[float]:
        """缓存快照的年龄（ms）；从未读过返回 None。"""
        if not self._last_ts:
            return None
        import time as _t

        return (_t.time() - self._last_ts) * 1000.0

    # ------------------------------------------------------------ 轮询

    def poll(
        self,
        hz: float = 1.0,
        dur: Optional[float] = None,
        domains: Optional[Any] = None,
        on_sample: Optional[Callable[[Dict[str, Dict[str, Any]]], None]] = None,
        stop: Optional[Callable[[], bool]] = None,
    ) -> List[Dict[str, Dict[str, Any]]]:
        """按 `hz` 轮询快照（**主机侧定时器**，固件无需知道）。

        这是"非数据采集阶段看实时值"的标准姿势: 1 Hz 常态、调参时 5 Hz。
        `stop` 是个返回 True 就提前结束的可调用对象（便于 UI 中断）。
        返回本次采到的全部样本。**会阻塞**，不要在事件回调里调用。
        """
        import time as _t

        period = 1.0 / max(0.05, float(hz))
        end = None if not dur else (_t.time() + float(dur))
        out: List[Dict[str, Dict[str, Any]]] = []
        # 以"下一次应到时刻"为基准推进, 避免每轮都把 read() 的耗时累加成漂移;
        # 一旦落后超过一整拍就重新对齐, 不追补(追补只会把链路压得更死)。
        nxt = _t.time()
        while True:
            if stop is not None and stop():
                break
            if end is not None and _t.time() >= end:
                break
            snap = self.read(domains)
            if snap:
                out.append(snap)
                if on_sample is not None:
                    try:
                        on_sample(snap)
                    except Exception:
                        pass
            nxt += period
            sleep = nxt - _t.time()
            if sleep > 0:
                _t.sleep(sleep)
            else:
                nxt = _t.time()
        return out

    # ------------------------------------------------------------ 派生视图

    def as_frames(self, snap: Optional[Dict[str, Dict[str, Any]]] = None) -> Dict[str, Dict[str, Any]]:
        """把 SNAP 结果映射成**遥测帧视角**的 dict，于是 `monitor` / `analyze` 可直接复用。

        返回 ``{"fast": {...}, "mid": {...}, "slow": {...}, "time": {...}}``；
        `slow` 由 SENSE + POWER 合并而成（本来它们在慢帧里就是一行）。
        """
        snap = snap if snap is not None else self.latest()
        out: Dict[str, Dict[str, Any]] = {}
        for dom, fname in FRAME_OF_DOMAIN.items():
            rec = snap.get(dom)
            if not rec:
                continue
            out.setdefault(fname, {}).update(rec)
        # 帧里的电压键叫 `volt`(V), 快照里叫 `battMv`(mV)。补一个派生键,
        # 让只认 `volt` 的既有显示代码(monitor 的系统行)不用分叉。
        for fname in ("slow", "fast"):
            rec = out.get(fname)
            if rec and "volt" not in rec and "battMv" in rec:
                rec["volt"] = float(rec["battMv"]) / 1000.0
        return out

    def ir_sat(self, snap: Optional[Dict[str, Dict[str, Any]]] = None) -> Dict[str, int]:
        """把 SENSE 里的 2bit×4 饱和掩码拆成 ``{"F1":0/1/2, "F2":..., "L":..., "R":...}``。"""
        snap = snap if snap is not None else self.latest()
        sense = snap.get("SENSE", {})
        if "irSat" not in sense:
            return {}
        return decode_ir_sat(int(sense["irSat"]))

    def ir_channels(self, snap: Optional[Dict[str, Dict[str, Any]]] = None) -> Dict[str, Dict[str, Any]]:
        """四路红外的**合并视图**：每路给出 ``{adc, mm, sat, sat_text}``。

        这是"红外测距"最实用的一个入口 —— 距离、原始 ADC、饱和状态一次给全，
        不必再去关心它们分别来自哪一行。
        """
        snap = snap if snap is not None else self.latest()
        sense = snap.get("SENSE", {})
        sat = self.ir_sat(snap)
        out: Dict[str, Dict[str, Any]] = {}
        for ch, adc_key, mm_key in (("F1", "adcF1", "irF1"), ("F2", "adcF2", "irF2"),
                                    ("L", "adcL", "irL"), ("R", "adcR", "irR")):
            if adc_key not in sense and mm_key not in sense:
                continue
            s = int(sat.get(ch, IR_SAT_NORMAL))
            out[ch] = {
                "adc": sense.get(adc_key),
                "mm": sense.get(mm_key),
                "sat": s,
                "sat_text": IR_SAT_NAMES.get(s, str(s)),
                "trustworthy": s == IR_SAT_NORMAL,
            }
        out["F"] = {"mm": sense.get("irF"), "weighted": sense.get("irF")}
        return out

    def battery(self, snap: Optional[Dict[str, Dict[str, Any]]] = None) -> Dict[str, Any]:
        """电源视图：``{adc, mv, volt, pct, low, enabled}``。

        `mv` 是固件按 `BATTKV` 换算后的毫伏; `pct` 是电量档。
        `enabled == 0` 说明固件的电池采样没打开 —— 此时 `mv/adc` 恒 0,
        **是"没采"而不是"没电"**, 这一点必须区分清楚。
        """
        snap = snap if snap is not None else self.latest()
        pw = snap.get("POWER", {})
        if not pw:
            return {}
        mv = int(pw.get("battMv", 0) or 0)
        return {
            "adc": pw.get("adcBatt"),
            "mv": mv,
            "volt": mv / 1000.0,
            "pct": pw.get("battPct"),
            "low": bool(pw.get("battLow")),
            "enabled": bool(pw.get("battEnabled")),
        }

    def check_battery(
        self,
        snap: Optional[Dict[str, Dict[str, Any]]] = None,
        low_mv: Optional[float] = None,
    ) -> Result:
        """取一次电源状态并给出**可判定**的结论（真机验收 V1/V3 用）。

        `low_mv` 省略时用固件参数 `BATTLOWMV`（即固件自己的低电判据），
        于是"上位机认为低电"与"固件认为低电"不会各说各话。
        """
        snap = snap if snap is not None else self.read(["POWER"])
        bat = self.battery(snap)
        if not bat:
            return Result(False, "NO_DATA", {"hint": "未取到 POWER 域; 固件是否支持 SNAP?"})
        if not bat["enabled"]:
            return Result(
                False,
                "BATT_DISABLED",
                {**bat, "hint": "固件 battMon.enabled==0: 电压恒 0 是'没采', 不是'没电'"},
            )
        thr = low_mv
        if thr is None:
            p = self._mc.params.get("BATTLOWMV")
            thr = p if p is not None else 7000.0
        bad = bat["mv"] < float(thr)
        return Result(not bad, "LOW_BATTERY" if bad else "OK",
                      {**bat, "threshold_mv": thr})

    # ------------------------------------------------------------ 展示

    def explain(self, snap: Optional[Dict[str, Dict[str, Any]]] = None) -> List[str]:
        """人可读的多行说明（CLI / 日志用）。"""
        snap = snap if snap is not None else self.latest()
        if not snap:
            return ["(无快照: 先调用 mc.snap.read())"]
        lines: List[str] = []
        m = snap.get("MOTION", {})
        if m:
            lines.append(
                f"运动  v={m.get('speedL')}/{m.get('speedR')} cm/s  "
                f"目标={m.get('speedTargetL')}/{m.get('speedTargetR')}  "
                f"pidErr={m.get('pidErr')}  PWM={m.get('pwmMotorL')}/{m.get('pwmMotorR')}  "
                f"角度={m.get('gyroAngle')}  任务={m.get('task')}  flags=0x{int(m.get('flags', 0)):02X}"
            )
        o = snap.get("ODOM", {})
        if o:
            lines.append(
                f"里程  cell={o.get('cellOdom')}  L/R={o.get('trackL')}/{o.get('trackR')}  "
                f"编码角={o.get('encAngle')}  陀螺 raw={o.get('gyroRaw')} 偏置={o.get('gyroBias')}"
            )
        ch = self.ir_channels(snap)
        if ch:
            parts = []
            for k in ("F1", "F2", "L", "R"):
                if k in ch:
                    c = ch[k]
                    parts.append(f"{k}:{c.get('mm')}mm/adc{c.get('adc')}/{c.get('sat_text')}")
            if "F" in ch:
                parts.append(f"前向综合:{ch['F'].get('mm')}mm")
            lines.append("红外  " + "  ".join(parts))
        bat = self.battery(snap)
        if bat:
            note = "" if bat["enabled"] else "  ⚠ 固件未启用电池采样(此时 0V 是'没采'不是'没电')"
            lines.append(
                f"电源  {bat['volt']:.2f} V  ({bat['mv']} mV, ADC={bat['adc']}, "
                f"档位={bat['pct']}, 低电={'是' if bat['low'] else '否'}){note}"
            )
        t = snap.get("TIME", {})
        if t:
            lines.append(
                f"时基  upMs={t.get('upMs')}  armMs={t.get('armMs')}  已发车={t.get('armed')}  "
                f"基准灯={t.get('led')}  遥测流={'开' if t.get('streamOn') else '关(静默)'}"
            )
        return lines

    # ------------------------------------------------------------ 内部

    def _normalize(self, domains: Optional[Any]) -> List[str]:
        if domains is None:
            return list(SNAP_DOMAINS)
        if isinstance(domains, str):
            d = domains.strip().upper()
            return list(SNAP_DOMAINS) if d in ("", "ALL") else [d]
        out = [str(d).strip().upper() for d in domains]
        return [d for d in out if d in SNAP_DOMAINS] or list(SNAP_DOMAINS)
