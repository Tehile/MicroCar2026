"""迷宫: 墙图拉取/渲染 + **状态机回传**(实验8 无记忆走迷宫)。

对应功能清单的 H 组。

墙位编码(与固件 `mapWall[MAZETYPE][MAZETYPE]` 低四位一致, 置位 = 无墙/可通行):
    bit0 上  bit1 右  bit2 下  bit3 左

迷宫尺寸取自设备上报的 `mazetype`(当前固件为 7×7), 上位机不写死 ——
换赛道尺寸时不必改这里。

## 状态机回传(三路, 都可单独用)

1. **事件流**(主用): 固件只在状态**变化**时上行 `MAZE EV ...`,
   经过 `Event.MAZE` 投递; 本 API 自动累积 (见 `events()`), 并能算成 `summary()`。
   识别的状态就是固件里真实存在的那些: 任务机(WAIT/START/SEARCH/SPURT)、
   路口类型(直道/左弯/右弯/T型/十字/死路)、岔路口栈深度、转弯/掉头动作、到达终点。
2. **1Hz 状态帧**: 仅"处于迷宫态"时发送, `state()` 取最近一帧。
3. **`SNAP MAZE` 点查**: 阻塞问答, 命令在中断里处理 —— **迷宫 while(1) 跑着也能问**。

事件掩码可用 `set_events("OFF"/"DEF"/"ALL"/0..63)` 调, 默认 31(TASK|ROAD|JUNC|TURN|GOAL),
`CELL`(每格一条)默认关。
"""

from __future__ import annotations

import time
from collections import deque
from itertools import islice
from typing import TYPE_CHECKING, Any, Callable, Deque, Dict, List, Optional, Tuple

from ..protocol.codec import (
    MAZE_EV_BITS,
    MOTION_TASK_NAMES,
    MAZE_EV_DEF,
    MAZE_FLAG_NAMES,
    MAZE_TASK_NAMES,
    ROAD_KINDS,
    ROAD_NAMES,
    WALL_DOWN_OPEN,
    WALL_LEFT_OPEN,
    WALL_RIGHT_OPEN,
    WALL_UP_OPEN,
)
from .events import Event

if TYPE_CHECKING:  # pragma: no cover
    from .client import MouseClient

DIR_NAMES = {0: "UP", 1: "RIGHT", 2: "DOWN", 3: "LEFT"}

#: 路口大类 -> 是否算"岔路口"(与固件 juncCnt 的口径一致)
JUNCTION_KINDS = ("TEE_FL", "TEE_FR", "TEE_LR", "CROSS")


class MazeAPI:
    """墙图 + 迷宫状态机(实验8 无记忆走迷宫)。"""

    def __init__(self, mc: "MouseClient") -> None:
        self._mc = mc
        self._events: Deque[Dict[str, Any]] = deque(maxlen=4000)
        self._hook_off: Optional[Callable[[], None]] = None
        self._last_mask: Optional[int] = None  # `MAZE EVMASK n` 回话(控制回话, 不入事件流)

    # ============================================================ 状态机: 事件流

    def _ensure_hooked(self) -> None:
        """首次使用时挂一次总线订阅。

        回调运行在**调度线程**(见 events.py 的线程契约), 所以这里只做入队/累加,
        绝不调用会阻塞等设备的 API。
        """
        if self._hook_off is not None:
            return

        def _cb(msg: Any) -> None:
            data = dict(msg.data)
            # `MAZE EVMASK <n>` 是掩码查询的回话, 属于**控制回话**而不是迷宫状态机事件;
            # 混进事件流会污染 evCount/统计(并让"掩码 OFF 后应无事件"这类断言误判)。
            if data.get("event") == "EVMASK":
                try:
                    self._last_mask = int(data.get("mask", 0))
                except (TypeError, ValueError):
                    self._last_mask = None
                return
            data["_ts"] = msg.ts
            self._events.append(data)

        self._hook_off = self._mc.on(Event.MAZE, _cb)

    def events(self, n: Optional[int] = None, kind: Optional[str] = None) -> List[Dict[str, Any]]:
        """已收到的事件(时间正序)。`kind` 可过滤: TASK/ROAD/JUNC/TURN/GOAL/BEGIN/EXIT/CELL。"""
        self._ensure_hooked()
        if kind is None:
            if n:
                # 只取尾部: monitor 每帧都会调, 不要整份拷贝
                return list(islice(reversed(self._events), n))[::-1]
            return list(self._events)
        k = kind.upper()
        out = [e for e in self._events if str(e.get("event", "")).upper() == k]
        return out[-n:] if n else out

    def clear_events(self) -> None:
        self._ensure_hooked()
        self._events.clear()

    def on_event(self, cb: Callable[[Dict[str, Any]], None]) -> Callable[[], None]:
        """订阅迷宫事件(在调度线程被调用)。返回注销函数。"""
        return self._mc.on(Event.MAZE, lambda m: cb(dict(m.data)))

    def watch(self, dur: float = 5.0, on_event: Optional[Callable[[Dict[str, Any]], None]] = None
              ) -> List[Dict[str, Any]]:
        """只收不阻塞设备地观察 `dur` 秒, 返回这段时间里的事件。"""
        self._ensure_hooked()
        start = len(self._events)
        got: List[Dict[str, Any]] = []
        end = time.time() + max(0.0, float(dur))
        while time.time() < end:
            cur = list(self._events)[start:]
            if len(cur) > len(got):
                for e in cur[len(got):]:
                    got.append(e)
                    if on_event is not None:
                        try:
                            on_event(e)
                        except Exception:
                            pass
            time.sleep(0.02)
        return got

    # ============================================================ 状态机: 状态帧 / 点查

    def state(self) -> Optional[Dict[str, Any]]:
        """最近的迷宫状态帧(1Hz, 仅迷宫态发送)。未跑迷宫时为 None。"""
        return self._mc.store.latest_maze

    def history(self) -> List[Tuple[float, Dict[str, Any]]]:
        """(单调时刻, 状态帧) 序列 —— 用来判断"什么时候变成这样"。"""
        with self._mc.store.lock:
            return list(self._mc.store.maze_history)

    def snap(self, timeout: float = 3.0) -> Optional[Dict[str, Any]]:
        """阻塞式点查 `SNAP MAZE`。**迷宫跑着也能问**(命令在中断里处理)。"""
        mc = self._mc
        mc._check_reentrancy("maze.snap()")
        rec = mc.snap.read(["MAZE"], timeout=timeout).get("MAZE")
        if not rec:
            return None
        # 补上人话字段, 与状态帧解码保持同一套键
        out = dict(rec)
        out["taskName"] = MAZE_TASK_NAMES.get(int(out.get("task", 0)), "?")
        out["roadName"] = ROAD_NAMES.get(int(out.get("road", 0)), "?")
        out["roadKind"] = ROAD_KINDS.get(out["roadName"], "未判定")
        out["goal"] = bool(int(out.get("atGoal", 0)))
        out["juncCnt"] = int(out.get("juncCnt", 0))
        out["evDropped"] = bool(int(out.get("evDrop", 0)))
        return out

    def set_events(self, mask: Any = "") -> Optional[int]:
        """设置事件掩码。接受 "OFF"/"DEF"/"ALL"/0..63; 不带参数即查询(返回当前值)。

        返回设置/查询后的掩码; 失败返回 None。
        """
        mc = self._mc
        mc._check_reentrancy("maze.set_events()")
        self._ensure_hooked()
        self._last_mask = None
        r = mc.send_cmd("maze.ev", mask=("" if mask == "" else str(mask)), timeout=3.0)
        # 固件先回一行 "MAZE EVMASK <n>" 再 ACK; 等那一行(ACK 先到也无妨, wait 会短等)
        mc.wait(lambda: self._last_mask is not None, timeout=0.5)
        if self._last_mask is not None:
            return self._last_mask
        return None if not r.ok else int(MAZE_EV_DEF)

    def reset(self) -> bool:
        """清固件侧迷宫统计(事件计数/岔路口/死路/转弯/格数)与本地事件缓冲。"""
        mc = self._mc
        mc._check_reentrancy("maze.reset()")
        r = mc.send_cmd("maze.rst", timeout=3.0)
        self.clear_events()
        return bool(r.ok)

    # ============================================================ 状态机: 汇总 / 人话

    def monitor_view(self, events: int = 3) -> Dict[str, Any]:
        """给实时面板用的紧凑视图: 最近状态帧 + 最近几条事件。不发任何命令。

        刻意与 `summary()` 分开: 面板每帧都要调, 不能每次都做全量统计。
        """
        st = self.state()
        if st is None:
            return {}
        out = dict(st)
        out["recent"] = [(e.get("event"), e.get("summary")) for e in self.events(n=events)]
        return out

    def summary(self) -> Dict[str, Any]:
        """把"最近状态帧 + 事件流"汇总成一份可直接打印/落盘的统计。"""
        st = self.state() or {}
        ev = self.events()

        tasks = [(e.get("from"), e.get("to")) for e in ev if e.get("event") == "TASK"]
        roads = [str(e.get("roadName")) for e in ev if e.get("event") == "ROAD" and e.get("roadName")]
        turns = [str(e.get("motion")) for e in ev if e.get("event") == "TURN" and e.get("motion")]
        goals = [e for e in ev if e.get("event") == "GOAL"]
        cells = [(e.get("x"), e.get("y")) for e in ev if e.get("event") == "CELL"]
        juncs = [e.get("stack") for e in ev if e.get("event") == "JUNC"]

        by_road: Dict[str, int] = {}
        for r in roads:
            by_road[r] = by_road.get(r, 0) + 1
        by_turn: Dict[str, int] = {}
        for t in turns:
            by_turn[t] = by_turn.get(t, 0) + 1

        return {
            "running": bool(st),
            "task": st.get("taskName"),
            "road": st.get("roadName"),
            "roadKind": st.get("roadKind"),
            "opens": st.get("opens"),
            "pos": (st.get("posX"), st.get("posY")) if st else None,
            "dir": DIR_NAMES.get(int(st.get("dir", 0)), "?") if st else None,
            "stack": st.get("stack"),
            "goal": bool(st.get("goal", False)),
            "back": bool(st.get("back", False)),
            "spurt": bool(st.get("spurt", False)),
            # "事件被丢弃"只有固件状态帧的 EVQ 标志能说明 —— 不能拿 EVMASK 回话去猜
            "evDropped": bool(st.get("evDropped", False)),
            "counters": {
                "evCount": int(st.get("evCount", len(ev))),
                "juncCnt": int(st.get("juncCnt", sum(1 for r in roads if r in JUNCTION_KINDS))),
                "turnCnt": int(st.get("turnCnt", len(turns))),
                "deadCnt": int(st.get("deadCnt", sum(1 for r in roads if r == "DEAD"))),
                # 周期帧里没有 cellCnt(它只在 SNAP MAZE 里), 未知就如实置 None
                "cellCnt": (int(st["cellCnt"]) if "cellCnt" in st else None) if st else None,
            },
            "roads": by_road,
            "turns": by_turn,
            "goalAt": (goals[0].get("x"), goals[0].get("y")) if goals else None,
            "path": cells,
            "taskSeq": tasks,
            "stackSeq": juncs,
            "flags": [n for b, n in MAZE_FLAG_NAMES.items() if st and int(st.get("flags", 0)) & b],
        }

    def explain(self) -> List[str]:
        """把 summary 变成若干行可直接打印的文字。"""
        s = self.summary()
        if not s["running"] and not s["counters"]["evCount"]:
            return ["（还没有迷宫状态数据: 先 maze.run 发车, 或 maze.snap() 点查）"]
        st = self.state() or {}
        motion_name = MOTION_TASK_NAMES.get(int(st.get("motion", 0)), str(st.get("motion", "—")))
        cells_txt = "—" if s["counters"]["cellCnt"] is None else str(s["counters"]["cellCnt"])
        lines = [
            f"状态机   : 任务 {s['task']}  动作 {motion_name}  朝向 {s['dir']}",
            f"路口     : {s['roadKind']}({s['road']})  开口 {s['opens']}  "
            f"岔路栈 {s['stack']}",
            f"位置     : ({s['pos'][0]},{s['pos'][1]})" if s["pos"] else "位置     : —",
            f"统计     : 事件 {s['counters']['evCount']}  岔路口 {s['counters']['juncCnt']}  "
            f"转向 {s['counters']['turnCnt']}  死路 {s['counters']['deadCnt']}  "
            f"格数 {cells_txt}",
        ]
        if s["roads"]:
            lines.append("路口分布 : " + "  ".join(f"{k}×{v}" for k, v in sorted(s["roads"].items())))
        if s["turns"]:
            lines.append("动作分布 : " + "  ".join(f"{k}×{v}" for k, v in sorted(s["turns"].items())))
        if s["goalAt"]:
            lines.append(f"终点     : 已到达 ({s['goalAt'][0]},{s['goalAt'][1]})")
        if s["flags"]:
            lines.append("标志     : " + " / ".join(s["flags"]))
        if s["evDropped"]:
            lines.append("⚠️ 事件有丢弃(链路拥塞): 事件流不完整, 但状态帧仍连续")
        if s["taskSeq"]:
            seq = " → ".join([str(s["taskSeq"][0][0])] + [str(t[1]) for t in s["taskSeq"]])
            lines.append("任务序列 : " + seq)
        return lines

    # ------------------------------------------------------------ 拉取

    def fetch(self, timeout: float = 10.0) -> Optional[Dict[str, Any]]:
        """请求并等待墙图。返回 `decode_map` 的结果。"""
        mc = self._mc
        mc._check_reentrancy("maze.fetch()")
        hits: List[Any] = []
        off = mc.on(Event.MAP, lambda m: hits.append(m))
        try:
            r = mc.send_cmd("maze.dump", timeout=3.0)
            if not r.ok and not hits:
                return mc.store.get_map()
            mc.wait(lambda: bool(hits), timeout=timeout)
        finally:
            off()
        if hits:
            return hits[0].data.get("rec")
        return mc.store.get_map()

    def last(self) -> Optional[Dict[str, Any]]:
        """最近一次收到的墙图(不发命令)。"""
        return self._mc.store.get_map()

    # ------------------------------------------------------------ 访问

    def mazetype(self) -> int:
        return int(self._mc.store.mazetype)

    def grid(self) -> Optional[List[List[int]]]:
        """墙位二维数组, `grid[x][y]`。"""
        m = self.last()
        return None if not m else m["mapWall"]

    def visited(self) -> Optional[List[List[bool]]]:
        m = self.last()
        return None if not m else m["mapVisited"]

    def position(self) -> Optional[Tuple[int, int, int, int]]:
        """(x, y, direction, mouseTask)。优先用墙图帧里的值, 否则用慢帧。"""
        m = self.last()
        if m:
            return (
                int(m.get("posX", 0)),
                int(m.get("posY", 0)),
                int(m.get("direction", 0)),
                int(m.get("mouseTask", 0)),
            )
        _f, _mid, slow = self._mc.store.latest()
        if slow:
            return (
                int(slow.get("posX", 0)),
                int(slow.get("posY", 0)),
                0,
                int(slow.get("mouseTask", 0)),
            )
        return None

    def cell(self, x: int, y: int) -> Optional[Dict[str, Any]]:
        """某一格的四方向通行情况。"""
        g = self.grid()
        if g is None:
            return None
        code = int(g[x][y])
        return {
            "x": x,
            "y": y,
            "code": code,
            "up": bool(code & WALL_UP_OPEN),
            "right": bool(code & WALL_RIGHT_OPEN),
            "down": bool(code & WALL_DOWN_OPEN),
            "left": bool(code & WALL_LEFT_OPEN),
            "visited": bool(self.visited()[x][y]) if self.visited() else None,
        }

    # ------------------------------------------------------------ 渲染

    def to_text(self, mark: Optional[Tuple[int, int]] = None) -> str:
        """渲染成 ASCII 迷宫。

        坐标约定: 列 = x(向右增大), 行 = y(向下增大), 因此 bit0「上」= y-1 方向。
        `mark` 给出当前位置, 会画成 `##`。
        """
        g = self.grid()
        if g is None:
            return "（还没有墙图数据, 先调 maze.fetch()）"
        n = self.mazetype()
        vis = self.visited()

        lines: List[str] = []
        for y in range(n):
            top = "+"
            for x in range(n):
                top += ("  " if (int(g[x][y]) & WALL_UP_OPEN) else "--") + "+"
            lines.append(top)
            mid = ""
            for x in range(n):
                left_open = bool(int(g[x][y]) & WALL_LEFT_OPEN)
                mid += (" " if left_open or x == 0 else "|")
                if mark is not None and (x, y) == mark:
                    mid += "##"
                elif vis is not None and vis[x][y]:
                    mid += "··"
                else:
                    mid += "  "
            mid += (" " if (int(g[n - 1][y]) & WALL_RIGHT_OPEN) else "|")
            lines.append(mid)
        bottom = "+"
        for x in range(n):
            bottom += ("  " if (int(g[x][n - 1]) & WALL_DOWN_OPEN) else "--") + "+"
        lines.append(bottom)
        return "\n".join(lines)

    def describe(self) -> str:
        """一行摘要: 尺寸、坐标、朝向、已探索格数。"""
        m = self.last()
        if not m:
            return "墙图: 未获取"
        n = self.mazetype()
        vis = self.visited()
        seen = sum(1 for col in vis for v in col if v) if vis else 0
        pos = self.position()
        return (
            f"墙图: {n}×{n}  坐标 ({pos[0]},{pos[1]}) 朝向 "
            f"{DIR_NAMES.get(pos[2], pos[2])}  已探索 {seen}/{n * n} 格"
        )
