"""数据模型: 线程安全的遥测环形缓冲与最新值快照。

读取线程往里写, Qt 主线程用定时器读 —— 所有访问都过锁,
所以两边都不需要跨线程信号。
"""

from __future__ import annotations

import threading
import time
from typing import Dict, List, Optional, Tuple

import numpy as np

from ..clock import now_monotonic
from ..protocol.codec import DUMP_PROFILE_CHANNELS, dump_profile

# 各流的通道定义(顺序即 numpy 列顺序)
FAST_CHANNELS = ["speedL", "speedR", "gyroAngle", "pidErr", "speedTargetL", "speedTargetR"]
MID_CHANNELS = ["cellOdom", "trackL", "trackR", "gyroRaw", "gyroDiff", "encAngle"]
SLOW_CHANNELS = ["irF1", "irF2", "irL", "irR", "posX", "posY", "volt", "cpu"]

# 各流的额定采样率(Hz), 用于时间轴换算
FAST_HZ = 250.0
MID_HZ = 50.0
SLOW_HZ = 5.0


class RingBuffer:
    """定长环形缓冲。容量满后覆盖最旧数据。"""

    def __init__(self, channels: List[str], capacity: int, hz: float) -> None:
        self.channels = channels
        self.capacity = capacity
        self.hz = hz
        self.buf = np.zeros((capacity, len(channels)), dtype=np.float64)
        self.ts = np.zeros(capacity, dtype=np.float64)  # 宿主时间(秒)
        self.idx = 0
        self.count = 0
        self.total = 0
        self.lock = threading.Lock()

    def push(self, values: List[float], t: Optional[float] = None) -> None:
        if t is None:
            t = time.time()
        with self.lock:
            self.buf[self.idx] = values
            self.ts[self.idx] = t
            self.idx = (self.idx + 1) % self.capacity
            if self.count < self.capacity:
                self.count += 1
            self.total += 1

    def snapshot(self, seconds: Optional[float] = None) -> Tuple[np.ndarray, np.ndarray]:
        """按时间正序返回 (t, data)。seconds 给定时只取最近这么多秒。"""
        with self.lock:
            n = self.count
            if n == 0:
                return np.zeros(0), np.zeros((0, len(self.channels)))
            if n < self.capacity:
                t = self.ts[:n].copy()
                d = self.buf[:n].copy()
            else:
                i = self.idx
                t = np.concatenate([self.ts[i:], self.ts[:i]])
                d = np.concatenate([self.buf[i:], self.buf[:i]])
        if seconds is not None and len(t) > 1:
            t0 = t[-1] - seconds
            k = int(np.searchsorted(t, t0))
            t = t[k:]
            d = d[k:]
        return t, d

    def clear(self) -> None:
        with self.lock:
            self.idx = 0
            self.count = 0
            self.total = 0


class TelemetryStore:
    """三路遥测流 + 最新值 + 墙图 + dump 累积。"""

    def __init__(self, window_s: float = 30.0) -> None:
        self.fast = RingBuffer(FAST_CHANNELS, int(window_s * FAST_HZ), FAST_HZ)
        self.mid = RingBuffer(MID_CHANNELS, int(window_s * MID_HZ), MID_HZ)
        self.slow = RingBuffer(SLOW_CHANNELS, max(int(window_s * SLOW_HZ), 64), SLOW_HZ)

        self.lock = threading.Lock()
        self.latest_fast: Dict[str, float] = {}
        self.latest_mid: Dict[str, float] = {}
        self.latest_slow: Dict[str, float] = {}
        self.latest_time: Optional[dict] = None  # 最近一帧时间同步帧(1Hz)
        # ---- 迷宫状态机(实验8): 最近一帧 + 近况轨迹(用单调时钟记到达时刻) ----
        self.latest_maze: Optional[dict] = None
        self.maze_history: List[tuple] = []  # [(mono_ts, rec)]
        #: 时间同步: (收到该帧的本机单调秒, 设备 ms 时基) 的最近若干对,
        #: 供 TimeSyncAPI 估偏移与漂移(见 host/host/api/timesync.py)。
        self.time_history: List[Tuple[float, int]] = []
        self.map_data: Optional[dict] = None
        self.mazetype: int = 7

        # dump 累积
        self.dump_active = False
        self.dump_hdr: Optional[dict] = None
        self.dump_blocks: Dict[int, list] = {}
        self.dump_words_blocks: Dict[int, list] = {}  # 同上的原始 4×u16(剖面 B..E)
        self.dump_records: List[Tuple[int, int, int, int]] = []  # (motionTask, gangle, speedl, speedr)
        self.dump_words: List[Tuple[int, int, int, int]] = []  # 原始 4×u16(任意剖面)
        self.dump_done = False
        self.dump_chksum = 0
        self.dump_time: Optional[float] = None

        # 事件流(来自文本异步行)
        self.events: List[Tuple[float, str]] = []

        self.on_dump_complete = None
        self.on_maze_change = None  # 每收到一帧迷宫状态帧时回调(可选)  # 可选回调(注意: 在读取线程中触发)

        # 每收到一帧就回调一次, 签名 cb(stream: str, rec: dict), stream ∈ {fast, mid, slow}。
        # **在读取线程中触发**, 因此回调必须是轻量的(门面里只做"入队")。
        # 有了它, 落盘才能做到"每帧一行"而不是"轮询最新快照" —— 后者在高采样率下
        # 会丢掉同一个轮询周期内的多数样本(轮询期 20ms, 而 250Hz 时一期内有 5 帧)。
        self.on_frame = None

    # ------------------------------------------------------------ 写入

    def _notify(self, stream: str, rec: dict) -> None:
        cb = self.on_frame
        if cb is None:
            return
        try:
            cb(stream, rec)
        except Exception:
            pass  # 订阅者异常绝不能打断读取线程

    def push_fast(self, rec: dict) -> None:
        self.fast.push([rec[c] for c in FAST_CHANNELS])
        with self.lock:
            self.latest_fast = rec
        self._notify("fast", rec)

    def push_mid(self, rec: dict) -> None:
        self.mid.push([rec[c] for c in MID_CHANNELS])
        with self.lock:
            self.latest_mid = rec
        self._notify("mid", rec)

    def push_slow(self, rec: dict) -> None:
        self.slow.push(
            [
                rec["irF1"],
                rec["irF2"],
                rec["irL"],
                rec["irR"],
                rec["posX"],
                rec["posY"],
                rec["volt"],
                rec["cpu"],
            ]
        )
        with self.lock:
            self.latest_slow = rec
        self._notify("slow", rec)

    def push_time(self, rec: dict) -> None:
        """时间同步帧(1Hz)。**用单调时钟记录到达时刻** —— 它是"设备时间→PC 时间"
        映射的唯一锚点, 绝不能受墙钟回拨影响。

        到达时刻优先取 `link._dispatch_frame` 附在记录上的 `_rx_mono`(那是真正
        "刚解析出来"的瞬间), 取不到才退回本函数自己取一次。
        """
        t = float(rec.get("_rx_mono") or now_monotonic())
        with self.lock:
            self.latest_time = rec
            self.time_history.append((t, int(rec.get("upMs", 0))))
            if len(self.time_history) > 600:  # 10 分钟 @1Hz
                del self.time_history[: len(self.time_history) - 600]
        self._notify("time", rec)

    def push_maze(self, rec: dict) -> None:
        """迷宫状态帧(仅迷宫态 @1Hz)。到达时刻用**单调时钟**, 与时间同步同一套时基。

        之所以保留一小段历史: 状态帧的用途是"趋势"(在哪个格、第几个岔路口、
        是否已到终点), 单看最近一帧无法判断"是不是刚变了"。
        """
        t = float(rec.get("_rx_mono") or now_monotonic())
        with self.lock:
            self.latest_maze = rec
            self.maze_history.append((t, rec))
            if len(self.maze_history) > 300:  # 5 分钟 @1Hz
                del self.maze_history[: len(self.maze_history) - 300]
            cb = self.on_maze_change
        if cb is not None:
            try:
                cb(rec)
            except Exception:
                pass
        self._notify("maze", rec)

    def push_map(self, rec: dict) -> None:
        with self.lock:
            self.map_data = rec
            self.mazetype = rec["mazetype"]
        self._notify("map", rec)

    def push_event(self, text: str) -> None:
        with self.lock:
            self.events.append((time.time(), text))
            if len(self.events) > 500:
                del self.events[:250]

    # ------------------------------------------------------------ dump

    def dump_begin(self) -> None:
        with self.lock:
            self.dump_active = True
            self.dump_done = False
            self.dump_hdr = None
            self.dump_blocks = {}
            self.dump_records = []
            self.dump_chksum = 0

    def push_dump_hdr(self, rec: dict) -> None:
        with self.lock:
            self.dump_hdr = rec

    def push_dump_blk(self, rec: dict) -> None:
        with self.lock:
            self.dump_blocks[rec["blkIdx"]] = rec["records"]
            # 原始 4×u16(剖面 B..E 用)。旧固件/模拟器不带 words 时留空。
            if "words" in rec:
                self.dump_words_blocks[rec["blkIdx"]] = rec["words"]

    def push_dump_end(self, rec: dict) -> None:
        with self.lock:
            records: List[Tuple[int, int, int, int]] = []
            words: List[Tuple[int, int, int, int]] = []
            for k in sorted(self.dump_blocks.keys()):
                records.extend(self.dump_blocks[k])
                words.extend(self.dump_words_blocks.get(k, []))
            self.dump_records = records
            self.dump_words = words
            self.dump_chksum = rec["chksum"]
            self.dump_done = True
            self.dump_active = False
            self.dump_time = time.time()
            cb = self.on_dump_complete
        if cb is not None:
            try:
                cb(self.dump_records)
            except Exception:
                pass

    # ------------------------------------------------------------ 剖面视图

    def dump_profile(self) -> str:
        """本次 dump 的**录制剖面**字母(A..E)。

        来自 `DUMP_HDR.channels` —— 固件把"channels"这个字节复用成剖面标识:
        A 报 4(与旧版逐字节一致), B..E 报 ASCII 'B'..'E'。
        认不出来的一律当 A, 因此旧固件的 dump 仍然是"运动学"。
        """
        with self.lock:
            hdr = dict(self.dump_hdr) if self.dump_hdr else {}
        return dump_profile(hdr.get("channels", 4))

    def dump_profile_channels(self) -> List[str]:
        """本次剖面 4 个 8B 通道的字段名(见 `DUMP_PROFILE_CHANNELS`)。"""
        return list(DUMP_PROFILE_CHANNELS.get(self.dump_profile(), DUMP_PROFILE_CHANNELS["A"]))

    def dump_profile_arrays(self):
        """返回 `(t_ms, {通道名: np.array})`, 按时间正序 —— **任意剖面通用**。

        与 `dump_arrays()` 的区别: 后者是剖面 A 的专用旧接口(保持兼容不动),
        本方法按 `dump_profile()` 给通道命名, 于是 B(红外 mm)/C(红外 ADC)/
        D(电压)/E(混合) 都能被同一套代码取出来画图。

        时间轴与截断/旋转的处理与 `dump_arrays()` 完全一致(共用同一份还原逻辑)。
        """
        with self.lock:
            words = list(self.dump_words)
            hdr = dict(self.dump_hdr) if self.dump_hdr else {}
            prof = dump_profile(hdr.get("channels", 4))
        if not words:
            return None
        arr = np.array(words, dtype=np.int32)
        arr = self._restore_time_order(arr, hdr)
        if arr is None:
            return None
        arr, t = arr
        names = DUMP_PROFILE_CHANNELS.get(prof, DUMP_PROFILE_CHANNELS["A"])
        return t, {n: arr[:, i] for i, n in enumerate(names)}

    def _restore_time_order(self, arr, hdr):
        """把"块 0 起"的线性回传还原成时间正序, 并生成绝对时间轴。

        三步(filled 截断 -> 回绕旋转 -> startMs 绝对时刻)是 dump 解析的**唯一**
        正确做法; `dump_arrays()` 与 `dump_profile_arrays()` 共用本方法,
        避免两处实现走偏(时间轴错了波形就整体错位, 而且很难一眼看出来)。
        """
        filled = int(hdr.get("filled", len(arr)) or len(arr))
        start = int(hdr.get("start", 0) or 0)
        start_ms = int(hdr.get("startMs", 0) or 0)
        n = len(arr)
        filled = max(0, min(filled, n))
        if filled == 0:
            return None
        if filled < n:
            arr = arr[:filled]  # 未回绕: 有效数据就是前 filled 点
        elif 0 < start < n:
            arr = np.concatenate([arr[start:], arr[:start]])  # 已回绕: 旋转到时间正序
        t = np.arange(len(arr), dtype=np.float64) + float(start_ms)
        return arr, t

    def dump_arrays(self):
        """返回 (t_ms, motionTask, gangle, speedl, speedr), 按**时间正序**排列。

        固件固定回传全部 1200 点(块 0 起), 但:
          - 若本次采集不足 1200 点, 尾部是陈旧数据 -> 用 hdr.filled 截断
          - 若已回绕, 块 0 不是时间上最早的点 -> 用 hdr.start (写指针) 旋转
        这两步不做的话, 波形的时间轴是错的。

        时间轴 `t_ms`: 若 hdr 带了 `startMs`(固件时间同步帧/头的绝对毫秒时基),
        就是 **绝对设备时刻**(t = startMs + i), 可与 ARM 发车时刻、1Hz 基准灯直接对齐;
        否则退化为从 0 起的相对毫秒, 与旧行为一致。
        """
        with self.lock:
            recs = list(self.dump_records)
            hdr = dict(self.dump_hdr) if self.dump_hdr else {}
        if not recs:
            return None
        arr = np.array(recs, dtype=np.int32)
        restored = self._restore_time_order(arr, hdr)
        if restored is None:
            return None
        arr, t = restored
        return t, arr[:, 0], arr[:, 1], arr[:, 2], arr[:, 3]

    def dump_progress(self) -> float:
        with self.lock:
            if self.dump_hdr is None:
                return 0.0
            total = self.dump_hdr.get("totalPts", 1) or 1
            got = sum(len(v) for v in self.dump_blocks.values())
        return min(1.0, got / float(total))

    def reset_dump(self) -> None:
        """开始新一轮回传前清空上一轮状态。

        不能直接用 dump_begin(): 那是给"采集"用的, 会置 dump_active。
        这里只清回传累积, 便于进度条从 0 重新计。
        """
        with self.lock:
            self.dump_hdr = None
            self.dump_blocks = {}
            self.dump_records = []
            self.dump_done = False
            self.dump_chksum = 0

    def dump_bytes_received(self) -> int:
        """已回传的近似字节数 = 点数×8 + 块开销, 用于估算实时速率。"""
        with self.lock:
            got = sum(len(v) for v in self.dump_blocks.values())
            nblk = len(self.dump_blocks)
        return got * 8 + nblk * 8

    # ------------------------------------------------------------ 读

    def latest(self) -> Tuple[dict, dict, dict]:
        with self.lock:
            return dict(self.latest_fast), dict(self.latest_mid), dict(self.latest_slow)

    def get_map(self) -> Optional[dict]:
        with self.lock:
            return self.map_data

    def clear(self) -> None:
        self.fast.clear()
        self.mid.clear()
        self.slow.clear()
        with self.lock:
            self.latest_fast = {}
            self.latest_mid = {}
            self.latest_slow = {}
