"""命令与帧的单一登记点(E1)。

扩展规约 —— 新增一项功能时只允许改本文件的表:

    新增一条下行命令  ->  COMMANDS 里加一个 CommandSpec
    新增一种上行帧    ->  FRAMES   里加一个 FrameSpec
    新增一个参数      ->  protocol/commands.py 的 PARAM_IDS / PARAM_META

两条由 contract_test.py 静态断言、由 CI 强制:

    a) transport/link.py 的帧分派必须走 FRAMES, 不得出现 `type == TYPE_*` 比较
       或 decode_* 直调(否则新增帧要改两处, 迟早漂移)
    b) 每个登记项都必须能被模拟器实际执行(契约测试逐条跑)

本模块只**描述**命令, 不实现传输。执行走 run(), 由调用者传入 CommandClient。
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Dict, Tuple

from .protocol.codec import (
    TYPE_DUMP_BLK,
    TYPE_DUMP_END,
    TYPE_DUMP_HDR,
    TYPE_FAST,
    TYPE_MAP,
    TYPE_MAZE,
    TYPE_MID,
    TYPE_SLOW,
    TYPE_TIME,
    decode_dump_blk,
    decode_dump_end,
    decode_dump_hdr,
    decode_maze,
    decode_fast,
    decode_map,
    decode_mid,
    decode_slow,
    decode_time,
)
from .protocol.commands import CommandClient

API_VERSION = "1.5.5"


# ---------------------------------------------------------------- 命令表

def _move_fwd(pulses: int, speed: int = 0) -> str:
    """speed 为 0 时省略 —— 固件据此走默认速度。与 commands.move_fwd 行为一致。"""
    return f"MOVE FWD {int(pulses)}" + (f" {int(speed)}" if speed else "")


def _move_rot(pwm: int, ms: int = 0) -> str:
    return f"MOVE ROT {int(pwm)}" + (f" {int(ms)}" if ms else "")


def _move_run(sp_l: int, sp_r: int, ms: int = 0, ir_mm: int = 0) -> str:
    """受"时间 + 红外"双护栏约束的远程运动(电机远程控制实验)。

    ms / ir_mm 为 0 时省略该参数, 由固件取默认值(2000 ms / 10 mm);
    ir_mm 传负值 (-1) 表示**关闭红外护栏**, 只验证时间护栏。
    """
    s = f"MOVE RUN {int(sp_l)} {int(sp_r)}"
    if ms or ir_mm:
        s += f" {int(ms)}"
        if ir_mm:
            s += f" {int(ir_mm)}"
    return s


def _maze_ev(mask: str = "") -> str:
    """`MAZE EV [mask|OFF|DEF|ALL]` —— 不带参数即查询当前掩码。"""
    m = str(mask).strip()
    return "MAZE EV" + (f" {m}" if m else "")


def _lesson_start(exp: int, a: int = 0, b: int = 0, c: int = 0, d: int = 0) -> str:
    """`LESSON START <exp> [a] [b] [c] [d]` —— 尾部为 0 的参数省略。

    固件用同一个整数解析器逐项取参, 取不到就按 0 处理, 因此"少写尾部 0"是安全的。
    参数含义随实验而定(见 host/host/api/lesson.py 的 LESSON_EXPS)。
    """
    vals = [int(a), int(b), int(c), int(d)]
    while vals and vals[-1] == 0:
        vals.pop()
    return " ".join([f"LESSON START {int(exp)}"] + [str(v) for v in vals])


@dataclass(frozen=True)
class CommandSpec:
    """一条下行命令。

    name  : API 名(点分层级), 也是 CLI 子命令与(将来)JSON-RPC 方法名的来源
    build : 由关键字参数拼出线上命令文本
    args  : build 接受的参数名(顺序即位置参数顺序), 供文档与参数校验使用
    ack   : 设备是否回 `ACK <seq> <status>`(全部为真, 保留字段以备将来单向命令)
    since : 引入该命令的 API 版本
    note  : 一句话说明, 会进自动生成的接口文档
    """

    name: str
    build: Callable[..., str]
    args: Tuple[str, ...] = ()
    ack: bool = True
    since: str = "1.0"
    note: str = ""
    #: 超时后是否重发。仅对"一发就已产生持续性副作用"的命令置 False:
    #: 重发不会让效果更快, 反而会往正在进行的流程里插命令。
    #: 目前只有 `scope.dump`(dump 一旦启动就在全速占用链路)。
    no_retry: bool = False


COMMANDS: Dict[str, CommandSpec] = {
    # ---- 设备与协议 ----
    "ping": CommandSpec("ping", lambda: "PING", note="心跳; 回 PONG <proto> <fw> <mazetype>"),
    "ver": CommandSpec("ver", lambda: "VER", note="固件版本与编译期常量"),
    # ---- 参数 ----
    "params.get": CommandSpec("params.get", lambda name: f"GET {name}", ("name",), note="回读单个参数(Q16.16)"),
    "params.get_all": CommandSpec("params.get_all", lambda: "GET ALL", note="回读全部参数"),
    "params.setq": CommandSpec(
        "params.setq", lambda name, q: f"SETQ {name} {int(q)}", ("name", "q"),
        note="写精确 Q16.16 定点(推荐路径)",
    ),
    "params.set": CommandSpec(
        "params.set", lambda name, v: f"SET {name} {v}", ("name", "v"),
        note="写十进制(精度低, 仅供手工调试)",
    ),
    "params.save": CommandSpec("params.save", lambda: "SAVE", note="参数表写入 Flash"),
    "params.reset": CommandSpec("params.reset", lambda: "RESET", note="擦参数页并复位为源码默认值"),
    # ---- 阻塞式测量快照(非数据采集阶段获取"全部可测量量"的唯一入口) ----
    "snap.get": CommandSpec(
        "snap.get", lambda dom=None: "SNAP" if not dom else f"SNAP {str(dom).upper()}",
        ("dom",),
        note=(
            "一问一答地取当前全部测量值。dom ∈ {MOTION,ODOM,SENSE,POWER,TIME,ALL}(省略=ALL)。"
            "回若干行 `SNAP <DOMAIN> <v...>` + ACK; **不依赖 STREAM ON**, 也不占常驻带宽。"
            "空间不足时回 ERR_BUSY(上位机应视为本轮跳过)"
        ),
    ),
    # ---- 运动控制 ----
    "tare": CommandSpec("tare", lambda: "TARE", note="陀螺角累加器与里程基准清零"),
    "stop": CommandSpec("stop", lambda: "STOP", note="正常停止"),
    "estop": CommandSpec("estop", lambda: "ESTOP", note="急停(置 freemode)"),
    # ---- 遥测开关 ----
    "stream.on": CommandSpec(
        "stream.on", lambda: "STREAM ON",
        note="开启遥测流。**固件上电默认静默**(否则会在无人读取时把蓝牙模块缓冲灌满)",
    ),
    "stream.off": CommandSpec("stream.off", lambda: "STREAM OFF"),
    "rate": CommandSpec(
        "rate", lambda hz: f"RATE {int(hz)}", ("hz",),
        note="快帧速率; 固件仅接受 {100,50,20,10,5,2} Hz; 受链路吞吐限制",
    ),
    # ---- 标定 ----
    "calib.cal": CommandSpec(
        "calib.cal", lambda item, act: f"CAL {item} {act}", ("item", "act"),
        note="标定项控制: item ∈ {GYRO,WALLDIST,IRDATA,GYRORATIO,ENCANGLE}, act ∈ {START,SAMPLE,ABORT}",
    ),
    # ---- 示波器 ----
    "scope.start": CommandSpec(
        "scope.start", lambda prof=None: "SCOPE START" if not prof else f"SCOPE START {str(prof).upper()}",
        ("prof",),
        note=(
            "开始 1kHz 本地采集(环缓冲 1200 点=1.2s)。prof 决定这块 8B/点的内存装什么: "
            "A=运动学(默认) / B=四路红外 mm / C=四路红外原始 ADC / D=电压 / E=混合。"
            "**一次只录一种**(20KB RAM 装不下全通道并行), 零新增 RAM"
        ),
    ),
    "scope.stop": CommandSpec("scope.stop", lambda: "SCOPE STOP"),
    "scope.dump": CommandSpec(
        "scope.dump", lambda: "SCOPE DUMP", no_retry=True,
        note=("整块回传; 固定 20 块 ≈ 9.8KB, 真机约 7s。**不重发**: 一发就开始全速占用链路, "
              "而它的 ACK 可能被 dump 数据挤后约 1s(真机实测) —— 重发只会添乱; "
              "是否收到数据以 DUMP_DONE 为准, 不以这声 ACK 为准"),
    ),
    # ---- 迷宫 ----
    "maze.dump": CommandSpec("maze.dump", lambda: "MAP DUMP", note="墙图整块回传"),
    "maze.ev": CommandSpec(
        "maze.ev", _maze_ev, ("mask",),
        note=(
            "设置迷宫事件掩码(0..63 十进制 / OFF / DEF / ALL), 不带参数=查询。"
            "位: 1=TASK 2=ROAD 4=JUNC 8=TURN 16=GOAL 32=CELL(默认关, 量最大); 缺省 31"
        ),
    ),
    "maze.rst": CommandSpec(
        "maze.rst", lambda: "MAZE RST",
        note="清迷宫统计(事件计数/岔路口/死路/转弯/格数); 事件掩码保留",
    ),
    # ---- 开环移动(标定辅助) ----
    "move.fwd": CommandSpec("move.fwd", _move_fwd, ("pulses", "speed"), note="固定脉冲直线(开环)"),
    "move.rot": CommandSpec("move.rot", _move_rot, ("pwm", "ms"), note="固定 PWM 定长原地转(开环)"),
    # ---- 远程控制(电机实验)。双护栏在固件 1ms ISR 里判定, 不依赖上位机在线 ----
    "move.run": CommandSpec(
        "move.run", _move_run, ("sp_l", "sp_r", "ms", "ir_mm"),
        note=(
            "受双护栏约束的远程运动: 左右轮速度(cm/s) + 最长运行时间(默认2000ms) "
            "+ 红外停车阈值(默认10mm, 负值=关闭)。停止后回 MOVEDONE RUN 明细, "
            "并自动冻结 1kHz 日志待 SCOPE DUMP"
        ),
    ),
    "estop.clear": CommandSpec(
        "estop.clear", lambda: "STOP",
        note="正常停车 + **解急停锁存**(测试模式下 STOP 兼作复位); 这是重新获得控制权的唯一入口",
    ),
    # ---- 时间同步 / 数据收集(不依赖固件模式; 见 docs/数据收集与时间同步.md) ----
    "arm": CommandSpec(
        "arm", lambda: "ARM",
        note=(
            "发车: 固件记下发车时刻 + 点亮 1Hz 时间基准灯(50% 占空比), "
            "并回一行 `ARMED <ms>`。之后每秒上行一帧 TIME(带完整 u32 时基), "
            "每个快帧也带时基低 8 位 —— 上位机据此把每个采样点钉到准确时刻"
        ),
    ),
    "maze.run": CommandSpec(
        "maze.run", lambda: "MAZE RUN",
        note=(
            "远程发车跑无记忆走迷宫(**仅 MOUSE_DATA_LOG 档**; 其余固件回 ERR_VALUE)。 "
            "固件只置请求位, 真正的 while(1) 迷宫由主循环执行 —— "
            "所以下达后命令通道与遥测都不会被阻塞"
        ),
    ),
    # ---- 课程调参实验(仅 MOUSE_LESSON_LAB 固件; 生产固件回 ERR_VALUE) ----
    "lesson.start": CommandSpec(
        "lesson.start", _lesson_start, ("exp", "a", "b", "c", "d"),
        note=(
            "启动课程实验并自带时间护栏。exp: 2=编码器测距 3=匀变速直行 "
            "5=陀螺标定 6=多传感器直行; 结束时固件上行 `LESSON DONE ...`"
        ),
    ),
    "lesson.stop": CommandSpec(
        "lesson.stop", lambda: "LESSON STOP", note="中止课程实验(停车并回 LESSON DONE ... STOP)",
    ),
    "lesson.status": CommandSpec(
        "lesson.status", lambda: "LESSON STATUS",
        note="回一行 `LESSON STATUS <exp> <running>` 异步状态",
    ),
}


def run(client: CommandClient, cmd: str, wait: bool = True, **kw: Any):
    """按名字执行一条登记在册的命令。返回 Pending(或 (ok, status) 形式见下)。

    这是"逃生舱"之上的**唯一**命令执行入口 —— CLI、契约测试、子 API 都走它,
    所以登记表就是命令的全集。
    """
    spec = COMMANDS.get(cmd)
    if spec is None:
        raise KeyError(f"未登记的命令: {cmd!r} (可用的见 registry.COMMANDS)")
    line = spec.build(**kw)
    return client.send(line, wait=wait)


def command_line(cmd: str, **kw: Any) -> str:
    """只拼命令文本, 不发送(供文档、日志、测试比对)。"""
    spec = COMMANDS[cmd]
    return spec.build(**kw)


def spec_of(cmd: str) -> CommandSpec:
    return COMMANDS[cmd]


def names(prefix: str = "") -> list:
    return sorted(n for n in COMMANDS if n.startswith(prefix))


# ---------------------------------------------------------------- 帧表

def _decode_map_auto(p: bytes) -> dict:
    """墙图帧的 mazetype 由载荷长度反推(墙图 + 访问图各 n² 字节)。

    固件不重复发 mazetype, 所以这里必须自己算 —— 做成统一签名后, FRAMES 的
    decoder 全部是 `Callable[[bytes], dict]`, 分派代码不必为某一种帧开特例。
    """
    n = int(((len(p) - 4) // 2) ** 0.5 + 0.5)
    return decode_map(p, n)


@dataclass(frozen=True)
class FrameSpec:
    """一种上行帧。

    sink  : `TelemetryStore` 上的累积方法名。帧分派**完全由表驱动** ——
            新增一种帧不需要改 link.py 一行代码。
    count : 计入 `Link.counts` 的键名(None = 该帧不单独计数)
    """

    type: int
    name: str
    decoder: Callable[[bytes], dict]
    stream: str
    sink: str
    count: "str | None" = None
    since: str = "1.0"


FRAMES: Dict[int, FrameSpec] = {
    TYPE_FAST: FrameSpec(TYPE_FAST, "FAST", decode_fast, "fast", "push_fast", "fast"),
    TYPE_MID: FrameSpec(TYPE_MID, "MID", decode_mid, "mid", "push_mid", "mid"),
    TYPE_SLOW: FrameSpec(TYPE_SLOW, "SLOW", decode_slow, "slow", "push_slow", "slow"),
    TYPE_DUMP_HDR: FrameSpec(TYPE_DUMP_HDR, "DUMP_HDR", decode_dump_hdr, "dump_hdr", "push_dump_hdr"),
    TYPE_DUMP_BLK: FrameSpec(
        TYPE_DUMP_BLK, "DUMP_BLK", decode_dump_blk, "dump_blk", "push_dump_blk", "dump_blk"
    ),
    TYPE_DUMP_END: FrameSpec(TYPE_DUMP_END, "DUMP_END", decode_dump_end, "dump_end", "push_dump_end"),
    TYPE_MAP: FrameSpec(TYPE_MAP, "MAP", _decode_map_auto, "map", "push_map", "map"),
    TYPE_TIME: FrameSpec(TYPE_TIME, "TIME", decode_time, "time", "push_time", "time"),
    TYPE_MAZE: FrameSpec(TYPE_MAZE, "MAZE", decode_maze, "maze", "push_maze", "maze"),
}


def frame_spec(ftype: int) -> "FrameSpec | None":
    return FRAMES.get(ftype)


# ---------------------------------------------------------------- 静态断言

#: link.py 里出现这些即说明帧分派被硬编码了 —— 新增帧就会漏改, 由契约测试报红。
FRAME_DISPATCH_FORBIDDEN = (
    "decode_fast(",
    "decode_mid(",
    "decode_slow(",
    "decode_map(",
    "decode_dump_hdr(",
    "decode_dump_blk(",
    "decode_dump_end(",
)


def check_frame_dispatch_is_table_driven(link_source: str) -> list:
    """检查 link.py 的帧分派是否走表。返回违规行说明列表(空 = 通过)。

    允许 `import` 行出现这些名字吗? 不允许 —— 改表之后 link.py 根本不需要导入它们。
    """
    bad = []
    for i, line in enumerate(link_source.splitlines(), 1):
        s = line.strip()
        if s.startswith("#") or s.startswith("//"):
            continue
        for pat in FRAME_DISPATCH_FORBIDDEN:
            if pat in line:
                bad.append(f"link.py:{i}: 出现 {pat.rstrip('(')} —— 帧分派应走 registry.FRAMES")
    return bad
