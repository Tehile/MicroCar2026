"""电脑鼠设备模拟器 —— 在没有硬件时让上位机完整跑通。

它按与固件 HARDWARE/link.c **完全相同的字节级协议**回话:
    - 1kHz 内部节拍, 按 250/50/5 Hz 产出快/中/慢三种二进制帧
    - 响应全部文本命令(ACK/GET/SET/SETQ/SAVE/RESET/TARE/STOP/ESTOP/RATE/SCOPE/MAP/MOVE/CAL)
    - 复刻 1200 点环形缓冲与 dump 分块回传(含冻结-防竞态语义)
    - 复刻 Flash 参数页的 magic/version/CRC 校验与"校验失败即忽略"的降级行为

用途有二:
    1. 上位机开发/演示(现在没有硬件也能验证全链路)
    2. 协议回归: selftest.py 可以把它拉起来做端到端断言

用法:
    python -m host.sim.mouse_sim               # 默认监听 127.0.0.1:5555
    python -m host.sim.mouse_sim --port 5556 --no-auto
"""

from __future__ import annotations

import argparse
import math
import random
import socket
import struct
import threading
import time
from typing import Dict, List, Optional, Tuple

from ..protocol.codec import (
    SCOPE_BLKS,
    SCOPE_LEN,
    SCOPE_PTS_PER_BLK,
    TYPE_DUMP_BLK,
    TYPE_DUMP_END,
    TYPE_DUMP_HDR,
    TYPE_FAST,
    TYPE_MAP,
    TYPE_MAZE,
    TYPE_MID,
    TYPE_SLOW,
    TYPE_TIME,
    MAZE_TASK_NAMES,
    ROAD_NAMES,
    crc16_modbus,
    pack_frame,
)

#: 转向/掉头类动作 -> 事件名。**镜像固件 link.c 的 link_TurnName()**:
#: 只有"转向/掉头"才进 TURN 事件流(直行/贴墙不报, 否则事件太密)。
MAZE_TURN_NAMES: Dict[int, str] = {
    2: "TURN", 4: "TURNAROUND", 39: "POINT90", 14: "TURNL", 15: "TURNR",
    27: "BEFORE90", 28: "BEFORE180", 29: "AFTER180", 17: "S45",
    101: "LT90", 102: "RT90", 103: "POINT_R90", 104: "POINT_L90",
    106: "LT90_SPURT", 107: "RT90_SPURT",
}

#: 迷宫任务机名(与固件 maze.h / 上位机 codec 同源)
MAZE_TASK_NAMES_SIM = MAZE_TASK_NAMES
#: 路口类型名(与固件 LINK_ROAD_* 同源)
MAZE_ROAD_NAMES = ROAD_NAMES

#: 迷宫事件掩码位(镜像固件 link.h)
MAZE_EV_TASK, MAZE_EV_ROAD, MAZE_EV_JUNC = 0x01, 0x02, 0x04
MAZE_EV_TURN, MAZE_EV_GOAL, MAZE_EV_CELL = 0x08, 0x10, 0x20
MAZE_EV_DEF = 0x1F

MAZETYPE = 7
PROTO_VER = 1
FW_VER = 100

# 参数表(与固件 id 对齐); 初值 = 固件 ISR_Init 里的源码默认值
PARAM_DEFAULTS: Dict[int, float] = {
    # ---- 生产标定(1..7, 任何固件都有) ----
    1: 62.59 * 0.85,  # TRACKL
    2: 62.68 * 0.85,  # TRACKR
    3: 0.6259 * 0.85,  # SPEEDL
    4: 0.6268 * 0.85,  # SPEEDR
    5: 399.0,  # GYRORATIO (u16 截断后的值)
    6: 67.0,  # ENCANGLE  (u16)(75*0.90)
    7: 42.0,  # WALLDIST
    # ---- 课程调参(8..21, 仅 MOUSE_LESSON_LAB 固件可读; 生产固件会回 ERR_NAME) ----
    8: 10.75,  # KPL  (= motor.h 红线值)
    9: 0.55,   # KIL
    10: 0.55,  # KDL
    11: 10.20, # KPR
    12: 0.5,   # KIR
    13: 0.5,   # KDR
    14: 0.1,   # IRPL
    15: 0.1,   # IRPR
    16: 2.5,   # GYROP
    17: 1.6,   # GYROD
    18: 50.0,  # SPEEDNEED
    19: 1000.0,  # ALLDIS
    20: 0.0,  # SENSORMODE  (0=全关)
    21: 1.0,  # WALLMODE     (1=靠左)
    # ---- 红外测量与阈值(22-32, 生产命名空间; 默认值 = 固件 core.h 的原宏值) ----
    22: 160.0,  # IRTHRWALL  (WALL_SIDE_THRESHOLD)
    23: 150.0,  # IRTHR45    (WALL_45_THRESHOLD)
    24: 60.0,  # IRTHRCRIT  (WALL_CRITICAL_THRESHOLD)
    25: 230.0,  # IRTHRFLO   (WALL_FRONT_FAR_LO)
    26: 240.0,  # IRTHRFMID  (WALL_FRONT_FAR_MID)
    27: 245.0,  # IRTHRFHI   (WALL_FRONT_FAR_HI)
    28: 80.0,  # IRTHRFNEAR (WALL_FRONT_NEAR)
    29: 100.0,  # IRKALQ     (0.0100 ×10000)
    30: 2000.0,  # IRKALP    (0.2000 ×10000)
    31: 1.0,  # IRKALSW      (卡尔曼开)
    32: 0.0,  # IRFRONTMODE  (0=均值)
    # ---- 电源监控(33-38; 默认值 = 固件 safety.c 原写死值的等价表示) ----
    33: 2417.0,  # BATTKV     (µV/LSB = 3.3V×3÷4096×1000)
    34: 7000.0,  # BATTLOWMV
    35: 7960.0,  # BATTHIGHMV (7000 + 8×120mV, 与原式 (volt-700)/12 一致)
    36: 100.0,  # BATTALPHA   (0.100 ×1000)
    37: 8.0,  # BATTMAXPCT
    38: 1.0,  # BATTMINPCT
}
PARAM_NAMES = {
    1: "TRACKL",
    2: "TRACKR",
    3: "SPEEDL",
    4: "SPEEDR",
    5: "GYRORATIO",
    6: "ENCANGLE",
    7: "WALLDIST",
    8: "KPL",
    9: "KIL",
    10: "KDL",
    11: "KPR",
    12: "KIR",
    13: "KDR",
    14: "IRPL",
    15: "IRPR",
    16: "GYROP",
    17: "GYROD",
    18: "SPEEDNEED",
    19: "ALLDIS",
    20: "SENSORMODE",
    21: "WALLMODE",
    22: "IRTHRWALL",
    23: "IRTHR45",
    24: "IRTHRCRIT",
    25: "IRTHRFLO",
    26: "IRTHRFMID",
    27: "IRTHRFHI",
    28: "IRTHRFNEAR",
    29: "IRKALQ",
    30: "IRKALP",
    31: "IRKALSW",
    32: "IRFRONTMODE",
    33: "BATTKV",
    34: "BATTLOWMV",
    35: "BATTHIGHMV",
    36: "BATTALPHA",
    37: "BATTMAXPCT",
    38: "BATTMINPCT",
}
NAME_IDS = {v: k for k, v in PARAM_NAMES.items()}

# 课程实验号(与固件 APP/lesson_lab.h LL_EXP_* 一致)
LL_EXP_ENCODER = 2
LL_EXP_PID = 3
LL_EXP_GYRO = 5
LL_EXP_MULTI = 6
LL_VALID_EXPS = (LL_EXP_ENCODER, LL_EXP_PID, LL_EXP_GYRO, LL_EXP_MULTI)

UP, RIGHT, DOWN, LEFT = 0, 1, 2, 3
DIR_DELTA = {UP: (0, 1), RIGHT: (1, 0), DOWN: (0, -1), LEFT: (-1, 0)}


def _q(v: float) -> int:
    s = v * 65536.0
    return int(s + 0.5) if s >= 0 else -int(-s + 0.5)


def _i16(v) -> int:
    """钳位到 int16 —— 真实固件字段是 s16, 越界会截断/回绕而非抛异常。

    模拟器必须同样防御: 否则一次异常输入(如过大的转速)会让 struct.pack 抛错,
    导致连接处理被中断、后续命令全部得不到应答(实机上表现为"突然全超时")。
    """
    v = int(v)
    if v > 32767:
        return 32767
    if v < -32768:
        return -32768
    return v


# ---------------------------------------------------------------- 迷宫

def build_maze(n: int = MAZETYPE, seed: int = 20260925) -> Tuple[List[List[int]], List[List[int]]]:
    """返回 (vwall, hwall)。vwall[x][y] = (x,y) 与 (x+1,y) 之间有墙; hwall 同理纵向。"""
    rnd = random.Random(seed)
    vwall = [[1 for _ in range(n)] for _ in range(n - 1)]
    hwall = [[1 for _ in range(n - 1)] for _ in range(n)]
    # 用随机 DFS 生成完美迷宫, 再随机打通一些墙制造环路与岔路
    visited = [[False] * n for _ in range(n)]
    stack = [(0, 0)]
    visited[0][0] = True
    while stack:
        x, y = stack[-1]
        nbrs = []
        for d in (UP, RIGHT, DOWN, LEFT):
            dx, dy = DIR_DELTA[d]
            nx, ny = x + dx, y + dy
            if 0 <= nx < n and 0 <= ny < n and not visited[nx][ny]:
                nbrs.append((d, nx, ny))
        if not nbrs:
            stack.pop()
            continue
        d, nx, ny = rnd.choice(nbrs)
        if d in (UP, DOWN):
            yy = min(y, ny)
            hwall[x][yy] = 0
        else:
            xx = min(x, nx)
            vwall[xx][y] = 0
        visited[nx][ny] = True
        stack.append((nx, ny))
    for _ in range(6):  # 打通若干墙形成环路
        if rnd.random() < 0.5 and n > 1:
            x = rnd.randrange(n - 1)
            y = rnd.randrange(n)
            vwall[x][y] = 0
        else:
            x = rnd.randrange(n)
            y = rnd.randrange(n - 1)
            hwall[x][y] = 0
    return vwall, hwall


def wall_byte(vwall, hwall, x: int, y: int, n: int) -> int:
    b = 0
    if y + 1 < n and not hwall[x][y]:
        b |= 0x01  # UP 可通行
    if x + 1 < n and not vwall[x][y]:
        b |= 0x02  # RIGHT
    if y - 1 >= 0 and not hwall[x][y - 1]:
        b |= 0x04  # DOWN
    if x - 1 >= 0 and not vwall[x - 1][y]:
        b |= 0x08  # LEFT
    return b


# ---------------------------------------------------------------- 模拟器

class MouseSim:
    def __init__(self, auto_explore: bool = True, seed: int = 20260925, safe: bool = False) -> None:
        self.n = MAZETYPE
        self.vwall, self.hwall = build_maze(self.n, seed)
        self.auto_explore = auto_explore
        #: 安全测试模式: 模拟"固件已禁用电机"的板子(快帧电机禁用位置位, 速度恒 0)
        self.safe = safe

        # 运行时参数
        self.params: Dict[int, float] = dict(PARAM_DEFAULTS)
        self.flash_valid = False  # 出厂未标定 -> 参数页 magic 不匹配

        # 运动状态
        self.speed_target_l = 0.0
        self.speed_target_r = 0.0
        self.speed_l = 0.0
        self.speed_r = 0.0
        self.gyro = 0.0  # deg
        self.angle_acc = 0.0
        self.dist_l_mm = 0.0
        self.dist_r_mm = 0.0
        self.run_dist_l = 0.0
        self.run_dist_r = 0.0
        self.enc_l = 0.0
        self.enc_r = 0.0
        self.enc_diff_acc = 0.0
        self.cell_odom = 0.0
        self.motion_task = 0
        self.pid_err = 0.0
        self.volt = 7.62
        self.cpu = 18
        self.emerg = False
        self.freemode = 0
        self.sleepmode = 0

        # 迷宫位置
        self.pos = (0, 0)
        self.dir = UP
        # 上电处于 WAIT(=0), 与固件一致 —— 固件在 main() 里才把 mouseTask 推到
        # START/MAZESEARCH。这里若直接给 2, 会让"进入迷宫态"的边沿永远不出现,
        # 于是迷宫状态机回传的 BEGIN / TASK 事件全都收不到。
        self.mouse_task = 0  # WAIT
        self.visited = [[False] * self.n for _ in range(self.n)]
        self.visited[0][0] = True
        self.wall_known = [[False] * self.n for _ in range(self.n)]
        self.map_wall = [[0] * self.n for _ in range(self.n)]

        # 红外的黑盒探针(用墙距生成, 让波形可信)
        self.ir = [230.0, 230.0, 230.0, 230.0]  # F1 F2 L R
        self.wall_bits = 0

        # 环形缓冲(1kHz, 1200 点) 与 dump
        self.ring: List[Tuple[int, int, int, int]] = [(0, 0, 0, 0)] * SCOPE_LEN
        self.scope_prof = "A"    # 录制剖面 A-E(与固件 LINK_SCOPE_PROF_* 对应)
        self.ring_idx = 0
        self.ring_count = 0
        self.scope_state = 0  # 0 idle 1 run 2 frozen
        self.dump_state = 0
        self.dump_blk = 0
        self.dump_chksum = 0

        # 命令状态
        self.seq = 0
        self.fast_div = 4    # 快帧分频(模拟器默认跑得比真机快, 便于 TCP 上快速验证)
        self.mid_div = 20    # 中帧分频
        self.slow_div = 200  # 慢帧分频
        self.tick = 0
        self.last_seq = -1
        self.last_crc = 0
        self.last_status = "OK"
        self.stream_on = False  # 与固件一致: 上电默认静默, STREAM ON 才发遥测

        # 运动驱动
        self.move_mode = "NONE"  # NONE / FWD / ROT / RUN / EXPLORE
        self.move_pulses = 0
        self.move_start_l = 0.0
        self.move_start_r = 0.0
        self.move_until = 0.0
        self.rot_target = 0.0
        self.alert: List[str] = []

        # ---- MOVE RUN: 时间 + 红外 双护栏(与固件 link_MoveService 对齐) ----
        self.run_limit = 0        # 最长运行时间(ms)
        self.run_elapsed = 0      # 已运行(ms)
        self.run_ir_mm = 0        # 红外停车阈值(mm); 0 = 关闭
        self.run_ir_min = 1 << 30  # 本次最小红外(初值取哨兵, 第一个 tick 就会覆盖)
        self.run_ir_which = 0     # 0=F1 1=F2 2=L 3=R
        self.run_start_l = 0.0
        self.run_start_r = 0.0
        self.run_vmax_l = 0
        self.run_vmax_r = 0
        # 急停锁存与"运动日志已就绪"(与固件 linkEStop / linkLogReady 对齐)
        self.estop_lock = False
        self.log_ready = False

        # 探索驱动
        self.phase = "CELL"
        self.phase_dist = 0.0
        self.turn_target_dir = UP

        # ---- 课程调参实验(与固件 APP/lesson_lab.c LL_REASON_* 对齐) ----
        # 模拟器始终接受 LESSON 命令组(无论 --lesson 与否), 便于上位机开发与契约测试通过;
        # 真实固件中, 这一段在 #ifdef MOUSE_LESSON_LAB 内, 生产固件会回 ERR_VALUE。
        self.lesson_running = False
        self.lesson_exp = 0
        self.lesson_phase = "IDLE"   # IDLE/ACC/CRUISE/DEC/STOP
        self.lesson_limit = 0       # 时间护栏 ms
        self.lesson_elapsed = 0     # ms
        self.lesson_dist_target = 0  # mm
        self.lesson_angle_target = 0  # 度
        self.lesson_v_cruise = 0     # cm/s
        self.lesson_t_acc = 0
        self.lesson_t_cruise = 0
        self.lesson_t_dec = 0
        self.lesson_start_l = 0.0   # 起点位移快照 mm
        self.lesson_start_r = 0.0
        self.lesson_d_l = 0          # 累计脉冲(回传用)
        self.lesson_d_r = 0
        self.lesson_v_peak_l = 0
        self.lesson_v_peak_r = 0
        self.lesson_gyro_start = 0.0  # 起点航向快照(度)
        self.lesson_done_pending = False  # LESSON DONE 已待发送
        self.lesson_done_line = ""

        # ---- 时间同步 / 发车(与固件 link.c 的 ARM / MAZE RUN / TYPE_TIME 对齐) ----
        # 模拟器始终支持这一组(不依赖任何档), 便于上位机开发与契约测试。
        self.link_time_ms = 0     # 上电以来的毫秒时基(u32)
        self.arm_ms = 0           # 发车基准; 0 = 未武装
        self.armed = False
        self.time_led = 0         # 1Hz 时间基准灯电平
        self.maze_running = False

        # ---- 迷宫状态机回传(实验8 无记忆走迷宫) ----
        # 与固件 link.c 的 linkMaze 同构: 同样的分类判据、同样的事件、同样的统计口径。
        self.maze_ev_mask = MAZE_EV_DEF
        self.maze_ev_count = 0
        self.maze_junc = 0
        self.maze_turn = 0
        self.maze_dead = 0
        self.maze_cell = 0
        self.maze_flags = 0
        self.maze_road = 0
        self.maze_road_raw = 0
        self.maze_road_same = 0
        self.maze_stack = 0
        self.maze_task_prev = 0
        self.maze_motion_prev = 0
        self.maze_pos_prev = (-1, -1)
        # 迷宫态边沿检测用**独立字段**(与固件 linkMaze.inMaze 同构)。
        # ⚠️ 曾经借用 maze_flags 的一个高位来记这件事, 而 _maze_reset() 会清 flags
        #    → 边沿检测每拍都成立 → BEGIN 被无限重发(实测 6 秒 299 条)。
        self.maze_in_prev = False
        self.maze_tick_div = 0
        self.maze_requested = False
        self.scope_start_ms = 0   # 本次采集第 0 点的绝对 ms(填进 DUMP_HDR.startMs)
        self._armed_pending = False  # 需要在下一批里补发一行 ARMED <ms>

        self.lock = threading.Lock()
        self.sample_ring_enabled = False

    # ---------------------------------------------------------- 物理步进

    def step(self) -> None:
        with self.lock:
            self._step_locked()

    def _step_locked(self) -> None:
        self.tick += 1
        self.link_time_ms += 1  # 毫秒时基(与固件 linkTimeMs 同语义: u32, 不回绕)
        self._maze_watch()  # 迷宫状态机观测(实验8); 内部 20ms 分频
        # 1Hz 时间基准灯: 与 TIME 帧同拍(50% 占空比)
        if self.armed:
            self.time_led = 1 if ((self.link_time_ms - self.arm_ms) % 1000) < 500 else 0

        if self.emerg:
            self.speed_target_l = self.speed_target_r = 0.0

        if self.safe:
            # 安全测试模式: 固件电机被物理禁用 —— 速度目标归零、电机处于自由模式,
            # 板子不动但传感器数据(陀螺零偏/红外/电压)照常刷新。
            self.speed_target_l = self.speed_target_r = 0.0
            self.freemode = 1

        # 一阶惯性逼近目标(时间常数约 4ms, 与实测曲线形态接近)
        self.speed_l += (self.speed_target_l - self.speed_l) * 0.22
        self.speed_r += (self.speed_target_r - self.speed_r) * 0.22

        # 陀螺: 顺时针为正(右轮前进为正)
        dt_deg = (self.speed_r - self.speed_l) * 0.00716
        self.gyro += dt_deg
        self.angle_acc += dt_deg * self.params[5]  # angleAcc = 角度 * gyroRatio
        # 编码器
        dl = self.speed_l / 100.0  # cm/s -> mm/ms
        dr = self.speed_r / 100.0
        self.dist_l_mm += dl
        self.dist_r_mm += dr
        self.run_dist_l += dl
        self.run_dist_r += dr
        self.enc_l += dl * self.params[1]
        self.enc_r += dr * self.params[2]
        self.enc_diff_acc += (dl - dr) * self.params[6]

        # 电压缓慢下降 + 纹波
        self.volt = max(6.9, self.volt - 1e-6) + random.uniform(-0.003, 0.003)
        self.cpu = int(max(8, min(60, self.cpu + random.uniform(-1.5, 1.5))))

        # 标签里程(相对)
        if self.phase == "CELL":
            self.cell_odom = self.phase_dist
        else:
            self.cell_odom = 0.0

        self._drive()
        self._update_ir()
        self._sample_ring()

    # ---------------------------------------------------------- 运动驱动

    def _drive(self) -> None:
        if self.move_mode == "FWD":
            d_l = self.dist_l_mm - self.move_start_l
            d_r = self.dist_r_mm - self.move_start_r
            if abs(d_l) >= self.move_pulses / self.params[1] or abs(d_r) >= self.move_pulses / self.params[2]:
                self.speed_target_l = self.speed_target_r = 0.0
                self.move_mode = "NONE"
                self.freemode = 1
                self.alert.append(
                    f"MOVEDONE FWD {int(abs(d_l) * self.params[1])} {int(abs(d_r) * self.params[2])}"
                )
            return

        if self.move_mode == "ROT":
            if time.time() >= self.move_until:
                self.speed_target_l = self.speed_target_r = 0.0
                self.move_mode = "NONE"
                self.freemode = 1
                self.alert.append("MOVEDONE ROT")
            return

        if self.move_mode == "RUN":
            # ---- 与固件 link_MoveService 的 RUN 分支逐条对齐 ----
            self.run_elapsed += 1

            ir, which = self._min_ir()
            if self.run_ir_min == 0 or ir < self.run_ir_min:
                self.run_ir_min = ir
                self.run_ir_which = which
            self.run_vmax_l = max(self.run_vmax_l, int(abs(self.speed_l)))
            self.run_vmax_r = max(self.run_vmax_r, int(abs(self.speed_r)))

            # 护栏 1: 红外贴脸必停
            if self.run_ir_mm and ir < self.run_ir_mm:
                self._finish_run("IR")
                return
            # 护栏 2: 到时必停
            if self.run_elapsed >= self.run_limit:
                self._finish_run("TIME")
                return
            return

        if self.move_mode == "SERVO":
            # 模拟角度基准扫描: 往复 10 次 x 90 度, 约 6 秒后回报累计量
            self.motion_task = 2
            if time.time() - self._sv_start > 6.0:
                deg = 900.0
                sum_acc = int(deg * self.params[5])
                sum_enc = int(deg * self.params[6])
                self.speed_target_l = self.speed_target_r = 0.0
                self.move_mode = "NONE"
                self.freemode = 1
                self.gyro = 0.0
                self.alert.append(f"CALDONE GYRORATIO {sum_acc} {sum_enc} {int(deg)}")
            return

        if self.move_mode == "LESSON":
            self._drive_lesson()
            return

        if self.move_mode != "EXPLORE":
            self.motion_task = 0
            return
        # ---- 右手法则探索: 每格 180mm, 遇墙转弯 ----
        if self.phase == "CELL":
            self.motion_task = 32  # SMARTSTRAIGHTFAST
            self.pid_err = self.gyro
            self.speed_target_l = 68.0
            self.speed_target_r = 68.0
            self.phase_dist += (self.speed_l + self.speed_r) / 2.0 / 100.0
            if self.phase_dist >= 180.0:
                self.phase_dist = 0.0
                self._arrive_cell()
        else:  # TURN
            self.motion_task = 2  # TURN
            ang = abs(self._rel_angle(self.turn_target_dir))
            err = 90.0 - ang
            if err < 2.0:
                self.speed_target_l = self.speed_target_r = 0.0
                self.gyro = 0.0
                self.dir = self.turn_target_dir
                self.phase = "CELL"
                self.pid_err = 0.0
            else:
                v = min(45.0, 12.0 + err * 0.55)
                # 目标方向相对当前朝向的符号决定转向
                delta = (self.turn_target_dir - self.dir) % 4
                sign = 1.0 if delta == 1 else -1.0
                self.speed_target_l = sign * v
                self.speed_target_r = -sign * v
                self.pid_err = self.gyro - 0.0

    def _rel_angle(self, target_dir: int) -> float:
        return self.gyro

    # ---------------------------------------------------------- 课程调参实验

    def _drive_lesson(self) -> None:
        """模拟器课程实验引擎 — 与固件 APP/lesson_lab.c LESSONLAB_Tick 等价。

        每个实验都按"加速 -> 匀速 -> 减速 -> 停"或"距离/角度判据"推进;
        所有实验都共享一条时间护栏: elapsed >= limit 即停。
        """
        # 上层把 lesson_running 设为 False 即停车(LESSON STOP 路径)
        if not self.lesson_running:
            self._finish_lesson("STOP")
            return

        self.lesson_elapsed += 1

        # 速度峰值统计(所有实验通用): "电机真的转了"的证据
        ai = abs(int(self.speed_l))
        if ai > self.lesson_v_peak_l:
            self.lesson_v_peak_l = ai
        ai = abs(int(self.speed_r))
        if ai > self.lesson_v_peak_r:
            self.lesson_v_peak_r = ai

        # 剖面推进
        d_l = self.dist_l_mm - self.lesson_start_l   # 行驶 mm
        d_r = self.dist_r_mm - self.lesson_start_r

        if self.lesson_exp == LL_EXP_PID:
            e = self.lesson_elapsed
            t1 = self.lesson_t_acc
            t2 = t1 + self.lesson_t_cruise
            t3 = t2 + self.lesson_t_dec
            if e <= t1:
                self.lesson_phase = "ACC"
                v = int(self.lesson_v_cruise * e / max(1, t1))
            elif e <= t2:
                self.lesson_phase = "CRUISE"
                v = self.lesson_v_cruise
            elif e <= t3:
                self.lesson_phase = "DEC"
                te = e - t2
                v = int(self.lesson_v_cruise * (self.lesson_t_dec - te) / max(1, self.lesson_t_dec))
            else:
                self._finish_lesson("DONE")
                return
            self.speed_target_l = self.speed_target_r = float(v)
            self.motion_task = 32  # SMARTSTRAIGHTFAST
        elif self.lesson_exp == LL_EXP_ENCODER:
            self.lesson_phase = "CRUISE"
            # 模拟固件: 固件自认走了 mm = dL_mm, 停在 distTarget
            if abs(d_l) >= self.lesson_dist_target or abs(d_r) >= self.lesson_dist_target:
                self._finish_lesson("DIST")
                return
            self.speed_target_l = self.speed_target_r = float(self.lesson_v_cruise)
            self.motion_task = 32
        elif self.lesson_exp == LL_EXP_GYRO:
            # 原地转: 左右轮反向; 用 gyro 增长判停
            self.lesson_phase = "CRUISE"
            cur = self.gyro - self.lesson_gyro_start
            if abs(cur) >= abs(self.lesson_angle_target):
                self._finish_lesson("ANGLE")
                return
            sign = 1.0 if self.lesson_angle_target > 0 else -1.0
            self.speed_target_l = sign * self.lesson_v_cruise
            self.speed_target_r = -sign * self.lesson_v_cruise
            self.motion_task = 2  # TURN
        elif self.lesson_exp == LL_EXP_MULTI:
            self.lesson_phase = "CRUISE"
            if abs(d_l) >= self.lesson_dist_target or abs(d_r) >= self.lesson_dist_target:
                self._finish_lesson("DONE")
                return
            self.speed_target_l = self.speed_target_r = float(self.lesson_v_cruise)
            self.motion_task = 32
        else:
            self._finish_lesson("STOP")
            return

        # 时间护栏(与固件一致, 放最后判)
        if self.lesson_elapsed >= self.lesson_limit:
            self._finish_lesson("TIME")

    def _finish_lesson(self, reason: str) -> None:
        """与固件 ll_Finish 等价的停车 + 上报明细行。"""
        d_l_mm = self.dist_l_mm - self.lesson_start_l
        d_r_mm = self.dist_r_mm - self.lesson_start_r
        # 脉冲量(与固件一致): mm * pulse/mm
        self.lesson_d_l = int(d_l_mm * self.params[1])
        self.lesson_d_r = int(d_r_mm * self.params[2])
        self.speed_target_l = self.speed_target_r = 0.0
        self.freemode = 1
        self.move_mode = "NONE"
        self.lesson_running = False
        self.lesson_phase = "STOP"
        self.lesson_done_pending = True
        # LESSON DONE <exp> <REASON> <ms> <dL> <dR> <vpkL> <vpkR> <angle>
        ang_end = self.gyro - self.lesson_gyro_start
        self.lesson_done_line = (
            f"LESSON DONE {int(self.lesson_exp)} {reason} {int(self.lesson_elapsed)} "
            f"{int(self.lesson_d_l)} {int(self.lesson_d_r)} "
            f"{int(self.lesson_v_peak_l)} {int(self.lesson_v_peak_r)} "
            f"{int(ang_end)}"
        )
        # 冻结日志环 + 置 log_ready(与固件一致)
        if self.scope_state == 1:
            self.scope_state = 2
        self.log_ready = True

    def _motion_busy(self) -> bool:
        """是否有任何"正在动"的活动 —— 对应固件 `link_MotionBusy()`。

        **为什么需要它**（真机实测揪出的缺陷, 2026-10-04）:
        `MOVE FWD/ROT/RUN` 启动时都会把 `motionCtrl.task` 置 NULL(它们由
        `link_MoveService` 驱动, 不走任务状态机), 所以"只看 task"是查不出正在跑 MOVE 的。
        当时固件四处 busy 检查都漏了 `linkMove.state`, 后果是第二条 `MOVE RUN` 会被接受
        并**覆盖 `linkMove.elapsed/limit` —— 时间护栏被重置**, 连续发就能无限延长运行。
        模拟器当时也没查, 所以整套测试盖不住这个问题; 这里补上, 让
        "第二条 MOVE 必须被 ERR_BUSY 拒掉" 成为可回归的断言。
        """
        # 注意不含 maze_running: 它是"已发车"的模式标志(与固件 LINK_MazeRequested
        # 同义), 而自走本身会体现为 move_mode == "EXPLORE"。
        return (self.move_mode != "NONE") or bool(self.lesson_running)

    def _flags(self) -> int:
        """快帧 flags 字节 —— 与固件 `link_Flags()` 位定义逐位一致。

        **为什么抽成方法**: 原先"快帧"和"SNAP MOTION"各算一遍, 结果 SNAP 那份
        只算了 `safe` 一位, 漏掉 estop_lock/freemode/emerg/... —— 真机上
        `SNAP MOTION` 回的是完整 flags(实测 0xC7), 两侧不一致会让"急停是否锁存"
        这类断言在模拟器上失效(2026-10-04 被发现)。单一来源即可根除。
        """
        f = 0
        if self.freemode:
            f |= 0x01        # LINK_FLAG_FREEMODE
        if self.sleepmode:
            f |= 0x02        # LINK_FLAG_SLEEP
        if self.emerg:
            f |= 0x04        # LINK_FLAG_EMERG
        if self.scope_state == 1:
            f |= 0x08        # LINK_FLAG_SCOPING
        if self.dump_state == 1:
            f |= 0x10        # LINK_FLAG_DUMPING
        if self.safe:
            f |= 0x20        # LINK_FLAG_MOTOR_OFF
        if self.estop_lock:
            f |= 0x40        # LINK_FLAG_ESTOP_LOCK
        if self.log_ready:
            f |= 0x80        # LINK_FLAG_RUNLOG
        return f

    def _start_lesson(self, exp: int, a: int, b: int, c: int, d: int) -> str:
        """验证参数并启动一个课程实验, 返回 ACK 状态。"""
        if self.estop_lock:
            return "ERR_ESTOP"
        if self.lesson_running or self._motion_busy():
            return "ERR_BUSY"
        # 与固件 LESSONLAB_Start 同样的逐项校验
        if exp == LL_EXP_ENCODER:
            if a <= 0 or a > 300 or b <= 0 or c <= 0:
                return "ERR_VALUE"
        elif exp == LL_EXP_PID:
            if a <= 0 or a > 300 or b < 0 or c < 0 or d < 0:
                return "ERR_VALUE"
            if b == 0 or d == 0:
                return "ERR_VALUE"
        elif exp == LL_EXP_GYRO:
            if a == 0 or abs(a) > 3600 or b <= 0 or b > 300 or c <= 0:
                return "ERR_VALUE"
        elif exp == LL_EXP_MULTI:
            if a <= 0 or a > 300 or b <= 0 or c <= 0:
                return "ERR_VALUE"
        else:
            return "ERR_EXP"

        # 起点快照(与固件 ll_Finish 中 lessonLab.vStartL = ll_DistL() 一致)
        self.lesson_exp = exp
        self.lesson_elapsed = 0
        self.lesson_phase = "CRUISE" if exp != LL_EXP_PID else "ACC"
        # 与固件 LESSONLAB_Start 的字段映射对齐:
        #   exp2 ENCODER: vCruise=a, distTarget=b, limit=c
        #   exp3 PID:     vCruise=a, tAcc=b, tCruise=c, tDec=d, limit=b+c+d+500
        #   exp5 GYRO:    angleTarget=a, vCruise=b, limit=c   <-- 注意 vCruise 取 b
        #   exp6 MULTI:   vCruise=a, distTarget=b, limit=c
        self.lesson_v_cruise = b if exp == LL_EXP_GYRO else a
        self.lesson_start_l = self.dist_l_mm
        self.lesson_start_r = self.dist_r_mm
        if exp == LL_EXP_PID:
            self.lesson_t_acc = b
            self.lesson_t_cruise = c
            self.lesson_t_dec = d
            self.lesson_limit = b + c + d + 500
        else:
            self.lesson_t_acc = self.lesson_t_cruise = self.lesson_t_dec = 0
            self.lesson_limit = max(1, min(c, 60000)) if exp != LL_EXP_PID else 0
        if exp in (LL_EXP_ENCODER, LL_EXP_MULTI):
            self.lesson_dist_target = b
        else:
            self.lesson_dist_target = 0
        if exp == LL_EXP_GYRO:
            self.lesson_angle_target = a
            self.lesson_gyro_start = self.gyro
        else:
            self.lesson_angle_target = 0
            self.lesson_gyro_start = self.gyro

        # 上电后默认静默的电机解禁 + 启动 1kHz 本地采集(与固件一致)
        self.freemode = 0
        self.lesson_running = True
        self._halt_internal_no_alert()
        self.lesson_v_peak_l = self.lesson_v_peak_r = 0
        self.lesson_d_l = self.lesson_d_r = 0
        self.lesson_done_pending = False   # 清掉上一次的待发 DONE 行
        self.move_mode = "LESSON"
        # 实验一开始就打开 1kHz 本地缓冲(零带宽, 停车后冻结)
        if self.scope_state != 1:
            self.scope_state = 1
            self.ring_idx = 0
            self.ring_count = 0
        self.sample_ring_enabled = True
        self.log_ready = False
        return "OK"

    def _halt_internal_no_alert(self) -> None:
        """停车但不写 alert 队列(LESSON 内部驱动用了 move_mode, 复用 MOVE 的清理)。"""
        self.speed_target_l = self.speed_target_r = 0.0
        self.phase = "CELL"
        self.phase_dist = 0.0

    # ---------------------------------------------------------- MOVE RUN

    def _min_ir(self) -> Tuple[int, int]:
        """(最小红外读数, 通道号)。通道 0=F1 1=F2 2=L 3=R, 与固件 link_MinIr 一致。"""
        vals = [int(self.ir[0]), int(self.ir[1]), int(self.ir[2]), int(self.ir[3])]
        i = min(range(4), key=lambda k: vals[k])
        return vals[i], i

    @staticmethod
    def _ir_chan_name(which: int) -> str:
        return ("F1", "F2", "L", "R")[which]

    def _finish_run(self, reason: str) -> None:
        """停车 + 冻结日志 + 上报明细(与固件 link_MoveFinishRun 对齐)。"""
        d_l = self.dist_l_mm - self.run_start_l
        d_r = self.dist_r_mm - self.run_start_r
        self.speed_target_l = self.speed_target_r = 0.0
        self.freemode = 1
        self.move_mode = "NONE"
        if self.scope_state == 1:
            self.scope_state = 2
        self.log_ready = True
        ir_min = self.run_ir_min if self.run_ir_min < (1 << 30) else 0
        self.alert.append(
            f"MOVEDONE RUN {reason} {self.run_elapsed} {ir_min} "
            f"{self._ir_chan_name(self.run_ir_which)} "
            f"{int(d_l * self.params[1])} {int(d_r * self.params[2])} "
            f"{self.run_vmax_l} {self.run_vmax_r}"
        )

    def _arrive_cell(self) -> None:
        self.enc_diff_acc = self.enc_diff_acc  # 保持累计
        x, y = self.pos
        self._mark_walls(x, y)
        # 右手法则: 右 -> 前 -> 左 -> 后
        for d in ((self.dir + 1) % 4, self.dir, (self.dir + 3) % 4, (self.dir + 2) % 4):
            if self._can_go(x, y, d):
                nx, ny = x + DIR_DELTA[d][0], y + DIR_DELTA[d][1]
                self.pos = (nx, ny)
                if nx < self.n and ny < self.n:
                    self.visited[nx][ny] = True
                self.turn_target_dir = d
                self.phase = "TURN"
                return
        self.turn_target_dir = (self.dir + 2) % 4
        self.phase = "TURN"

    def _mark_walls(self, x: int, y: int) -> None:
        self.wall_known[x][y] = True
        self.map_wall[x][y] = wall_byte(self.vwall, self.hwall, x, y, self.n)

    def _can_go(self, x: int, y: int, d: int) -> bool:
        dx, dy = DIR_DELTA[d]
        nx, ny = x + dx, y + dy
        if not (0 <= nx < self.n and 0 <= ny < self.n):
            return False
        b = wall_byte(self.vwall, self.hwall, x, y, self.n)
        return bool(b & (1 << d))

    # ---------------------------------------------------------- 迷宫状态机回传(实验8)

    def _maze_road(self) -> int:
        """路口类型分类 —— 与固件 link_RoadKind() 同一判据。

        `self.wall_bits` 的口径与固件 wallSns 一致(置位 = 有墙), 故同式:
        f/l/r = 前/左/右 是否开口。
        """
        f = not (self.wall_bits & 0x04)
        l = not (self.wall_bits & 0x01)
        r = not (self.wall_bits & 0x02)
        if f and l and r:
            return 7   # CROSS
        if f and l:
            return 4   # TEE_FL
        if f and r:
            return 5   # TEE_FR
        if l and r:
            return 6   # TEE_LR
        if f:
            return 1   # THRU
        if l:
            return 2   # CORNER_L
        if r:
            return 3   # CORNER_R
        return 8       # DEAD

    def _maze_opens(self) -> int:
        n = 0
        if not (self.wall_bits & 0x04):
            n += 1
        if not (self.wall_bits & 0x01):
            n += 1
        if not (self.wall_bits & 0x02):
            n += 1
        return n

    def _maze_in(self) -> bool:
        return 1 <= self.mouse_task <= 5

    def _maze_ev(self, mask: int, name: str, *args) -> None:
        if not (self.maze_ev_mask & mask):
            return
        self.maze_ev_count += 1
        tail = (" " + " ".join(str(a) for a in args)) if args else ""
        self.alert.append(f"MAZE EV {name}{tail}")

    def _maze_reset(self) -> None:
        """清统计。**不动 maze_in_prev**(迷宫态边沿状态), 否则 BEGIN 会被反复触发。"""
        self.maze_road = 0
        self.maze_road_raw = 0
        self.maze_road_same = 0
        self.maze_stack = self.stack_idx if hasattr(self, "stack_idx") else 0
        self.maze_ev_count = 0
        self.maze_junc = 0
        self.maze_turn = 0
        self.maze_dead = 0
        self.maze_cell = 0
        self.maze_flags = 0
        self.maze_motion_prev = self.motion_task
        self.maze_task_prev = self.mouse_task
        self.maze_pos_prev = (self.pos[0], self.pos[1])

    def _maze_watch(self) -> None:
        """每 1ms 调一次, 内部 20ms 分频 —— 与固件 link_MazeWatch() 同构。"""
        self.maze_tick_div += 1
        if self.maze_tick_div < 20:
            return
        self.maze_tick_div = 0

        in_maze = self._maze_in()
        if in_maze != self.maze_in_prev:
            self.maze_in_prev = in_maze
            if in_maze:
                self._maze_reset()  # 新一轮迷宫: 统计归零(reset 不动 maze_in_prev)
                # reset 会把 task 记成"当前值", 那会把"从空闲进入迷宫"这条迁移吞掉。
                # 显式退回 WAIT, 让下面的迁移检测报出首条 TASK(如 WAIT > SEARCH)。
                self.maze_task_prev = 0  # WAIT
                self._maze_ev(MAZE_EV_GOAL, "BEGIN", self.pos[0], self.pos[1])
            else:
                self._maze_ev(MAZE_EV_GOAL, "EXIT")
        if not in_maze:
            return

        # 任务状态机迁移
        if self.mouse_task != self.maze_task_prev:
            self._maze_ev(MAZE_EV_TASK, "TASK",
                          MAZE_TASK_NAMES_SIM.get(self.maze_task_prev, "OTHER"),
                          MAZE_TASK_NAMES_SIM.get(self.mouse_task, "OTHER"))
            if self.mouse_task == 3:
                self.maze_flags |= 0x04
                if self.maze_flags & 0x01:
                    self.maze_flags |= 0x02
            self.maze_task_prev = self.mouse_task

        # 路口识别: 只在搜索决策态评估(与固件同)
        if self.mouse_task == 2:
            raw = self._maze_road()
            if raw == self.maze_road_raw:
                self.maze_road_same = min(self.maze_road_same + 1, 2)
            else:
                self.maze_road_raw = raw
                self.maze_road_same = 0
            if self.maze_road_same >= 2 and raw != self.maze_road:
                self.maze_road = raw
                if raw in (4, 5, 6, 7):
                    self.maze_junc += 1
                    self.maze_flags |= 0x08
                elif raw == 8:
                    self.maze_dead += 1
                    self.maze_flags |= 0x20
                self._maze_ev(MAZE_EV_ROAD, "ROAD", MAZE_ROAD_NAMES.get(raw, "?"), raw)
        else:
            self.maze_road_same = 0

        # 岔路口栈(模拟器没有搜索栈, 用 0)
        stack = 0
        if stack != self.maze_stack:
            self.maze_stack = stack
            self._maze_ev(MAZE_EV_JUNC, "JUNC", stack)

        # 转弯/掉头动作
        if self.motion_task != self.maze_motion_prev:
            self.maze_motion_prev = self.motion_task
            tn = MAZE_TURN_NAMES.get(self.motion_task)
            if tn:
                self.maze_turn += 1
                self._maze_ev(MAZE_EV_TURN, "TURN", tn, self.motion_task)

        # 到达终点(模拟器: 用 x/y 到角格近似)
        if self.pos[0] == self.n - 1 and self.pos[1] == self.n - 1:
            if not (self.maze_flags & 0x01):
                self.maze_flags |= 0x01
                self._maze_ev(MAZE_EV_GOAL, "GOAL", self.pos[0], self.pos[1])

        # 进入新格
        if (self.pos[0], self.pos[1]) != self.maze_pos_prev:
            self.maze_pos_prev = (self.pos[0], self.pos[1])
            self.maze_cell += 1
            self._maze_ev(MAZE_EV_CELL, "CELL", self.pos[0], self.pos[1], self.dir)

    def _update_ir(self) -> None:
        x, y = self.pos
        b = wall_byte(self.vwall, self.hwall, x, y, self.n) if 0 <= x < self.n and 0 <= y < self.n else 0
        # 相对朝向的 前/左/右 距离
        f_open = bool(b & (1 << self.dir))
        l_open = bool(b & (1 << ((self.dir + 3) % 4)))
        r_open = bool(b & (1 << ((self.dir + 1) % 4)))
        base = 34.0 if self.phase == "TURN" else 42.0
        f = 232.0 if f_open else max(28.0, base + random.uniform(-2, 2))
        # 前进时前向距离随 cellOdom 减小
        if not f_open:
            f = max(26.0, 180.0 - self.cell_odom + random.uniform(-2, 2))
            f = min(f, 235.0)
        self.ir[0] = f
        self.ir[1] = f + random.uniform(-3, 3)
        self.ir[2] = 236.0 if l_open else max(28.0, 42.0 + random.uniform(-2, 2))
        self.ir[3] = 236.0 if r_open else max(28.0, 42.0 + random.uniform(-2, 2))
        self.wall_bits = 0
        if not l_open:
            self.wall_bits |= 0x01
        if not r_open:
            self.wall_bits |= 0x02
        if not f_open:
            self.wall_bits |= 0x04

    # ---------------------------------------------------------- 环缓冲

    def _sample_ring(self) -> None:
        if not self.sample_ring_enabled or self.scope_state != 1:
            return
        if self.ring_count == 0:
            # 与固件 link_ScopeSample 一致: 记下"环里第 0 点"的绝对毫秒时基
            self.scope_start_ms = self.link_time_ms
        # 与固件同构: 8B 点按剖面装不同的物理量(A=运动学, 其余 4×u16)
        prof = self.scope_prof
        if prof == "B":
            self.ring[self.ring_idx] = (int(self.ir[0]), int(self.ir[1]),
                                        int(self.ir[2]), int(self.ir[3]))
        elif prof == "C":
            adc = [max(0, min(4095, 2990 - int(mm) * 12)) for mm in
                   (self.ir[0], self.ir[1], self.ir[2], self.ir[3])]
            self.ring[self.ring_idx] = tuple(adc)
        elif prof == "D":
            adc_batt = int(round(self.volt * 1000.0 / (self.params[33] / 1000.0))) if self.params[33] else 0
            self.ring[self.ring_idx] = (int((self.ir[0] + self.ir[1]) / 2),
                                        int(adc_batt * self.params[33] / 1000.0), adc_batt, 0)
        elif prof == "E":
            self.ring[self.ring_idx] = (int(self.ir[1]), int(self.ir[0]),
                                        int(self.volt * 1000.0), self.motion_task)
        else:
            self.ring[self.ring_idx] = (
                self.motion_task,
                int(self.gyro),
                int(self.speed_l),
                int(self.speed_r),
            )
        self.ring_idx = (self.ring_idx + 1) % SCOPE_LEN
        if self.ring_count < SCOPE_LEN:
            self.ring_count += 1

    # ---------------------------------------------------------- 组帧

    def _frame_fast(self) -> bytes:
        pl = struct.pack(
            "<hhhhhhBBBB",
            _i16(self.speed_l),
            _i16(self.speed_r),
            _i16(self.gyro),
            _i16(self.pid_err),
            _i16(self.speed_target_l),
            _i16(self.speed_target_r),
            self.motion_task & 0xFF,
            int(self.volt * 10) & 0xFF,
            self._flags(),
            self.link_time_ms & 0xFF,  # 原保留字节: 毫秒时基低 8 位(时间同步用)
        )
        return pack_frame(TYPE_FAST, pl, self.seq)

    def _frame_time(self) -> bytes:
        """时间同步帧 @1Hz: upMs | armMs | led | flags | rsvd。"""
        flags = 0
        if self.armed:
            flags |= 0x01
        if self.maze_running:
            flags |= 0x02
        if self.time_led:
            flags |= 0x04
        pl = struct.pack(
            "<IIBBH", self.link_time_ms, self.arm_ms, self.time_led, flags, 0
        )
        return pack_frame(TYPE_TIME, pl, self.seq)

    def _frame_maze(self) -> bytes:
        """迷宫状态帧 @1Hz(仅迷宫态 + 已开流) —— 与固件 link_SendMazeFrame() 同布局。"""
        pl = bytes([
            self.mouse_task & 0xFF,
            self.maze_road & 0xFF,
            self._maze_opens() & 0xFF,
            self.motion_task & 0xFF,
            self.pos[0] & 0xFF, self.pos[1] & 0xFF, self.dir & 0xFF,
            self.maze_stack & 0xFF,
            self.maze_flags & 0xFF,
            self.maze_ev_mask & 0xFF,
            self.maze_ev_count & 0xFF, (self.maze_ev_count >> 8) & 0xFF,
            self.maze_junc & 0xFF, (self.maze_junc >> 8) & 0xFF,
            self.maze_turn & 0xFF,
            self.maze_dead & 0xFF,
        ])
        return pack_frame(TYPE_MAZE, pl, self.seq)

    def _frame_mid(self) -> bytes:
        pl = struct.pack(
            "<hhhhhh",
            _i16(self.cell_odom),
            int(self.run_dist_l) % 32000,
            int(self.run_dist_r) % 32000,
            2048 + int(random.gauss(0, 3)),
            _i16((self.speed_r - self.speed_l) * 12),
            _i16(self.enc_diff_acc / max(1.0, self.params[6])),
        )
        return pack_frame(TYPE_MID, pl, self.seq)

    def _frame_slow(self) -> bytes:
        pl = struct.pack(
            "<hhhhBBbbHBB",
            _i16(self.ir[0]),
            _i16(self.ir[1]),
            _i16(self.ir[2]),
            _i16(self.ir[3]),
            self.wall_bits,
            self.mouse_task & 0xFF,
            self.pos[0],
            self.pos[1],
            int(self.volt * 100),
            self.cpu,
            0,
        )
        return pack_frame(TYPE_SLOW, pl, self.seq)

    def _frame_map(self) -> bytes:
        wall = bytearray()
        for x in range(self.n):
            for y in range(self.n):
                wall.append(self.map_wall[x][y] if self.wall_known[x][y] else 0)
        vis = bytearray()
        for x in range(self.n):
            for y in range(self.n):
                vis.append(1 if self.visited[x][y] else 0)
        pl = struct.pack("<bbBB", self.pos[0], self.pos[1], self.dir, self.mouse_task) + bytes(wall) + bytes(vis)
        return pack_frame(TYPE_MAP, pl, self.seq)

    def _frame_dump_blk(self, blk: int) -> bytes:
        start = blk * SCOPE_PTS_PER_BLK
        body = bytearray()
        for i in range(SCOPE_PTS_PER_BLK):
            mt, ang, sl, sr = self.ring[(start + i) % SCOPE_LEN]
            body += struct.pack("<BBhhh", mt & 0xFF, 0, ang, sl, sr)
            self.dump_chksum = (self.dump_chksum + sl) & 0x7FFFFFFF
        return pack_frame(TYPE_DUMP_BLK, struct.pack("<H", blk) + bytes(body), self.seq)

    # ---------------------------------------------------------- 命令处理

    def handle_line(self, line: str) -> List[bytes]:
        """返回待发送的文本应答(不含遥测帧)。"""
        out: List[str] = []
        try:
            star = line.rfind("*")
            if star < 0 or len(line) - star < 5:
                return [b"ACK -1 ERR_NOCRC\r\n"]
            body = line[:star]
            crc_rx = int(line[star + 1 : star + 5], 16)
            if crc16_modbus(body.encode("ascii")) != crc_rx:
                return [b"ACK -1 ERR_CRC\r\n"]
            seq = -1
            if "#" in body:
                body, seq_s = body.split("#", 1)
                seq = int(seq_s)
            if seq >= 0 and seq == self.last_seq and crc_rx == self.last_crc:
                return [f"ACK {seq} {self.last_status}\r\n".encode()]
            self.last_seq, self.last_crc = seq, crc_rx
            replies = self._exec(body.strip(), seq)
        except Exception as e:  # 模拟器自身异常不应中断服务
            replies = [f"ACK -1 ERR_SIM({e})\r\n"]
        return [r.encode() for r in replies]

    def _exec(self, cmd: str, seq: int) -> List[str]:
        t = cmd.split()
        if not t:
            return [f"ACK {seq} ERR_CMD\r\n"]

        def ack(s: str) -> str:
            self.last_status = s
            return f"ACK {seq} {s}\r\n"

        c = t[0].upper()

        if c == "PING":
            return [f"PONG {PROTO_VER} {FW_VER} {self.n}\r\n", ack("OK")]
        if c == "VER":
            return [
                f"VER proto={PROTO_VER} fw={FW_VER} mazetype={self.n} txbuf=256 scopedepth={SCOPE_LEN}\r\n",
                ack("OK"),
            ]
        if c == "GET":
            if len(t) >= 2 and t[1].upper() == "ALL":
                lines = [f"P {i} {_q(self.params[i])}\r\n" for i in sorted(self.params)]
                return lines + [ack("OK")]
            if len(t) >= 2 and t[1].upper() in NAME_IDS:
                i = NAME_IDS[t[1].upper()]
                return [f"P {i} {_q(self.params[i])}\r\n", ack("OK")]
            return [ack("ERR_NAME")]
        if c == "SNAP":
            # 阻塞式全量测量快照。与固件 link_SnapLine() 的字段顺序**逐项一致**;
            # 字段名与 decode_fast/mid/slow 的字典键同名, 主机侧零分叉。
            dom = t[1].upper() if len(t) >= 2 and t[1] else "ALL"
            if dom not in ("ALL", "MOTION", "ODOM", "SENSE", "POWER", "TIME", "MAZE"):
                return [ack("ERR_VALUE")]
            out: List[str] = []

            def line(name: str, vals) -> str:
                return f"SNAP {name} " + " ".join(str(int(v)) for v in vals) + "\r\n"

            flags = self._flags()
            if dom in ("ALL", "MOTION"):
                out.append(line("MOTION", [
                    self.speed_l, self.speed_r,
                    self.speed_target_l, self.speed_target_r,
                    0, self.speed_target_l, self.speed_target_r,
                    self.gyro, 0, flags,
                ]))
            if dom in ("ALL", "ODOM"):
                out.append(line("ODOM", [
                    self.cell_odom, self.enc_l, self.enc_r,
                    0, 0, self.angle_acc, 0, self.angle_acc,
                ]))
            if dom in ("ALL", "SENSE"):
                # 四路原始 ADC 由 mm 反推(仅用于让"测距/ADC/饱和"三者自洽)
                adc = [max(0, min(4095, 2990 - int(mm) * 12)) for mm in
                       (self.ir[0], self.ir[1], self.ir[2], self.ir[3])]
                sat = 0
                for k, a in enumerate(adc):
                    s = 1 if a > 2990 else (2 if a < 59 else 0)
                    sat |= (s & 0x03) << (2 * k)
                out.append(line("SENSE", [
                    adc[0], adc[1], adc[2], adc[3],
                    self.ir[0], self.ir[1], self.ir[2], self.ir[3],
                    (self.ir[0] + self.ir[1]) / 2, sat, self.wall_bits,
                    self.pos[0], self.pos[1], self.mouse_task, 1, int(self.params[22]),
                ]))
            if dom in ("ALL", "POWER"):
                adc_batt = int(round(self.volt * 1000.0 / (self.params[33] / 1000.0))) if self.params[33] else 0
                mv = int(round(adc_batt * self.params[33] / 1000.0))
                low = int(self.params[34])
                high = int(self.params[35])
                maxp = max(1, int(self.params[37]))
                minp = int(self.params[38])
                step = max(1, (high - low) // maxp)
                pct = (mv - low) // step if mv > low else 0
                pct = max(minp, min(maxp, pct))
                out.append(line("POWER", [
                    adc_batt, mv, pct, 1 if mv < low else 0, 1,
                    self.cpu, 0, 0, 0,
                ]))
            if dom in ("ALL", "MAZE"):
                out.append(line("MAZE", [
                    self.mouse_task, self.maze_road, self._maze_opens(), self.motion_task,
                    self.pos[0], self.pos[1], self.dir, self.maze_stack,
                    self.maze_flags & 0xFF, self.maze_ev_count, 0,
                    self.maze_junc, self.maze_turn, self.maze_dead, self.maze_cell,
                    1 if (self.maze_flags & 0x01) else 0,
                ]))
            if dom in ("ALL", "TIME"):
                out.append(line("TIME", [
                    self.link_time_ms, self.arm_ms,
                    (self.link_time_ms - self.arm_ms) if self.arm_ms else 0,
                    1 if self.arm_ms else 0, 1 if self.maze_running else 0,
                    self.time_led, 1 if self.stream_on else 0,
                ]))
            return out + [ack("OK")]
        if c == "SET":
            if len(t) < 3 or t[1].upper() not in NAME_IDS:
                return [ack("ERR_NAME")]
            try:
                v = float(t[2])
            except ValueError:
                return [ack("ERR_VALUE")]
            self.params[NAME_IDS[t[1].upper()]] = v
            return [ack("OK")]
        if c == "SETQ":
            if len(t) < 3 or t[1].upper() not in NAME_IDS:
                return [ack("ERR_NAME")]
            try:
                q = int(t[2])
            except ValueError:
                return [ack("ERR_VALUE")]
            self.params[NAME_IDS[t[1].upper()]] = q / 65536.0
            return [ack("OK")]
        if c == "SAVE":
            # 运动/实验期间擦写 Flash 的取指停顿会打断 1kHz 控制环 -> 与固件一致地拒绝
            if self._motion_busy():
                return [ack("ERR_BUSY")]
            self.flash_valid = True
            return [ack("OK")]
        if c == "RESET":
            self.flash_valid = False
            return [ack("OK")]
        if c == "TARE":
            self.gyro = 0.0
            self.enc_diff_acc = 0.0
            return [ack("OK")]
        if c == "STOP":
            self._halt()
            # 与固件一致: 测试模式下 STOP 兼作"解急停", 并让板子保持在线
            self.estop_lock = False
            self.emerg = False
            self.log_ready = False
            self.sleepmode = 0
            return [ack("OK")]
        if c == "ESTOP":
            self._halt()
            self.emerg = True
            self.estop_lock = True
            self.log_ready = True
            if self.scope_state == 1:
                self.scope_state = 2
            return [ack("OK")]
        if c == "STREAM":
            if len(t) < 2:
                return [ack("ERR_VALUE")]
            a = t[1].upper()
            if a == "ON":
                self.stream_on = True
                return [ack("OK")]
            if a == "OFF":
                self.stream_on = False
                return [ack("OK")]
            return [ack("ERR_VALUE")]
        if c == "RATE":
            if len(t) < 2:
                return [ack("ERR_VALUE")]
            try:
                hz = int(t[1])
            except ValueError:
                return [ack("ERR_VALUE")]
            # 与固件 link.c 的 RATE 分档一致: div = 1000/hz
            div = {100: 10, 50: 20, 20: 50, 10: 100, 5: 200, 2: 500}.get(hz)
            if div is None:
                return [ack("ERR_VALUE")]
            self.fast_div = div
            return [ack("OK")]
        if c == "SCOPE":
            if len(t) < 2:
                return [ack("ERR_VALUE")]
            a = t[1].upper()
            if a == "START":
                # 可选剖面参数: A 运动学(默认) / B 四路红外 mm / C 原始 ADC / D 电压 / E 混合
                prof = "A"
                if len(t) >= 3 and t[2]:
                    p = t[2].upper()
                    if p not in ("A", "B", "C", "D", "E"):
                        return [ack("ERR_VALUE")]
                    prof = p
                self.scope_state = 1
                self.scope_prof = prof
                self.ring_idx = 0
                self.ring_count = 0
                self.sample_ring_enabled = True
                self.run_dist_l = 0.0
                self.run_dist_r = 0.0
                self.scope_start_ms = self.link_time_ms  # 第 0 点的绝对时刻
                self.move_mode = "EXPLORE" if self.auto_explore else self.move_mode
                return [ack("OK")]
            if a == "STOP":
                if self.scope_state == 1:
                    self.scope_state = 2
                return [ack("OK")]
            if a == "DUMP":
                if self.dump_state == 1:
                    return [ack("ERR_BUSY")]
                self.scope_state = 2
                self.dump_state = 1
                self.dump_blk = 0
                self.dump_chksum = 0
                self.log_ready = False  # 与固件 link_StartDump 一致: 索取即消费"就绪"位
                return [ack("OK")]
            return [ack("ERR_VALUE")]
        if c == "MAP":
            if len(t) >= 2 and t[1].upper() == "DUMP":
                self.map_reply = self._frame_map()
                return [ack("OK")]
            return [ack("ERR_VALUE")]
        if c == "MOVE":
            if len(t) < 2:
                return [ack("ERR_VALUE")]
            a = t[1].upper()
            if a == "RUN":
                # MOVE RUN <spL> <spR> [ms] [ir_mm]
                if len(t) < 4:
                    return [ack("ERR_VALUE")]
                try:
                    sp_l = int(float(t[2]))
                    sp_r = int(float(t[3]))
                    ms = int(float(t[4])) if len(t) >= 5 else 0
                    ir = int(float(t[5])) if len(t) >= 6 else 0
                except ValueError:
                    return [ack("ERR_VALUE")]
                if self.estop_lock:
                    return [ack("ERR_ESTOP")]
                if self._motion_busy():
                    # 关键: 必须包含 move_mode != NONE。否则第二条 RUN 会覆盖
                    # run_elapsed/run_limit, 把时间护栏重置掉(真机曾如此)。
                    return [ack("ERR_BUSY")]
                if sp_l == 0 and sp_r == 0:
                    return [ack("ERR_VALUE")]
                if ms <= 0:
                    ms = 2000
                if ir < 0:
                    ir = 0            # 负值 = 关闭红外护栏
                elif ir == 0:
                    ir = 10           # 省略 = 默认 10mm
                self._halt()
                self.run_limit = ms
                self.run_elapsed = 0
                self.run_ir_mm = ir
                self.run_ir_min = 1 << 30
                self.run_ir_which = 0
                self.run_vmax_l = self.run_vmax_r = 0
                self.run_start_l = self.dist_l_mm
                self.run_start_r = self.dist_r_mm
                self.freemode = 0
                self.move_mode = "RUN"
                self.speed_target_l, self.speed_target_r = float(sp_l), float(sp_r)
                # 双流: 运动一开始就打开 1kHz 本地记录(零带宽), 停止时冻结
                self.scope_state = 1
                self.ring_idx = 0
                self.ring_count = 0
                self.sample_ring_enabled = True
                self.log_ready = False
                return [ack("OK")]
            if a == "FWD" and len(t) >= 3:
                if self.estop_lock:
                    return [ack("ERR_ESTOP")]
                if self._motion_busy():
                    return [ack("ERR_BUSY")]
                self._halt()
                self.move_pulses = int(float(t[2]))
                self.move_start_l = self.dist_l_mm
                self.move_start_r = self.dist_r_mm
                speed = float(t[3]) if len(t) >= 4 else 40.0
                self.freemode = 0
                self.move_mode = "FWD"
                self.speed_target_l = self.speed_target_r = speed
                return [ack("OK")]
            if a == "ROT" and len(t) >= 3:
                if self.estop_lock:
                    return [ack("ERR_ESTOP")]
                if self._motion_busy():
                    return [ack("ERR_BUSY")]
                self._halt()
                pwm = float(t[2])
                ms = int(float(t[3])) if len(t) >= 4 else 500
                self.freemode = 0
                self.move_mode = "ROT"
                self.move_until = time.time() + ms / 1000.0
                self.speed_target_l, self.speed_target_r = pwm, -pwm
                return [ack("OK")]
            return [ack("ERR_VALUE")]
        if c == "ARM":
            # 发车: 记下发车时刻 + 点亮 1Hz 时间基准灯(与固件 link.c 的 ARM 一致)
            self.armed = True
            self.arm_ms = self.link_time_ms
            self.time_led = 1
            self._armed_pending = True  # 下一批补发一行 "ARMED <ms>"
            return [ack("OK")]
        if c == "MAZE":
            if len(t) >= 2 and t[1].upper() == "RUN":
                if self.maze_requested or self.maze_running:
                    return [ack("ERR_BUSY")]
                self.maze_requested = True
                self.maze_running = True   # 模拟器没有"主循环等待"一说, 直接开跑
                self.mouse_task = 2        # MAZESEARCH
                # MAZE RUN 是**显式**发车命令, 因此不受 --no-auto(那是"别自己乱跑")影响
                self.move_mode = "EXPLORE"
                self.freemode = 0
                return [ack("OK")]
            # MAZE EV [mask|OFF|DEF|ALL] —— 事件掩码; 不带参数则查询
            if len(t) >= 2 and t[1].upper() == "EV":
                if len(t) >= 3:
                    arg = t[2].upper()
                    if arg == "OFF":
                        self.maze_ev_mask = 0
                    elif arg == "DEF":
                        self.maze_ev_mask = MAZE_EV_DEF
                    elif arg == "ALL":
                        self.maze_ev_mask = MAZE_EV_DEF | MAZE_EV_CELL
                    else:
                        try:
                            self.maze_ev_mask = int(arg, 0) & 0x3F
                        except ValueError:
                            return [ack("ERR_VALUE")]
                return [f"MAZE EVMASK {self.maze_ev_mask}\r\n", ack("OK")]
            # MAZE RST —— 清统计(掩码保留)
            if len(t) >= 2 and t[1].upper() == "RST":
                self._maze_reset()
                return [ack("OK")]
            return [ack("ERR_VALUE")]
        if c == "LESSON":
            # LESSON START <exp> [a] [b] [c] [d]  /  LESSON STOP  /  LESSON STATUS
            if len(t) < 2:
                return [ack("ERR_VALUE")]
            a = t[1].upper()
            if a == "STATUS":
                # LESSON STATUS <exp> <running>  (exp=0 if idle)
                return [
                    f"LESSON STATUS {int(self.lesson_exp)} {1 if self.lesson_running else 0}\r\n",
                    ack("OK"),
                ]
            if a == "STOP":
                if self.lesson_running:
                    # 立即停车并回 STOP 明细
                    self._finish_lesson("STOP")
                else:
                    # 没在跑也回 OK + 一行(幂等, 与固件 LESSONLAB_Abort 行为一致)
                    self.lesson_done_pending = True
                    self.lesson_done_line = "LESSON DONE 0 STOP 0 0 0 0 0 0"
                return [ack("OK")]
            if a == "START":
                if len(t) < 3:
                    return [ack("ERR_VALUE")]
                try:
                    exp = int(t[2])
                    a1 = int(t[3]) if len(t) >= 4 else 0
                    a2 = int(t[4]) if len(t) >= 5 else 0
                    a3 = int(t[5]) if len(t) >= 6 else 0
                    a4 = int(t[6]) if len(t) >= 7 else 0
                except ValueError:
                    return [ack("ERR_VALUE")]
                st = self._start_lesson(exp, a1, a2, a3, a4)
                return [ack(st)]
            return [ack("ERR_VALUE")]
        if c == "CAL":
            if len(t) < 3:
                return [ack("ERR_VALUE")]
            item, act = t[1].upper(), t[2].upper()
            if act == "ABORT":
                self._halt()
                return [ack("OK")]
            if act == "START":
                if self.estop_lock and item in ("GYRORATIO", "ENCANGLE"):
                    return [ack("ERR_ESTOP")]
                self._halt()
                if item == "GYRO":
                    self.alert.append(f"CALDONE GYRO {random.randint(2020, 2060)}")
                elif item == "WALLDIST":
                    self.alert.append(f"CALDONE WALLDIST {int(self.ir[2]) if self.ir[2] < 200 else 42}")
                elif item == "IRDATA":
                    self._ir_phase = 0
                elif item in ("GYRORATIO", "ENCANGLE"):
                    self._sv_start = time.time()
                    self.freemode = 0
                    self.move_mode = "SERVO"
                    self.speed_target_l, self.speed_target_r = 25.0, -25.0
                return [ack("OK")]
            if act == "SAMPLE" and item == "IRDATA":
                p = getattr(self, "_ir_phase", 0)
                self.alert.append(f"CALSTEP IRDATA {p}")
                self._ir_phase = p + 1
                if self._ir_phase >= 4:
                    self.alert.append("CALDONE IRDATA")
                return [ack("OK")]
            return [ack("ERR_VALUE")]
        return [ack("ERR_CMD")]

    def _halt(self) -> None:
        self.speed_target_l = self.speed_target_r = 0.0
        self.move_mode = "NONE"
        self.freemode = 1
        self.motion_task = 0
        self.phase = "CELL"
        self.phase_dist = 0.0

    # ---------------------------------------------------------- 服务端

    def run(self, host: str, port: int) -> None:
        srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        srv.bind((host, port))
        srv.listen(1)
        print(f"[sim] 监听 {host}:{port}（Ctrl+C 退出）")
        while True:
            conn, addr = srv.accept()
            print(f"[sim] 客户端接入 {addr}")
            try:
                self._serve_one(conn)
            except Exception as e:
                print(f"[sim] 客户端异常: {e}")
            finally:
                try:
                    conn.close()
                except OSError:
                    pass
            print("[sim] 客户端断开, 等待下一个连接")

    def _serve_one(self, conn: socket.socket) -> None:
        conn.settimeout(None)
        rx = bytearray()
        conn.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        next_tick = time.perf_counter()
        tx = bytearray()
        last_flush = time.perf_counter()

        while True:
            # ---- 收 ----
            conn.settimeout(0.0)
            try:
                chunk = conn.recv(4096)
                if not chunk:
                    return
                rx += chunk
            except BlockingIOError:
                pass
            except OSError:
                return

            # 文本命令按 CR/LF 分帧(与固件 usart.c 的语义一致)
            while True:
                nl = rx.find(b"\n")
                if nl < 0:
                    break
                raw = bytes(rx[: nl + 1])
                del rx[: nl + 1]
                line = raw.decode("ascii", "replace").strip()
                if line:
                    for r in self.handle_line(line):
                        tx += r

            # ---- 物理与遥测 ----
            now = time.perf_counter()
            while now >= next_tick:
                self.step()
                next_tick += 0.001
                if next_tick < now - 0.25:  # 落后太多则重新对齐, 避免追帧风暴
                    next_tick = now + 0.001

            for alert in self.alert:
                tx += (alert + "\r\n").encode()
            self.alert.clear()
            if self.lesson_done_pending:
                self.lesson_done_pending = False
                tx += (self.lesson_done_line + "\r\n").encode()
            if self._armed_pending:
                self._armed_pending = False
                tx += f"ARMED {self.arm_ms}\r\n".encode()

            with self.lock:
                if self.dump_state == 1:
                    if self.dump_blk >= SCOPE_BLKS:
                        pl = struct.pack("<i", self.dump_chksum)
                        tx += pack_frame(TYPE_DUMP_END, pl, self.seq)
                        self.dump_state = 0
                    else:
                        if self.dump_blk == 0:
                            _filled = min(self.ring_count, SCOPE_LEN)
                            _start = self.ring_idx % SCOPE_LEN
                            # startMs = 回传数组中最早一点的绝对设备毫秒时基
                            # (未回绕 = scope_start_ms; 已回绕 = +start)
                            _start_ms = self.scope_start_ms + (
                                _start if _filled >= SCOPE_LEN else 0
                            )
                            hdr = struct.pack(
                                "<HBBHHI",
                                SCOPE_LEN,
                                SCOPE_PTS_PER_BLK,
                                # channels 字节兼作"录制剖面标识": A 报 4(旧行为),
                                # B..E 报 ASCII 'B'..'E'。
                                4 if self.scope_prof == "A" else ord(self.scope_prof),
                                _filled,  # filled
                                _start,   # start (写指针)
                                _start_ms,  # 时间同步: 绝对设备时刻
                            )
                            tx += pack_frame(TYPE_DUMP_HDR, hdr, self.seq)
                        tx += self._frame_dump_blk(self.dump_blk)
                        self.dump_blk += 1
                else:
                    if self.stream_on:
                        if self.tick % self.fast_div == 0:
                            tx += self._frame_fast()
                        if self.tick % self.mid_div == 0:
                            tx += self._frame_mid()
                        if self.tick % self.slow_div == 0:
                            tx += self._frame_slow()
                        # 时间同步帧 @1Hz: 与基准灯同拍(与固件 linkTimeMs % 1000 一致)
                        if self.link_time_ms % 1000 == 0:
                            tx += self._frame_time()
                        # 迷宫状态帧 @1Hz: 仅"处于迷宫态"时发(空闲零带宽增量)
                        if self._maze_in() and self.link_time_ms % 1000 == 0:
                            tx += self._frame_maze()

            mr = getattr(self, "map_reply", None)
            if mr is not None:
                tx += mr
                self.map_reply = None

            # ---- 发送(约 5ms 一批, 降低 syscall 开销) ----
            if tx and (time.perf_counter() - last_flush > 0.005 or len(tx) > 4096):
                try:
                    conn.sendall(bytes(tx))
                except OSError:
                    return
                tx.clear()
                last_flush = time.perf_counter()

            time.sleep(0.0005)


def main() -> None:
    ap = argparse.ArgumentParser(description="电脑鼠设备模拟器(协议与固件一致)")
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=5555)
    ap.add_argument("--no-auto", action="store_true", help="不自动跑探索, 需要手动 SCOPE START")
    ap.add_argument("--safe", action="store_true",
                    help="安全测试模式: 置'电机禁用'标志且速度恒 0(对齐 MOUSE_TEST_NO_MOTOR 固件)")
    ap.add_argument("--realistic", action="store_true",
                    help="按真机蓝牙链路的速率发送: 快 5Hz / 中 1Hz / 慢 0.5Hz(≈152 B/s)")
    ap.add_argument("--seed", type=int, default=20260925)
    args = ap.parse_args()
    sim = MouseSim(auto_explore=not args.no_auto, seed=args.seed, safe=args.safe)
    if args.realistic:
        # 对齐固件默认速率(见 link.c link_Telemetry): 快 24B@5Hz + 中 20B@1Hz + 慢 24B@0.5Hz
        sim.fast_div, sim.mid_div, sim.slow_div = 200, 1000, 2000
    try:
        sim.run(args.host, args.port)
    except KeyboardInterrupt:
        print("\n[sim] 退出")


if __name__ == "__main__":
    main()
