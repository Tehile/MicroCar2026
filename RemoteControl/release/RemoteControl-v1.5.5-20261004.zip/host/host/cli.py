"""上位机命令行入口 —— CLI 本身即机器可调用的接口。

用法(在 host/ 目录下):
    python -m host.cli ports --json
    python -m host.cli monitor COM7 --expect-safe     # 实时数据监视器(本阶段主用)
    python -m host.cli connect COM7 --stream --record
    python -m host.cli get TRACKL --json --target COM7
    python -m host.cli set TRACKL 53.2015 --save --target COM7
    python -m host.cli calib gyro --target COM7
    python -m host.cli calib walldist --target COM7 && python -m host.cli save --target COM7
    python -m host.cli calib irdata --target COM7     # 4 个摆位逐点采(交互)
    python -m host.cli scope fetch --out dump.csv --target COM7
    python -m host.cli maze --target COM7
    python -m host.cli diagnose COM7
    python -m host.cli scan-baud COM7
    python -m host.cli replay sessions/2026-09-27_0151 --analyze

约定: 每个子命令 = 一次 API 调用; `--json` 输出结构化结果(可被 jq 解析)。
不指定 --target 时自动挑第一个可用串口, 没有串口则回退到模拟器 TCP(5555)。
"""

from __future__ import annotations

import argparse
import csv
import json
import os
import sys


# ---------------------------------------------------------------- 输出辅助

def _emit(obj, as_json: bool) -> None:
    if as_json:
        print(json.dumps(obj, ensure_ascii=False, indent=2))
    elif isinstance(obj, str):
        print(obj)
    else:
        for line in _flatten(obj):
            print(line)


def _flatten(obj) -> list:
    """把 dict/list 转成简洁的 key: value 行。"""
    if isinstance(obj, dict):
        return [f"{k}: {v}" for k, v in obj.items()]
    if isinstance(obj, (list, tuple)):
        return [str(x) for x in obj]
    return [str(obj)]


# ---------------------------------------------------------------- 连接辅助

def _open_client(target: str, **ctor_kw):
    from host.api import MouseClient

    mc = MouseClient(**ctor_kw)
    if not mc.connect(target):
        detail = mc.state_detail or "未知原因"
        mc.close()
        raise SystemExit(f"连接失败: {detail}")
    return mc


def _resolve_target(args) -> str:
    t = getattr(args, "target", None)
    if t:
        return t
    # 自动: 第一个可用串口, 否则模拟器 TCP
    from host.api import coerce_target

    return coerce_target(None)


# ---------------------------------------------------------------- 子命令

def cmd_monitor(args) -> None:
    """实时数据监视器(终端仪表盘) —— 串到 host.monitor。"""
    from host import monitor

    argv = []
    if args.target:
        argv.append(args.target)
    argv += ["--baud", str(args.baud), "--hz", str(args.hz), "--width", str(args.width),
             "--timeout", str(args.timeout)]
    if args.seconds:
        argv += ["--seconds", str(args.seconds)]
    for flag in ("once", "json", "no_color", "no_clear", "no_stream", "record", "expect_safe"):
        if getattr(args, flag.replace("-", "_")):
            argv.append("--" + flag.replace("_", "-"))
    rc = monitor.main(argv)
    if rc:
        raise SystemExit(rc)


def cmd_motor_test(args) -> None:
    """电机远程控制实验(双流) —— 串到 host.motor_test。"""
    from host import motor_test

    argv = []
    if args.target:
        argv.append(args.target)
    argv += ["--baud", str(args.baud), "--sp", *[str(x) for x in args.sp],
             "--time", str(args.time), "--ir", str(args.ir),
             "--hz", str(args.hz), "--log-timeout", str(args.log_timeout)]
    if args.out:
        argv += ["--out", args.out]
    if args.out_realtime:
        argv += ["--out-realtime", args.out_realtime]
    for flag in ("no_log", "no_analyze", "status", "estop", "resume", "expect_safe",
                 "json", "no_color"):
        if getattr(args, flag):
            argv.append("--" + flag.replace("_", "-"))
    raise SystemExit(motor_test.main(argv))


def cmd_lesson(args) -> None:
    """课程调参实验(参数设定 + 启停 + 自动算参) —— 串到 host.lesson。"""
    from host import lesson

    argv = []
    if args.target:
        argv.append(args.target)
    if args.exp is not None:
        argv.append(str(args.exp))
    argv += ["--baud", str(args.baud), "--hz", str(args.hz),
             "--log-timeout", str(args.log_timeout)]
    for pair in args.set or []:
        argv += ["--set", pair]
    for name, attr in (("v", "v"), ("dist", "dist"), ("ms", "ms"), ("angle", "angle"),
                       ("t-acc", "t_acc"), ("t-cruise", "t_cruise"), ("t-dec", "t_dec")):
        val = getattr(args, attr, None)
        if val is not None:
            argv += ["--" + name, str(val)]
    if args.truth is not None:
        argv += ["--truth", str(args.truth)]
    if args.out:
        argv += ["--out", args.out]
    for flag in ("list", "theory", "params", "status", "stop", "start", "save", "apply",
                 "json", "no_color"):
        if getattr(args, flag.replace("-", "_"), False):
            argv.append("--" + flag.replace("_", "-"))
    if args.readback is False:
        argv.append("--no-readback")
    raise SystemExit(lesson.main(argv))


def cmd_datalog(args) -> None:
    """数据收集台(远程发车 + 时间同步 + 完整采集) —— 串到 host.datalog。"""
    from host import datalog

    argv = []
    if args.target:
        argv.append(args.target)
    argv += ["--baud", str(args.baud), "--seconds", str(args.seconds), "--hz", str(args.hz),
             "--log-timeout", str(args.log_timeout)]
    if args.out:
        argv += ["--out", args.out]
    for flag in ("no_maze", "no_arm", "no_dump", "force", "arm_only", "maze_only",
                 "status", "json", "no_color"):
        if getattr(args, flag):
            argv.append("--" + flag.replace("_", "-"))
    raise SystemExit(datalog.main(argv))


def cmd_estop(args) -> None:
    """一键急停(随时可用, 不需要其它前置条件)。"""
    from host import motor_test

    argv = []
    if args.target:
        argv.append(args.target)
    argv += ["--baud", str(args.baud)]
    argv.append("--resume" if args.resume else "--estop")
    if args.json:
        argv.append("--json")
    raise SystemExit(motor_test.main(argv))


def cmd_ports(args) -> None:
    from host.api import MouseClient

    mc = MouseClient(auto_session=False, auto_stream=False)
    try:
        ports = mc.conn.ports()
        labels = mc.conn.port_labels()
    finally:
        mc.close()
    if getattr(args, "json", False):
        _emit(
            [
                {"device": p.device, "description": p.description, "direction": p.direction,
                 "is_bluetooth": p.is_bluetooth, "usable": p.usable}
                for p in ports
            ],
            True,
        )
    else:
        print("\n".join(labels) if labels else "（未发现串口）")


def cmd_connect(args) -> None:
    from host.api import MouseClient

    mc = MouseClient(auto_session=args.record, auto_stream=args.stream)
    if not mc.connect(args.target, baud=args.baud):
        raise SystemExit(f"连接失败: {mc.state_detail}")
    print(f"已连接: {mc.state_detail}")
    print(f"设备: {mc.device}")
    if args.stream:
        print("等待遥测首帧…")
        if mc.telemetry.wait_first_frame(timeout=5):
            print("遥测已到达。Ctrl+C 退出。")
            try:
                mc.telemetry.live(seconds=args.seconds)
            except KeyboardInterrupt:
                pass
        else:
            print("未收到遥测(设备可能默认静默, 需 STREAM ON)")
    elif args.seconds:
        try:
            mc.telemetry.live(seconds=args.seconds)
        except KeyboardInterrupt:
            pass
    print("会话目录:", mc.session.path if args.record else "(未开启)")
    mc.close()


def cmd_get(args) -> None:
    mc = _open_client(_resolve_target(args))
    try:
        val = mc.params.get(args.param)
        if val is None:
            raise SystemExit(f"回读失败: {args.param}")
        _emit({"param": args.param, "value": val}, getattr(args, "json", False))
    finally:
        mc.close()


def cmd_get_all(args) -> None:
    mc = _open_client(_resolve_target(args))
    try:
        got = mc.params.get_all()
        if getattr(args, "json", False):
            _emit(got, True)
        else:
            print(mc.params.table())
    finally:
        mc.close()


def cmd_snap(args) -> None:
    """阻塞式测量快照: 非数据采集阶段获取"全部可测量量"的标准入口。

    不需要 STREAM ON —— 走的是命令/应答通道, 因此可以在**静默链路**上工作,
    也不占任何常驻遥测带宽。`--poll` 时按固定频率连续问(纯主机侧定时器)。
    """
    mc = _open_client(_resolve_target(args))
    dom = None if getattr(args, "dom", None) in (None, "", "ALL") else getattr(args, "dom")
    try:
        if getattr(args, "poll", 0.0):
            samples = mc.snap.poll(
                hz=float(args.poll),
                dur=float(getattr(args, "seconds", 0.0) or 0.0) or None,
                domains=dom,
            )
            if getattr(args, "json", False):
                _emit(samples, True)
            else:
                for i, s in enumerate(samples):
                    bat = mc.snap.battery(s)
                    ch = mc.snap.ir_channels(s)
                    print(f"[{i:03d}] " + "  ".join(
                        [f"电压 {bat.get('volt', 0):.2f}V"] +
                        [f"{k} {ch[k].get('mm')}mm(adc{ch[k].get('adc')})"
                         for k in ("F1", "F2", "L", "R") if k in ch]
                    ))
            return
        snap = mc.snap.read(dom)
        if getattr(args, "json", False):
            _emit(snap, True)
            return
        if not snap:
            print(f"(未取到快照; 状态 {mc.snap.last_status()})")
            return
        for line in mc.snap.explain(snap):
            print(line)
    finally:
        mc.close()


def cmd_set(args) -> None:
    mc = _open_client(_resolve_target(args))
    try:
        r = mc.params.set(args.param, args.value)
        if not r.ok:
            raise SystemExit(f"写入失败: {r.status}")
        if args.save:
            s = mc.params.save()
            if not s.ok:
                raise SystemExit(f"保存失败: {s.status}")
        _emit({"param": args.param, "value": args.value, "ok": True,
               "readback": r.data.get("readback"), "saved": args.save},
              getattr(args, "json", False))
    finally:
        mc.close()


def cmd_calib(args) -> None:
    from host.api import MouseClient

    mc = _open_client(_resolve_target(args))
    try:
        item = args.item.upper()
        if item == "IRDATA":
            # 4 个摆位逐点采: 每点等操作者摆好再采(与固件的 CAL IRDATA SAMPLE 一致)
            def _ask(i: int, name: str, desc: str) -> bool:
                print(f"\n第 {i + 1}/4 点 —— {name}: {desc}")
                if args.yes:
                    return True
                ans = input("  摆好后回车采集 (输入 c 取消): ").strip().lower()
                return ans != "c"

            r = mc.calib.ir_data(on_prompt=_ask)
        else:
            fn = {
                "GYRO": mc.calib.gyro,
                "WALLDIST": mc.calib.wall_distance,
                "ANGLE": mc.calib.angle,
                "TRACK": mc.calib.track,
            }.get(item)
            if fn is None:
                raise SystemExit(
                    f"未知标定项: {item} (可选 GYRO/WALLDIST/IRDATA/ANGLE/TRACK)"
                )
            r = fn() if item in ("GYRO", "WALLDIST", "ANGLE") else fn(
                pulses=args.pulses, speed=args.speed
            )
        _emit({"item": item, "ok": r.ok, "status": r.status, "data": r.data},
              getattr(args, "json", False))
        if not r.ok and r.status == "MOTOR_DISABLED":
            print(f"\n提示: {r.data.get('hint', '')}", file=sys.stderr)
    finally:
        mc.close()


def cmd_save(args) -> None:
    """把参数表写入 Flash(page 115)。WALLDIST / 角度系数 / 里程系数改完 RAM 后需要它。"""
    from host.api import MouseClient

    mc = _open_client(_resolve_target(args))
    try:
        r = mc.params.save(timeout=args.timeout)
        _emit({"ok": r.ok, "status": r.status}, getattr(args, "json", False))
        if not r.ok:
            raise SystemExit(f"SAVE 失败: {r.status}")
    finally:
        mc.close()


def cmd_scope(args) -> None:
    mc = _open_client(_resolve_target(args))
    prof = (getattr(args, "profile", None) or "A").upper()
    try:
        if prof == "A":
            arr = mc.scope.fetch(timeout=args.timeout)
            if arr is None:
                raise SystemExit("波形回传失败或超时")
            if args.out:
                _write_dump_csv(arr, args.out)
            if args.analyze:
                print(mc.analyze.explain(arr))
            _emit({"profile": "A", "points": len(arr[0]), "out": args.out},
                  getattr(args, "json", False))
            return
        # 剖面 B..E: 先按剖面开采集, 再走同一套"停车 -> 回传"的双流式
        got = mc.scope.fetch_data(prof, timeout=args.timeout)
        if got is None:
            raise SystemExit("测量波形回传失败或超时")
        prof_got, t, ch = got
        if args.out:
            _write_meas_csv(prof_got, t, ch, args.out)
        chans = ", ".join(ch.keys())
        _emit({"profile": prof_got, "points": len(t), "channels": chans, "out": args.out},
              getattr(args, "json", False))
    finally:
        mc.close()


def _write_meas_csv(profile: str, t, ch, path: str) -> None:
    """按剖面把测量波形落成 CSV(与 dump 落盘的表头规则一致)。"""
    names = list(ch.keys())
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["i", "t_ms"] + names)
        for i in range(len(t)):
            w.writerow([i, int(t[i])] + [int(ch[n][i]) for n in names])


def cmd_maze(args) -> None:
    """迷宫: 墙图 + **状态机回传**(实验8 无记忆走迷宫)。

    `action` 省略时等价 `map`(向后兼容)。
    """
    action = getattr(args, "action", None) or "map"
    mc = _open_client(_resolve_target(args))
    try:
        if action == "map":
            m = mc.maze.fetch()
            if not m:
                raise SystemExit("未获取到墙图")
            print(mc.maze.to_text(mark=mc.maze.position()[:2]))
            if args.out:
                with open(args.out, "w", encoding="utf-8") as f:
                    json.dump({"mazetype": m["mazetype"], "mapWall": m["mapWall"],
                               "mapVisited": m["mapVisited"]}, f, ensure_ascii=False)
            _emit({"mazetype": m["mazetype"], "out": args.out}, getattr(args, "json", False))
            return

        if action == "state":
            # 1Hz 状态帧需要 STREAM ON(与其它周期帧同一约定)
            mc.send_cmd("stream.on", timeout=3.0)
            mc.wait(lambda: mc.maze.state() is not None, timeout=2.5)
            st = mc.maze.state()
            if getattr(args, "json", False):
                _emit(st or {}, True)
            elif st is None:
                print("（还没收到迷宫状态帧。迷宫没在跑? 或先 `maze snap` 点查）")
            else:
                print(f"任务 {st['taskName']}  动作 {st['motion']}  "
                      f"路口 {st['roadKind']}({st['roadName']})  开口 {st['opens']}")
                print(f"位置 ({st['posX']},{st['posY']}) 朝向 {st['dir']}  "
                      f"岔路栈 {st['stack']}  标志 0x{st['flags']:02X}")
                print(f"统计: 事件 {st['evCount']}  岔路口 {st['juncCnt']}  "
                      f"转向 {st['turnCnt']}  死路 {st['deadCnt']}")
                if st["evDropped"]:
                    print("⚠️ 有事件被丢弃(链路拥塞): 事件流不完整")
            return

        if action == "snap":
            st = mc.maze.snap(timeout=float(getattr(args, "timeout", 3.0)))
            if getattr(args, "json", False):
                _emit(st or {}, True)
            elif st is None:
                print("SNAP MAZE 无回话(设备可能不支持该固件)")
            else:
                print(f"任务 {st['taskName']}  路口 {st['roadKind']}({st['roadName']})  "
                      f"开口 {st['opens']}  动作 {st['motion']}")
                print(f"位置 ({st['posX']},{st['posY']}) 朝向 {st['dir']}  "
                      f"岔路栈 {st['stack']}  到达终点 {int(st['goal'])}")
                print(f"统计: 事件 {st['evCount']}(丢 {st['evDrop']})  岔路口 {st['juncCnt']}  "
                      f"转向 {st['turnCnt']}  死路 {st['deadCnt']}  格数 {st['cellCnt']}")
            return

        if action == "events":
            mc.maze._ensure_hooked()
            n = int(getattr(args, "n", 50) or 50)
            evs = mc.maze.events(n=n, kind=getattr(args, "kind", None))
            if getattr(args, "json", False):
                _emit(evs, True)
            else:
                for e in evs:
                    print(f"  {e.get('event','?'):<6} {e.get('summary','')}")
                print(f"  —— 共 {len(evs)} 条")
            return

        if action == "watch":
            secs = float(getattr(args, "seconds", 0.0) or 15.0)
            print(f"跟随迷宫事件 {secs:.0f}s ... (Ctrl-C 提前结束)")

            def _show(e):
                print(f"  {e.get('event','?'):<6} {e.get('summary','')}", flush=True)

            evs = mc.maze.watch(dur=secs, on_event=_show)
            if getattr(args, "json", False):
                _emit(evs, True)
            else:
                print(f"  —— 共 {len(evs)} 条")
            return

        if action == "summary":
            s = mc.maze.summary()
            if getattr(args, "json", False):
                _emit(s, True)
            else:
                for line in mc.maze.explain():
                    print(line)
            return

        if action == "ev":
            cur = mc.maze.set_events(getattr(args, "mask", "") or "")
            print(f"事件掩码 = {cur}" if cur is not None else "查询掩码失败")
            return

        if action == "rst":
            print("已清迷宫统计" if mc.maze.reset() else "清统计失败(超时?)")
            return

        raise SystemExit(f"未知 maze 动作: {action}")
    finally:
        mc.close()


def cmd_diagnose(args) -> None:
    from host.api import MouseClient

    mc = MouseClient(auto_session=False, auto_stream=False)
    try:
        r = mc.conn.probe(args.port, args.baud, args.seconds)
    finally:
        mc.close()
    _emit(r, getattr(args, "json", False))


def cmd_scan_baud(args) -> None:
    from host.api import MouseClient

    mc = MouseClient(auto_session=False, auto_stream=False)
    try:
        results = mc.conn.scan_baud(args.port, args.bauds, args.seconds)
    finally:
        mc.close()
    if getattr(args, "json", False):
        _emit(results, True)
    else:
        for r in results:
            print(f"{r.get('baud', '?')}: {r.get('bytes', 0)}B  "
                  f"frames={r.get('frames', 0)} lines={r.get('text_lines', 0)} "
                  f"crc={r.get('bad_crc', 0)}")


def cmd_replay(args) -> None:
    from host.api import MouseClient

    mc = MouseClient(auto_session=False, auto_stream=False)
    mc.connect("replay://" + args.session)
    try:
        print(f"回放: {args.session}")
        mc.telemetry.wait_first_frame(timeout=10)
        print(mc.telemetry.summary_text())
        st = mc.stats()
        print(f"帧: {st.get('frames', 0)}  字节: {st.get('rx_bps', 0):.0f} B/s")
        if args.analyze:
            arr = _load_dump_csv(args.session)
            if arr is not None:
                print("—— 动作段分析 ——")
                print(mc.analyze.explain(arr))
            else:
                print("（该会话无 1kHz dump 记录）")
        if getattr(args, "json", False):
            _emit({"frames": st.get("frames"), "rx_bps": st.get("rx_bps")}, True)
    finally:
        mc.close()


# ---------------------------------------------------------------- 工具

def _write_dump_csv(arr, path: str) -> None:
    t, task, ang, sl, sr = arr
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["i", "t_ms", "motionTask", "gangle", "speedl", "speedr"])
        for i in range(len(t)):
            w.writerow([i, int(t[i]), int(task[i]), int(ang[i]), int(sl[i]), int(sr[i])])


def _load_dump_csv(session_dir: str):
    import glob

    import numpy as np

    files = sorted(glob.glob(os.path.join(session_dir, "dump_1khz_*.csv")))
    if not files:
        return None
    a = np.genfromtxt(files[-1], delimiter=",", skip_header=1)
    if a.ndim == 1 or len(a) == 0:
        return None
    return (a[:, 1], a[:, 2], a[:, 3], a[:, 4], a[:, 5])


# ---------------------------------------------------------------- 参数解析

def _build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="host.cli", description="电脑鼠上位机命令行接口")
    sub = p.add_subparsers(dest="cmd", required=True)

    sp = sub.add_parser("ports", help="枚举串口")
    sp.add_argument("--json", action="store_true")

    sp = sub.add_parser("connect", help="连接(可选开流+录会话+实时状态)")
    sp.add_argument("target")
    sp.add_argument("--baud", type=int, default=115200)
    sp.add_argument("--stream", action="store_true", help="连接后 STREAM ON")
    sp.add_argument("--record", action="store_true", help="开启会话落盘")
    sp.add_argument("--seconds", type=float, default=0.0, help="实时状态持续时间(0=直到 Ctrl+C)")

    sp = sub.add_parser("get", help="读单个参数")
    sp.add_argument("param")
    sp.add_argument("--target")
    sp.add_argument("--json", action="store_true")

    sp = sub.add_parser("get-all", help="读全部参数")
    sp.add_argument("--target")
    sp.add_argument("--json", action="store_true")

    sp = sub.add_parser("set", help="写参数(可 --save 落 Flash)")
    sp.add_argument("param")
    sp.add_argument("value", type=float)
    sp.add_argument("--save", action="store_true")
    sp.add_argument("--target")
    sp.add_argument("--json", action="store_true")

    sp = sub.add_parser("calib", help="跑一项标定")
    sp.add_argument("item", help="GYRO/WALLDIST/IRDATA/ANGLE/TRACK")
    sp.add_argument("--pulses", type=int, default=20000)
    sp.add_argument("--speed", type=int, default=40)
    sp.add_argument("--yes", action="store_true",
                    help="IRDATA: 不逐点等回车, 连续采 4 点(自动化用)")
    sp.add_argument("--target")
    sp.add_argument("--json", action="store_true")

    sp = sub.add_parser("save", help="把参数表写入 Flash(page 115)")
    sp.add_argument("--timeout", type=float, default=5.0)
    sp.add_argument("--target")
    sp.add_argument("--json", action="store_true")

    sp = sub.add_parser("scope", help="示波器/波形回传")
    sp.add_argument("action", choices=["fetch"])
    sp.add_argument("--out", help="导出 dump.csv")
    sp.add_argument("--analyze", action="store_true")
    sp.add_argument("--profile", default="A",
                    help="录制剖面 A..E: A=运动学(默认) / B=四路红外 mm / "
                         "C=四路红外原始 ADC / D=电压 / E=混合")
    sp.add_argument("--timeout", type=float, default=300.0)
    sp.add_argument("--target")
    sp.add_argument("--json", action="store_true")

    sp = sub.add_parser("maze", help="迷宫: 墙图 + 状态机回传(实验8)")
    sp.add_argument("action", nargs="?", default="map",
                    choices=["map", "state", "snap", "events", "watch", "summary", "ev", "rst"],
                    help="map=墙图(默认) state=最近1Hz状态帧 snap=阻塞点查 "
                         "events=已收事件 watch=实时跟随 summary=汇总 "
                         "ev=查/设事件掩码 rst=清统计")
    sp.add_argument("--out", help="map: 导出 map.json")
    sp.add_argument("--n", type=int, default=50, help="events: 最多显示条数")
    sp.add_argument("--kind", default=None,
                    help="events: 只看某类 TASK/ROAD/JUNC/TURN/GOAL/BEGIN/EXIT/CELL")
    sp.add_argument("--mask", default="", help="ev: OFF/DEF/ALL/0..63(省略=查询)")
    sp.add_argument("--seconds", type=float, default=0.0, help="watch: 观察秒数(默认15)")
    sp.add_argument("--timeout", type=float, default=3.0, help="snap: 超时秒")
    sp.add_argument("--target")
    sp.add_argument("--json", action="store_true")

    sp = sub.add_parser("monitor", help="实时数据监视器(终端仪表盘)")
    sp.add_argument("target", nargs="?", default=None,
                    help="串口/TCP/回放目标; 省略则自动选择")
    sp.add_argument("--baud", type=int, default=115200)
    sp.add_argument("--hz", type=float, default=5.0)
    sp.add_argument("--width", type=int, default=78)
    sp.add_argument("--seconds", type=float, default=0.0)
    sp.add_argument("--timeout", type=float, default=5.0)
    sp.add_argument("--once", action="store_true", help="打印一次快照后退出")
    sp.add_argument("--json", action="store_true", help="每行一条 JSON")
    sp.add_argument("--no-color", action="store_true")
    sp.add_argument("--no-clear", action="store_true")
    sp.add_argument("--no-stream", action="store_true")
    sp.add_argument("--record", action="store_true")
    sp.add_argument("--expect-safe", action="store_true",
                    help="期望固件处于安全测试模式(电机禁用)")

    sp = sub.add_parser("motor-test", help="电机远程控制实验(双流: 运动时实时流 / 停止后日志流)")
    sp.add_argument("target", nargs="?", default=None, help="串口/TCP; 省略则自动选择")
    sp.add_argument("--baud", type=int, default=115200)
    sp.add_argument("--sp", type=int, nargs="+", default=[40],
                    help="目标速度 cm/s: 一个值=左右相同, 两个值=左 右")
    sp.add_argument("--time", type=float, default=2.0, help="最长运行时间(秒), 默认 2.0")
    sp.add_argument("--ir", type=int, default=10,
                    help="红外停车阈值(mm), 默认 10; 负值=关闭红外护栏")
    sp.add_argument("--hz", type=float, default=5.0, help="实时流采样显示频率")
    sp.add_argument("--log-timeout", type=float, default=300.0)
    sp.add_argument("--out", help="1kHz 日志导出 CSV")
    sp.add_argument("--out-realtime", dest="out_realtime", help="实时流导出 CSV")
    sp.add_argument("--no-log", action="store_true", help="跳过停止后的日志回传")
    sp.add_argument("--no-analyze", action="store_true")
    sp.add_argument("--status", action="store_true", help="只打印状态")
    sp.add_argument("--estop", action="store_true", help="只发急停")
    sp.add_argument("--resume", action="store_true", help="只发 STOP(解急停)")
    sp.add_argument("--expect-safe", action="store_true")

    sp = sub.add_parser("lesson", help="课程调参实验(参数设定 + 启停 + 自动算参)")
    sp.add_argument("target", nargs="?", default=None, help="串口/TCP; 省略则自动选择")
    sp.add_argument("exp", nargs="?", type=int, default=None, help="实验号 2/3/5/6")
    sp.add_argument("--baud", type=int, default=115200)
    sp.add_argument("--list", action="store_true", help="列出可驱动的实验")
    sp.add_argument("--theory", action="store_true", help="打印里程/角度系数理论值")
    sp.add_argument("--params", action="store_true", help="打印 14 个课程调参量")
    sp.add_argument("--status", action="store_true", help="只打印状态")
    sp.add_argument("--stop", action="store_true", help="结束当前实验(LESSON STOP)")
    sp.add_argument("--start", action="store_true", help="只启动实验, 不等结果")
    sp.add_argument("--set", action="append", default=[], metavar="NAME=VALUE",
                    help="设定课程参数, 可重复")
    sp.add_argument("--no-readback", dest="readback", action="store_false", default=True)
    sp.add_argument("--save", action="store_true", help="设参/应用后落 Flash(page 116)")
    sp.add_argument("--v", type=int, default=None, help="目标速度 cm/s")
    sp.add_argument("--dist", type=int, default=None, help="目标里程 mm")
    sp.add_argument("--ms", type=int, default=None, help="时间护栏 ms")
    sp.add_argument("--angle", type=int, default=None, help="目标角度 度")
    sp.add_argument("--t-acc", dest="t_acc", type=int, default=None, help="加速段 ms")
    sp.add_argument("--t-cruise", dest="t_cruise", type=int, default=None, help="匀速段 ms")
    sp.add_argument("--t-dec", dest="t_dec", type=int, default=None, help="减速段 ms")
    sp.add_argument("--truth", type=float, default=None,
                    help="实测真值: 实验三=实际距离(mm), 实验六=实际角度(度)")
    sp.add_argument("--apply", action="store_true", help="把算出的修正系数写回设备")
    sp.add_argument("--hz", type=float, default=5.0)
    sp.add_argument("--no-log", dest="no_log", action="store_true", help="跳过 1kHz 日志回传")
    sp.add_argument("--log-timeout", type=float, default=300.0)
    sp.add_argument("--out", help="1kHz 日志导出 CSV")
    sp.add_argument("--json", action="store_true")
    sp.add_argument("--no-color", dest="no_color", action="store_true")

    sp = sub.add_parser("datalog", help="数据收集台(远程发车 + 时间同步 + 完整采集)")
    sp.add_argument("target", nargs="?", default=None, help="串口/TCP; 省略则自动选择")
    sp.add_argument("--baud", type=int, default=115200)
    sp.add_argument("--seconds", type=float, default=10.0, help="采集时长(秒)")
    sp.add_argument("--hz", type=float, default=5.0, help="实时流显示频率")
    sp.add_argument("--no-maze", dest="no_maze", action="store_true",
                    help="不远程发车跑迷宫, 只采集")
    sp.add_argument("--no-arm", dest="no_arm", action="store_true",
                    help="不发车(不点基准灯、数据不带 dev_ms)")
    sp.add_argument("--no-dump", dest="no_dump", action="store_true",
                    help="不做 1kHz 日志回传")
    sp.add_argument("--force", action="store_true", help="MAZE RUN 被拒时也继续")
    sp.add_argument("--arm-only", dest="arm_only", action="store_true")
    sp.add_argument("--maze-only", dest="maze_only", action="store_true")
    sp.add_argument("--status", action="store_true", help="只打印时间同步状态")
    sp.add_argument("--log-timeout", type=float, default=300.0)
    sp.add_argument("--out", help="1kHz 日志导出 CSV")
    sp.add_argument("--json", action="store_true")
    sp.add_argument("--no-color", dest="no_color", action="store_true")

    sp = sub.add_parser("estop", help="一键急停 / --resume 解锁")
    sp.add_argument("--target")
    sp.add_argument("--baud", type=int, default=115200)
    sp.add_argument("--resume", action="store_true", help="改为发 STOP(正常停车并解急停锁存)")

    sp = sub.add_parser("diagnose", help="诊断单个串口")
    sp.add_argument("port")
    sp.add_argument("--baud", type=int, default=115200)
    sp.add_argument("--seconds", type=float, default=2.0)
    sp.add_argument("--json", action="store_true")

    sp = sub.add_parser("scan-baud", help="扫描波特率")
    sp.add_argument("port")
    sp.add_argument("--bauds", type=int, nargs="*")
    sp.add_argument("--seconds", type=float, default=1.0)
    sp.add_argument("--json", action="store_true")

    sp = sub.add_parser("replay", help="回放历史会话")
    sp.add_argument("session")
    sp.add_argument("--analyze", action="store_true")
    sp.add_argument("--speed", type=float, default=1.0)
    sp.add_argument("--json", action="store_true")

    # ---- snap: 阻塞式全量测量快照 ----
    sp = sub.add_parser("snap", help="阻塞式测量快照(不必开遥测流)")
    sp.add_argument("--dom", default=None,
                    help="只取某个域: MOTION/ODOM/SENSE/POWER/TIME(省略=全部)")
    sp.add_argument("--poll", type=float, default=0.0, metavar="HZ",
                    help="按 HZ 连续轮询(纯主机侧定时器)")
    sp.add_argument("--seconds", type=float, default=0.0, help="配合 --poll: 持续秒数(0=一直)")
    sp.add_argument("--json", action="store_true")
    sp.add_argument("--target", default=None, help="串口 COM7 / tcp://host:port; 省略自动选择")

    return p


_DISPATCH = {
    "ports": cmd_ports,
    "monitor": cmd_monitor,
    "connect": cmd_connect,
    "get": cmd_get,
    "get-all": cmd_get_all,
    "snap": cmd_snap,
    "set": cmd_set,
    "calib": cmd_calib,
    "save": cmd_save,
    "scope": cmd_scope,
    "maze": cmd_maze,
    "motor-test": cmd_motor_test,
    "lesson": cmd_lesson,
    "datalog": cmd_datalog,
    "estop": cmd_estop,
    "diagnose": cmd_diagnose,
    "scan-baud": cmd_scan_baud,
    "replay": cmd_replay,
}


def main(argv=None) -> int:
    args = _build_parser().parse_args(argv)
    try:
        _DISPATCH[args.cmd](args)
    except SystemExit as e:
        # SystemExit 的 code 可能是字符串(raise SystemExit("原因"))或 None。
        # 字符串要打出来再返回非 0 —— 直接 int() 会抛 ValueError, 变成 traceback。
        if e.code is None:
            return 0
        if isinstance(e.code, str):
            print(e.code, file=sys.stderr)
            return 2
        return int(e.code)
    except KeyboardInterrupt:
        return 130
    return 0


if __name__ == "__main__":
    sys.exit(main())
