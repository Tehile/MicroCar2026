# RemoteControl 项目长期备忘（电脑鼠蓝牙上位机）

## 目录
- `code_stm32f1_mouse/` — STM32F103RB 固件（Keil MDK V5.06 / ARMCC V5 / C90 / -O0 / OneElfS=1）。
  `HARDWARE/link.c|h` 是新增蓝牙链路模块（遥测/命令/标定/参数持久化），不动原业务逻辑与红线数值。
- `host/` — Python 上位机（`host/host/` 包：api / registry.py / cli.py / monitor.py / replay.py / transport / protocol / model / sim / ui）。
- `docs/` 设计文档 + 自动生成的接口参考 + CHANGELOG；`release/` 归档。**项目不是 git 仓库**。

## 链路与协议
- USART1(PA9/PA10) ↔ 蓝牙透传 ↔ CH340 → PC(COM7)；不做配对，一切走串口；115200-8-N-1。
- 上行 `AA55|LEN(2,LE)|TYPE|SEQ|PAYLOAD|CRC16-MODBUS`（8B 开销）；下行 ASCII 行 `<CMD> [args] [#seq] *CRC16`。参数 Q16.16，MAZETYPE=7。
- 固件上电静默，须 `STREAM ON`；断开前先 `STREAM OFF`。
- 吞吐：常驻遥测预算 **152 B/s**（快24B@5Hz+中20B@1Hz+慢24B@0.5Hz，刻意压低）。
  突发实测 `SCOPE DUMP` 9.8KB 用 **7.1s ≈ 1.38 KB/s**；dump 恒发 20 块×490B，耗时与采集点数无关（按 `filled` 截断）。
  早期"超 152 B/s 即静默、需给模块重新上电"未复现（疑为上位机抽干太慢）；压测前仍按 152 B/s。
- ⚠️ **真机链路特征（2026-10-04 实测，COM7/CH340+蓝牙透传）**：
  - **稳态命令往返 ≈230 ms**（20 次 `SNAP` 问答 4.6 s）→ `TIMEOUT_S` 已由 0.20 改为 **0.50 s**（2.3× 余量）。
  - **连接后第一条命令**可能慢到 ~750 ms（模块唤醒）。
  - 链路上**偶发命令行位错** → 设备回 `ACK -1 ERR_CRC`（主机不匹配任何挂起项，幂等重发自愈）。
- ⚠️ **dump 期间的 ACK 不可依赖**（一启动 dump 就全速占用无线电链路，模块缓冲里 ACK 可能排在 dump 数据之后，实测可晚 ~1 s）：
  - `CommandSpec.no_retry` 字段（仅 **`scope.dump`** 置真）：不重发的命令**不在此层按 `TIMEOUT_S` 判死**，
    到期由**调用者的 timeout** 决定；`MouseClient._wait_pending()` 超时时调 `CommandClient.abandon()` 摘除挂起项
    （否则 Pending 永久残留在 `_pending`）。
  - 固件已把 `link_Ack("OK")` 提到 `link_StartDump()` **之前**（字节流已证实 ACK 在首个 dump 帧之前）——**已烧录**。
  - 上位机 `ScopeAPI.fetch()` 对 `TIMEOUT` 不再放弃、改等 `DUMP_DONE`（**收到数据与否只看 DUMP_DONE**）。
  - 修后真机：`sent 51 / retries 0 / timeouts 0`，残留挂起项 0。

## 固件五档（`USER/main.h`，五宏互斥，定义 ≥2 个 `#error`）
- **[1] `MOUSE_TEST_NO_MOTOR`** 安全测试：电机物理禁用（无 TIM4 PWM、LoopControl 恒 0、跳过 doTask*/LESSON_ISR）。派生 `MOUSE_TEST_MODE`。
- **[2] `MOUSE_TEST_MOTOR_LAB`** 电机远程：可控无自走，只认 `MOVE RUN/FWD/ROT` + 时间/红外/急停护栏。派生。
- **[3] `MOUSE_LESSON_LAB`** 课程调参：可控无自走 + `APP/lesson_lab.c` 剖面引擎，电机六增益变运行时变量。派生。
- **[4] `MOUSE_DATA_LOG`** 数据收集：可控**含自走**（远程发车 + 时间同步）。**不派生 `MOUSE_TEST_MODE`** —— 要编进 doTask*/LESSON_ISR。
- **[5] 全不定义** = 原比赛固件。⚠️ **当前 [5] 链接失败**（超程序区，见下）。
- `motor.c` 的 `#ifdef` 只看 NO_MOTOR → [2][3][4] 电机自然可控；[3] 用 `lessonGain.*`。
- 快帧 flags：bit0 FREEMODE、bit1 `SLEEP`(0x02)、bit2 EMERG、bit3 SCOPING、bit4 DUMPING、
  bit5 `MOTOR_OFF`(0x20，仅[1])、bit6 `ESTOP_LOCK`(0x40)、bit7 `RUNLOG`(0x80)。`SNAP MOTION` 回同一字节。
- `speedSt.freemode==1` = 电机输出强制 0（自由模式），不是"解锁"。
- 入口：[2] `python -m host.motor_test COM7`、[3] `python -m host.lesson COM7`、[4] `python -m host.datalog COM7`。

### 迷宫状态机回传（实验8 无记忆走迷宫，v1.5.5）
- **只读观测**：观测层全在 `HARDWARE/link.c`（新增模块），**不在 maze/state/lesson/motion 插钩子**；
  只读 `mazeState`(坐标/朝向/任务/岔路栈/终点区) + `wallSns`(前/左/右) + `motionCtrl.task`，
  观测点在 SysTick 1ms → 迷宫 `while(1)` 挡不住。
- **三通道**：① 事件行 `MAZE EV <EVENT> …`（**迁移驱动**：BEGIN/EXIT/TASK/ROAD/JUNC/TURN/GOAL/CELL）；
  ② `LINK_TYPE_MAZE(0x09)` 16B @**1Hz 且仅在迷宫态**（受 STREAM ON 约束，空闲零增量）；
  ③ `SNAP MAZE`（阻塞点查，**迷宫跑着也能问**，多给 `evDrop`/`cellCnt`）。
- **路口 8 类**（与 `lessonStr.roadStat` 同源输入）：THRU/CORNER_L/CORNER_R/TEE_FL/TEE_FR/TEE_LR/CROSS/DEAD。
  **只在 `task==SEARCH` 评估 + 连续 2×20ms 一致**（否则侧向开口会抖动）。
  终点判据 = **只读复制** `state.c` 的 `x∈{xGoal0,xGoal1} && y∈{yGoal0,yGoal1}`。
- 命令：`MAZE EV [mask|OFF|DEF|ALL]`（默认 31，CELL 默认关）、`MAZE RST`。
  事件前要求 TX 空闲 ≥64B，不足则**丢弃并计数**（`evDrop`）→ 状态帧置 `EVQ`（事件流不完整）。
- 上位机：`mc.maze` 的 `state/history/snap/events/watch/on_event/summary/explain/set_events/reset/monitor_view`；
  `Event.MAZE`；`monitor` 多一节迷宫面板；`cli maze` 8 个动作；`FRAMES` 8→9。
- **三坑（已做回归）**：① BEGIN 无限重发（借 `maze_flags` 高位记边沿, 而 reset 清 flags → 改独立字段）；
  ② 进入迷宫的 TASK 迁移被 reset 吞掉（reset 把 task_prev 设成当前值 → 进迷宫时显式退回 WAIT）；
  ③ **`ring.py` 的 `push_time` 末尾 `self._notify("time", rec)` 被挤进新函数** → TIME 帧不再通知
  （时间同步样本恒 0）、迷宫帧冒名通知成 "time"，**编译/import 都不报错**。
  已加静态断言：**每个帧 sink 只 notify 自己的 stream**。
- 模拟器保真度：上电 `mouse_task` 2 → **0 (WAIT)**，与固件一致（否则"进入迷宫态"边沿永不出现）。

### ⚠️ 档位门控必须用具名派生宏（血的教训，2026-10-04）
`main.h` 里有两个**具名派生宏**，含义完全不同，不要混：
- `MOUSE_TEST_MODE` = [1][2][3]（"不跑菜单/状态机/课程示例"）。
- `MOUSE_ESTOP_RECOVERABLE` = [1][2][3]**+[4]**（"`STOP` 能解急停 + 急停后不休眠"）。

**同一语义绝不要在各处重复裸 `#ifdef MOUSE_TEST_MODE`** —— 漏一处没有编译错误，
只在真机上表现为行为不一致。已发生的实例：`link.c` 的 STOP 解锁块、`isr.c` 的急停休眠块
当时是裸 `#ifdef MOUSE_TEST_MODE` → [4] 档**急停后锁死（只能断电）**且**进 sleepmode**；
后者跳过全部采样而 `LINK_Tick()` 在门外照发帧 → **链路活着、数据冻结**
（`upMs` 在涨而 `cpu/adcBatt/battMv` 逐字节不变），现场极难察觉。
`contract_test [S5]` 静态钉死了这件事（含"残留裸门控清点基线"）。

### Flash 分区（2026-10-04 **已调整**：[5] 比赛固件现已可编译）
**新布局**（改动仅 5 处地址常量/项目设置，**程序逻辑一行未动**）：
| 页 | 用途 |
|---|---|
| 0..100 | **程序区 101 KB**（uvprojx IROM1 `0x19400`） |
| 101 | `FLASH_ADDR_DATA_NUM` `0x08019400` |
| 102..114 | `FLASH_ADDR_DATA` `0x08019800` — **擦除范围正好 13 页**（`saveNum/100+1`，saveNum=1200） |
| 115 | `FLASH_ADDR_SYSCALIB` `0x0801CC00`（原 99） |
| 116 | `FLASH_ADDR_LESSONPARAM` `0x0801D000`（原 100） |
| 117 | 备用 |
| 118..127 | 迷宫墙/起终点/90°路径/`IRDATA`/常规路径/陀螺零偏 —— **地址未变，不需要重标定** |

- 关键洞察：运行数据区**预留 29 页却只用 13 页**（`FLASH_EraseRunData` 的擦除足迹），
  虚设的 16 页还给了程序区 → 程序区 88 → 101 KB，**[5] 余量 9312 B**。
- ⚠️ **顺带修掉的真实冲突**：标定页原先取 page 99/100，**正落在擦除范围 89..101 内** ——
  `FLASH_EraseRunData()` 被 `calibrate.c:71`/`menu.c:136`/`state.c:274` 三处调用，
  一次就能把生产标定与课程参数一起抹掉。现在 115/116 与擦除区不相交。
- **改 `saveNum` 或这些页地址后必须重新核对**是否落进擦除范围 —— `contract_test [S5]` 已有 4 条断言钉住
  （程序区上界 == `FLASH_ADDR_DATA_NUM`；擦除范围 13 页；两个标定页位于数据区/1KB 对齐/不越迷宫页/**不在擦除范围内**）。
- 各档 ROM（盘上实测）：[1] 30976 / [2] 31528 / [3] 36056 / [4] **79104** / [5] **94112**（余 9312）。
  ⚠️ 先前多处误写 [4]=77104，实为 79104（55740+21204+2160）；已更正。

### ROM 占用归因（2026-10-04 逐对象实测，方案见 `docs/比赛固件空间不足诊断与瘦身方案.md`）
用 `fromelf --text -z` **对每个 `.o` 逐个**测量（对 `.axf` 只给总汇总）。[5] 合计 94112 B：
- **`speedtable.o` = 20280 B（RO 20266 / Code 仅 14）** ← **全工程最大单一 ROM 消耗，占程序区 22.5%（当时 88 KB / 现 101 KB）**。
  `MOTION/speedtable.c` 43 张 `const short` 查表（10 个族，10133 点）。**没有死表**（`LOW_ENABLE` 在 `motion.h:14` 已定义）。
  - 值域：**32 张可 int8 / 6 张可 uint8 / 仅 5 张需 16 位**（值域跨 ±180 的 gyro 表）→ **收窄到 1 字节可省 8488 B**。
  - **仿射冗余 16 张可导出**（逐值精确成立）：`gyroR* = −gyroL*`（12 张）、`vinner* = −vouter* + c`（4 张，c=150/120/140/140）
    → 去冗余可省 7654 B；两步叠加省 13302 B。这 16 张**只被 `speedtable.h` + `motion.c` 引用**（约 20 处）。
- **`link.o` = 14298 B**（Code 14266）；`link_ExecCmd` 单函数 2704 B，`link_SnapLine` 1080，`link_CalibService` 1232。
- 其余：isr.o 9036 / state.o 6710 / motion.o 5538 / spurt.o 4890 / calibrate.o 4688 / lesson.o 3323 / path.o 3118 / irs.o 2508。
- **C 库 printf/浮点全家桶只有 ≈1.9 KB**（不值得动）。
- RAM 侧与 ROM 无关：[5] RW+ZI = 17617 / 20480，**余 2863 B**；`flash.o` ZI 9600（`run_data[1200]`）、`irs.o` RW 2016（4×250 u16）、`link.o` 1422、`maze.o` 1344。

### ⚠️ `sizeof` 陷阱（改查表类型前必读）
`motion.c` 的 `TurnParam_t.length = sizeof(表)`，而使用处是 `while(tick < length/2 - 2)` —— **把字节数当元素数、把元素宽度 2 字节写死在分母**。
查表元素一旦收窄到 1 字节，`length/2` 减半 → 转弯只走一半的表（"能动但不对"的可怕故障）。
修法：`length` 改"点数"语义（`sizeof(t)/sizeof(t[0])`、`tick < length-2`）。
表的类型声明分布 3 处，必须同步：`speedtable.h`（43 extern）、`motion.c`（`TurnParam_t`）、`core.h`（`TurnTable`，被 `isr.c` 9 处 `*(turnTbl.xx + tick)` 解引用）。
**"表内容不变"只能靠逐值比对脚本保证，编译通过证明不了。**

## 参数（共 38 个；Q16.16，上行 `P <id> <q>`）
- **生产标定 1–7**：TRACKL TRACKR SPEEDL SPEEDR GYRORATIO ENCANGLE WALLDIST（任何固件都有；Flash page99）。
- **课程调参 8–21**：KPL…WALLMODE（仅 [3]，独立 Flash page100）。
- **红外测量与电源 22–38（v1.5.0 新增，生产命名空间、page99）**：
  IRTHRWALL/IRTHR45/IRTHRCRIT/IRTHRFLO/IRTHRFMID/IRTHRFHI/IRTHRFNEAR（原 `core.h` 阈值宏 →
  运行时 `irCfg`，**默认值=原宏值，行为零回归**）、IRKALQ/IRKALP（×1e-4，默认 100/2000）、
  IRKALSW、IRFRONTMODE（0均值/1取小/2加权）；
  BATTKV（**分压标定** µV/LSB，默认 2417）、BATTLOWMV=7000、BATTHIGHMV=**7960**（取 7960 才使
  step=120mV 与旧式 `(volt-700)/12` 逐位一致）、BATTALPHA=100(×1e-3)、BATTMAXPCT=8、BATTMINPCT=1。
  **`LINK_P_NUM` = 24**（1–7 + 22–38）；课程段不参与 `GET ALL`。
- ⚠️ **`IRTHRWALL` 的唯一真源是 `wallSns.wallThresh`**（u8）：`APP/state.c:225` 在比赛流程把它改成 140
  属**红线**，不能被参数架空。其余阈值宏保留作 `CORE_Init()` 的默认值来源、运行时读 `irCfg.*`。
- `SPEEDL/R ≡ TRACKL/R ÷ 100`（派生关系，不要独立标定）。写 `mc.params.set()`，持久化 `save()`。
- ⚠️ **固件读侧只有生产表**：`GET ALL` 只遍历 `LINK_P_NUM`(=24)，`GET <name>` 只查 `link_ParamFind` →
  课程 14 项**读不回来**（回 `ERR_NAME`）；写侧 `link_ParamSet` 有课程分支、能写。
  模拟器却回全部 38 项 → 测试全绿掩盖了这一点。**待修**。上位机 `get_all()` 已改等
  `PRODUCTION_PARAM_IDS`（24 项）否则白等超时。

## 测量回传（v1.5.0 已实施：`SNAP` 阻塞快照 + `SCOPE` 录制剖面）
- **`SNAP [MOTION|ODOM|SENSE|POWER|TIME|ALL]`**（`link.c`）：**一问一答**回全部可测量量，
  5 行文本，**字段名与 `decode_fast/mid/slow` 的字典键同名**（monitor/analyze 零分叉）。
  MOTION/ODOM/SENSE 覆盖**既有全部量**，SENSE/POWER 追加新量（4 路原始 ADC、饱和掩码、
  电池 ADC/mV/档位/低电、CPU/丢包/过流）。**不依赖 `STREAM ON`** → 静默链路也能问，
  **零常驻带宽**（实测遥测仍 172 B/s）。上位机 `mc.snap`。
- **`LINK_TX_BUF_SIZE` 256 → 512** + 空间门 `link_TxSpace() < 320 → ERR_BUSY`：
  `link_TxStr` 走 `link_TxPut` **不做空间检查**，dump 期间写 250B 快照会回绕覆盖未发数据。
- **`SCOPE START [A–E]` 录制剖面**（零新增 RAM，同一块 9600B `run_data[]` 换内容）：
  A 运动学(默认) / B 1kHz 四路红外 mm / C 1kHz 四路原始 ADC / D 电压 / E 混合。
  `DUMP_HDR.channels` 兼作剖面标识：**A 仍报 4**（旧解析零改动），B..E 报 ASCII。非 A 剖面把
  8B 点当 **4×u16** 写。上位机 `mc.scope.start/fetch_data/last_data`；A 的 `fetch()` 一字未改。
- **饱和标志**是关键新信息：查表在两端被夹紧（贴脸→0mm、超量程→249mm），单看 mm 无法区分。
  判据与 `IR_FindDis` 同源，由 `link_IrSat()` 现算 → **`irs.c` 一行未改**
  （`irCalib.rawf1/f2/l/r` 本来就存着卡尔曼后的 ADC）。
- 电源：`safety.c` 参数化（mV 域整数 IIR，新增 `battMon.adc/mv/low`）；**比赛固件也开
  `battMon.enabled=1`**（原来恒 0 → 显示 0.00V 是"没采"不是"没电"）。
- 分析：`analyze.ir_saturation_stats / ir_range_curve / batt_low_events / batt_discharge`。
- 未做：急停三阈值参数化（会动 `motor.c` 红线路径）、1kHz 全通道并行（20KB RAM 装不下）、
  `irDist.l45/r45` 等 12 个**死字段**（只移位不计算，如实标注不虚构）。

## 红外 / 电源测量回传（v1.5.0 已实施；设计见 `docs/红外与电源测量回传设计方案.md`）
- 实施前的状态（作为背景保留）：电压在快帧(1B@0.1V)/慢帧(s16@0.01V)里但**比赛固件恒 0**；
  红外 4 路 mm 在慢帧里但**只有 0.5Hz**、无原始 ADC/饱和；阈值与分压系数全写死。
- 现已按上述"测量回传"一节实施，九套件全绿 **553 项**（原 396），`API_VERSION` **1.5.0**。
- ⚠️ **Flash 扩容陷阱（结论：用户已决定不修）**：`link_CalibLoad` 校验 `cnt != LINK_P_NUM` 就判无效
  （`link.c:754`）→ 参数表一扩容，旧 page99 立刻作废、**TRACKL/TRACKR 等标定回落源码默认值**。
  **用户明确接受"用默认参数就行、不做升级兼容"**（2026-10-04）→ `link_CalibSave/Load` 一行不改、
  不 bump `LINK_CALIB_VER`；只是刷固件后要重标。**现场表现是"读到默认值"，别误判成"写不进去"。**
- 真机全部未验证（V1–V11 仅对模拟器跑过）。
- ⚠️ TRACKL/TRACKR/GYRORATIO 属生产命名空间 → **不能**用 `mc.lesson.set_params()`（ERR_NAME），须 `mc.params.set()`；终端 `--apply` 已自动分流。

## [2] 电机远程实验
- ⚠️ **运动互斥（v1.5.2 修复的既有缺陷）**：`MOVE FWD/ROT/RUN` 启动时都会把
  `motionCtrl.task` 置 `MOTION_TASK_NULL`（它们由 `link_MoveService()` 驱动、**不走任务状态机**），
  所以**只看 `motionCtrl.task` 是查不出"正在跑 MOVE"的**。原来 `SAVE`/`MOVE RUN`/`MOVE FWD`/`MOVE ROT`
  四处 busy 检查都漏了 `linkMove.state` → 第二条 MOVE 会覆盖 `linkMove.elapsed/limit`，
  **把时间护栏重置**（连发即可无限延长运行；实测首条 1500ms + 0.48s 处再发一条 → 实跑到 ~1.98s）。
  现统一走 `link_MotionBusy()`（task + linkMove.state + linkSrv.state + linkCal.active）。
  **模拟器当时也没查 → 固件与模拟器一起错，测试全绿却盖不住**；现已同步 `_motion_busy()` 并加
  `contract_test [D3] 幂等` / `[D4] 运动互斥` 两条回归（`[D1]` 顺序表也加了"每条运动命令前先 stop"）。
- `MOVE RUN <spL> <spR> [ms] [ir_mm]`：时间护栏默认 2000ms/上限 60000；红外默认 10mm（**负值=关**）；±300 上限、左右不同时 0。
  拒绝码 `ERR_ESTOP`/`ERR_BUSY`/`ERR_VALUE`。护栏在固件 1ms `link_MoveService()`，上位机掉线也照停。
- 完成回 `MOVEDONE RUN <REASON> <ms> <ir_min> <chan> <dL> <dR> <vpkL> <vpkR>`（REASON=TIME/IR/ESTOP/STOP/USER）。
- `ESTOP` 锁存，**只有 `STOP` 能解锁**（[1]–[4] 档；比赛固件[5]刻意锁死到断电），触发上行 `ESTOP TRIP`；
  按键急停也调 `LINK_EStopTrip()`（幂等）。
- 双流：运动时只发实时流；固件本地 1kHz 写 `run_data[]`（零带宽），停止后冻结 + 置 RUNLOG → `SCOPE DUMP` 整块回传。
- 红外只在 0.5Hz 慢帧 → 短于 ~2s 的动作实时流里红外可能是 `—`；全程最小值随 MOVEDONE 给。
- 上位机 `mc.lab` = `MotorLabAPI`；文档 `docs/电机远程控制与双流传输.md`。

## [3] 课程调参实验（三~八）
- `LESSON START <exp> [a][b][c][d] | STOP | STATUS`；上行 `LESSON DONE <exp> <REASON> <ms> <dL> <dR> <vpkL> <vpkR> <angle>`。
  REASON=DONE/TIME/DIST/ANGLE/IR/ESTOP/STOP；拒绝码 `ERR_ESTOP`/`ERR_BUSY`/`ERR_VALUE`/`ERR_EXP`；与 `MOVE` 互斥。
  `a b c d` 随 exp 变：exp2/6=`v dist ms`，exp3=`v t_acc t_cruise t_dec`，exp5=`angle v ms`；exp4/7 → `ERR_EXP`。
- 每个实验自带时间护栏（`LESSONLAB_Tick` 末尾统一判），由 `LINK_Tick()` 推进，上位机失联也停。
- `mc.lesson` = `LessonAPI`（params/param_meta/set_params/read_param/status/start/stop/run/fetch_log/explain → `LessonResult`）；
  终端 `python -m host.lesson COM7 <exp> …`。纯函数：`theory_track_ratio`=62.2267、`theory_gyro_ratio`=415.8061、
  `solve_ratio`（新=旧×固件读数/真值）、`step_metrics`、`straightness_metrics`、`ir_error_stats`；`--truth … --apply` 闭环。
- 文档 `docs/课程调参实验与参数设定.md`。

## [4] 数据收集与时间同步
- **决定性结构事实**：`LINK_Tick()` 在 SysTick 1ms 里**同时消费命令与组帧** → 命令/遥测完全中断驱动、与主循环无关
  → 可直接搭在阻塞式迷宫 `while(1)` 上，不需要重构迷宫。
- 时基 `linkTimeMs`(u32) 不绕（49 天）；`ARM` → 记 `armMs` + 点亮 1Hz 基准灯 + 回 `ARMED <ms>`；
  `MAZE RUN` 只置请求位，由 `main()` 等待循环进迷宫（**仅 [4] 实现**，其余回 `ERR_VALUE`）。
- 新帧 `LINK_TYPE_TIME`(0x08)@1Hz：`upMs`(u32)+`armMs`(u32)+led+flags，与基准灯**同拍**。
  快帧保留字节 `f[15]` = 时基低 8 位（帧长不变）；`DUMP_HDR` 8→12B 加 `startMs`。
- `ledBeaconLock`：发车后状态灯 `LED_On/Off` 直接 return，基准灯独占 LED4(PC7)；其余模式恒 0。
- 上位机：`host/host/clock.py`（单调时钟，链路时间差一律用它）；`mc.timesync`（arm/maze_run/wait_sync/offset_s/
  drift_ppm/frame_time_up/frame_time/dev_ms/frame_age_ms/snapshot/explain）；纯函数 `min_delay_offset`（**取 min**）、
  `fit_clock`/`drift_ppm`、`resolve_ms8`（预测误差须 <128ms）。
- 丢帧检测：`step=(seq-prev)&0xFF; step>=2 → seq_lost+=step-1`（256 回绕不误报）→ `stats()` 有 `seq_gap`/`seq_lost`。
- 落盘：`stream_*.csv` 加 `dev_ms`/`seq`；dump 的 `t_ms` 语义已改为绝对设备时刻（`t = startMs + i`）。
- COMMANDS 28 / FRAMES 8；文档 `docs/数据收集与时间同步.md`。

## 标定能力边界
- 5 项 `CAL <item> {START,SAMPLE,ABORT}`：GYRO / WALLDIST / IRDATA / GYRORATIO / ENCANGLE。
- 安全模式只能做静态 3 项：`GYRO`(车静止，Flash **page127**)、`WALLDIST`(左侧贴墙，仅 RAM，`SAVE`→page99)、
  `IRDATA`(4 摆位逐点，第 4 点后写 **page123**)。逐点走 `link_IrRebuild()`，**不擦除迷宫**。
- 需电机的 2 项（GYRORATIO/ENCANGLE、里程系数）安全模式做不了 → **首选切 [2] 重编译**，或 [3] 用课程剖面；只有真要比赛自走才切 [4]。
- 上位机护栏：`mc.motor_disabled` / `mc.motor_guard()`；高层方法（`move.forward/rotate`、`calib.angle/servo/track`）
  在 [1] 下立即返回 `MOTOR_DISABLED`（不空等 90s）；底层 `send_cmd`/`calib.step` 不受限；常量 `CalibAPI.STATIC_ITEMS`/`MOTION_ITEMS`。
- `flashSt.flashenable=0` 只挡业务侧写 Flash，不影响 `SAVE`。

## 构建 / 测试 / 环境
- 编译：`"/c/Keil_v5/UV4/UV4.exe" -b "<工程绝对路径>\USER\Mouse.uvprojx" -o "<日志绝对路径>"`（必须绝对路径；exit=1 可能只是告警）。
- 符号核查：`/c/Keil_v5/ARM/ARMCC/bin/fromelf.exe --text -s USER/Object/Mouse.axf`。
- J-Link V976a；CommanderScript 用 `savebin`/`loadfile` 时**路径不能含空格**（先拷到 `C:\jltmp`）；
  连接会**暂停内核**，探测完必须 `go`，否则表现为"串口无应答"。
- 九套件（在 `host/` 跑）：selftest --e2e 59 / contract **239** / **maze 58** / snap 117 /
  motor_lab 44 / lesson 38 / timesync 46 / facade 38 / monitor 28 = **667 全绿**（v1.5.5）。
  `contract_test [S5]` 现含 5 类静态断言：档位门控 / Flash 页布局 / **注释提前闭合扫描** /
  **帧 sink 只 notify 自己的 stream**；`[D3]/[D4]/[D5]` 是运动幂等/互斥/急停可恢复。
  `contract_test` 的 `[S5]` 是**静态查固件源码**的断言（档位门控 + Flash 页布局不变量）；
  `[D3]/[D4]/[D5]` 是运动幂等/互斥/急停可恢复。
  `monitor_smoke` 在批次连跑时偶发 1 项假失败（断言实时渲染文本），单独跑稳定 28/0。
- `contract_test` 的 D2 遍历全部 `PARAM_IDS` → 加参数必须同步模拟器，否则报红；S4 基线计数同步改。
  D1 的顺序表要求**每条登记命令都被跑到**（新增命令必须手工加进去，否则报"未覆盖"）。
- `gen_api_reference.py` 的子 API 清单（`subapis` + `_class_of`）、Event 说明、命令示例参数
  （含 `_EXAMPLE_ARGS` 同名表在 `contract_test.py`）**都是硬编码**，新子 API / 新命令参数要手工登记才进文档。
- Python 用 `C:/ProgramData/anaconda3/python.exe`（有 numpy + pyserial）；托管 venv 里没有；PySide6 未装 → `uismoke.py` 跑不了。
- `link_CalibService` 由 `LINK_Tick()` 无条件推进；`GYRO_Sample/ODOM_Sample/doWallDetect` 在 `NO_MOTOR` 的 `#ifdef` 之外 → 安全模式下采集与标定照常。

## 归档（`release/`，v1.5.5）
- 非 git 仓库 → 走"显式白名单 + 排除规则"的 `make_archive.py`（不是 `git archive`）；zip 逐文件原样写入、无行尾转换，
  实测 **182/182 与工作区逐字节一致**，故 `SHA256SUMS.txt` 以工作区为基准对两者都成立。
- 当前产物：`RemoteControl-v1.5.5-20261004.zip`（**182 文件 / 解压 3.03 MB / 压缩 1.34 MB**）+ `归档说明.md` +
  `make_archive.py` + `verify_archive.py` + `SHA256SUMS.txt`（**不在 zip 内**）。`verify_archive.py` 的 `MUST_HAVE` = 39 条。
- 刻意不入档：`code_stm32f1_mouse - 副本/`（上游原始副本 25 MB，含它自己的 `.git`）、`host/sessions/`、`__pycache__`、
  `USER/Object/*`（除 `Mouse.hex`）、`*.log`/`*.uvguix.*`/`JLinkLog.txt`/`*.lst`。
- **顺序固定**：先跑绿并重编 → 接口一致性审计 → 修正过期文档（**历史 CHANGELOG 不动**）→ 写说明 →
  **写记忆** → 打包 → 抽查 + 逐字节比对 → 台账 + `sha256sum -c` 零告警。
  ⚠️ **记忆文件本身在归档清单里 ⇒ 必须先写记忆再打包**（否则 zip 内记忆是旧的、要重打 —— v1.4.0 踩过）。
  ⚠️ 打包前查 `Mouse.hex` 是哪一档（最后一次编译可能是 [5]）→ 要 [4] 就必须重编一次。
- 接口审计要点：子 API 是 `__init__` 的实例属性，`inspect.getmembers(类)` 查不到，须先实例化 `MouseClient`
  （当前 **14 子 API / 173 公开方法 / 31 命令 / 9 帧 / 38 参数**）。
  `registry.API_VERSION` 必须与 CHANGELOG 最新版一致 —— 每次加接口都容易漏（v1.5.5 归档时就停在 1.5.0）。

## 用户偏好
- 追求一步到位、直接产出可用成果；**不需要**固件版本匹配/向后兼容的额外机制。
- 实时只传关键参数；重数据（1kHz dump、墙图）等**停车后**整块回传。
