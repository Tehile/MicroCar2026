# 项目长期备忘（RemoteControl / 电脑鼠蓝牙上位机）

## 目录与职责
- `code_stm32f1_mouse/` — STM32F103RB 固件（Keil MDK V5.06 / ARMCC V5 / C90 / -O0 / OneElfS=1）。
  `HARDWARE/link.c|h` 是纯新增的蓝牙链路模块（遥测/命令/标定/参数持久化），不改动原有业务逻辑与红线数值。
- `host/` — Python 上位机。`host/host/` 为包：`api/`(门面 MouseClient + 子 API)、`registry.py`(命令/帧单一登记表)、
  `cli.py`、`monitor.py`、`replay.py`、`transport/`、`protocol/`、`model/`、`sim/`、`ui/`。
- `docs/` — 设计方案、接口参考（自动生成）、安全测试模式说明、CHANGELOG。

## 硬件链路（关键约束）
- STM32 USART1 (PA9/PA10) ↔ 蓝牙透传模块 ↔ 无线 ↔ CH340 → PC 串口（COM7）。**不做蓝牙配对，一切走串口**。
- **吞吐模型（真机修订 2026-09-27）**：USART1 固定 115200-8-N-1 → MCU 侧理论上限 11520 B/s。
  常驻遥测按 **152 B/s** 预算（快 24B@5Hz + 中 20B@1Hz + 慢 24B@0.5Hz），这是**刻意压低**的防悬崖策略。
  **突发**实测：一次 `SCOPE DUMP`（20 块 × 490B ≈ 9.8KB）**7.1s 传完 ≈ 1.38 KB/s**（两次重复一致，约理论上限的 12%）。
  ⚠️ 早期"超 152 B/s 会灌满模块缓冲、彻底静默（0 字节 = 没有数据在流，需模块重新上电）"**待重新验证**：
  改成独立读线程持续抽干串口后，真机连传 ~20KB 未出现静默 —— 更可能是**上位机抽干不够快**（轮询式读取），
  而非链路硬顶。做持续压测（风险：真灌满需手动给模块上电）之前，常驻预算仍按 152 B/s。
- 固件**上电默认静默**，必须由主机发 `STREAM ON` 才开始上行；断开前先 `STREAM OFF`。
- 协议：上行二进制帧 `AA 55 | LEN(2,LE) | TYPE | SEQ | PAYLOAD | CRC16-MODBUS`（开销 8B）；
  下行 ASCII 行 `<CMD> [args] [#seq] *CRC16`。参数为 Q16.16。迷宫 MAZETYPE=7。

## 测试模式（`code_stm32f1_mouse/USER/main.h`，**五档互斥**）
- **[1] `MOUSE_TEST_NO_MOTOR`** = 安全测试模式，电机**物理禁用**（PB6-9 普通推挽低电平、不配 TIM4 PWM、
  `MOTOR_LoopControl` 恒 0、SysTick 跳过 doTask*/LESSON_ISR、main 跳过菜单与 STATE_MainLoop）。
- **[2] `MOUSE_TEST_MOTOR_LAB`** = 电机远程控制实验，电机**可控**（走正常 PWM 闭环）但**无自走策略**，
  驱动它的只有显式命令 `MOVE RUN/FWD/ROT`，带时间/红外/急停三重护栏。
- **[3] `MOUSE_LESSON_LAB`** = 课程调参实验（实验三~八），电机**可控**、无自走策略，
  **多一层"按课件剖面自动跑"的引擎**（`APP/lesson_lab.c`），且电机六增益变运行时变量。
- **[4] `MOUSE_DATA_LOG`** = 数据收集档，电机**可控**且**含自走策略**（无记忆走迷宫 + 运动控制），
  **远程发车**（`ARM` + `MAZE RUN`）+ **时间同步**。见 `docs/数据收集与时间同步.md`。
- **[5] 全都不定义** = 原比赛固件（自走 / 按键菜单 / 课程实验）。
- **四宏互斥**，同时定义两个以上会 `#error`。
- **[1][2][3] 派生 `MOUSE_TEST_MODE`；[4] 不派生** —— 这是关键差别：前三档在"关掉自己跑起来的口子"，
  [4] 恰恰要打开（`doTask*` / `LESSON_ISR` 都要编进去）。
- `motor.c` 的 `#ifdef` **只看 NO_MOTOR** → [2]/[3]/[4] 下电机自然可控；[3] 下 `MOTOR_LoopControl` 改用 `lessonGain.*`。
- **[2] 电机实验激活**（`python -m host.motor_test COM7`）；**[3] 课程调参激活**（`python -m host.lesson COM7`）；
  **[4] 数据收集激活**（`python -m host.datalog COM7`）。
- 快帧 flags bit5 = `LINK_FLAG_MOTOR_OFF`（0x20，**只有 [1] 置位**），上位机据此显示"电机已禁用(安全模式)"
  并在 [1] 下拦截高层运动方法。
- `speedSt.freemode==1` 的语义是**电机输出强制为 0**（自由模式），不是"解锁"——文案已统一。

## 电机远程控制实验（模式 [2]，轮子悬空）
- 命令 **`MOVE RUN <spL> <spR> [ms] [ir_mm]`**：双护栏 = 时间（默认 2000ms/上限 60000）+ 红外（默认 10mm=1cm，
  **负值=关闭**）。±300 速度上限、左右不能同时 0；拒绝码 `ERR_ESTOP`/`ERR_BUSY`/`ERR_VALUE`。
- **护栏全在固件 1ms 逻辑里**（`link_MoveService()`），上位机挂了/掉线也照停 —— 这是"可靠"的落点。
- 完成回 **`MOVEDONE RUN <REASON> <ms> <ir_min> <chan> <dL> <dR> <vpkL> <vpkR>`**（REASON= TIME/IR/ESTOP/STOP/USER；
  `vpk` = 实测速度峰值，是"电机真响应了"的证据）。
- **`ESTOP` 锁存**：随时可用、无前置条件；锁存后一切 MOVE/CAL 返回 `ERR_ESTOP`，**只有 `STOP` 能解锁**；
  触发即上行 `ESTOP TRIP`。isr.c 按键急停也调 `LINK_EStopTrip()`（幂等）。
- 快帧 flags：bit6 `LINK_FLAG_ESTOP_LOCK`(0x40)、bit7 `LINK_FLAG_RUNLOG`(0x80)。
- **双流（分时）**：运动时只跑实时流（≈152 B/s，看"有没有在动"）；固件同时在本地 1kHz 写 `run_data[]`（**零带宽**）；
  停止时冻结环 + 置 `RUNLOG` 位 → 之后整块 `SCOPE DUMP`（**固定 20 块 × 490B ≈ 9.8KB，真机 ~7.1s ≈1.38KB/s**）看"动得怎么样"。
  **dump 耗时与采集点数无关**（`link_DumpService()` 恒发满 20 块，上位机按 `filled` 截断）→ 0.6s 与 2s 的动作回传耗时都是 ~7.1s。
  日志点数 ≈ 时长×1000（环深 1200=1.2s，短动作按 `filled` 截断，**不是固定 1200**）。
- 上位机：`mc.lab`（`MotorLabAPI`）`status()/run()/estop()/resume()/fetch_log()/explain()` → `RunResult`；
  `mc.estop_locked`/`mc.log_ready`；终端 `python -m host.motor_test COM7 …`。
- 文档：`docs/电机远程控制与双流传输.md`（设计出处：`docs/蓝牙上位机设计方案.md` §5.5 + 附录 F）。
- **注意**：红外只在 0.5Hz 慢帧上 → 短于 ~2s 的动作，实时流里红外可能显示 `—`；全程最小红外由固件 1kHz 统计随 MOVEDONE 给出。

## 课程调参实验（模式 [3]，实验三~八）
- 设计原则：**实验代码与最终版代码分开** —— `APP/lesson_lab.c|h` 整层在 `#ifdef MOUSE_LESSON_LAB` 内，
  生产固件零占用；课程参数单独 Flash **page100**（生产标定是 page99）；命名空间 id **8–21**（生产 1–7）。
- 课程参数 14 项：`KPL/KIL/KDL/KPR/KIR/KDR`（PID，默认值 = `motor.h` 红线常量，**数值未改**）、
  `IRPL/IRPR/GYROP/GYROD`、`SPEEDNEED/ALLDIS`、`SENSORMODE`（**派生量**：写它同改 `lessonStr.irSwitch/gyroSwitch`）、`WALLMODE`。
- **`LESSON` 命令组**：`START <exp> [a][b][c][d]` / `STOP` / `STATUS`。拒绝码 `ERR_ESTOP`/`ERR_BUSY`/`ERR_VALUE`/`ERR_EXP`。
  **`LESSON` 与 `MOVE` 互斥**（都写速度目标）。`a b c d` **含义随 exp 变**：
  exp2=`v dist ms`；exp3=`v t_acc t_cruise t_dec`（t_acc/t_dec 不得 0）；exp5=`angle v ms`（**vCruise 取 b**）；
  exp6=`v dist ms`；exp4(红外)/exp7(转向)→`ERR_EXP`（红外走既有 `CAL IRDATA` 四步）。
- **`LESSON DONE <exp> <REASON> <ms> <dL> <dR> <vpkL> <vpkR> <angle>`**（全整数）。
  REASON：`DONE/TIME/DIST/ANGLE/IR/ESTOP/STOP`。**每个实验都自带时间护栏**（`LESSONLAB_Tick` 最后统一判）。
- 剖面引擎 `LESSONLAB_Tick()` 由 `LINK_Tick()`（SysTick 内）推进；上位机失联也照停。
- 上位机：`mc.lesson`（`LessonAPI`）`params/param_meta/set_params/read_param/status/start/stop/run/fetch_log/explain`
  → `LessonResult`；终端 `python -m host.lesson COM7 <exp> …`（= `host.cli lesson`）。
  自动算参纯函数在 `api/lesson.py`：`theory_track_ratio`=62.2267、`theory_gyro_ratio`=415.8061、
  **`solve_ratio`（实验三/六共用：新 = 旧 × 固件读数 / 真值）**、`step_metrics`（σ%/ts/tp，稳态取末 30%）、
  `straightness_metrics`、`ir_error_stats`。`--truth <实测值> [--apply]` 完成"回传→算参→写回"闭环。
- **⚠ 命名空间边界**：`TRACKL/TRACKR/GYRORATIO` 是**生产参数**，不在 `LESSON_PARAM_NAMES` 内 →
  **不能用 `mc.lesson.set_params()`**（回 `ERR_NAME`），必须 `mc.params.set()`。终端 `--apply` 已自动分流。
- 文档：`docs/课程调参实验与参数设定.md`。构建 ROM 30048 B（0 错 0 警）；`LESSONLAB_*` 存在、自走符号全为 0。

## 数据收集与时间同步（模式 [4] `MOUSE_DATA_LOG`）
- **最重要的结构事实**：`LINK_Tick()` 跑在 SysTick 1ms 中断里，**同时负责消费接收命令与遥测组帧**
  → **命令与遥测完全由中断驱动，与主循环无关**。所以主循环卡在 `LESSON_Blind8()` 的 `while(1)` 里
  跑迷宫时，遥测照发、命令照收 —— **数据收集直接搭在阻塞式自走上，不需要重构迷宫**。
- 时间同步**不依赖任何档**（`link.c` 无条件编译，生产固件也能用；不发 `ARM` 则零影响）：
  - `linkTimeMs`(u32) 毫秒时基（`LINK_Tick` 开头 ++，49 天不绕）；
  - `ARM` → 记 `armMs` + 点亮 1Hz 基准灯 + 回 `ARMED <ms>`；
  - `MAZE RUN` → 只置请求位，`main()` 等待循环据此进迷宫（**仅 [4] 档实现，其余回 `ERR_VALUE`**）；
  - 新帧 **`LINK_TYPE_TIME`(0x08) @1Hz**：12B = `upMs`(u32)+`armMs`(u32)+`led`+`flags`+rsvd，
    与基准灯**同拍**（`linkTimeMs % 1000 == 0`）；
  - **快帧保留字节 `f[15]` = 时基低 8 位** → 每个快帧可定位到 256ms 窗口，**帧长不变**；
  - **`DUMP_HDR` 8→12B** 加 `startMs`(u32) = 回传数组最早一点的绝对设备 ms。
- **`ledBeaconLock`**（`led.c|h`）：发车后 `LED_On/LED_Off` 直接 return，基准灯**独占 LED4(PC7)** ——
  方波被状态灯搅浑则时间同步作废。其余模式恒 0。
- 上位机：新 `host/host/clock.py`（`now_monotonic`/`now_wall_ms`，**数据链路的时间差一律用单调时钟**）；
  `mc.timesync`（`arm/maze_run/wait_sync/offset_s/drift_ppm/frame_time_up/frame_time/dev_ms/
  frame_age_ms/snapshot/explain`）；纯函数 `min_delay_offset`（**取 min 不取平均**）、
  `fit_clock`/`drift_ppm`、`resolve_ms8`（要求预测误差 <128ms）；终端 `python -m host.datalog`。
- **丢帧检测**：帧头 SEQ 原来解析后即丢弃 → 现在 `step=(seq-prev)&0xFF; if step>=2: seq_lost+=step-1`
  （256 回绕不误报）→ `stats()` 有 `seq_gap`/`seq_lost`。
- **落盘**：`stream_*.csv` 加 `dev_ms`/`seq` 两列；**dump 的 `t_ms` 语义已变为绝对设备时刻**
  （`t = startMs + i`，原来从 0 起 —— 这是行为变更）。
- 构建 ROM 73624 B（自走策略编入）；`COMMANDS` 28 / `FRAMES` 8（新增 `arm`/`maze.run`/`TIME`）。
- 文档：`docs/数据收集与时间同步.md`。

## 归档（`release/`，v1.4.0）
- **本项目不是 git 仓库** → 归档走"**显式白名单 + 排除规则**"的 `release/make_archive.py`，
  不是 `git archive <tag>`。zip 由 `zipfile.write` 逐文件原样写入，**无行尾转换**，
  与工作区**逐字节一致**（已实测）—— 所以 `SHA256SUMS.txt` 以工作区为基准对两者都成立。
- 产物：`RemoteControl-v1.4.0-20260927.zip`（175 文件 / 解压 2.66 MB / 压缩 1.19 MB）、
  `归档说明.md`（六节）、`make_archive.py`、`verify_archive.py`、`SHA256SUMS.txt`（18 条，**不在 zip 内**）。
- **刻意不入档**：`code_stm32f1_mouse - 副本/`（**上游原始副本，25 MB，含它自己的 `.git`**）、
  `host/sessions/`（运行现场）、`__pycache__`、`USER/Object/*`（除 `Mouse.hex`）、`*.log`/`*.uvguix.*`/`JLinkLog.txt`/`*.lst`。
- 归档四步：**先跑绿并重编 → 接口一致性审计 → 修正过期文档 → 写说明 → 打包 → 抽查 → 台账 + `sha256sum -c` 零告警 → 写记忆**。
  **说明必须在打包之前写**（否则包里没说明）。
- 最强验证：把 zip 解压到**干净目录**再跑测试（证明归档自足，不依赖工作区）。
- **接口一致性审计要点**：子 API 是 `__init__` 的**实例属性**，`inspect.getmembers(类)` 查不到，
  必须先实例化 `MouseClient` 再枚举。当前 13 子 API / 28 命令 / 8 帧 / 21 参数 / 17 CLI 子命令。
- 若日后要 tag 式归档：先 `git init`，把 `- 副本/`、`host/sessions/`、`__pycache__` 写进 `.gitignore`。

## 标定能力边界（安全模式下）
- 固件标定项 5 个（`CAL <item> {START,SAMPLE,ABORT}`）：`GYRO / WALLDIST / IRDATA / GYRORATIO / ENCANGLE`。
- **安全模式只能做静态 3 项**：`GYRO`(车静止，直写 Flash **page127**)、`WALLDIST`(左侧贴墙，仅 RAM，
  `SAVE`→page99)、`IRDATA`(4 摆位逐点，第 4 点后写 Flash **page123**)。
- **需电机 2 项**（安全模式下做不了，属设计）：`GYRORATIO`/`ENCANGLE`（车往复转 900°）、里程系数（`MOVE FWD` 跑直线）。
  做它们**首选切到 [2] `MOUSE_TEST_MOTOR_LAB`**（电机可控、无自走策略、仍有护栏）重编译；
  或切 [3] `MOUSE_LESSON_LAB` 用课程剖面引擎；除非确实要比赛自走逻辑，才切 [4]。
- 上位机护栏：`mc.motor_disabled` 属性 + `mc.motor_guard()`；高层方法
  (`move.forward/rotate`、`calib.angle/servo/track`) 在安全模式下立即返回 `MOTOR_DISABLED`（不空等 90s），
  底层 `send_cmd`/`calib.step` 不受限。常量在 `CalibAPI.STATIC_ITEMS`/`MOTION_ITEMS`。
- 逐点 IRDATA 走 `link_IrRebuild()`，**不擦除迷宫**（区别于教学用的 `CALIB_InitIr()`）。
- 约定：标定/参数改完若需持久化，显式 `SAVE`（`mc.params.save()` / `host.cli save`）；`flashSt.flashenable=0` 只挡住业务侧写 Flash。

## 构建与测试
- 编译：`"/c/Keil_v5/UV4/UV4.exe" -b "<工程绝对路径>\USER\Mouse.uvprojx" -o "<日志绝对路径>"`（必须绝对路径；exit=1 也可能是仅告警）。
- 符号裁剪核查：`/c/Keil_v5/ARM/ARMCC/bin/fromelf.exe --text -s USER/Object/Mouse.axf`。
- 烧录/回读校验：J-Link V976a 位于 `/c/Program Files/SEGGER/JLink_V976a/JLink.exe`；
  用 CommanderScript + `savebin`/`loadfile` 时**路径不能含空格**（先拷到 `C:\jltmp`）。
  注意 J-Link Commander 连接会**暂停内核**，探测完务必 `go`，否则芯片停在调试态、表现为"串口无应答"。
- 测试七套件（在 `host/` 下跑）：`selftest.py --e2e`(59) / `contract_test.py`(**144**，28 命令 / 8 帧 / 21 参数) /
  `motor_lab_smoke.py`(44) / `lesson_smoke.py`(38) / `timesync_smoke.py`(**46**) /
  `facade_smoke.py`(37) / `monitor_smoke.py`(28)。全绿基线 **396**。
- `contract_test.py` 的 **D2 会遍历全部 `PARAM_IDS`**（现 21 个）→ 模拟器必须应答每一个；加参数时务必同步模拟器，
  否则 D2 报红。S4 的基线计数也要跟着改。
- `gen_api_reference.py` 的子 API 清单是**硬编码**的（`subapis` 列表 + `_class_of`）→ 新子 API 要手工登记才进文档。
  同理 Event 的说明 dict 与命令示例参数 dict 也是手写的。
- 模拟器默认支持 `LESSON` 命令组与 14 个课程参数（不需要额外开关），便于契约测试与开发。
- Python 环境：用 `C:/ProgramData/anaconda3/python.exe`（有 numpy + pyserial）。
  托管 venv `~/.workbuddy/binaries/python/envs/default` 里**没有** numpy/pyserial，也没有 PySide6。
- UI（PySide6）在本机未安装，`uismoke.py` 跑不了；验证 CI 走 headless 的 monitor/cli/测试套件。
- `link_CalibService` 由 `LINK_Tick()`(SysTick 内，无条件调用)推进；`GYRO_Sample/ODOM_Sample/doWallDetect`
  在 `MOUSE_TEST_NO_MOTOR` 的 `#ifdef` 之外，所以安全模式下采集与标定照常。

## 用户偏好
- 追求一步到位、直接产出可用成果；不需要固件版本匹配/向后兼容的额外机制。
- 实时只传关键参数；重数据（1kHz SCOPE dump、墙图）等**停车后**整块回传。
