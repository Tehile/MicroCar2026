﻿/*
********************************************************************************************************
*                                               示例代码
*                                             EXAMPLE  CODE
*
*               The code is for internal use only, not for commercial transactions(开源学习,请勿商用).
*               The code ADAPTS the corresponding hardware mouse(代码适配对应人工智能电脑鼠/mouse).
*               the specific details consult the professional(欢迎联系我们).
*       ------------------------------------------------------------------------------------------------
*               Function: link.c —— 蓝牙链路(遥测上行/命令下行/标定服务/参数持久化)
*       ------------------------------------------------------------------------------------------------
*               红线声明: 本文件不修改任何既有逻辑与红线数值。它只**读取**既有全局结构体, 并在
*                         方案约定的白名单内写入运行时变量(sysCfg / speedSt / irCalib / gyroStr /
*                         motionCtrl.task / odomStr.angleBase 经 MOTION_SetAngle)。
*
*               三条实现级关键约束(详见 docs/蓝牙上位机设计方案.md §4):
*                 1) RX 优先级必须高于 SysTick —— 否则 1ms 中断期间 USART 的 DR 未被读走,
*                    后续字节全部触发 ORE 被成片丢弃(一条 30B 命令丢 4-6B, 几乎必然损坏)。
*                 2) TX 必须走 DMA —— TXE 每 87us 置位一次, 而本模块的 Tick 每 1ms 才执行一次,
*                    若在 Tick 里轮询写 DR, 实际吞吐上限只有约 1000B/s(而非 11520B/s), 预算崩 10 倍。
*                 3) 1kHz 环形缓冲复用 flash.c 的 run_data[](9600B, 主流程闲置) —— 新增 RAM 0 字节。
*********************************************************************************************************
*/

#include "link.h"

/*-------------------------------------  E X T E R N S  -------------------------------------*/
extern RunData run_data[]; /* flash.c: 运行数据缓冲(saveNum=1200 项 x 8B = 9600B), 复用作 1kHz 环形缓冲 */

/*-------------------------------------  内部常量  -------------------------------------*/
#define LINK_FAST_DIV_500HZ 2
#define LINK_FAST_DIV_250HZ 4
#define LINK_FAST_DIV_200HZ 5
#define LINK_FAST_DIV_100HZ 10
#define LINK_FAST_DIV_50HZ 20
#define LINK_FAST_DIV_20HZ 50
#define LINK_FAST_DIV_10HZ 100
#define LINK_FAST_DIV_5HZ 200 /* 1000/200 = 5Hz —— 默认档 */

/* 三路遥测的合计字节率必须落在这条蓝牙透传链路的"可持续吞吐"以内。
 * 实机实测(见 docs 附录 F)分两个层次:
 *   1) 短时(3s)能过到约 1.5KB/s, 但那是缓冲被批量推送造成的假象;
 *   2) 真正持续的发送, 511 B/s 会在约 80-90 秒后把模块缓冲灌满并**彻底归零**
 *      (且不会自恢复, 需要模块重新上电)。
 * 原版例程长期稳定在 150 B/s, 故这里按其量级取默认值:
 *     快帧 5Hz x 20B = 100 B/s
 *     中帧 1Hz x 18B =  18 B/s
 *     慢帧 0.5Hz x21B = 10.5 B/s
 *     合计            ≈ 128 B/s
 * 要点: 需要高频波形时**不要**提高实时流速率, 而应走 SCOPE 的本地 1kHz 缓冲 +
 *       事后整块 dump(配合 STREAM 开关, 只在需要时占用带宽)。 */
#define LINK_MID_DIV 1000  /* 1000/1000 =  1Hz */
#define LINK_SLOW_DIV 2000 /* 1000/2000 =  0.5Hz */

#define LINK_MOVE_SPEED_DEF 40 /* MOVE 默认速度(cm/s) */
#define LINK_SRV_SPEED 25      /* 角度基准扫描速度(cm/s) */
#define LINK_SRV_GUARD_MS 250  /* 起步保护(等速度环跟上) */
#define LINK_SRV_RISE_MS 120   /* 离开极小判据: 连续 N ms 高于当前极小 */
#define LINK_SRV_REPS 10       /* 往复次数(每次 90 度, 合计 900 度) */
#define LINK_SRV_MAXMS 30000   /* 超时保护 */
#define LINK_IR_SAMPLE_N 20    /* 单点采样平均点数 */
#define LINK_CAL_TIMEOUT 10000 /* 标定项超时(ms) */

/*-------------------------------------  内部类型  -------------------------------------*/
typedef struct
{
	u16 id;
	s32 q; /* Q16.16 */
} LinkParam;

typedef struct
{
	u8 state;    /* LINK_SCOPE_* */
	u16 idx;     /* 写指针 */
	u16 cnt;     /* 已采点数 */
	u32 startMs; /* 本次采集第 0 点对应的毫秒时基读数(见 link_ScopeSample)
	              * 有了它, 1kHz 数据就能被钉在绝对时间轴上, 而不是只有相对下标 */
} LinkScopeState;

typedef struct
{
	u8 state;   /* 0=空闲 1=传输中 */
	u8 blk;     /* 当前块号 */
	s32 chksum; /* 汇总校验 */
} LinkDumpState;

typedef struct
{
	u8 state;  /* LINK_MOVE_* */
	u16 speed; /* cm/s */
	u32 target;
	u32 elapsed;
	u32 limit;
	long pStartL, pStartR;
	/* ---- LINK_MOVE_RUN(电机远程控制实验)专用 ---- */
	long runStartL, runStartR; /* 本次运动的累计脉冲起点 */
	u32 irMm;                  /* 红外停车阈值(mm); 0 = 关闭红外护栏 */
	u32 irMin;                 /* 本次观测到的最小红外读数(mm) */
	u8 irWhich;                /* 最小读数来自哪一路: 0=F1 1=F2 2=L 3=R */
	s16 vmaxL, vmaxR;          /* 左右轮实测速度峰值(cm/s) */
} LinkMoveState;

typedef struct
{
	u8 state;
	u16 guard;
	u16 rise;
	u32 elapsed;
	long bestV;
	s32 bestAcc;
	s32 bestEnc;
	s32 prevAcc, prevEnc;
	u8 havePrev;
	u8 reps;
	s32 sumAcc;
	s32 sumEnc;
	s16 dir;
} LinkServoState;

typedef struct
{
	u8 item;
	u8 phase;
	u8 active;
	u8 needSample; /* 1=正在采样 */
	u8 samples;
	long acc;
	long acc2;
	u16 timeout;
} LinkCalState;

/*-------------------------------------  内部状态  -------------------------------------*/
/* TX 环形缓冲与状态仅在本文件(且仅由 LINK_Tick)访问, 故无需 volatile */
static u8 linkTxBuf[LINK_TX_BUF_SIZE];
static u16 linkTxHead;
static u16 linkTxTail;
static u16 linkTxInflight;

static u8 linkDumpBuf[LINK_DUMP_BUF_SIZE];

static LinkScopeState linkScope;
static LinkDumpState linkDump;
static LinkMoveState linkMove;
static LinkServoState linkSrv;
static LinkCalState linkCal;
static LinkParam linkParam[LINK_P_NUM];
#ifdef MOUSE_LESSON_LAB
/* 课程调参量(独立命名空间, id 从 LL_P_KPL=8 起, 不占用生产标定参数的 1..7)。
 * 与生产参数分开存表、分开落页 —— 即"实验代码与最终版代码分开"在存储层的体现。 */
static LinkParam linkLessonParam[LL_P_NUM];
#endif

static u16 linkTick;
static u16 linkFastDiv; /* 快帧分频; 用 u16 以便支持 0.5Hz 这类 >255 的分频值 */
static u8 linkStreamOn; /* 遥测总开关: 0=静默(上电默认), 1=按分频发送; 见 link_Telemetry 说明 */
static u8 linkSeq;
static u16 linkDrop;
static u32 linkFrames;

/* ---- 急停锁存与运动日志就绪(电机远程控制实验) ---- */
static u8 linkEStop;    /* 1=急停锁存中: MOVE/CAL 被拒, 须 STOP 解锁 */
static u8 linkLogReady; /* 1=1kHz 环里有一段可回传的运动日志(上次 MOVE RUN 已冻结) */

/* ---- 时间同步 / 发车(独立于校准与各测试档; 见 link.h 与 docs/数据收集与时间同步.md) ----
 * 这一组**不由任何测试档包住**: 生产固件同样编译、同样可用。
 * 全部只在 1ms 中断上下文(LINK_Tick / 命令处理)里读写, 与主循环并发,
 * 所以跑迷宫(主循环 while(1))期间计时照走、灯照闪、帧照发。 */
static u32 linkTimeMs;  /* 上电以来的毫秒时基。u32 可走 49 天不回绕 */
static u32 linkArmMs;   /* 发车(ARM)时刻在 linkTimeMs 上的读数; 0 = 未武装 */
static u8 linkArmed;    /* 1 = 已收到 ARM */
static u8 linkTimeLed;  /* 时间基准灯当前电平(0/1) */
static u8 linkMazeReq;  /* 1 = 已收到 MAZE RUN, 请 main() 发车跑迷宫 */
static u8 linkMazeRun;  /* 1 = main() 已真的进入迷宫 */

static s32 linkLastSeq;
static u16 linkLastCrc;
static u8 linkLastStatus[14];

static long linkEncPrevL, linkEncPrevR;
static long linkEncDiffAcc;

/*-------------------------------------  C R C 1 6 (MODBUS)  -------------------------------------*/
/* 半字节查表: tab[n] = 从初值 n 出发连续做 4 次"右移/条件异或 0xA001"的结果。
 * 于是一个字节由"内层循环 8 次"降为"两条语句", 函数体是直线代码(无分支循环)。
 *
 * 收益是**时间**而不是体积: 实测(-O0) 查表版 9 条指令/字节, 逐位版函数体 14 条但
 * 内含执行 8 次的循环, 动态约 94 条/字节, 相差约 10 倍。换算到 482 字节的 dump 块:
 *   逐位版 ~0.79ms, 查表版 ~0.075ms。
 * 这点很关键 —— dump 块的 CRC 是在 1ms 的 SysTick 里算的, 0.79ms 会吃掉近 80% 预算。
 * 代价: RO 增加 32 字节(16 项 u16 表), 整机 ROM 由 91556B 变为 91588B。
 *
 * 等价性已在 Python 上穷举验证: 256 个字节值 x 1024 个 CRC 状态(262144 组)零差异,
 * 另有 3000 组 0~600 字节随机缓冲零差异, 且 "123456789" -> 0x4B37 与标准向量一致。 */
static const u16 linkCrcTab[16] = {
	0x0000, 0xCC01, 0xD801, 0x1400,
	0xF001, 0x3C00, 0x2800, 0xE401,
	0xA001, 0x6C00, 0x7800, 0xB401,
	0x5000, 0x9C01, 0x8801, 0x4400};

/**
 * @brief  CRC16 单字节推进(多项式 0xA001, 初值 0xFFFF)
 * @param  crc 当前值
 * @param  data 字节
 * @return 新值
 * @note   与上位机 host/host/protocol/codec.py 的输出逐位一致;
 *         校验向量 "123456789" -> 0x4B37, 已在 host/selftest.py 中断言。
 */
static u16 link_CrcByte(u16 crc, u8 data)
{
	crc ^= (u16)data;
	crc = (u16)((crc >> 4) ^ linkCrcTab[crc & 0x0F]);
	crc = (u16)((crc >> 4) ^ linkCrcTab[crc & 0x0F]);
	return crc;
}

static u16 link_Crc16(const u8 *p, u16 n)
{
	u16 crc = 0xFFFF;
	while (n--)
		crc = link_CrcByte(crc, *p++);
	return crc;
}

/*-------------------------------------  T X : DMA  -------------------------------------*/
/**
 * @brief  DMA 初始化(USART1_TX 固定映射 DMA1_Channel4)
 * @param  none
 * @return none
 * @note   本项目全工程零 DMA 使用(ADC 为软件触发单次阻塞读), 故 Channel4 可独占。
 */
static void link_DmaInit(void)
{
	RCC->AHBENR |= 1 << 0; /* DMA1 时钟 */
	USART1->CR3 |= 1 << 7; /* DMAT: USART1 发送由 DMA 供数 */
	DMA1_Channel4->CCR = 0;
}

/**
 * @brief  查询 DMA 是否空闲, 并在完成时推进 TX 记账
 * @param  none
 * @return 1=空闲 0=忙
 * @note   tail 只在传输完成后推进, 因此生产者看到的空间是保守值, 绝不会覆写在途数据
 */
static u8 link_DmaIdle(void)
{
	if (DMA1_Channel4->CNDTR != 0)
		return 0;
	if (linkTxInflight)
	{
		linkTxTail = (u16)(linkTxTail + linkTxInflight);
		linkTxInflight = 0;
	}
	return 1;
}

/**
 * @brief  启动一次 DMA 传输(内存 -> USART1->DR)
 * @param  src 源地址(须连续)
 * @param  n   字节数(非 0)
 * @return none
 */
static void link_DmaStart(const u8 *src, u16 n)
{
	DMA1_Channel4->CCR = 0; /* EN=0 之后才允许改写 CMAR/CPAR/CNDTR */
	DMA1_Channel4->CPAR = (u32)(&USART1->DR);
	DMA1_Channel4->CMAR = (u32)src;
	DMA1_Channel4->CNDTR = n;
	/* EN | DIR(内存->外设) | MINC(内存地址递增), PSIZE/MSIZE 均 8bit, 低优先级 */
	DMA1_Channel4->CCR = (1 << 0) | (1 << 4) | (1 << 7);
}

/*-------------------------------------  T X : 环缓冲  -------------------------------------*/
static u16 link_TxUsed(void)
{
	return (u16)(linkTxHead - linkTxTail);
}

static u16 link_TxSpace(void)
{
	return (u16)(LINK_TX_BUF_SIZE - link_TxUsed());
}

/**
 * @brief  向 TX 环缓冲写一个字节(内部使用)
 * @param  b 字节
 * @return none
 * @note   用 PRIMASK 保护"读 head -> 写 buf -> 自增 head"三步。
 *         必要性: LINK_Tick 在 SysTick 上下文入队, 而 printf 经 LINK_PutChar
 *         可能在更高优先级的中断里入队; 若两者交错, 会写同一个槽位并丢失计数。
 *         保护段极短(约几十纳秒), 不会影响 USART1 接收中断的响应。
 */
static void link_TxPut(u8 b)
{
	u32 pm = __get_PRIMASK();
	__disable_irq();
	linkTxBuf[linkTxHead & (LINK_TX_BUF_SIZE - 1)] = b;
	linkTxHead = (u16)(linkTxHead + 1);
	__set_PRIMASK(pm);
}

static void link_TxStr(const char *s)
{
	while (*s)
		link_TxPut((u8)(*s++));
}

static void link_TxInt(s32 v)
{
	char b[12];
	u8 n = 0;
	if (v < 0)
	{
		link_TxPut('-');
		v = -v;
	}
	if (v == 0)
		b[n++] = '0';
	while (v > 0)
	{
		b[n++] = (char)('0' + (v % 10));
		v /= 10;
	}
	while (n)
		link_TxPut((u8)b[--n]);
}

/**
 * @brief  把环缓冲的连续段交给 DMA
 * @param  none
 * @return none
 * @note   每次只搬"到缓冲末尾"的一段; 回绕时下一毫秒自动续上
 */
static void link_TxDrain(void)
{
	u16 used, n, idx;
	if (!link_DmaIdle())
		return;
	used = link_TxUsed();
	if (used == 0)
		return;
	idx = (u16)(linkTxTail & (LINK_TX_BUF_SIZE - 1));
	n = (u16)(LINK_TX_BUF_SIZE - idx);
	if (n > used)
		n = used;
	linkTxInflight = n;
	link_DmaStart(&linkTxBuf[idx], n);
}

/**
 * @brief  向 TX 环缓冲写一个字节 —— printf 的统一出口
 * @param  b 字节
 * @return 1=已入队, 0=环满已丢弃
 * @note   供 usart.c 的 fputc() 调用, 让 printf 与遥测共用同一条发送队列。
 *         这是必需的而非优化: DMA1_Channel4 已接管 USART1->DR, 若 printf 仍然
 *         直接写 DR, 会有两个后果 ——
 *           1) 与 DMA 争抢 DR, 把调试文本插进遥测帧中间, 主机侧该帧 CRC 必然失败;
 *           2) 原 fputc 用"等 TC 置位"来阻塞发送, 而 DMA 连续供数时 TC 几乎不置位,
 *              会把调用者(包括在 ISR 中的 printf)长时间卡住。
 *         写入用 PRIMASK 保护: 本函数可能在任意上下文被调用, 而 LINK_Tick
 *         也在 SysTick 上下文修改同一个 head。
 *         环满时直接丢弃该字节 —— 宁可丢调试文本, 也不阻塞系统。
 */
u8 LINK_PutChar(u8 b)
{
	u32 pm = __get_PRIMASK();
	__disable_irq();
	if ((u16)(LINK_TX_BUF_SIZE - (u16)(linkTxHead - linkTxTail)) == 0)
	{
		linkDrop++; /* 环满: 记一笔后丢弃, 绝不阻塞调用者 */
		__set_PRIMASK(pm);
		return 0;
	}
	linkTxBuf[linkTxHead & (LINK_TX_BUF_SIZE - 1)] = b;
	linkTxHead = (u16)(linkTxHead + 1);
	__set_PRIMASK(pm);
	return 1;
}

/*-------------------------------------  组帧  -------------------------------------*/
/**
 * @brief  发送一个遥测帧(经 TX 环缓冲)
 * @param  type 帧类型
 * @param  payload 载荷
 * @param  len 载荷长度
 * @return none
 * @note   空间不足时**整帧丢弃**并计数, 绝不部分写入(部分写入会造成主机永久错帧)
 */
static void link_SendFrame(u8 type, const u8 *payload, u16 len)
{
	u16 i;
	u16 crc = 0xFFFF;
	/* 预留 32B 余量: printf 路径(LINK_PutChar)与组帧可能在不同上下文并发,
	 * 若不在"检查空间"与"写入"之间留出余量, 极端情况下 head 会越过
	 * tail + LINK_TX_BUF_SIZE, 使 link_TxSpace() 的无符号减法下溢成巨大值。 */
	if (link_TxSpace() < (u16)(len + LINK_FRAME_OVERHEAD + 32))
	{
		linkDrop++;
		return;
	}
	link_TxPut(LINK_SYNC0);
	link_TxPut(LINK_SYNC1);
	link_TxPut((u8)(len & 0xFF));
	link_TxPut((u8)(len >> 8));
	link_TxPut(type);
	link_TxPut(linkSeq);
	crc = link_CrcByte(crc, type);
	crc = link_CrcByte(crc, linkSeq);
	for (i = 0; i < len; i++)
	{
		link_TxPut(payload[i]);
		crc = link_CrcByte(crc, payload[i]);
	}
	link_TxPut((u8)(crc & 0xFF));
	link_TxPut((u8)(crc >> 8));
	linkSeq++;
	linkFrames++;
}

/**
 * @brief  构造完整帧到外部缓冲(供大帧走 DMA 直发)
 * @param  dst 目标缓冲(容量须 >= len + LINK_FRAME_OVERHEAD)
 * @param  type 帧类型
 * @param  payload 载荷
 * @param  len 载荷长度
 * @return 完整帧长度
 */
static u16 link_BuildFrame(u8 *dst, u8 type, const u8 *payload, u16 len)
{
	u16 crc;
	dst[0] = LINK_SYNC0;
	dst[1] = LINK_SYNC1;
	dst[2] = (u8)(len & 0xFF);
	dst[3] = (u8)(len >> 8);
	dst[4] = type;
	dst[5] = linkSeq;
	if (len)
		memcpy(&dst[6], payload, len);
	crc = link_Crc16(&dst[4], (u16)(2 + len));
	dst[6 + len] = (u8)(crc & 0xFF);
	dst[7 + len] = (u8)(crc >> 8);
	linkSeq++;
	linkFrames++;
	return (u16)(len + LINK_FRAME_OVERHEAD);
}

/*-------------------------------------  数值工具  -------------------------------------*/
static s16 link_Sat16(long v)
{
	if (v > 32767L)
		return 32767;
	if (v < -32768L)
		return -32768;
	return (s16)v;
}

static void link_Put16(u8 *p, s16 v)
{
	p[0] = (u8)((u16)v & 0xFF);
	p[1] = (u8)(((u16)v >> 8) & 0xFF);
}

static void link_Put32(u8 *p, s32 v)
{
	p[0] = (u8)((u32)v & 0xFF);
	p[1] = (u8)(((u32)v >> 8) & 0xFF);
	p[2] = (u8)(((u32)v >> 16) & 0xFF);
	p[3] = (u8)(((u32)v >> 24) & 0xFF);
}

/*-------------------------------------  标定参数表  -------------------------------------*/
static s32 link_F2Q(float f)
{
	return (s32)((f >= 0.0f) ? (f * 65536.0f + 0.5f) : (f * 65536.0f - 0.5f));
}

static s32 link_D2Q(double d)
{
	return (s32)((d >= 0.0) ? (d * 65536.0 + 0.5) : (d * 65536.0 - 0.5));
}

static float link_Q2F(s32 q)
{
	return (float)q / 65536.0f;
}

static s32 link_Q2I(s32 q)
{
	if (q >= 0)
		return (q + 32768) >> 16;
	return -(((-q) + 32768) >> 16);
}

static void link_ParamFromSys(void)
{
	linkParam[0].id = LINK_P_TRACKL;
	linkParam[0].q = link_F2Q(sysCfg.trackRatioL);
	linkParam[1].id = LINK_P_TRACKR;
	linkParam[1].q = link_F2Q(sysCfg.trackRatioR);
	linkParam[2].id = LINK_P_SPEEDL;
	linkParam[2].q = link_D2Q(sysCfg.speedRatioL);
	linkParam[3].id = LINK_P_SPEEDR;
	linkParam[3].q = link_D2Q(sysCfg.speedRatioR);
	linkParam[4].id = LINK_P_GYRO;
	linkParam[4].q = (s32)sysCfg.gyroRatio << 16;
	linkParam[5].id = LINK_P_ENCANG;
	linkParam[5].q = (s32)sysCfg.encAngleRatio << 16;
	linkParam[6].id = LINK_P_WALLDIST;
	linkParam[6].q = (s32)sysCfg.distToWall << 16;
}

/**
 * @brief  把单个标定参数应用到运行时配置
 * @param  id 参数 id
 * @param  q  Q16.16
 * @return 1=成功 0=id 非法
 * @note   只转换被改动的那一项, 避免无谓的软件浮点开销(F1 无 FPU)。
 *         gyroRatio/encAngleRatio/distToWall 在 core.h 中为整型, 故取整写入;
 *         其量化粒度已在方案文档 §6.3 论证无害(三者均不在控制环内)。
 */
static u8 link_ParamApplyOne(u16 id, s32 q)
{
	switch (id)
	{
	case LINK_P_TRACKL:
		sysCfg.trackRatioL = link_Q2F(q);
		break;
	case LINK_P_TRACKR:
		sysCfg.trackRatioR = link_Q2F(q);
		break;
	case LINK_P_SPEEDL:
		sysCfg.speedRatioL = (double)q / 65536.0;
		break;
	case LINK_P_SPEEDR:
		sysCfg.speedRatioR = (double)q / 65536.0;
		break;
	case LINK_P_GYRO:
		sysCfg.gyroRatio = (u16)link_Q2I(q);
		break;
	case LINK_P_ENCANG:
		sysCfg.encAngleRatio = (u16)link_Q2I(q);
		break;
	case LINK_P_WALLDIST:
		sysCfg.distToWall = (u8)link_Q2I(q);
		break;
	default:
		return 0;
	}
	return 1;
}

static u8 link_ParamFind(u16 id, u16 *idx)
{
	u16 i;
	for (i = 0; i < LINK_P_NUM; i++)
	{
		if (linkParam[i].id == id)
		{
			*idx = i;
			return 1;
		}
	}
	return 0;
}

#ifdef MOUSE_LESSON_LAB
/** @brief 在课程参数表中查 id(与生产参数表完全独立) */
static u8 link_LessonFind(u16 id, u16 *idx)
{
	u16 i;
	for (i = 0; i < LL_P_NUM; i++)
	{
		if (linkLessonParam[i].id == id)
		{
			*idx = i;
			return 1;
		}
	}
	return 0;
}

/** @brief 把课程参数表同步为"运行时当前值"(开机与 RESET 后调用) */
static void link_LessonFromSys(void)
{
	u16 i;
	u16 id;
	s32 q;

	for (i = 0; i < LL_P_NUM; i++)
	{
		id = (u16)(LL_P_KPL + i);
		linkLessonParam[i].id = id;
		linkLessonParam[i].q = 0;
		if (LESSONLAB_ParamGet(id, &q))
			linkLessonParam[i].q = q;
	}
}
#endif

static u8 link_ParamSet(u16 id, s32 q)
{
	u16 i;
	if (!link_ParamFind(id, &i))
	{
#ifdef MOUSE_LESSON_LAB
		/* 不在生产参数表 -> 试课程参数表(独立命名空间与独立落页) */
		if (!link_LessonFind(id, &i))
			return 0;
		if (!LESSONLAB_ParamSet(id, q))
			return 0; /* 值域非法(如速度超上限) */
		linkLessonParam[i].q = q;
		return 1;
#else
		return 0;
#endif
	}
	linkParam[i].q = q;
	return link_ParamApplyOne(id, q);
}

static u8 link_NameToId(const char *s, u16 *id)
{
	if (!strcmp(s, "TRACKL"))
		*id = LINK_P_TRACKL;
	else if (!strcmp(s, "TRACKR"))
		*id = LINK_P_TRACKR;
	else if (!strcmp(s, "SPEEDL"))
		*id = LINK_P_SPEEDL;
	else if (!strcmp(s, "SPEEDR"))
		*id = LINK_P_SPEEDR;
	else if (!strcmp(s, "GYRORATIO"))
		*id = LINK_P_GYRO;
	else if (!strcmp(s, "ENCANGLE"))
		*id = LINK_P_ENCANG;
	else if (!strcmp(s, "WALLDIST"))
		*id = LINK_P_WALLDIST;
#ifdef MOUSE_LESSON_LAB
	/* ---- 课程调参量(实验代码与生产代码分开: 名字也只在本模式下认得) ---- */
	else if (!strcmp(s, "KPL"))
		*id = LL_P_KPL;
	else if (!strcmp(s, "KIL"))
		*id = LL_P_KIL;
	else if (!strcmp(s, "KDL"))
		*id = LL_P_KDL;
	else if (!strcmp(s, "KPR"))
		*id = LL_P_KPR;
	else if (!strcmp(s, "KIR"))
		*id = LL_P_KIR;
	else if (!strcmp(s, "KDR"))
		*id = LL_P_KDR;
	else if (!strcmp(s, "IRPL"))
		*id = LL_P_IRPL;
	else if (!strcmp(s, "IRPR"))
		*id = LL_P_IRPR;
	else if (!strcmp(s, "GYROP"))
		*id = LL_P_GYROP;
	else if (!strcmp(s, "GYROD"))
		*id = LL_P_GYROD;
	else if (!strcmp(s, "SPEEDNEED"))
		*id = LL_P_SPEEDNEED;
	else if (!strcmp(s, "ALLDIS"))
		*id = LL_P_ALLDIS;
	else if (!strcmp(s, "SENSORMODE"))
		*id = LL_P_SENSORMODE;
	else if (!strcmp(s, "WALLMODE"))
		*id = LL_P_WALLMODE;
#endif
	else
		return 0;
	return 1;
}

/*-------------------------------------  Flash 持久化  -------------------------------------*/
/**
 * @brief  擦除并写入标定参数页(page 99)
 * @param  none
 * @return none
 * @note   页布局: magic(u32) ver(u16) cnt(u16) crc(u16) rsvd(u16) | payload(每项 id u16 + q s32)
 *         写 Flash 期间 CPU 取指停顿, 故调用方应保证电机已停(标定流程本身 freemode=1)。
 */
static void link_CalibSave(void)
{
	u32 addr;
	u16 i;
	u16 crc = 0xFFFF;

	FLASH_Unlock();
	FLASH_ErasePage(FLASH_ADDR_SYSCALIB);

	addr = FLASH_ADDR_SYSCALIB;
	FLASH_Unlock();
	FLASH_WriteHalfWord(addr, (int)(LINK_CALIB_MAGIC & 0xFFFF));
	addr += 2;
	FLASH_Unlock();
	FLASH_WriteHalfWord(addr, (int)((LINK_CALIB_MAGIC >> 16) & 0xFFFF));
	addr += 2;
	FLASH_Unlock();
	FLASH_WriteHalfWord(addr, LINK_CALIB_VER);
	addr += 2;
	FLASH_Unlock();
	FLASH_WriteHalfWord(addr, LINK_P_NUM);
	addr += 2;
	FLASH_Unlock();
	FLASH_WriteHalfWord(addr, 0); /* crc 占位 */
	addr += 2;
	FLASH_Unlock();
	FLASH_WriteHalfWord(addr, 0);
	addr += 2;

	addr = FLASH_ADDR_SYSCALIB + LINK_CALIB_PAYLOAD_OFF;
	for (i = 0; i < LINK_P_NUM; i++)
	{
		FLASH_Unlock();
		FLASH_WriteHalfWord(addr, (int)linkParam[i].id);
		crc = link_CrcByte(crc, (u8)(linkParam[i].id & 0xFF));
		crc = link_CrcByte(crc, (u8)((linkParam[i].id >> 8) & 0xFF));
		addr += 2;
		FLASH_Unlock();
		FLASH_WriteHalfWord(addr, (int)((u32)linkParam[i].q & 0xFFFF));
		crc = link_CrcByte(crc, (u8)((u32)linkParam[i].q & 0xFF));
		crc = link_CrcByte(crc, (u8)(((u32)linkParam[i].q >> 8) & 0xFF));
		addr += 2;
		FLASH_Unlock();
		FLASH_WriteHalfWord(addr, (int)(((u32)linkParam[i].q >> 16) & 0xFFFF));
		crc = link_CrcByte(crc, (u8)(((u32)linkParam[i].q >> 16) & 0xFF));
		crc = link_CrcByte(crc, (u8)(((u32)linkParam[i].q >> 24) & 0xFF));
		addr += 2;
	}

	FLASH_Unlock();
	FLASH_WriteHalfWord(FLASH_ADDR_SYSCALIB + 8, (int)crc);
	FLASH_Lock();
}

/**
 * @brief  从 Flash 载入标定参数并应用
 * @param  none
 * @return 1=载入成功 0=无有效参数
 * @note   任何一项校验失败都静默返回 0: 参数页损坏等价于"未标定", 而不是加载一个错的值。
 */
static u8 link_CalibLoad(void)
{
	u32 addr;
	u32 magic;
	u16 i, cnt;
	u16 crcF, crcC = 0xFFFF;

	magic = (u32)(FLASH_ReadHalfWord(FLASH_ADDR_SYSCALIB) & 0xFFFF);
	magic |= (u32)(FLASH_ReadHalfWord(FLASH_ADDR_SYSCALIB + 2) & 0xFFFF) << 16;
	if (magic != LINK_CALIB_MAGIC)
		return 0;
	if ((u16)FLASH_ReadHalfWord(FLASH_ADDR_SYSCALIB + 4) != LINK_CALIB_VER)
		return 0;
	cnt = (u16)FLASH_ReadHalfWord(FLASH_ADDR_SYSCALIB + 6);
	if (cnt != LINK_P_NUM)
		return 0;
	crcF = (u16)FLASH_ReadHalfWord(FLASH_ADDR_SYSCALIB + 8);

	addr = FLASH_ADDR_SYSCALIB + LINK_CALIB_PAYLOAD_OFF;
	for (i = 0; i < LINK_P_NUM; i++)
	{
		linkParam[i].id = (u16)FLASH_ReadHalfWord(addr);
		crcC = link_CrcByte(crcC, (u8)(linkParam[i].id & 0xFF));
		crcC = link_CrcByte(crcC, (u8)((linkParam[i].id >> 8) & 0xFF));
		addr += 2;
		linkParam[i].q = (s32)((u32)FLASH_ReadHalfWord(addr) & 0xFFFF);
		crcC = link_CrcByte(crcC, (u8)((u32)linkParam[i].q & 0xFF));
		crcC = link_CrcByte(crcC, (u8)(((u32)linkParam[i].q >> 8) & 0xFF));
		addr += 2;
		linkParam[i].q |= (s32)(((u32)FLASH_ReadHalfWord(addr) & 0xFFFF) << 16);
		crcC = link_CrcByte(crcC, (u8)(((u32)linkParam[i].q >> 16) & 0xFF));
		crcC = link_CrcByte(crcC, (u8)(((u32)linkParam[i].q >> 24) & 0xFF));
		addr += 2;
	}
	if (crcF != crcC)
		return 0;

	for (i = 0; i < LINK_P_NUM; i++)
		link_ParamApplyOne(linkParam[i].id, linkParam[i].q);
	return 1;
}

static void link_CalibErase(void)
{
	FLASH_Unlock();
	FLASH_ErasePage(FLASH_ADDR_SYSCALIB);
	FLASH_Lock();
}

#ifdef MOUSE_LESSON_LAB
/*-------------------------------------  课程参数持久化(page 100)  -------------------------------------*/
/**
 * @brief  擦除并写入课程参数页
 * @note   布局与生产参数页同构, 但用**独立 magic**, 因此两页互不误认。
 *         课程参数会被反复试验(每次调参都 SAVE), 单独占一页可避免与生产标定值
 *         共享擦除单元 —— 万一写坏, 坏的只是实验参数。
 */
static void link_LessonSave(void)
{
	u32 addr;
	u16 i;
	u16 crc = 0xFFFF;

	FLASH_Unlock();
	FLASH_ErasePage(FLASH_ADDR_LESSONPARAM);

	addr = FLASH_ADDR_LESSONPARAM;
	FLASH_Unlock();
	FLASH_WriteHalfWord(addr, (int)(LINK_LESSON_MAGIC & 0xFFFF));
	addr += 2;
	FLASH_Unlock();
	FLASH_WriteHalfWord(addr, (int)((LINK_LESSON_MAGIC >> 16) & 0xFFFF));
	addr += 2;
	FLASH_Unlock();
	FLASH_WriteHalfWord(addr, LINK_CALIB_VER);
	addr += 2;
	FLASH_Unlock();
	FLASH_WriteHalfWord(addr, LL_P_NUM);
	addr += 2;
	FLASH_Unlock();
	FLASH_WriteHalfWord(addr, 0); /* crc 占位 */
	addr += 2;
	FLASH_Unlock();
	FLASH_WriteHalfWord(addr, 0);
	addr += 2;

	addr = FLASH_ADDR_LESSONPARAM + LINK_CALIB_PAYLOAD_OFF;
	for (i = 0; i < LL_P_NUM; i++)
	{
		FLASH_Unlock();
		FLASH_WriteHalfWord(addr, (int)linkLessonParam[i].id);
		crc = link_CrcByte(crc, (u8)(linkLessonParam[i].id & 0xFF));
		crc = link_CrcByte(crc, (u8)((linkLessonParam[i].id >> 8) & 0xFF));
		addr += 2;
		FLASH_Unlock();
		FLASH_WriteHalfWord(addr, (int)((u32)linkLessonParam[i].q & 0xFFFF));
		crc = link_CrcByte(crc, (u8)((u32)linkLessonParam[i].q & 0xFF));
		crc = link_CrcByte(crc, (u8)(((u32)linkLessonParam[i].q >> 8) & 0xFF));
		addr += 2;
		FLASH_Unlock();
		FLASH_WriteHalfWord(addr, (int)(((u32)linkLessonParam[i].q >> 16) & 0xFFFF));
		crc = link_CrcByte(crc, (u8)(((u32)linkLessonParam[i].q >> 16) & 0xFF));
		crc = link_CrcByte(crc, (u8)(((u32)linkLessonParam[i].q >> 24) & 0xFF));
		addr += 2;
	}

	FLASH_Unlock();
	FLASH_WriteHalfWord(FLASH_ADDR_LESSONPARAM + 8, (int)crc);
	FLASH_Lock();
}

/**
 * @brief 从 Flash 载入课程参数并应用
 * @return 1=载入成功 0=无有效参数(等价于"用默认值")
 */
static u8 link_LessonLoad(void)
{
	u32 addr;
	u32 magic;
	u16 i, cnt;
	u16 crcF, crcC = 0xFFFF;

	magic = (u32)(FLASH_ReadHalfWord(FLASH_ADDR_LESSONPARAM) & 0xFFFF);
	magic |= (u32)(FLASH_ReadHalfWord(FLASH_ADDR_LESSONPARAM + 2) & 0xFFFF) << 16;
	if (magic != LINK_LESSON_MAGIC)
		return 0;
	if ((u16)FLASH_ReadHalfWord(FLASH_ADDR_LESSONPARAM + 4) != LINK_CALIB_VER)
		return 0;
	cnt = (u16)FLASH_ReadHalfWord(FLASH_ADDR_LESSONPARAM + 6);
	if (cnt != LL_P_NUM)
		return 0;
	crcF = (u16)FLASH_ReadHalfWord(FLASH_ADDR_LESSONPARAM + 8);

	addr = FLASH_ADDR_LESSONPARAM + LINK_CALIB_PAYLOAD_OFF;
	for (i = 0; i < LL_P_NUM; i++)
	{
		linkLessonParam[i].id = (u16)FLASH_ReadHalfWord(addr);
		crcC = link_CrcByte(crcC, (u8)(linkLessonParam[i].id & 0xFF));
		crcC = link_CrcByte(crcC, (u8)((linkLessonParam[i].id >> 8) & 0xFF));
		addr += 2;
		linkLessonParam[i].q = (s32)((u32)FLASH_ReadHalfWord(addr) & 0xFFFF);
		crcC = link_CrcByte(crcC, (u8)((u32)linkLessonParam[i].q & 0xFF));
		crcC = link_CrcByte(crcC, (u8)(((u32)linkLessonParam[i].q >> 8) & 0xFF));
		addr += 2;
		linkLessonParam[i].q |= (s32)(((u32)FLASH_ReadHalfWord(addr) & 0xFFFF) << 16);
		crcC = link_CrcByte(crcC, (u8)(((u32)linkLessonParam[i].q >> 16) & 0xFF));
		crcC = link_CrcByte(crcC, (u8)(((u32)linkLessonParam[i].q >> 24) & 0xFF));
		addr += 2;
	}
	if (crcF != crcC)
		return 0;

	for (i = 0; i < LL_P_NUM; i++)
		LESSONLAB_ParamSet(linkLessonParam[i].id, linkLessonParam[i].q);
	return 1;
}

static void link_LessonErase(void)
{
	FLASH_Unlock();
	FLASH_ErasePage(FLASH_ADDR_LESSONPARAM);
	FLASH_Lock();
}
#endif /* MOUSE_LESSON_LAB */

/*-------------------------------------  红外查表重建  -------------------------------------*/
/**
 * @brief  用当前 irCalib 的 8 个标定值重建四张查表
 * @param  none
 * @return none
 * @note   调用参数与 APP/calibrate.c:47-50 逐项一致(近/远距离常量 33/94/95/32/213)。
 *         刻意**不复用** CALIB_InitIr(): 后者会擦除迷宫与路径页(BLOCK/GOPATH/BACKPATH),
 *         属于破坏性副作用——标定不应该把已探索的迷宫清掉。
 *         若将来 calibrate.c 修改了这些距离常量, 此处必须同步。
 */
static void link_IrRebuild(void)
{
	IR_InfCorrect(irCalib.rawlavrgnear, 33, irCalib.rawlavrgfar, 94, 250, datal, L);
	IR_InfCorrect(irCalib.rawravrgnear, 33, irCalib.rawravrgfar, 95, 250, datar, R);
	IR_InfCorrect(irCalib.rawf1avrgnear, 32, irCalib.rawf1avrgfar, 213, 250, dataf1, F1);
	IR_InfCorrect(irCalib.rawf2avrgnear, 32, irCalib.rawf2avrgfar, 213, 250, dataf2, F2);
}

/*-------------------------------------  1kHz 环缓冲  -------------------------------------*/
static void link_ScopeSample(void)
{
	RunData *p;
	if (linkScope.state != LINK_SCOPE_RUN)
		return;
	if (linkScope.idx >= LINK_SCOPE_LEN)
		linkScope.idx = 0;
	if (linkScope.cnt == 0)
		/* 记下"环里第 0 点"的毫秒时基。之后无论是否回绕, 主机都能算出
		 * 回传数组中**最早一点**的绝对设备时刻(见 link_SendDumpHdr)。 */
		linkScope.startMs = linkTimeMs;
	p = &run_data[linkScope.idx];
	p->motionTask = motionCtrl.task;
	p->gangle = link_Sat16(gyroStr.angle);
	p->speedl = link_Sat16(speedSt.speedL);
	p->speedr = link_Sat16(speedSt.speedR);
	linkScope.idx++;
	if (linkScope.cnt < LINK_SCOPE_LEN)
		linkScope.cnt++;
}

/*-------------------------------------  原始轮差累计  -------------------------------------*/
/**
 * @brief  累计 (左编码器 - 右编码器) 的原始脉冲数
 * @param  none
 * @return none
 * @note   独立于 sysCfg.encAngleRatio, 因此可作为 encAngleRatio 的标定基准,
 *         不会形成"用编码器角标编码器"的循环依赖。
 */
static void link_EncAccumulate(void)
{
	long dl = odomStr.encL - linkEncPrevL;
	long dr = odomStr.encR - linkEncPrevR;
	if (dl < -ENCODER_WRAP_THRESHOLD)
		dl += ENCODER_ARR_VALUE;
	else if (dl > ENCODER_WRAP_THRESHOLD)
		dl -= ENCODER_ARR_VALUE;
	if (dr < -ENCODER_WRAP_THRESHOLD)
		dr += ENCODER_ARR_VALUE;
	else if (dr > ENCODER_WRAP_THRESHOLD)
		dr -= ENCODER_ARR_VALUE;
	linkEncPrevL = odomStr.encL;
	linkEncPrevR = odomStr.encR;
	linkEncDiffAcc += (dl - dr);
}

/*-------------------------------------  遥测组帧  -------------------------------------*/
static u8 link_Flags(void)
{
	u8 f = 0;
	if (speedSt.freemode == 1)
		f |= LINK_FLAG_FREEMODE;
	if (speedSt.sleepmode == 1)
		f |= LINK_FLAG_SLEEP;
	if (emergMon.active == 1)
		f |= LINK_FLAG_EMERG;
	if (linkScope.state == LINK_SCOPE_RUN)
		f |= LINK_FLAG_SCOPING;
	if (linkDump.state == 1)
		f |= LINK_FLAG_DUMPING;
#ifdef MOUSE_TEST_NO_MOTOR
	/* 安全测试模式: 把"电机已被物理禁用"这一事实明确告知上位机,
	 * 便于现场一眼确认烧进去的是安全固件(而不是靠推断)。 */
	f |= LINK_FLAG_MOTOR_OFF;
#endif
	/* 急停锁存与"运动日志已就绪"是两个**独立**于 emergMon 的链路层事实:
	 * 前者表示"必须显式 STOP 才能再动", 后者表示"1kHz 环里有一段刚跑完的日志"。 */
	if (linkEStop)
		f |= LINK_FLAG_ESTOP_LOCK;
	if (linkLogReady)
		f |= LINK_FLAG_RUNLOG;
	return f;
}

static void link_Telemetry(void)
{
	u8 pl[LINK_SLOW_LEN];

	/* 遥测总开关: 默认【关】。
	 * 关键原因(实机验证): 本链路经过一对蓝牙透传模块, 其内部缓冲一旦被灌满
	 * 就会停止转发, 且不会自行恢复(需要模块重新上电)。而 STM32 上电后在蓝牙
	 * 射频链路建好之前就已经开始发送, 会在无人读取时把缓冲灌满 -> 之后上位机
	 * 无论何时打开都收不到任何字节。
	 * 因此改为: 上电默认静默, 由上位机连上后发 "STREAM ON" 才开流,
	 * 断开时发 "STREAM OFF"。命令通道始终可用, 不受本开关影响。 */
	if (!linkStreamOn)
		return;

	if (linkDump.state == 1)
		return; /* dump 期间暂停全部遥测帧, 把带宽全部让给全分辨率数据 */

	/* ---- 快帧: 转速/角度/pidErr @ 默认 20Hz ---- */
	if ((u16)(linkTick % linkFastDiv) == 0)
	{
		u8 f[LINK_FAST_LEN];
		link_Put16(&f[0], link_Sat16(speedSt.speedL));
		link_Put16(&f[2], link_Sat16(speedSt.speedR));
		link_Put16(&f[4], link_Sat16(gyroStr.angle));
		link_Put16(&f[6], link_Sat16(motionCtrl.pidErr));
		link_Put16(&f[8], link_Sat16(speedSt.speedTargetL));
		link_Put16(&f[10], link_Sat16(speedSt.speedTargetR));
		f[12] = motionCtrl.task;
		f[13] = (u8)(battMon.voltage / 10.0); /* 0.1V 单位, 如 75 表示 7.5V */
		f[14] = link_Flags();
		/* 时间同步: 保留字节改为"毫秒时基低 8 位"。
		 * 单靠这个字节只能定位到 256ms 窗口, 但它与每秒一帧的 TIME 帧
		 * (带完整 u32)配合, 就能把**每一个快帧**都钉到准确的设备时刻上 ——
		 * 于是蓝牙透传的不确定延迟不再污染每个采样点的时间。 */
		f[15] = (u8)(linkTimeMs & 0xFFu);
		link_SendFrame(LINK_TYPE_FAST, f, LINK_FAST_LEN);
	}

	/* ---- 中帧: 里程/编码器角/陀螺原始 @ 50Hz ---- */
	if ((u16)(linkTick % LINK_MID_DIV) == 0)
	{
		u8 m[LINK_MID_LEN];
		link_Put16(&m[0], link_Sat16(odomStr.cellOdom));
		link_Put16(&m[2], link_Sat16(odomStr.trackL));
		link_Put16(&m[4], link_Sat16(odomStr.trackR));
		link_Put16(&m[6], link_Sat16(gyroStr.raw));
		link_Put16(&m[8], link_Sat16(gyroStr.diff));
		link_Put16(&m[10], link_Sat16(odomStr.angle));
		link_SendFrame(LINK_TYPE_MID, m, LINK_MID_LEN);
	}

	/* ---- 慢帧: 红外/墙/电压/CPU/坐标/丢帧 @ 5Hz ----
	 * 偏移固定: 0-7 四路红外(s16) | 8 墙位 | 9 任务 | 10-11 坐标 |
	 *           12-13 电压(s16, 740 表示 7.40V) | 14 CPU | 15 累计丢帧 */
	if ((u16)(linkTick % LINK_SLOW_DIV) == 0)
	{
		link_Put16(&pl[0], link_Sat16(irDist.f1));
		link_Put16(&pl[2], link_Sat16(irDist.f2));
		link_Put16(&pl[4], link_Sat16(irDist.l));
		link_Put16(&pl[6], link_Sat16(irDist.r));
		pl[8] = 0;
		if (wallSns.left)
			pl[8] |= 0x01;
		if (wallSns.right)
			pl[8] |= 0x02;
		if (wallSns.front)
			pl[8] |= 0x04;
		if (wallSns.left45)
			pl[8] |= 0x08;
		if (wallSns.right45)
			pl[8] |= 0x10;
		pl[9] = mazeState.mouseTask;
		pl[10] = (u8)mazeState.mousePos.cX;
		pl[11] = (u8)mazeState.mousePos.cY;
		link_Put16(&pl[12], link_Sat16((long)battMon.voltage));
		pl[14] = (u8)cpuMon.ticks;
		pl[15] = (u8)(linkDrop & 0xFF);
		link_SendFrame(LINK_TYPE_SLOW, pl, LINK_SLOW_LEN);
	}

	/* ---- 时间同步帧 @1Hz: 与"1Hz 时间基准灯"同拍, 软件与物理互相印证 ----
	 * payload 12B: upMs(u32 LE) | armMs(u32 LE) | led(u8) | flags(u8) | rsvd(u16)
	 *   上位机用 (upMs -> 本机单调时钟) 建立"设备时间 -> PC 时间"的映射,
	 *   再把每个快帧的 f[15](低 8 位) 插进去, 得到每个采样点的准确时间。 */
	if ((linkTimeMs % (u32)LINK_TIME_DIV) == 0u)
	{
		u8 t[LINK_TIME_LEN];
		u8 fl = 0;
		t[0] = (u8)(linkTimeMs & 0xFF);
		t[1] = (u8)((linkTimeMs >> 8) & 0xFF);
		t[2] = (u8)((linkTimeMs >> 16) & 0xFF);
		t[3] = (u8)((linkTimeMs >> 24) & 0xFF);
		t[4] = (u8)(linkArmMs & 0xFF);
		t[5] = (u8)((linkArmMs >> 8) & 0xFF);
		t[6] = (u8)((linkArmMs >> 16) & 0xFF);
		t[7] = (u8)((linkArmMs >> 24) & 0xFF);
		t[8] = linkTimeLed;
		if (linkArmed)
			fl |= LINK_TIME_FLAG_ARMED;
		if (linkMazeRun)
			fl |= LINK_TIME_FLAG_MAZERUN;
		if (linkTimeLed)
			fl |= LINK_TIME_FLAG_BEACON;
		t[9] = fl;
		t[10] = 0;
		t[11] = 0;
		link_SendFrame(LINK_TYPE_TIME, t, LINK_TIME_LEN);
	}
}

/*-------------------------------------  运动服务  -------------------------------------*/
/**
 * @brief  取四路红外中的最小读数, 并记录它来自哪一路
 * @param  which 输出: 0=F1 1=F2 2=L 3=R
 * @return 最小读数(mm, 已钳到 >= 0)
 * @note   四路一起看而不是只看前方两路: 轮子悬空或侧向贴障碍时侧红外同样能反映
 *         "快贴上了"; 本实验要证明的正是"任何一路触发都能停"。
 */
static long link_MinIr(u8 *which)
{
	long v = irDist.f1;
	long t;

	*which = 0;
	t = irDist.f2;
	if (t < v)
	{
		v = t;
		*which = 1;
	}
	t = irDist.l;
	if (t < v)
	{
		v = t;
		*which = 2;
	}
	t = irDist.r;
	if (t < v)
	{
		v = t;
		*which = 3;
	}
	if (v < 0)
		v = 0;
	return v;
}

static const char *link_IrChanName(u8 which)
{
	switch (which)
	{
	case 0:
		return "F1";
	case 1:
		return "F2";
	case 2:
		return "L";
	default:
		return "R";
	}
}

/**
 * @brief  结束一次 MOVE RUN: 停车 + 冻结日志 + 上报明细
 * @param  reason  停止原因(LINK_RUN_REASON_*)
 * @param  elapsed 实际运行时长(ms)
 * @return none
 * @note   三个副作用正是"双流"设计的落点:
 *           1) 速度目标归零 + freemode=1 —— 电机停, 且**完全不依赖上位机**;
 *           2) SCOPE 由 RUN 转 FROZEN —— 1kHz 环冻结, 内容不会被后续采样冲掉;
 *           3) 置 linkLogReady —— 快帧 flags bit7, 上位机据此知道"可以拉日志了"。
 *         上报用文本行(一次运动一行, 低频)而不是新帧型: 零帧开销, 且能与其他
 *         异步文本共用既有解析通路。
 */
static void link_MoveFinishRun(const char *reason, u32 elapsed)
{
	long dL, dR;

	dL = odomStr.distL + odomStr.distLCycle * ENCODER_ARR_VALUE - linkMove.runStartL;
	dR = odomStr.distR + odomStr.distRCycle * ENCODER_ARR_VALUE - linkMove.runStartR;

	speedSt.speedTargetL = 0;
	speedSt.speedTargetR = 0;
	speedSt.freemode = 1;
	linkMove.state = LINK_MOVE_NONE;

	if (linkScope.state == LINK_SCOPE_RUN)
		linkScope.state = LINK_SCOPE_FROZEN;
	linkLogReady = 1;

	link_TxStr("MOVEDONE RUN ");
	link_TxStr(reason);
	link_TxPut(' ');
	link_TxInt((s32)elapsed);
	link_TxPut(' ');
	link_TxInt((s32)linkMove.irMin);
	link_TxPut(' ');
	link_TxStr(link_IrChanName(linkMove.irWhich));
	link_TxPut(' ');
	link_TxInt(dL);
	link_TxPut(' ');
	link_TxInt(dR);
	link_TxPut(' ');
	link_TxInt(linkMove.vmaxL);
	link_TxPut(' ');
	link_TxInt(linkMove.vmaxR);
	link_TxStr("\r\n");
}

/**
 * @brief  停车并清掉所有运动/标定子状态(STOP 与 ESTOP 共用)
 * @param  runReason 若当时正在 MOVE RUN, 用它上报停止原因
 * @return none
 */
static void link_StopMotion(const char *runReason)
{
	if (linkMove.state == LINK_MOVE_RUN)
		link_MoveFinishRun(runReason, linkMove.elapsed);

	speedSt.speedTargetL = 0;
	speedSt.speedTargetR = 0;
	speedSt.freemode = 1;
	motionCtrl.task = MOTION_TASK_NULL;
	linkMove.state = LINK_MOVE_NONE;
	linkSrv.state = LINK_SRV_NONE;
	linkCal.active = 0;
	linkCal.needSample = 0;
	irCalib.calibMode = 0;

#ifdef MOUSE_LESSON_LAB
	/* 课程实验若在跑, 一并停掉并带上真实原因(急停 vs 正常停车)。
	 * 必须在清完上面这些状态之后: ll_Finish 会写 speedSt, 而这里刚把速度归零。 */
	if (runReason != NULL && !strcmp(runReason, LINK_RUN_REASON_ESTOP))
		LESSONLAB_Abort(LL_REASON_ESTOP);
	else
		LESSONLAB_Abort(LL_REASON_STOP);
#endif
}

/**
 * @brief  固定脉冲直线 / 定长原地转 / 受双护栏约束的远程运动 的状态机
 * @param  none
 * @return none
 * @note   写 speedSt.speedTargetL/R 之前必须把 motionCtrl.task 置 MOTION_TASK_NULL,
 *         否则各 doTask* 会在每个 1ms 周期覆盖目标速度。
 */
static void link_MoveService(void)
{
	long dL, dR;
	long ir;
	u8 which;
	s16 v;

	if (linkMove.state == LINK_MOVE_NONE)
		return;

	/* ================= MOVE RUN: 时间 + 红外 双护栏 ================= */
	if (linkMove.state == LINK_MOVE_RUN)
	{
		linkMove.elapsed++;

		ir = link_MinIr(&which);
		if ((u32)ir < linkMove.irMin)
		{
			linkMove.irMin = (u32)ir;
			linkMove.irWhich = which;
		}

		/* 记录实测速度峰值(|v|)。轮子悬空时它是"电机确实响应了"的客观证据 ——
		 * 比"命令发出去了"强得多。 */
		v = link_Sat16(speedSt.speedL);
		if (v < 0)
			v = (s16)(-v);
		if (v > linkMove.vmaxL)
			linkMove.vmaxL = v;
		v = link_Sat16(speedSt.speedR);
		if (v < 0)
			v = (s16)(-v);
		if (v > linkMove.vmaxR)
			linkMove.vmaxR = v;

		/* ---- 护栏 1: 红外贴脸必停 ---- */
		if (linkMove.irMm && (u32)ir < linkMove.irMm)
		{
			link_MoveFinishRun(LINK_RUN_REASON_IR, linkMove.elapsed);
			return;
		}

		/* ---- 护栏 2: 到时必停 ---- */
		if (linkMove.elapsed >= linkMove.limit)
		{
			link_MoveFinishRun(LINK_RUN_REASON_TIME, linkMove.elapsed);
			return;
		}
		return;
	}

	if (linkMove.state == LINK_MOVE_FWD)
	{
		dL = odomStr.distL + odomStr.distLCycle * ENCODER_ARR_VALUE - linkMove.pStartL;
		dR = odomStr.distR + odomStr.distRCycle * ENCODER_ARR_VALUE - linkMove.pStartR;
		if (dL < 0)
			dL = -dL;
		if (dR < 0)
			dR = -dR;
		if (dL >= (long)linkMove.target || dR >= (long)linkMove.target)
		{
			speedSt.speedTargetL = 0;
			speedSt.speedTargetR = 0;
			speedSt.freemode = 1;
			linkMove.state = LINK_MOVE_NONE;
			link_TxStr("MOVEDONE FWD ");
			link_TxInt(dL);
			link_TxPut(' ');
			link_TxInt(dR);
			link_TxStr("\r\n");
		}
	}
	else
	{
		linkMove.elapsed++;
		if (linkMove.elapsed >= linkMove.limit)
		{
			speedSt.speedTargetL = 0;
			speedSt.speedTargetR = 0;
			speedSt.freemode = 1;
			linkMove.state = LINK_MOVE_NONE;
			link_TxStr("MOVEDONE ROT\r\n");
		}
	}
}

/**
 * @brief  角度基准扫描: 用"前向红外正对墙"的极小值作为物理角度基准
 * @param  none
 * @return none
 * @note   这是**非循环依赖**的关键: 极小值由红外几何决定, 与陀螺系数/编码器系数无关,
 *         因此可用它标定 gyroRatio 与 encAngleRatio(方案文档 §6.3)。
 *         相邻两个极小相差 90 度; 往复 LINK_SRV_REPS 次, 累计 900 度, 把 ±2 度的
 *         极值定位误差均摊到约 0.2%。
 *         要求放在迷宫角格(相邻两面互相垂直的墙), 否则找不到两个相邻极小。
 */
static void link_ServoService(void)
{
	long v;
	s32 dAcc, dEnc;

	if (linkSrv.state == LINK_SRV_NONE)
		return;

	linkSrv.elapsed++;
	if (linkSrv.elapsed > LINK_SRV_MAXMS)
	{
		speedSt.speedTargetL = 0;
		speedSt.speedTargetR = 0;
		speedSt.freemode = 1;
		linkSrv.state = LINK_SRV_NONE;
		link_TxStr("CALERR GYRORATIO TIMEOUT\r\n");
		return;
	}

	if (linkSrv.guard)
	{
		linkSrv.guard--;
		return;
	}

	v = irDist.f1 + irDist.f2;
	if (v < linkSrv.bestV)
	{
		linkSrv.bestV = v;
		linkSrv.bestAcc = gyroStr.angleAcc;
		linkSrv.bestEnc = linkEncDiffAcc;
		linkSrv.rise = 0;
	}
	else
	{
		linkSrv.rise++;
	}

	if (linkSrv.rise < LINK_SRV_RISE_MS)
		return;

	/* ---- 找到一个极小 ---- */
	if (linkSrv.havePrev)
	{
		dAcc = linkSrv.bestAcc - linkSrv.prevAcc;
		dEnc = linkSrv.bestEnc - linkSrv.prevEnc;
		if (dAcc < 0)
			dAcc = -dAcc;
		if (dEnc < 0)
			dEnc = -dEnc;
		linkSrv.sumAcc += dAcc;
		linkSrv.sumEnc += dEnc;
		linkSrv.reps++;
	}
	linkSrv.prevAcc = linkSrv.bestAcc;
	linkSrv.prevEnc = linkSrv.bestEnc;
	linkSrv.havePrev = 1;
	linkSrv.bestV = 0x7FFFFFFFL;
	linkSrv.rise = 0;
	linkSrv.guard = LINK_SRV_GUARD_MS;

	if (linkSrv.reps >= LINK_SRV_REPS)
	{
		speedSt.speedTargetL = 0;
		speedSt.speedTargetR = 0;
		speedSt.freemode = 1;
		linkSrv.state = LINK_SRV_NONE;
		link_TxStr("CALDONE GYRORATIO ");
		link_TxInt(linkSrv.sumAcc);
		link_TxPut(' ');
		link_TxInt(linkSrv.sumEnc);
		link_TxPut(' ');
		link_TxInt((s32)LINK_SRV_REPS * 90);
		link_TxStr("\r\n");
		return;
	}

	/* 反向继续找下一个极小(往复) */
	linkSrv.dir = (s16)(-linkSrv.dir);
	speedSt.speedTargetL = linkSrv.dir * LINK_SRV_SPEED;
	speedSt.speedTargetR = -(linkSrv.dir * LINK_SRV_SPEED);
}

/*-------------------------------------  标定服务  -------------------------------------*/
/**
 * @brief  标定项的统一非阻塞状态机(蓝牙链路与按键菜单可共用)
 * @param  item 标定项(LINK_CAL_*)
 * @param  act  LINK_ACT_START/STEP/DONE/ABORT
 * @return 1=该项已完成 0=进行中
 * @note   IRDATA 必须由上位机逐点触发: START 后先发 SAMPLE 采第 1 点, 摆好位置再发 SAMPLE
 *         采下一点, 共 4 点。其余各项 START 后自动采集。
 */
static u8 link_CalibService(u8 item, u8 act)
{
	if (act == LINK_ACT_ABORT)
	{
		linkCal.active = 0;
		linkCal.needSample = 0;
		speedSt.speedTargetL = 0;
		speedSt.speedTargetR = 0;
		speedSt.freemode = 1;
		linkSrv.state = LINK_SRV_NONE;
		linkMove.state = LINK_MOVE_NONE;
		irCalib.calibMode = 0;
		return 1;
	}

	if (act == LINK_ACT_START)
	{
		linkCal.item = item;
		linkCal.phase = 0;
		linkCal.samples = 0;
		linkCal.acc = 0;
		linkCal.acc2 = 0;
		linkCal.timeout = 0;
		linkCal.active = 1;
		linkCal.needSample = 1;
		motionCtrl.task = MOTION_TASK_NULL;
		speedSt.speedTargetL = 0;
		speedSt.speedTargetR = 0;
		wallSns.irSwitch = 1;

		switch (item)
		{
		case LINK_CAL_GYRO:
			gyroStr.correctionEnable = 1; /* 关闭"编码器角度稳定则清零陀螺"的干扰 */
			gyroStr.adjCounter = 0;
			gyroStr.adjFlag = 1;
			speedSt.freemode = 1;
			break;
		case LINK_CAL_WALLDIST:
			speedSt.freemode = 1;
			break;
		case LINK_CAL_IRDATA:
			irCalib.calibMode = 1; /* 滑动平均而非查表 */
			speedSt.freemode = 1;
			linkCal.needSample = 0; /* 等上位机逐点 SAMPLE */
			break;
		case LINK_CAL_GYRORATIO:
		case LINK_CAL_ENCANGLE:
			gyroStr.correctionEnable = 1;
			gyroStr.adjFlag = 0;
			speedSt.freemode = 0;
			linkSrv.state = LINK_SRV_SWEEP;
			linkSrv.guard = LINK_SRV_GUARD_MS;
			linkSrv.rise = 0;
			linkSrv.elapsed = 0;
			linkSrv.bestV = 0x7FFFFFFFL;
			linkSrv.havePrev = 0;
			linkSrv.reps = 0;
			linkSrv.sumAcc = 0;
			linkSrv.sumEnc = 0;
			linkSrv.dir = 1;
			speedSt.speedTargetL = LINK_SRV_SPEED;
			speedSt.speedTargetR = -LINK_SRV_SPEED;
			break;
		default:
			speedSt.freemode = 1;
			break;
		}
		return 0;
	}

	/* ---- 显式采样触发(IRDATA 逐点采集) ---- */
	if (act == LINK_ACT_SAMPLE)
	{
		linkCal.samples = 0;
		linkCal.acc = 0;
		linkCal.acc2 = 0;
		linkCal.needSample = 1;
		return 0;
	}

	if (!linkCal.active)
		return 1;

	if (linkCal.item != LINK_CAL_GYRORATIO && linkCal.item != LINK_CAL_ENCANGLE)
	{
		linkCal.timeout++;
		if (linkCal.timeout > LINK_CAL_TIMEOUT)
		{
			linkCal.active = 0;
			linkCal.needSample = 0;
			speedSt.freemode = 1;
			irCalib.calibMode = 0;
			link_TxStr("CALERR TIMEOUT\r\n");
			return 1;
		}
	}
	else
	{
		if (linkSrv.state == LINK_SRV_NONE)
		{
			linkCal.active = 0; /* CALDONE/CALERR 已由 link_ServoService 发出 */
			return 1;
		}
		return 0;
	}

	/* ---- 陀螺零偏: 由 GYRO_Sample 内部自算, 这里只等它就绪并落盘 ---- */
	if (linkCal.item == LINK_CAL_GYRO)
	{
		if (gyroStr.adjCounter > 1500)
		{
			gyroStr.adjFlag = 0;
			gyroStr.correctionEnable = 0;
			FLASH_Unlock();
			FLASH_ErasePage(FLASH_ADDR_GYRO0);
			FLASH_Unlock();
			FLASH_WriteHalfWord(FLASH_ADDR_GYRO0, gyroStr.bias);
			linkCal.active = 0;
			link_TxStr("CALDONE GYRO ");
			link_TxInt(gyroStr.bias);
			link_TxStr("\r\n");
			return 1;
		}
		return 0;
	}

	/* ---- 车心到墙距离: 静止时取左红外稳定均值 ---- */
	if (linkCal.item == LINK_CAL_WALLDIST)
	{
		if (!linkCal.needSample)
			return 0;
		linkCal.acc += irDist.l;
		linkCal.samples++;
		if (linkCal.samples >= LINK_IR_SAMPLE_N)
		{
			s32 avg = linkCal.acc / (long)linkCal.samples;
			link_ParamSet(LINK_P_WALLDIST, avg << 16);
			linkCal.active = 0;
			linkCal.needSample = 0;
			link_TxStr("CALDONE WALLDIST ");
			link_TxInt(avg);
			link_TxStr("\r\n");
			return 1;
		}
		return 0;
	}

	/* ---- 红外 8 值: 4 个位置逐点采样 ---- */
	if (linkCal.item == LINK_CAL_IRDATA)
	{
		if (!linkCal.needSample)
			return 0;
		switch (linkCal.phase)
		{
		case 0: /* 左近墙 */
			linkCal.acc += irCalib.rawl;
			break;
		case 1: /* 左远墙 */
			linkCal.acc += irCalib.rawl;
			break;
		case 2: /* 前近墙 */
			linkCal.acc += irCalib.rawf1;
			linkCal.acc2 += irCalib.rawf2;
			break;
		default: /* 前远墙 */
			linkCal.acc += irCalib.rawf1;
			linkCal.acc2 += irCalib.rawf2;
			break;
		}
		linkCal.samples++;
		if (linkCal.samples < LINK_IR_SAMPLE_N)
			return 0;

		switch (linkCal.phase)
		{
		case 0:
			irCalib.rawlavrgnear = (int)(linkCal.acc / (long)linkCal.samples);
			irCalib.rawravrgfar = irCalib.rawr; /* 与 calibrate.c 步骤1 的配对方式一致 */
			break;
		case 1:
			irCalib.rawlavrgfar = (int)(linkCal.acc / (long)linkCal.samples);
			irCalib.rawravrgnear = irCalib.rawr;
			break;
		case 2:
			irCalib.rawf1avrgnear = (int)(linkCal.acc / (long)linkCal.samples);
			irCalib.rawf2avrgnear = (int)(linkCal.acc2 / (long)linkCal.samples);
			break;
		default:
			irCalib.rawf1avrgfar = (int)(linkCal.acc / (long)linkCal.samples);
			irCalib.rawf2avrgfar = (int)(linkCal.acc2 / (long)linkCal.samples);
			break;
		}
		linkCal.samples = 0;
		linkCal.acc = 0;
		linkCal.acc2 = 0;
		linkCal.needSample = 0;
		link_TxStr("CALSTEP IRDATA ");
		link_TxInt(linkCal.phase);
		link_TxStr("\r\n");
		linkCal.phase++;
		if (linkCal.phase <= 3)
			return 0;

		/* ---- 4 点齐了: 重建查表 + 写既有 page123 ---- */
		link_IrRebuild();
		irCalib.calibMode = 0;
		{
			u32 a = FLASH_ADDR_IRDATA;
			FLASH_Unlock();
			FLASH_ErasePage(FLASH_ADDR_IRDATA);
			FLASH_Unlock();
			FLASH_WriteHalfWord(a, irCalib.rawf1avrgnear);
			a += 2;
			FLASH_Unlock();
			FLASH_WriteHalfWord(a, irCalib.rawf1avrgfar);
			a += 2;
			FLASH_Unlock();
			FLASH_WriteHalfWord(a, irCalib.rawf2avrgnear);
			a += 2;
			FLASH_Unlock();
			FLASH_WriteHalfWord(a, irCalib.rawf2avrgfar);
			a += 2;
			FLASH_Unlock();
			FLASH_WriteHalfWord(a, irCalib.rawlavrgnear);
			a += 2;
			FLASH_Unlock();
			FLASH_WriteHalfWord(a, irCalib.rawlavrgfar);
			a += 2;
			FLASH_Unlock();
			FLASH_WriteHalfWord(a, irCalib.rawravrgnear);
			a += 2;
			FLASH_Unlock();
			FLASH_WriteHalfWord(a, irCalib.rawravrgfar);
		}
		linkCal.active = 0;
		link_TxStr("CALDONE IRDATA\r\n");
		return 1;
	}

	return 0;
}

/*-------------------------------------  dump 传输  -------------------------------------*/
static void link_StartDump(void)
{
	u8 hdr[LINK_DUMPHDR_LEN];
	if (linkDump.state == 1)
		return;
	linkScope.state = LINK_SCOPE_FROZEN; /* 冻结: 保证 DMA 读到的不是正在被写的内存 */
	linkLogReady = 0;                    /* 上位机已主动索取日志 -> 消费掉这个"就绪"提示 */
	linkDump.state = 1;
	linkDump.blk = 0;
	linkDump.chksum = 0;
	link_Put16(&hdr[0], (s16)LINK_SCOPE_LEN);
	hdr[2] = (u8)LINK_SCOPE_PTS_PER_BLK;
	hdr[3] = 4; /* 通道数: motionTask/gangle/speedl/speedr */
	/* 关键: 报告"已填点数"与"写指针"。环缓冲只有 1200 点, 若本次采集不足 1.2 秒,
	 * 尾部是陈旧数据; 若已回绕, 块 0 并不是时间上最早的点。
	 * 主机必须靠这两个字段才能还原时间顺序, 否则波形是错的。 */
	link_Put16(&hdr[4], (s16)linkScope.cnt);
	link_Put16(&hdr[6], (s16)linkScope.idx);
	/* 时间同步: 回传数组中**最早一点**的绝对设备时刻(ms 时基)。
	 * 未回绕时最早点就是 ring[0], 时刻 = startMs;
	 * 已回绕(满了)时最早点是 ring[idx], 比 ring[0] 晚了 idx 毫秒。
	 * 有了它, 主机就能把 1kHz 数据直接画在绝对时间轴上
	 * (t = startMs + i), 与 ARM 发车时刻、1Hz 基准灯完全对齐。 */
	link_Put32(&hdr[8], (s32)(linkScope.startMs +
	                          (linkScope.cnt >= LINK_SCOPE_LEN ? (u32)linkScope.idx : 0u)));
	link_SendFrame(LINK_TYPE_DUMP_HDR, hdr, LINK_DUMPHDR_LEN);
}

/**
 * @brief  dump 状态机: 每毫秒最多发一块, 全程零阻塞
 * @param  none
 * @return none
 * @note   只在"环缓冲已排空且 DMA 空闲"时才发起直发传输, 因此不会与普通遥测争用 DMA。
 *         每块 489B 约需 42ms, 20 块共约 0.85s。由于走 DMA 且逐块推进, 1ms 控制周期
 *         完全不受影响。
 */
static void link_DumpService(void)
{
	u16 n, total;
	u8 pl[LINK_DUMPBLK_LEN];
	u8 end[LINK_DUMPEND_LEN];

	if (linkDump.state == 0)
		return;
	if (!link_DmaIdle())
		return;
	if (link_TxUsed() != 0)
		return;

	if (linkDump.blk >= (u8)LINK_SCOPE_BLKS)
	{
		link_Put32(&end[0], linkDump.chksum);
		total = link_BuildFrame(linkDumpBuf, LINK_TYPE_DUMP_END, end, LINK_DUMPEND_LEN);
		linkDump.state = 0;
		link_DmaStart(linkDumpBuf, total);
		return;
	}

	link_Put16(&pl[0], (s16)linkDump.blk);
	memcpy(&pl[2], (const u8 *)&run_data[(u16)linkDump.blk * LINK_SCOPE_PTS_PER_BLK],
	       LINK_SCOPE_PTS_PER_BLK * 8);
	n = 0;
	{
		u16 i;
		RunData *p = &run_data[(u16)linkDump.blk * LINK_SCOPE_PTS_PER_BLK];
		for (i = 0; i < LINK_SCOPE_PTS_PER_BLK; i++)
			n = (u16)(n + (u16)p[i].speedl);
	}
	linkDump.chksum += (s32)n;
	{
		u16 flen = link_BuildFrame(linkDumpBuf, LINK_TYPE_DUMP_BLK, pl, LINK_DUMPBLK_LEN);
		linkDump.blk++;
		link_DmaStart(linkDumpBuf, flen);
	}
}

/*-------------------------------------  墙图回传  -------------------------------------*/
static void link_SendMap(void)
{
	u8 pl[LINK_MAP_LEN];
	u16 o = 0;
	u8 x, y;
	pl[o++] = (u8)mazeState.mousePos.cX;
	pl[o++] = (u8)mazeState.mousePos.cY;
	pl[o++] = mazeState.mouseDirection;
	pl[o++] = mazeState.mouseTask;
	for (x = 0; x < MAZETYPE; x++)
		for (y = 0; y < MAZETYPE; y++)
			pl[o++] = mazeState.mapWall[x][y];
	for (x = 0; x < MAZETYPE; x++)
		for (y = 0; y < MAZETYPE; y++)
			pl[o++] = mazeState.mapVisited[x][y];
	link_SendFrame(LINK_TYPE_MAP, pl, LINK_MAP_LEN);
}

/*-------------------------------------  命令解析工具  -------------------------------------*/
static char *link_SkipSp(char *p)
{
	while (*p == ' ' || *p == '\t')
		p++;
	return p;
}

/**
 * @brief  匹配并消费一个 token(以空格/制表/结束为界)
 * @param  p 指针的指针
 * @param  tok 待匹配 token
 * @return 1=匹配 0=不匹配(不推进指针)
 */
static u8 link_TokIs(char **p, const char *tok)
{
	u8 n = 0;
	char *q;
	*p = link_SkipSp(*p);
	q = *p;
	while (tok[n])
	{
		if (q[n] != tok[n])
			return 0;
		n++;
	}
	if (q[n] != ' ' && q[n] != '\t' && q[n] != '\0')
		return 0;
	*p = q + n;
	return 1;
}

static s32 link_TokNum(char **p)
{
	s32 v = 0;
	u8 neg = 0;
	*p = link_SkipSp(*p);
	if (**p == '-')
	{
		neg = 1;
		(*p)++;
	}
	while (**p >= '0' && **p <= '9')
	{
		v = v * 10 + (s32)(**p - '0');
		(*p)++;
	}
	return neg ? -v : v;
}

/**
 * @brief  解析 Q16.16 定点数, 支持 "53.2015" 这类十进制写法
 * @param  p 指针的指针
 * @param  out 输出 Q16.16
 * @return 1=成功 0=格式错误或超范围
 * @note   全程纯整数运算(禁止 atof: 在 F1 上是毫秒级软件浮点, 不能进 ISR)。
 *         小数部分最多 4 位, 保证 fp*65536 不溢出 u32(9999*65536≈6.55e8 < 4.29e9)。
 *         需要完整 6 位小数精度时请改用 SETQ 直接下发 Q16.16 整数。
 */
static u8 link_TokQ16(char **p, s32 *out)
{
	char *q;
	u8 fd = 0, neg = 0;
	u32 ip = 0, fp = 0, div = 1, mul;
	*p = link_SkipSp(*p);
	q = *p;
	if (*q == '-')
	{
		neg = 1;
		q++;
	}
	if (*q < '0' || *q > '9')
		return 0;
	while (*q >= '0' && *q <= '9')
	{
		ip = ip * 10u + (u8)(*q - '0');
		q++;
	}
	if (*q == '.')
	{
		q++;
		while (*q >= '0' && *q <= '9' && fd < 4)
		{
			fp = fp * 10u + (u8)(*q - '0');
			div *= 10u;
			fd++;
			q++;
		}
	}
	if (ip > 32767u)
		return 0;
	mul = ip << 16;
	if (div > 1u)
		mul += (fp * 65536u) / div;
	*out = neg ? -(s32)mul : (s32)mul;
	*p = q;
	return 1;
}

/**
 * @brief  取下一个空格分隔的 token(就地以 '\0' 结尾)
 * @param  p 指针的指针
 * @return token 起始地址
 */
static char *link_TokWord(char **p)
{
	char *q;
	*p = link_SkipSp(*p);
	q = *p;
	while (**p && **p != ' ' && **p != '\t')
		(*p)++;
	if (**p)
	{
		**p = '\0';
		(*p)++;
	}
	return q;
}

/*-------------------------------------  应答  -------------------------------------*/
/**
 * @brief  回复一条文本应答, 并记录状态供幂等重放
 * @param  seq 命令序号(可为负, 表示未提供)
 * @param  status 状态串(OK / ERR_xxx)
 * @return none
 * @note   记录状态是为了让"重发同一命令"时直接重放上次结果, 而不会重复执行副作用
 *         (例如重复写参数、重复触发标定动作)。
 */
static void link_Ack(s32 seq, const char *status)
{
	u8 i;
	link_TxStr("ACK ");
	link_TxInt(seq);
	link_TxPut(' ');
	link_TxStr(status);
	link_TxStr("\r\n");
	if (seq >= 0)
	{
		for (i = 0; i < 13 && status[i]; i++)
			linkLastStatus[i] = (u8)status[i];
		linkLastStatus[i] = 0;
	}
}

/*-------------------------------------  命令分发  -------------------------------------*/
static u8 link_CalItemToId(const char *s)
{
	if (!strcmp(s, "GYRO"))
		return LINK_CAL_GYRO;
	if (!strcmp(s, "WALLDIST"))
		return LINK_CAL_WALLDIST;
	if (!strcmp(s, "IRDATA"))
		return LINK_CAL_IRDATA;
	if (!strcmp(s, "GYRORATIO"))
		return LINK_CAL_GYRORATIO;
	if (!strcmp(s, "ENCANGLE"))
		return LINK_CAL_ENCANGLE;
	return 0;
}

/**
 * @brief  执行一条已通过 CRC 校验的命令
 * @param  line 命令部分(已去掉 *crc 与 #seq)
 * @param  seq  命令序号(无则 -1)
 * @return none
 * @note   所有应答都是文本行; 二进制只用于遥测上行, 两者互不干扰。
 */
static void link_ExecCmd(char *line, s32 seq)
{
	char *p = line;
	char *w;
	u16 id;
	s32 v;

	/* ================= PING / VER ================= */
	if (link_TokIs(&p, "PING"))
	{
		link_TxStr("PONG ");
		link_TxInt(LINK_PROTO_VER);
		link_TxPut(' ');
		link_TxInt(LINK_FW_VER);
		link_TxPut(' ');
		link_TxInt(MAZETYPE);
		link_TxStr("\r\n");
		link_Ack(seq, "OK");
		return;
	}

	if (link_TokIs(&p, "VER"))
	{
		link_TxStr("VER proto=");
		link_TxInt(LINK_PROTO_VER);
		link_TxStr(" fw=");
		link_TxInt(LINK_FW_VER);
		link_TxStr(" mazetype=");
		link_TxInt(MAZETYPE);
		link_TxStr(" txbuf=");
		link_TxInt(LINK_TX_BUF_SIZE);
		link_TxStr(" scopedepth=");
		link_TxInt(LINK_SCOPE_LEN);
		link_TxStr("\r\n");
		link_Ack(seq, "OK");
		return;
	}

	/* ================= GET ================= */
	if (link_TokIs(&p, "GET"))
	{
		w = link_TokWord(&p);
		if (!strcmp(w, "ALL"))
		{
			u16 i;
			for (i = 0; i < LINK_P_NUM; i++)
			{
				link_TxStr("P ");
				link_TxInt(linkParam[i].id);
				link_TxPut(' ');
				link_TxInt(linkParam[i].q);
				link_TxStr("\r\n");
			}
			link_Ack(seq, "OK");
			return;
		}
		if (!link_NameToId(w, &id))
		{
			link_Ack(seq, "ERR_NAME");
			return;
		}
		{
			u16 idx;
			if (link_ParamFind(id, &idx))
			{
				link_TxStr("P ");
				link_TxInt(id);
				link_TxPut(' ');
				link_TxInt(linkParam[idx].q);
				link_TxStr("\r\n");
				link_Ack(seq, "OK");
			}
			else
			{
				link_Ack(seq, "ERR_NAME");
			}
		}
		return;
	}

	/* ================= SETQ: 直接下发 Q16.16 整数(上位机用, 无精度损失) ================= */
	if (link_TokIs(&p, "SETQ"))
	{
		w = link_TokWord(&p);
		if (!link_NameToId(w, &id))
		{
			link_Ack(seq, "ERR_NAME");
			return;
		}
		v = link_TokNum(&p);
		if (!link_ParamSet(id, v)) /* v 即 Q16.16 原始整数(如 53.2015 -> 3486565) */
		{
			link_Ack(seq, "ERR_NAME");
			return;
		}
		link_Ack(seq, "OK");
		return;
	}

	/* ================= SET: 十进制写法(人手敲用, 最多 4 位小数) =================
	 * 注意 link_TokIs 只在整个 token 匹配时才推进指针, 因此 "SETQ ..." 不会误入此分支。 */
	if (link_TokIs(&p, "SET"))
	{
		w = link_TokWord(&p);
		if (!link_NameToId(w, &id))
		{
			link_Ack(seq, "ERR_NAME");
			return;
		}
		if (!link_TokQ16(&p, &v))
		{
			link_Ack(seq, "ERR_VALUE");
			return;
		}
		if (!link_ParamSet(id, v))
		{
			link_Ack(seq, "ERR_NAME");
			return;
		}
		link_Ack(seq, "OK");
		return;
	}

#ifdef MOUSE_LESSON_LAB
	/* ================= LESSON: 课程调参实验启停 =================
	 * 语法: LESSON START <exp> [a] [b] [c] [d] | LESSON STOP | LESSON STATUS
	 * 参数含义随实验而定(见 APP/lesson_lab.c 的 LESSONLAB_Start 注释):
	 *      2 编码器测距 : a=速度cm/s b=目标距离mm        c=时间上限ms
	 *      3 匀变速直行 : a=巡航速度 b=加速ms c=匀速ms    d=减速ms
	 *      5 陀螺标定   : a=目标角度 b=旋转速度           c=时间上限ms
	 *      6 多传感器   : a=速度cm/s b=目标距离mm        c=时间上限ms
	 * 实验结束时固件主动上行一行 "LESSON DONE ..."; 上位机据此停车并回传 1kHz 日志。 */
	if (link_TokIs(&p, "LESSON"))
	{
		if (link_TokIs(&p, "START"))
		{
			s32 exp = link_TokNum(&p);
			s32 a = link_TokNum(&p);
			s32 b = link_TokNum(&p);
			s32 c = link_TokNum(&p);
			s32 d = link_TokNum(&p);
			u8 rc;

			if (linkEStop)
			{
				link_Ack(seq, "ERR_ESTOP");
				return;
			}
			if (linkMove.state != LINK_MOVE_NONE)
			{
				link_Ack(seq, "ERR_BUSY"); /* 一次只允许一个会动的东西 */
				return;
			}
			rc = LESSONLAB_Start((u16)exp, a, b, c, d);
			if (rc == LL_OK)
				link_Ack(seq, "OK");
			else if (rc == LL_ERR_BUSY)
				link_Ack(seq, "ERR_BUSY");
			else if (rc == LL_ERR_VALUE)
				link_Ack(seq, "ERR_VALUE");
			else
				link_Ack(seq, "ERR_EXP");
			return;
		}
		if (link_TokIs(&p, "STOP"))
		{
			LESSONLAB_Stop();
			link_Ack(seq, "OK");
			return;
		}
		if (link_TokIs(&p, "STATUS"))
		{
			link_TxStr("LESSON STATUS ");
			link_TxInt((s32)LESSONLAB_Exp());
			link_TxPut(' ');
			link_TxInt((s32)LESSONLAB_Running());
			link_TxStr("\r\n");
			link_Ack(seq, "OK");
			return;
		}
		link_Ack(seq, "ERR_VALUE");
		return;
	}
#endif /* MOUSE_LESSON_LAB */

	/* ================= SAVE / RESET ================= */
	if (link_TokIs(&p, "SAVE"))
	{
		if (motionCtrl.task != MOTION_TASK_NULL || linkSrv.state != LINK_SRV_NONE)
		{
			link_Ack(seq, "ERR_BUSY");
			return;
		}
#ifdef MOUSE_LESSON_LAB
		if (LESSONLAB_Running())
		{
			/* 实验中禁止写 Flash: 擦写期间的取指停顿会打断 1kHz 控制环 */
			link_Ack(seq, "ERR_BUSY");
			return;
		}
#endif
		link_CalibSave();
#ifdef MOUSE_LESSON_LAB
		link_LessonSave(); /* 课程参数落到独立页 100, 不碰生产参数页 99 */
#endif
		link_Ack(seq, "OK");
		return;
	}

	if (link_TokIs(&p, "RESET"))
	{
		link_CalibErase();
#ifdef MOUSE_LESSON_LAB
		link_LessonErase(); /* 实验参数随生产参数一起清掉: "交比赛固件"时不必单独清理 */
#endif
		/* 只擦除参数页。RAM 中 sysCfg 保持当前值不动, 因此 RESET 的完整效果
		 * (回落到 ISR_Init 里的源码默认值)在下次上电由 LINK_Init 体现。
		 * 这样做的原因: 运行中把 sysCfg 改回默认值会让机器人的运动参数突变,
		 * 反而危险; 让它随重启自然生效更安全。 */
		link_Ack(seq, "OK");
		return;
	}

	/* ================= TARE / STOP / ESTOP ================= */
	if (link_TokIs(&p, "TARE"))
	{
		MOTION_SetAngle(0);
		linkEncDiffAcc = 0;
		link_Ack(seq, "OK");
		return;
	}

	if (link_TokIs(&p, "STOP"))
	{
		link_StopMotion(LINK_RUN_REASON_STOP);
#ifdef MOUSE_TEST_MODE
		/* 测试模式下 STOP 兼作"解急停" —— 这是操作者重新取得控制权的唯一入口。
		 * 同时把 sleepmode 清回 0, 使急停后板子仍在线(传感器/链路继续工作)。
		 * 比赛固件保持原语义: 急停后必然休眠, 不接受远程复位。 */
		linkEStop = 0;
		emergMon.active = 0;
		emergMon.delay = 0;
		speedSt.sleepmode = 0;
#endif
		link_Ack(seq, "OK");
		return;
	}

	if (link_TokIs(&p, "ESTOP"))
	{
		/* 若正在 MOVE RUN, 先按 RUN 的格式上报一次, 让上位机拿到统一的明细行 */
		link_StopMotion(LINK_RUN_REASON_ESTOP);
		linkLogReady = 1; /* 刚急停, 正是最想看现场波形的时刻: 保留日志 */
		emergMon.active = 1; /* 触发既有急停通路(比赛固件会 200ms 后休眠; 测试模式不休眠) */
		linkEStop = 1;       /* 锁存: 之后的 MOVE/CAL 一律 ERR_ESTOP, 直到显式 STOP */
		link_Ack(seq, "OK");
		return;
	}

	/* ================= RATE ================= */
	/* ================= STREAM 遥测总开关 ================= */
	if (link_TokIs(&p, "STREAM"))
	{
		/* 注意: 不能用 "A || B" 短路后再判关键字 —— 短路时关键字已被消费, 见附录 C */
		if (link_TokIs(&p, "ON"))
		{
			linkStreamOn = 1;
			link_Ack(seq, "OK");
			return;
		}
		if (link_TokIs(&p, "OFF"))
		{
			linkStreamOn = 0;
			link_Ack(seq, "OK");
			return;
		}
		link_Ack(seq, "ERR_VALUE");
		return;
	}

	/* ================= RATE: 快帧速率 =================
	 * 档位按"链路可持续吞吐"设, 上限刻意压住 —— 实机实测该蓝牙透传链路在
	 * 数百 B/s 量级才稳定, 一旦超限就完全堵死且需模块重新上电(见 link_Telemetry)。
	 * 需要高分辨率波形请用 SCOPE(本地 1kHz 缓冲 + 事后 dump), 不要盲目提速率。 */
	if (link_TokIs(&p, "RATE"))
	{
		v = link_TokNum(&p);
		if (v == 100)
			linkFastDiv = LINK_FAST_DIV_100HZ;
		else if (v == 50)
			linkFastDiv = LINK_FAST_DIV_50HZ;
		else if (v == 20)
			linkFastDiv = LINK_FAST_DIV_20HZ;
		else if (v == 10)
			linkFastDiv = 100;
		else if (v == 5)
			linkFastDiv = 200;
		else if (v == 2)
			linkFastDiv = 500;
		else
		{
			link_Ack(seq, "ERR_VALUE");
			return;
		}
		link_Ack(seq, "OK");
		return;
	}

	/* ================= SCOPE ================= */
	if (link_TokIs(&p, "SCOPE"))
	{
		if (link_TokIs(&p, "START"))
		{
			if (linkDump.state == 1)
			{
				link_Ack(seq, "ERR_BUSY");
				return;
			}
			flashSt.flashenable = 0; /* 独占 run_data[]: 关闭既有黑匣子写入 */
			linkScope.state = LINK_SCOPE_RUN;
			linkScope.idx = 0;
			linkScope.cnt = 0;
			link_Ack(seq, "OK");
			return;
		}
		if (link_TokIs(&p, "STOP"))
		{
			if (linkScope.state == LINK_SCOPE_RUN)
				linkScope.state = LINK_SCOPE_FROZEN;
			link_Ack(seq, "OK");
			return;
		}
		if (link_TokIs(&p, "DUMP"))
		{
			if (linkDump.state == 1)
			{
				link_Ack(seq, "ERR_BUSY");
				return;
			}
			link_StartDump();
			link_Ack(seq, "OK");
			return;
		}
		link_Ack(seq, "ERR_VALUE");
		return;
	}

	/* ================= MAP ================= */
	if (link_TokIs(&p, "MAP"))
	{
		if (link_TokIs(&p, "DUMP"))
		{
			link_SendMap();
			link_Ack(seq, "OK");
			return;
		}
		link_Ack(seq, "ERR_VALUE");
		return;
	}

	/* ================= ARM / MAZE —— 时间同步与远程发车 =================
	 * 时间同步这一块**不依赖任何测试档**: 生产固件也编译、也能用。
	 * 上位机流程通常是: ARM(武装计时 + 点亮 1Hz 基准灯 + 记发车时刻)
	 *                   -> MAZE RUN(让电脑鼠开始跑无记忆迷宫) 或 MOVE RUN 等。
	 * 两条分开是有意的: ARM 之后"任何动作"都被同一时间基准覆盖, 不限于跑迷宫。 */
	if (link_TokIs(&p, "ARM"))
	{
		linkArmed = 1;
		linkArmMs = linkTimeMs;
		linkTimeLed = 1;
		ledBeaconLock = 1; /* 基准灯独占 LED, 保证方波干净 */
		LED4 = 0;          /* 低电平点亮 */
		/* 异步回执: 上位机据此知道"发车时刻"已落在设备的哪个时基读数上。
		 * 与 TIME 帧重复一次是有意的 —— 单条文本丢了也能从 1Hz 帧自愈。 */
		link_TxStr("ARMED ");
		link_TxInt((s32)linkArmMs);
		link_TxStr("\r\n");
		link_Ack(seq, "OK");
		return;
	}

	if (link_TokIs(&p, "MAZE"))
	{
		/* MAZE RUN —— 请 main() 进入无记忆走迷宫(LESSON_Blind8)。
		 * 本命令只置请求位: 真正"跑"由主循环执行, 命令处理在中断里,
		 * 这里绝不能在 ISR 里跑那个 while(1)。 */
		if (link_TokIs(&p, "RUN"))
		{
#ifndef MOUSE_DATA_LOG
			/* 只有数据收集档的 main() 会等这条命令。其余固件若回 OK 就是撒谎
			 * (主机以为发车了, 其实没有任何东西会跑), 所以明确拒绝。 */
			link_Ack(seq, "ERR_VALUE");
			return;
#else
			if (linkMazeReq || linkMazeRun)
			{
				link_Ack(seq, "ERR_BUSY");
				return;
			}
			linkMazeReq = 1;
			link_Ack(seq, "OK");
			return;
#endif
		}
		link_Ack(seq, "ERR_VALUE");
		return;
	}

	/* ================= MOVE ================= */
	if (link_TokIs(&p, "MOVE"))
	{
#ifdef MOUSE_LESSON_LAB
		/* 课程实验正在跑时拒绝一切 MOVE: 两者都在写 speedSt 的速度目标,
		 * 同时存在会互相覆盖 —— 宁可明确回 ERR_BUSY, 也不要"半听谁的话"。 */
		if (LESSONLAB_Running())
		{
			link_Ack(seq, "ERR_BUSY");
			return;
		}
#endif
		/* ---- MOVE RUN: 受"时间 + 红外"双护栏约束的远程运动(电机远程控制实验) ----
		 * 用法: MOVE RUN <spL> <spR> [<ms>] [<ir_mm>]
		 *   spL/spR : 左右轮目标速度(cm/s), 可正可负, 可为 0(单轮)；不能同时为 0
		 *   ms      : 最长运行时间, 省略=2000ms, 上限 LINK_RUN_MS_MAX
		 *   ir_mm   : 红外停车阈值(mm), 省略=10mm(=1cm)；**负值=关闭红外护栏**
		 * 完成回: MOVEDONE RUN <REASON> <elapsed_ms> <ir_min> <chan> <dL> <dR> <vpkL> <vpkR>
		 * 护栏在 1ms ISR 里判定, 不依赖上位机在线。 */
		if (link_TokIs(&p, "RUN"))
		{
			s32 spL = link_TokNum(&p);
			s32 spR = link_TokNum(&p);
			s32 ms = link_TokNum(&p);
			s32 ir = link_TokNum(&p);

			if (linkEStop)
			{
				link_Ack(seq, "ERR_ESTOP");
				return;
			}
			if (motionCtrl.task != MOTION_TASK_NULL || linkSrv.state != LINK_SRV_NONE || linkCal.active)
			{
				link_Ack(seq, "ERR_BUSY");
				return;
			}
			if ((spL == 0 && spR == 0) || spL > LINK_RUN_SPEED_MAX || spL < -LINK_RUN_SPEED_MAX ||
			    spR > LINK_RUN_SPEED_MAX || spR < -LINK_RUN_SPEED_MAX)
			{
				link_Ack(seq, "ERR_VALUE");
				return;
			}
			if (ms <= 0)
				ms = LINK_RUN_MS_DEF;
			if (ms > LINK_RUN_MS_MAX)
				ms = LINK_RUN_MS_MAX;
			/* ir<0 = 显式关闭红外护栏(便于单独验证时间护栏); ir==0/省略 = 默认 10mm。
			 * 注意 link_TokNum 对"缺省"和"写 0"都返回 0, 所以要区分"关闭"只能用负值。 */
			if (ir < 0)
				ir = 0;
			else if (ir == 0)
				ir = LINK_RUN_IR_DEF;
			if (ir > LINK_RUN_IR_MAX)
				ir = LINK_RUN_IR_MAX;

			linkMove.state = LINK_MOVE_RUN;
			linkMove.elapsed = 0;
			linkMove.limit = (u32)ms;
			linkMove.irMm = (u32)ir;
			linkMove.irMin = 0xFFFFFFFFu;
			linkMove.irWhich = 0;
			linkMove.vmaxL = 0;
			linkMove.vmaxR = 0;
			linkMove.runStartL = odomStr.distL + odomStr.distLCycle * ENCODER_ARR_VALUE;
			linkMove.runStartR = odomStr.distR + odomStr.distRCycle * ENCODER_ARR_VALUE;

			motionCtrl.task = MOTION_TASK_NULL;
			speedSt.freemode = 0;
			speedSt.speedTargetL = spL;
			speedSt.speedTargetR = spR;

			/* 双流的"详细日志"这一路: 运动一开始就打开 1kHz 本地记录, 全程零带宽占用,
			 * 停止时由 link_MoveFinishRun 冻结。于是"运动时只跑实时流、停止后再回传
			 * 高分辨率日志"不需要上位机额外配合(方案文档 §5.5 的分工)。 */
			flashSt.flashenable = 0; /* 独占 run_data[]: 关闭既有黑匣子写入 */
			linkScope.state = LINK_SCOPE_RUN;
			linkScope.idx = 0;
			linkScope.cnt = 0;
			linkLogReady = 0;

			link_Ack(seq, "OK");
			return;
		}

		if (link_TokIs(&p, "FWD"))
		{
			u32 pulses = (u32)link_TokNum(&p);
			s32 sp = link_TokNum(&p);
			if (linkEStop)
			{
				link_Ack(seq, "ERR_ESTOP");
				return;
			}
			if (motionCtrl.task != MOTION_TASK_NULL)
			{
				link_Ack(seq, "ERR_BUSY");
				return;
			}
			if (pulses == 0)
			{
				link_Ack(seq, "ERR_VALUE");
				return;
			}
			if (sp <= 0)
				sp = LINK_MOVE_SPEED_DEF;
			linkMove.state = LINK_MOVE_FWD;
			linkMove.target = pulses;
			linkMove.speed = (u16)sp;
			linkMove.pStartL = odomStr.distL + odomStr.distLCycle * ENCODER_ARR_VALUE;
			linkMove.pStartR = odomStr.distR + odomStr.distRCycle * ENCODER_ARR_VALUE;
			motionCtrl.task = MOTION_TASK_NULL;
			speedSt.freemode = 0;
			speedSt.speedTargetL = sp;
			speedSt.speedTargetR = sp;
			link_Ack(seq, "OK");
			return;
		}
		if (link_TokIs(&p, "ROT"))
		{
			s32 sp = link_TokNum(&p);
			s32 ms = link_TokNum(&p);
			if (linkEStop)
			{
				link_Ack(seq, "ERR_ESTOP");
				return;
			}
			if (motionCtrl.task != MOTION_TASK_NULL)
			{
				link_Ack(seq, "ERR_BUSY");
				return;
			}
			if (sp == 0)
			{
				link_Ack(seq, "ERR_VALUE");
				return;
			}
			if (ms <= 0)
				ms = 500;
			linkMove.state = LINK_MOVE_ROT;
			linkMove.elapsed = 0;
			linkMove.limit = (u32)ms;
			motionCtrl.task = MOTION_TASK_NULL;
			speedSt.freemode = 0;
			speedSt.speedTargetL = sp;
			speedSt.speedTargetR = -sp;
			link_Ack(seq, "OK");
			return;
		}
		link_Ack(seq, "ERR_VALUE");
		return;
	}

	/* ================= CAL ================= */
	if (link_TokIs(&p, "CAL"))
	{
		u8 item;
		w = link_TokWord(&p);
		item = link_CalItemToId(w);
		if (item == 0)
		{
			link_Ack(seq, "ERR_NAME");
			return;
		}
		if (link_TokIs(&p, "START"))
		{
			/* 需要电机转的两项在急停锁存期间必须一并拒绝, 否则"锁死"是假的 ——
			 * 静态三项(GYRO/WALLDIST/IRDATA)不涉及运动, 照常放行。 */
			if (linkEStop && (item == LINK_CAL_GYRORATIO || item == LINK_CAL_ENCANGLE))
			{
				link_Ack(seq, "ERR_ESTOP");
				return;
			}
			link_CalibService(item, LINK_ACT_START);
			link_Ack(seq, "OK");
			return;
		}
		if (link_TokIs(&p, "SAMPLE"))
		{
			link_CalibService(item, LINK_ACT_SAMPLE);
			link_Ack(seq, "OK");
			return;
		}
		if (link_TokIs(&p, "ABORT"))
		{
			link_CalibService(item, LINK_ACT_ABORT);
			link_Ack(seq, "OK");
			return;
		}
		link_Ack(seq, "ERR_VALUE");
		return;
	}

	link_Ack(seq, "ERR_CMD");
}

/*-------------------------------------  接收行处理  -------------------------------------*/
/**
 * @brief  处理一条完整接收行
 * @param  buf 行缓冲
 * @param  len 字节数(不含 CR/LF)
 * @return none
 * @note   行格式: <CMD> [args] [#seq] *<CRC16 HEX4>; CRC 覆盖 '*' 之前的全部字节。
 *         幂等: seq 与 CRC 都与上一条相同则不重复执行, 直接重放上次状态。
 */
static void link_HandleLine(char *buf, u8 len)
{
	char *star = 0;
	char *hash = 0;
	char *p;
	s32 seq = -1;
	u16 crcCalc, crcRecv = 0;
	u16 i, cmdLen;

	if (len == 0)
		return;
	if (len > 63)
		len = 63;
	buf[len] = '\0';
	cmdLen = (u16)len;

	/* ---- 取 '*' 后的 4 位十六进制 CRC ---- */
	for (i = 0; i < cmdLen; i++)
		if (buf[i] == '*')
			star = &buf[i];
	if (!star || (u16)(cmdLen - (u16)(star - buf)) < 5u)
	{
		link_Ack(-1, "ERR_NOCRC");
		return;
	}
	for (i = 1; i <= 4; i++)
	{
		u8 c = (u8)star[i];
		u8 v;
		if (c >= '0' && c <= '9')
			v = (u8)(c - '0');
		else if (c >= 'A' && c <= 'F')
			v = (u8)(c - 'A' + 10);
		else if (c >= 'a' && c <= 'f')
			v = (u8)(c - 'a' + 10);
		else
		{
			link_Ack(-1, "ERR_CRC");
			return;
		}
		crcRecv = (u16)((crcRecv << 4) | v);
	}
	crcCalc = link_Crc16((const u8 *)buf, (u16)(star - buf));
	*star = '\0';
	if (crcCalc != crcRecv)
	{
		link_Ack(-1, "ERR_CRC");
		return;
	}

	/* ---- 可选 '#seq' ---- */
	for (i = 0; i < (u16)strlen(buf); i++)
		if (buf[i] == '#')
			hash = &buf[i];
	if (hash)
	{
		*hash = '\0';
		p = hash + 1;
		seq = link_TokNum(&p);
	}

	/* ---- 幂等: 相同 seq 且相同 CRC -> 重放上次应答 ---- */
	if (seq >= 0 && seq == linkLastSeq && crcRecv == linkLastCrc)
	{
		link_TxStr("ACK ");
		link_TxInt(seq);
		link_TxPut(' ');
		link_TxStr((const char *)linkLastStatus);
		link_TxStr("\r\n");
		return;
	}
	linkLastSeq = seq;
	linkLastCrc = crcRecv;

	link_ExecCmd(buf, seq);
}

/*-------------------------------------  初始化  -------------------------------------*/
void LINK_Init(void)
{
	linkTxHead = 0;
	linkTxTail = 0;
	linkTxInflight = 0;
	linkTick = 0;
	linkSeq = 0;
	/* 默认快帧 20Hz。
	 * 实机实测(见 docs 附录 F): 这条蓝牙透传链路在约 1.5KB/s 处是"悬崖" ——
	 * 超过就完全收不到(模块缓冲饱和后停止转发)。原先 250Hz(合计 6.0KB/s)
	 * 与后来 100Hz(合计 3.0KB/s) 都在悬崖之外, 所以整条链双向堵死。
	 * 现按 1/3 余量取: 快帧 20Hz + 中帧 5Hz + 慢帧 1Hz = 511 B/s。
	 * 需要高分辨率波形时用 SCOPE(本地 1kHz 缓冲 + 事后 dump), 不要提实时流速率。 */
	linkFastDiv = LINK_FAST_DIV_5HZ;
	linkStreamOn = 0; /* 上电默认静默: 等上位机连上后发 STREAM ON 才开流,
	                   * 避免在蓝牙链路建好之前就把模块缓冲灌满(见 link_Telemetry) */
	linkDrop = 0;
	linkFrames = 0;
	linkLastSeq = -1;
	linkLastCrc = 0;
	linkLastStatus[0] = 0;
	linkScope.state = LINK_SCOPE_IDLE;
	linkScope.idx = 0;
	linkScope.cnt = 0;
	linkScope.startMs = 0;
	linkDump.state = 0;
	linkDump.blk = 0;
	linkMove.state = LINK_MOVE_NONE;
	linkSrv.state = LINK_SRV_NONE;
	linkCal.active = 0;
	linkCal.needSample = 0;
	linkEStop = 0;    /* 上电不锁存: 只有真正急停过才锁 */
	linkLogReady = 0;

	/* 时间同步: 上电时基从 0 起走; 未武装(等 ARM 命令发车) */
	linkTimeMs = 0;
	linkArmMs = 0;
	linkArmed = 0;
	linkTimeLed = 0;
	linkMazeReq = 0;
	linkMazeRun = 0;
	ledBeaconLock = 0; /* 未发车前 LED 照常充当状态灯 */

	/* ================= RX 优先级修正(关键) =================
	 * 现状: SysTick 占复位默认的抢占优先级 0(全工程无任何代码写 SCB->SHP),
	 *       而 USART1 RX 被 usart.c 的 MY_NVIC_Init(3, 3, ..., 2) 设为最低
	 *       => SysTick 可以抢占 RX, 反之不行。
	 *       若 SysTick 的 1ms 处理耗时 100-200us(F1 无 FPU, PID 全 double 软件浮点),
	 *       期间 RX 的 DR 未被读走, 后续到达的字节全部触发 ORE 被丢弃(成片丢, 非偶发)。
	 * 处理: 把 SysTick 的抢占降到 1, RX 提到 0, 让约 2.5us 的 RX ISR 可以抢占 SysTick。
	 * 说明: 中断分组为 2 位抢占 / 2 位子优先级(见 usart.c), 抢占位占优先级字节的 bit7:6,
	 *       故 SysTick 需要 0x40(抢占 1), USART1 需要 0x00(抢占 0)。
	 *       此处直接写寄存器而非 NVIC_SetPriority(), 以免 CMSIS 的移位约定产生歧义。 */
	SCB->SHP[11] = 0x40;          /* SysTick: 异常号 15 -> SHP[11], 抢占 1 / 子 0 */
	NVIC->IP[USART1_IRQn] = 0x00; /* USART1 RX: 抢占 0 / 子 0 */

	/* ================= TX DMA ================= */
	link_DmaInit();

	/* ================= 标定参数 =================
	 * 先取源码默认值, 再尝试用 Flash page99 覆盖。
	 * LINK_Init 在 HARDWARE_Init 之后调用, 此时 ISR_Init 已给 sysCfg 赋过默认值,
	 * 所以这里直接覆盖即可 —— ISR_Init 零改动。 */
	link_ParamFromSys();
	if (!link_CalibLoad())
		link_ParamFromSys(); /* 载入失败时确保参数表与源码默认值一致 */

#ifdef MOUSE_LESSON_LAB
	/* ================= 课程调参参数(独立页 100) =================
	 * 顺序: 先置默认增益(= motor.h 红线常量的引用), 再据此建表,
	 *       最后尝试用 page100 覆盖 —— 没有有效参数就用默认值, 与生产参数的做法一致。 */
	LESSONLAB_Init();
	link_LessonFromSys();
	if (!link_LessonLoad())
		link_LessonFromSys();
#endif

	linkEncPrevL = odomStr.encL;
	linkEncPrevR = odomStr.encR;
	linkEncDiffAcc = 0;
}

/*-------------------------------------  每毫秒  -------------------------------------*/
void LINK_Tick(void)
{
	u16 len;

	linkTick++;
	linkTimeMs++; /* 全局毫秒时基(独立于任何测试档): 与 linkTick 不同, u32 不回绕 */

	/* 0. 时间基准灯: 发车后以 1Hz(50% 占空比)闪烁, 供外部(摄像头/光电/人眼)
	 *    与回传的时间戳做互相印证。这里直接写引脚(不走 LED_On/Off),
	 *    因为 ledBeaconLock 已把所有状态灯的写入挡掉了 —— 保证方波干净。 */
	if (linkArmed)
	{
		u8 lv = (u8)(((linkTimeMs - linkArmMs) % (u32)LINK_TIME_DIV) < (u32)(LINK_TIME_DIV / 2));
		if (lv != linkTimeLed)
		{
			linkTimeLed = lv;
			if (lv)
				LED4 = 0; /* 低电平点亮 */
			else
				LED4 = 1;
		}
	}

	/* 1. 消费接收行。RX ISR 优先级低于 SysTick, 不会打断本段, 故读-解析-清空天然原子。
	 *    若忘记消费 USART_RX_STA 的 bit7, 一行收完后后续所有字节会被 usart.c 直接丢弃。 */
	if (USART_RX_STA & 0x80)
	{
		len = (u16)(USART_RX_STA & 0x3F);
		link_HandleLine((char *)USART_RX_BUF, (u8)len);
		USART_RX_STA = 0;
	}

	/* 2. 原始轮差累计(始终运行, 供角度标定使用) */
	link_EncAccumulate();

	/* 3. 1kHz 环形缓冲采样 */
	link_ScopeSample();

	/* 4. 运动 / 角度扫描 / 标定状态机 */
	link_MoveService();

#ifdef MOUSE_LESSON_LAB
	/* 5. 课程实验引擎 + 结束回报
	 *    与 link_MoveService 并列, 同样跑在 1ms 上下文里 —— 因此实验剖面
	 *    (加速/匀速/减速)也是硬件定时的, 不受上位机抖动影响。
	 *    整段在 #ifdef 之内: 正式固件里连这段代码都不存在。 */
	{
		static char lessonLine[96];
		LESSONLAB_Tick();
		if (LESSONLAB_TakeDone(lessonLine, (u16)sizeof(lessonLine)))
		{
			link_TxStr(lessonLine);
			link_TxStr("\r\n");
		}
	}
#endif
	link_ServoService();
	if (linkCal.active)
		link_CalibService(linkCal.item, LINK_ACT_STEP);

	/* 5. 遥测组帧(先入 TX 环) */
	link_Telemetry();

	/* 6. TX 搬运(必须早于 dump: 让普通帧先占用 DMA, dump 只在环空且 DMA 空闲时才发起) */
	link_TxDrain();

	/* 7. 大帧直发(dump) */
	link_DumpService();
}

/*-------------------------------------  急停通知  -------------------------------------*/
/**
 * @brief  由 isr.c 在 emergMon.active==1 时调用: 把急停锁存到链路层
 * @param  none
 * @return none
 * @note   必须在 SysTick(1ms) 上下文调用, 且会被**每毫秒**调用一次 ——
 *         所以第一件事就是判断是否已经锁存并直接返回(否则 1ms 刷一行文本把链路灌死)。
 *         急停的"停车"动作由 ISR 自己完成(清速度目标 + 任务码), 这里只负责三件事:
 *           1) 锁存 -> 之后 MOVE/CAL 一律 ERR_ESTOP, 必须显式 STOP 才解锁;
 *           2) 冻结 1kHz 环并置"日志就绪", 使急停现场可以被完整回放;
 *           3) 主动上行一行 "ESTOP TRIP", 让上位机不必等到下一帧快帧才知道出了事。
 */
void LINK_EStopTrip(void)
{
	if (linkEStop)
		return; /* 已锁存: 1ms 一次的调用不能重复上报 */

	linkEStop = 1;
	linkMove.state = LINK_MOVE_NONE;
	linkSrv.state = LINK_SRV_NONE;
	linkCal.active = 0;
	linkCal.needSample = 0;
	if (linkScope.state == LINK_SCOPE_RUN)
		linkScope.state = LINK_SCOPE_FROZEN;
	linkLogReady = 1;

	link_TxStr("ESTOP TRIP\r\n");
}

/*-------------------------------------  远程发车  -------------------------------------*/
/**
 * @brief  是否有待处理的远程发车请求(main() 的等待循环用)
 * @param  none
 * @return 1=已收到 MAZE RUN 且尚未启动
 */
u8 LINK_MazeRequested(void)
{
	return linkMazeReq;
}

/**
 * @brief  标记"迷宫已真的开始跑"(由 main() 在进入迷宫前调用)
 * @param  none
 * @return none
 * @note   置位后 TIME 帧的 MAZERUN 标志为 1, 主机可据此确认发车已生效。
 */
void LINK_MazeStarted(void)
{
	linkMazeRun = 1;
}
