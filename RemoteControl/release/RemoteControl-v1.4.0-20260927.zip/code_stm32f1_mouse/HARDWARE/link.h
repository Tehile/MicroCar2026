﻿/*
********************************************************************************************************
*                                               示例代码
*                                             EXAMPLE  CODE
*
*               The code is for internal use only, not for commercial transactions(开源学习,请勿商用).
*               The code ADAPTS the corresponding hardware mouse(代码适配对应人工智能电脑鼠/mouse).
*               the specific details consult the professional(欢迎联系我们).
*       ------------------------------------------------------------------------------------------------
*               Function: link.h —— 蓝牙链路(遥测上行/命令下行/标定服务/参数持久化)
*       ------------------------------------------------------------------------------------------------
*               设计要点(细节见 docs/蓝牙上位机设计方案.md):
*                 - 本模块为**纯新增**, 不改动任何现有业务逻辑与红线数值
*                 - 上行: 二进制帧 AA 55 | LEN(2) | TYPE | SEQ | PAYLOAD | CRC16(2); MODBUS 多项式
*                 - 下行: ASCII 文本行 <CMD> [args] [#seq] *CRC16, 应答亦为文本行
*                 - 与 printf 共存: printf 只产出 0x09-0x7E, 永不产出 0xAA, 故可分流
*                 - 1kHz 环形缓冲复用 flash.c 的 run_data[] (零新增 RAM)
*                 - 发送搬运走 DMA1_Channel4 (USART1_TX), 零 CPU 占用
*********************************************************************************************************
*/

#ifndef _LINK_H_
#define _LINK_H_
#include "main.h"
/*-----------------------------------------  I N C L U D E S  -----------------------------------------*/

/*---------------------------------------  D E F I N I T I O N  ---------------------------------------*/

/* ---- 协议版本 ---- */
#define LINK_PROTO_VER 1
#define LINK_FW_VER 100 /* 1.00 */

/* ---- 帧同步头与开销 ----
 * 布局: AA 55 | LEN(2,LE) | TYPE | SEQ | PAYLOAD(LEN) | CRC16(2,LE)
 * 开销 = 同步2 + 长度2 + 类型1 + 序号1 + CRC2 = 8 字节(不是 7!) */
#define LINK_SYNC0 0xAA
#define LINK_SYNC1 0x55
#define LINK_FRAME_OVERHEAD 8

/* ---- 上行帧类型(二进制) ---- */
#define LINK_TYPE_FAST 0x01 /* 快帧 16B @ 250Hz  转速/角度/pidErr */
#define LINK_TYPE_MID 0x02  /* 中帧 12B @  50Hz  里程/编码器角/陀螺原始 */
#define LINK_TYPE_SLOW 0x03 /* 慢帧 16B @   5Hz  红外/墙/电压/CPU/坐标 */
#define LINK_TYPE_DUMP_HDR 0x04
#define LINK_TYPE_DUMP_BLK 0x05
#define LINK_TYPE_DUMP_END 0x06
#define LINK_TYPE_MAP 0x07 /* 墙图整块 */
/* 时间同步帧(见 docs/数据收集与时间同步.md)
 *   payload 12B: upMs(u32 LE) | armMs(u32 LE) | led(u8) | flags(u8) | rsvd(u16)
 *   以 1Hz 发送, 与"1Hz 时间基准灯"同一节拍 —— 软件戳与物理灯互相印证。
 *   该帧不依赖任何测试档: 生产固件也编译、也发送(只要 STREAM ON)。 */
#define LINK_TYPE_TIME 0x08

/* ---- 各帧载荷长度 ---- */
#define LINK_FAST_LEN 16
#define LINK_MID_LEN 12
#define LINK_SLOW_LEN 16
#define LINK_DUMPHDR_LEN 12 /* payload: totalPts(u16) ptsPerBlk(u8) channels(u8)
                             *          filled(u16) start(u16) startMs(u32)
                             * startMs = 回传数组中最早一点的绝对毫秒时基(时间同步用) */
#define LINK_DUMPBLK_LEN (2 + LINK_SCOPE_PTS_PER_BLK * 8)
#define LINK_DUMPEND_LEN 4
#define LINK_TIME_LEN 12 /* 时间同步帧 payload: 见 LINK_TYPE_TIME */

/* ---- 时间同步(相对独立于校准与各测试档; 见 docs/数据收集与时间同步.md) ----
 * 毫秒时基 linkTimeMs 由 SysTick 每 1ms 自增(u32, 49 天不绕), 上电起走。
 * 收到 ARM 命令即"发车": 记下基准 armMs 并点亮 1Hz 时间基准灯(50% 占空比)。
 * 回传链路两条:
 *   1) 新帧 LINK_TYPE_TIME @1Hz —— 完整 u32 upMs + armMs, 供上位机建立绝对映射;
 *   2) 快帧保留字节 f[15] —— upMs 低 8 位, 使**每个快帧**都能被定位到 256ms 窗口内。 */
#define LINK_TIME_LED 4    /* 时间基准灯 = LED4(PC7)。见 led.h 的 ledBeaconLock */
#define LINK_TIME_DIV 1000 /* 时间同步帧周期(ms) = 1Hz, 与基准灯同拍 */

#define LINK_TIME_FLAG_ARMED 0x01     /* 已发车(ARM 已收到) */
#define LINK_TIME_FLAG_MAZERUN 0x02   /* 无记忆走迷宫正在跑 */
#define LINK_TIME_FLAG_BEACON 0x04    /* 当前基准灯电平(与 led 字节同义, 冗余一份便于位判) */
/* 墙图: cX,cY,dir,task + mapWall[MAZETYPE^2] + mapVisited[MAZETYPE^2]
 * 注意 MAZETYPE 定义在 STRATEGY/maze.h。宏体在**使用点**才展开, 而 link.c 使用时
 * main.h 已完整展开到 maze.h, 故此处取值正确(当前 MAZETYPE=7 -> 102 字节)。
 * 若将来把 MAZETYPE 改成 16, 本帧自动变为 516 字节, 单帧仍可发送。 */
#define LINK_MAP_LEN (4 + MAZETYPE * MAZETYPE * 2)

/* ---- 快帧 flags 位 ---- */
#define LINK_FLAG_FREEMODE 0x01 /* 自由模式 freemode==1: 电机输出被强制为 0(不是"解锁"!) */
#define LINK_FLAG_SLEEP 0x02    /* 休眠(sleepmode==1) */
#define LINK_FLAG_EMERG 0x04    /* 急停生效(本次上电以来触发过一次, 由 emergMon.active 镜像) */
#define LINK_FLAG_SCOPING 0x08  /* 示波器采集中 */
#define LINK_FLAG_DUMPING 0x10  /* dump 传输中 */
#define LINK_FLAG_MOTOR_OFF 0x20 /* 固件处于安全测试模式(MOUSE_TEST_NO_MOTOR): 电机物理禁用 */
#define LINK_FLAG_ESTOP_LOCK 0x40 /* 急停**锁存**中: 新的 MOVE/CAL 会被拒(ERR_ESTOP), 须 STOP 解锁 */
#define LINK_FLAG_RUNLOG 0x80     /* 运动详细日志已就绪: 1kHz 环已冻结, 可直接 SCOPE DUMP */

/* ---- 1kHz 环形缓冲: 直接复用 flash.c 的 run_data[] ---- */
/* run_data[] 元素为 RunData{u8 motionTask; s16 gangle; s16 speedl; s16 speedr;} = 8B
 * 数组长度 = saveNum = 1200  ->  1kHz 采样可覆盖 1.2 秒, 新增 RAM 0 字节 */
#define LINK_SCOPE_LEN 1200
#define LINK_SCOPE_PTS_PER_BLK 60                               /* 每块 60 点 = 480B */
#define LINK_SCOPE_BLKS (LINK_SCOPE_LEN / LINK_SCOPE_PTS_PER_BLK) /* 20 块 */

/* ---- 缓冲区尺寸(TX 环为 2 的幂, 便于位运算取模) ---- */
#define LINK_TX_BUF_SIZE 256   /* TX 环形缓冲 */
#define LINK_DUMP_BUF_SIZE 512 /* dump 块整帧缓冲(489B 用) */

/* ---- Flash 标定参数页 ---- */
/* pages 0-87 代码区(上限 88KB); 88-98 运行数据(run_data 落盘 1200*8B=9600B);
 * pages 118-127 迷宫/路径/红外/陀螺零偏; 故 pages 99-117 空闲, 取 page 99。
 * 注意: page 90 在运行数据区中间, 不可用。 */
#define FLASH_ADDR_SYSCALIB 0x08018C00
#define LINK_CALIB_MAGIC 0x4D435331 /* 'MCS1' */
#define LINK_CALIB_VER 1
#define LINK_CALIB_PAYLOAD_OFF 16   /* 头 12B + 4B 对齐预留 */

/* ---- 课程调参参数页(仅 MOUSE_LESSON_LAB) ----
 * 生产标定参数在 page 99, 课程参数**另起 page 100**。分开的理由:
 *   1) "实验代码与最终版代码分开"这条要求落到存储上就是"参数分页"——
 *      交比赛固件前清掉实验参数, 不会碰到生产标定值;
 *   2) 课程参数较多且会频繁试验(每次调参都在翻页), 不应与生产值共享一个擦除单元。 */
#define FLASH_ADDR_LESSONPARAM 0x08019000 /* page 100 */
#define LINK_LESSON_MAGIC 0x4D434C32      /* 'MCL2' */

/* ---- LESSON 命令的动作词 ---- */
#define LINK_LESSON_ACT_START "START"
#define LINK_LESSON_ACT_STOP "STOP"
#define LINK_LESSON_ACT_STATUS "STATUS"

/* ---- 标定参数 id ---- */
#define LINK_P_TRACKL 1   /* sysCfg.trackRatioL   里程脉冲/mm */
#define LINK_P_TRACKR 2   /* sysCfg.trackRatioR */
#define LINK_P_SPEEDL 3   /* sysCfg.speedRatioL   (pulse/ms)/(cm/s) = TRACKL/100 */
#define LINK_P_SPEEDR 4   /* sysCfg.speedRatioR */
#define LINK_P_GYRO 5     /* sysCfg.gyroRatio */
#define LINK_P_ENCANG 6   /* sysCfg.encAngleRatio */
#define LINK_P_WALLDIST 7 /* sysCfg.distToWall */
#define LINK_P_NUM 7

/* ---- 示波器状态 ---- */
#define LINK_SCOPE_IDLE 0   /* 空闲(绝不触碰 run_data[]) */
#define LINK_SCOPE_RUN 1    /* 采集中(滚动) */
#define LINK_SCOPE_FROZEN 2 /* 已冻结, 可 dump */

/* ---- 标定动作 ---- */
#define LINK_ACT_START 0
#define LINK_ACT_STEP 1
#define LINK_ACT_DONE 2
#define LINK_ACT_ABORT 3
#define LINK_ACT_SAMPLE 4 /* 显式触发一次采样(IRDATA 逐点采集用) */

/* ---- 标定项(LINK_CAL_*, 对应命令 CAL <item> <act>) ---- */
#define LINK_CAL_GYRO 1      /* 陀螺零偏 -> 既有 page127 */
#define LINK_CAL_WALLDIST 2  /* 车心到墙距离 */
#define LINK_CAL_IRDATA 3    /* 红外 8 值 -> 既有 page123 */
#define LINK_CAL_GYRORATIO 4 /* 陀螺角度系数(以红外极值为物理基准) */
#define LINK_CAL_ENCANGLE 5  /* 编码器角度系数(同一基准) */

/* ---- 移动/标定子状态 ---- */
#define LINK_MOVE_NONE 0
#define LINK_MOVE_FWD 1  /* 固定脉冲直线 */
#define LINK_MOVE_ROT 2  /* 固定 PWM 定长原地转 */
#define LINK_MOVE_RUN 3  /* 受"时间 + 红外"双护栏约束的远程运动(电机远程控制实验) */
#define LINK_SRV_NONE 0
#define LINK_SRV_SWEEP 1 /* 全周扫描找最小, 记录基准 */
#define LINK_SRV_PARK 2  /* 停到最近极小 */

/* ---- 电机远程控制实验: MOVE RUN 的护栏常量 ----
 * 为什么护栏要放在固件里(而不是上位机定时发 STOP):
 *   上位机可能卡死、蓝牙可能断、操作者可能离开 —— 而这条链路是不做配对的一次性透传。
 *   把"到时必停 / 贴脸必停"放在 1ms ISR 里判定, 停止就不再依赖任何外部条件。 */
#define LINK_RUN_MS_DEF 2000   /* 默认最长运行时间(ms)。2 秒是实验建议值 */
#define LINK_RUN_MS_MAX 60000  /* 上限, 防止误敲出天量数字把护栏架空 */
#define LINK_RUN_IR_DEF 10     /* 默认红外停车阈值(mm) = 1cm */
#define LINK_RUN_IR_MAX 3000   /* 阈值上限(大于红外量程即等于关闭) */
#define LINK_RUN_SPEED_MAX 300 /* 速度绝对值上限(cm/s)。超限直接 ERR_VALUE, 不再靠饱和 */

/* ---- MOVE RUN 的停止原因(MOVEDONE RUN 的第一个字段) ---- */
#define LINK_RUN_REASON_TIME "TIME"
#define LINK_RUN_REASON_IR "IR"
#define LINK_RUN_REASON_ESTOP "ESTOP"
#define LINK_RUN_REASON_STOP "STOP"
#define LINK_RUN_REASON_USER "USER"

/*-------------------------------------  F U N C T I O N S  -------------------------------------*/
void LINK_Init(void); /* 链路初始化: RX 优先级/DMA/标定参数载入(须在 HARDWARE_Init 之后调用) */
void LINK_Tick(void); /* 每 1ms 由 SysTick_Handler 调用(须置于 sleepmode 分支之外) */

/* 急停通知(由 isr.c 的 SysTick_Handler 在 emergMon.active==1 时调用)。
 * 作用: 把"急停已发生"这一事实锁存到链路层 ——
 *   1) 快帧 flags 的 LINK_FLAG_ESTOP_LOCK 置位, 上位机一眼可见;
 *   2) 之后所有 MOVE/CAL 命令回 ERR_ESTOP, 直到显式 STOP 解锁。
 * 这样操作者在任何时候按下急停, 系统都会**停在锁死状态**而不是悄悄恢复。 */
void LINK_EStopTrip(void);

/* ---- 远程发车(见 docs/数据收集与时间同步.md) ----------------------------------------
 * 设计要点: **时基与基准灯都在 1ms 中断里维护**, 因此无论主循环在做什么
 * (包括卡在 LESSON_Blind8() 的 while(1) 里跑迷宫), 计时与灯都不受影响;
 * 反过来, 命令解析与遥测组帧也在同一个中断里完成 —— 所以跑迷宫期间
 * 上位机依然能收数据、发命令。数据收集能"搭"在阻塞式自走上, 靠的就是这一点。
 * 时基本身(linkTimeMs / armMs / 基准灯 / TIME 帧)在 link.c 内维护, 不经这些函数暴露 ——
 * 对外只需要下面这两个"发车握手"用的入口。 */
u8 LINK_MazeRequested(void);  /* 是否已收到 MAZE RUN 请求 */
void LINK_MazeStarted(void);  /* 由 main() 在真正进入迷宫前调用, 置"已在跑" */

/* printf 出口: usart.c 的 fputc() 调用它, 使 printf 与遥测共用 TX 环缓冲。
 * 返回 1=已入队, 0=环满已丢弃(不阻塞)。 见 link.c 中的详细说明。 */
u8 LINK_PutChar(u8 b);

#endif
