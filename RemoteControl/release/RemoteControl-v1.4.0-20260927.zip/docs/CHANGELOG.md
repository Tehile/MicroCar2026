# 上位机 API 变更记录（CHANGELOG）

> 记录 `host.api` 门面层的每次接口变更。破坏性变更只允许新增 `_v2` 名称 + 弃用期。
> 由接口化改造（`docs/上位机接口化设计方案.md`）引入。

---

## [1.4.0] — 2026-09-27

### 新增：数据收集档 + 时间同步（发车计时 / 1Hz 基准灯 / 逐帧准确时间）

按"检测运动特性并收集数据"的要求，补齐**远程发车 + 时间同步 + 完整采集**这条链路
（对应 `docs/数据收集与时间同步.md`）。

- **固件：新测试模式 `MOUSE_DATA_LOG`**（`USER/main.h`，第五档）——电机**可控**且
  **含自走策略**（无记忆走迷宫 + 运动控制）。与 [1][2][3] 的本质差别是**它不定义 `MOUSE_TEST_MODE`**
  （前三个测试档都在"关掉自己跑起来的口子"，而它恰恰要打开）。四个模式宏互斥（加上原比赛固件共五档）。
- **固件：时间同步（不依赖任何档，生产固件也编译）**——`linkTimeMs` 毫秒时基（SysTick 1ms 自增，
  u32 49 天不绕）、`ARM` 命令（记发车时刻 + 点亮 1Hz 基准灯 + 回 `ARMED <ms>`）、
  `MAZE RUN` 命令（远程发车跑无记忆迷宫；仅 [4] 档实现，其余回 `ERR_VALUE`）。
- **固件：新帧 `LINK_TYPE_TIME`(0x08) @1Hz**——payload 12B：`upMs`(u32) + `armMs`(u32) +
  `led`(u8) + `flags`(u8)。与基准灯**同拍**（都在 `linkTimeMs % 1000 == 0`）。
- **固件：快帧保留字节改为时基低 8 位**——`f[15] = linkTimeMs & 0xFF`，
  使**每个快帧**都能被定位到 256ms 窗口内；**帧长一个字节都没变**，零带宽代价。
- **固件：`DUMP_HDR` 8 → 12 字节**，追加 `startMs`(u32) = 回传数组中最早一点的绝对设备毫秒时基。
  于是 1kHz 数据也能被钉在绝对时间轴上。
- **固件：`ledBeaconLock`**（`led.c|h`）——发车后 `LED_On/LED_Off` 全部直接返回，
  基准灯**独占** LED4(PC7)。理由：给外部（摄像头/光电/人眼）做时间对齐用的方波一旦被状态灯搅浑，
  时间同步就废了。其余模式恒为 0，LED 行为一字不变。
- **上位机**：
  - 新模块 `host/host/clock.py`：`now_monotonic()` / `now_wall_ms()`。
    原工程**所有**时间戳都取自墙钟 `time.time()`，一次 NTP 回拨就会让时间映射倒挂。
    数据链路的时间计算改用单调时钟。
  - 注册表新增 `arm`、`maze.run` 两条命令（`COMMANDS` 26 → **28**）；
    `FRAMES` 新增 `TIME`（7 → **8** 种）。
  - 新子 API **`mc.timesync`（`TimeSyncAPI`）**：`arm()` / `maze_run()` / `wait_sync()` /
    `offset_s()` / `drift_ppm()` / `frame_time_up()` / `frame_time()` / `dev_ms()` /
    `frame_age_ms()` / `snapshot()` / `explain()`。
  - **算时间的纯函数**（可脱硬件单测）：`min_delay_offset`（min-delay 偏移估计）、
    `fit_clock` / `drift_ppm`（最小二乘频差）、`resolve_ms8`（8 位 → 完整时基）。
  - **丢帧检测**：帧头 SEQ 原来解析后即丢弃，现在在帧分派处启用 ——
    `stats()` 新增 `seq_gap`（间隙次数）与 `seq_lost`（丢失帧数）。
  - **落盘**：`stream_*.csv` 新增 `dev_ms`（发车以来毫秒）与 `seq` 两列；
    帧的"到达时刻"（`_rx_mono`）与序号跟着记录走，落盘与 UI 拿到同一时刻。
  - 新事件 `Event.TIMESYNC`。
  - 新终端入口 **`python -m host.datalog`**（`host.cli datalog` 等价）：
    `--arm-only` / `--maze-only` / `--status` / `--seconds` / `--no-maze` / `--out`，
    一次跑完"发车 → 远程发车 → 实时监视（带 dev_ms）→ 停车 → 1kHz 回传 → 完整性报告"。
  - 模拟器实现同一套：毫秒时基、`ARM`/`ARMED`、`MAZE RUN`、`TIME` 帧、快帧低 8 位、`DUMP_HDR.startMs`。

### 变更（行为）

- **dump 的 `t_ms` 语义变更**：现在是**绝对设备毫秒时基**（`t = startMs + i`），不再从 0 起。
  这样 1kHz 数据可直接与发车时刻/基准灯对齐；按"差值"使用它的分析代码不受影响。
- `motor_lab_smoke` 的"时间轴从 0 开始"断言随之更新为"等长且逐点 +1ms 且起点 > 0"。

### 测试

- 新增 `host/timesync_smoke.py`（T1–T7：纯函数 / 发车 / 逐帧时间 / dump 绝对时间轴 /
  丢帧检测 / 落盘完整性 / 远程发车）。
- `contract_test.py` 基线更新（28 命令 / 8 帧），D1 覆盖 `arm`/`maze.run`，
  帧往返新增 `TIME`，S5 CLI 子命令加入 `datalog`。
- 全绿 **396**：`selftest --e2e` 59 / `contract_test` **144** / `motor_lab_smoke` 44 /
  `lesson_smoke` 38 / **`timesync_smoke` 46** / `facade_smoke` 37 / `monitor_smoke` 28。

### 固件构建（`MOUSE_DATA_LOG`）

- `0 Error(s)`；Code 52416 + RO 21208 = **73624 B** ROM（自走策略已编入，故大于测试档）。
- 符号：`LINK_MazeRequested`/`LINK_MazeStarted`/`ledBeaconLock` 存在；
  自走路径 `LESSON_Blind8`/`doTaskTurn`/`MOTION_MouseTurnBack`/`EXPLORE_CrosswayChoice`/`SEARCH_HasWall` 全在。

---

## [1.3.0] — 2026-09-27

### 新增：课程调参实验 + 参数设定（实验三~八）

按课件要求补齐"参数设定功能"：上位机在 PC 上设定关键目标参数 → 传到电脑鼠 → 按课件剖面动作 →
回传过程数据 → 上位机**自动算出应写回的修正参数**（对应 `docs/课程调参实验与参数设定.md`）。

- **固件：新测试模式 `MOUSE_LESSON_LAB`**（`USER/main.h`）——第四档模式，电机**可控**、无自走策略、
  但多一层"按课件剖面自动跑"的引擎；与 `MOUSE_TEST_NO_MOTOR` / `MOUSE_TEST_MOTOR_LAB` **三者互斥**。
- **固件：新模块 `APP/lesson_lab.c|h`**——整体被 `#ifdef MOUSE_LESSON_LAB` 包住，
  生产固件里**一个字节都不占**（实验代码与最终版代码分开）。含 `LESSONLAB_Init/Tick/Start/Stop/
  Abort/Running/Exp/TakeDone/ParamGet/ParamSet`。
- **固件：课程参数表（id 8–21，14 项）**——`KPL/KIL/KDL/KPR/KIR/KDR`（PID，默认值取自 `motor.h` 红线常量）、
  `IRPL/IRPR/GYROP/GYROD`（纠偏增益）、`SPEEDNEED/ALLDIS`、`SENSORMODE`（派生：写它同改红外/陀螺开关）、`WALLMODE`。
  单独落 **Flash page100**，与生产标定页（99）互不覆盖。
- **固件：`LESSON` 命令组**——`START <exp> [a] [b] [c] [d]` / `STOP` / `STATUS`；
  拒绝码 `ERR_ESTOP` / `ERR_BUSY` / `ERR_VALUE` / `ERR_EXP`。`LESSON` 与 `MOVE` **互斥**。
- **固件：`LESSON DONE <exp> <REASON> <ms> <dL> <dR> <vpkL> <vpkR> <angle>`** 明细行；
  四个实验剖面（2 编码器测距 / 3 匀变速直线 / 5 陀螺标定 / 6 多传感器直行）全在 1 ms 引擎里推进，
  **每个实验都自带时间护栏**（上位机失联也不会失控）。
- **固件：`MOTOR_LoopControl` 在 `MOUSE_LESSON_LAB` 下改用 `lessonGain.*`**——
  电机六增益变成运行时变量；**红线常量数值一字未改**，只是从常量变成可改的变量。
- **上位机**：
  - `protocol/commands.py` 拆出 `PARAM_IDS_BASE`(1–7) + **`LESSON_PARAM_IDS`(8–21)**，加 `PARAM_GROUPS`；
    `PARAM_META` 补全 14 项课程参数（`PARAM_IDS` 7 → **21**）。
  - 注册表新增 `lesson.start` / `lesson.stop` / `lesson.status` 三条命令（`COMMANDS` 23 → **26**）。
  - 新子 API **`mc.lesson`（`LessonAPI`）**：`params()` / `param_meta()` / `set_params()` / `read_param()` /
    `status()` / `start()` / `stop()` / `run()`（阻塞闭环：采集→启动→等 DONE→冻结→回传→自动算参）/
    `fetch_log()` / `explain()`；返回 `LessonResult`。
  - `api/lesson.py` 内置**算参纯函数**（可脱离硬件单测）：`theory_track_ratio`（62.2267）、
    `theory_gyro_ratio`（415.8061）、`solve_ratio`（实验三/六共用）、`error_ratio`（≤3% 验收线）、
    `step_metrics`（σ%/ts/tp）、`straightness_metrics`、`ir_error_stats` / `pick_best_position`。
  - 新事件 `Event.LESSON`（`kind=DONE`/`STATUS`）。
  - 新终端实验台 **`python -m host.lesson`**（`host.cli lesson` 等价）：`--list` / `--theory` /
    `--params` / `--set` / `--start` / `--stop` / `--truth` / `--apply` / `--save`。
    其中 `--truth <实测真值>` + `--apply` 完成"回传数据 → 自动算参 → 写回设备"的闭环。
  - 模拟器实现同一套 `LESSON` 命令组、四个实验剖面、14 项课程参数与 `LESSON DONE` 回传。

### 修正

- `mc.lesson.set_params()` 只接受课程命名空间；生产标定（`TRACKL/TRACKR/GYRORATIO`）必须走 `mc.params.set()`。
  终端 `--apply` 已按命名空间自动分流（两套参数在不同的 Flash 页）。
- `facade_smoke` / `selftest` 的"GET ALL 回读 7 项"断言更新为 **21 项**（生产 7 + 课程 14）。

### 测试

- 新增 `host/lesson_smoke.py`（L1–L5：参数读写 / 启停 / 四个剖面 / 自动算参写回 / 安全固件立即拒绝）。
- `contract_test.py` 基线更新（26 命令 / 21 参数），D1 覆盖三个 LESSON 命令，D2 覆盖全部 21 个参数。
- 全绿：`selftest --e2e` **59/59**、`contract_test` **137/137**、`motor_lab_smoke` **43/43**、
  `lesson_smoke` **38/38**、`facade_smoke` **37/37**、`monitor_smoke` **28/28**。

### 固件构建（`MOUSE_LESSON_LAB`）

- `0 Error(s), 0 Warning(s)`；Code 29588 + RO 460 = **30048 B** ROM。
- 符号核查：`LESSONLAB_*`（10 个函数）、`lessonGain`、`lessonLab` 存在；
  自走路径 `MENU_Run`/`STATE_MainLoop`/`doTaskTurn`/`LESSON_Motor1` 全部为 0。

---

## [1.2.0] — 2026-09-27

### 新增：电机远程控制实验 + 双流数据传输

轮子悬空阶段的**远程电机测试**：一条命令让电机转一下，同时验证"运动时走实时流、
停止后回传高分辨率日志"的分时双流方案（对应 `docs/电机远程控制与双流传输.md`，
设计出处 `docs/蓝牙上位机设计方案.md` §5.5）。

- **固件：新测试模式 `MOUSE_TEST_MOTOR_LAB`**（`USER/main.h`）——电机**可控**，但不含自走策略；
  与 `MOUSE_TEST_NO_MOTOR` 互斥，派生 `MOUSE_TEST_MODE` 统一包住测试分支。
  `isr.c` 的急停分支在测试模式下不升睡眠、改为调 `LINK_EStopTrip()`。
- **固件：`MOVE RUN <spL> <spR> [ms] [ir_mm]`**——受**时间（默认 2 s）+ 红外（默认 1 cm，负值关闭）
  双护栏**约束的远程运动，护栏全在 1 ms ISR 判定，不依赖上位机在线。
- **固件：`ESTOP` 锁存**——随时可用的急停；锁存后一切 `MOVE`/`CAL` 返回 `ERR_ESTOP`，
  必须显式 `STOP` 解锁。急停触发上行一行 `ESTOP TRIP`（`isr.c` 按键急停同样调用）。
- **固件：`MOVEDONE RUN <REASON> <ms> <ir_min> <chan> <dL> <dR> <vpkL> <vpkR>`** 明细行；
  停止时冻结 1 kHz 环并置就绪位，供事后整块回传。
- **快帧 flags 新增两位**：`LINK_FLAG_ESTOP_LOCK`(0x40)、`LINK_FLAG_RUNLOG`(0x80)。
- **上位机**：
  - 注册表新增 `move.run`、`estop.clear` 两条命令（`COMMANDS` 21 → **23**）。
  - 新子 API **`mc.lab`（`MotorLabAPI`）**：`status()` / `run()`（双流编排 + 前置拦截）/
    `estop()` / `resume()` / `fetch_log()` / `explain()`；返回 `RunResult`。
  - `mc.move` 新增 `run()` / `estop()` / `resume()` / `stop()`；
    `mc.estop_locked` / `mc.log_ready` 两个属性。
  - 新事件 `Event.ESTOP`；监视器状态行新增"急停锁存" / "运动日志已就绪"。
  - 新终端实验入口 **`python -m host.motor_test`**（`host.cli motor-test` / `host.cli estop` 等价）。
  - 模拟器实现同一套 `MOVE RUN` 双护栏 / `ESTOP` 锁存 / `MOVEDONE RUN` / 两个状态位。

### 修正

- 修复 `host/cli.py` 中 `diagnose` 子命令的**语法错误**（两条语句挤在一行），
  该错误会让整个 CLI 无法导入；新增前它未被任何测试覆盖。
- `tools/gen_api_reference.py` 补上 `mc.lab` 子 API 段与 `estop` 事件说明。

### 测试

- 新增 `host/motor_lab_smoke.py`（L1–L5：时间护栏 / 红外护栏 / 急停锁存 / 双流 / 安全固件快速拒绝）。
- `contract_test.py` 新增静态检查 **S5**：CLI 必须可导入且子命令齐备（正是上面那个语法错误的回归护栏）。
- 全绿：`contract_test` **100/100**、`motor_lab_smoke` **43/43**、`selftest --e2e` **59/59**、
  `facade_smoke` **37/37**、`monitor_smoke` **28/28**。

### 真机验证（2026-09-27）

- 实验室固件经 J-Link 烧录，回读与 `Mouse.bin` **字节一致**（MD5 吻合）。
- 真机跑 `--sp 40 --time 2 --ir 10`：停止原因 **TIME @ 2000 ms**，实测峰值 L 46 / R 50 cm/s，
  坏 CRC 0，日志 1200 点回传成功。
- **吞吐模型修订**：一次 `SCOPE DUMP`（20 块 × 490 B ≈ 9.8 KB）真机耗时 **~7.1 s（≈1.38 KB/s）**，
  为 UART 理论上限（11520 B/s）的约 12%，即早期"152 B/s"是**常驻预算**而非突发上限。
  该耗时**与采集点数无关**（固件固定回传 20 块）。已同步修订 `docs/蓝牙上位机设计方案.md` §5.5
  与 `docs/电机远程控制与双流传输.md` §4.1、§7.4。

---

## [1.1.0] — 2026-09-27

### 新增：可编程接口门面（P1–P4 完成）

把原先散落在 `ui/main_window.py` 里的编排逻辑收口为 headless 门面，并建立
"新增功能只改一张表"的强制机制。

- **门面 `host.api.MouseClient`**
  - 连接生命周期：连接自动 `STREAM ON`、断开前 `STREAM OFF`、失败不建会话。
  - 20ms 调度线程：`poll()` / 事件派发 / 订阅式落盘（修复高采样率漏帧）/ 周期任务。
  - 事件总线（push/pull 双模式）、`wait()`/`wait_event()` 阻塞辅助。
  - 九个子 API：`conn` `params` `telemetry` `stream` `calib` `move` `scope` `maze` `analyze` `session`。
- **注册表 `host.registry`**（E1 单一登记点）
  - `COMMANDS`（21 条命令）/ `FRAMES`（7 种帧）登记表。
  - `link.py` 帧分派改为查表，新增帧不改 link.py。
- **契约测试 `contract_test.py`**（E3）：遍历登记表，静态断言 + 模拟器逐条 ACK + 参数往返。
- **CLI `host.cli`**（P3）：`ports/connect/get/set/calib/scope/maze/diagnose/scan-baud/replay`，`--json` 输出。
- **回放 `host.replay`**（P4）：`Target(kind="replay")` 按 `raw.ts` 原始节奏重放历史会话。
- **文档自动生成 `tools/gen_api_reference.py`**（E5）：`docs/api_reference.md` 由登记表+docstring 反射生成。

### 修正

- 删除固件不存在的幽灵命令：`text`（`TEXT ON/OFF`）、`move.servo`（`MOVE SERVO`）、
  `scope.arm`（`SCOPE ARM`）—— 登记表现与固件实际命令集逐条一致（21 条）。
- 修正 `RATE` 取值与固件分档一致：`{100, 50, 20, 10, 5, 2}` Hz。
- 修正 `send_cmd`/`command_line`/`registry.run` 的「命令名」形参 `name` 与参数命令
  的 `name` 参数撞名问题（形参统一改为 `cmd`）。
- 模拟器对齐固件：上电默认静默 + `STREAM ON/OFF` 门控遥测 + `RATE` 分档一致。

### 明确不做（用户确认）

- 固件匹配/跨语言同步脚本 `tools/sync_check.py`（E2）——不需要。
- 固件新增 `CAPS` 能力协商命令（E4）——不需要兼容性协商。

---

## [1.0.0] — 之前

- 协议层（帧编解码、CRC16、Q16.16、流式分流）、命令层（ACK/重发/幂等/回读）、
  传输层（串口/TCP 双模）、数据模型（环形缓冲/会话落盘）、分析指标。
- 实机联调：蓝牙透传链路吞吐实测 ~152 B/s 上限，默认静默 + STREAM 开关方案落地。
