"""协议自检 + 端到端回归。

用法:
    python selftest.py            # 纯协议断言(不需要网络)
    python selftest.py --e2e      # 额外拉起模拟器做端到端断言

覆盖:
    1. CRC16/MODBUS 标准校验向量
    2. Q16.16 编解码往返
    3. 帧打包/解析往返, 含"文本与二进制混流"
    4. 解析器对损坏帧的自恢复能力
    5. (--e2e) 命令往返: PING / GET ALL / SETQ+回读 / SCOPE dump / MOVE FWD / 拔插
"""

from __future__ import annotations

import argparse
import socket
import struct
import subprocess
import sys
import threading
import time

import numpy as np

from host.protocol.codec import (
    FRAME_OVERHEAD,
    SCOPE_BLKS,
    TYPE_FAST,
    TYPE_MAP,
    TYPE_SLOW,
    crc16_modbus,
    decode_fast,
    decode_map,
    decode_slow,
    float_to_q1616,
    pack_frame,
    q1616_to_float,
    FrameStreamParser,
)
from host.protocol.commands import CommandClient

PASS = 0
FAIL = 0


def check(name: str, cond: bool, detail: str = "") -> None:
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"  [OK]   {name}")
    else:
        FAIL += 1
        print(f"  [FAIL] {name}  {detail}")


# ---------------------------------------------------------------- 1. CRC

def test_crc() -> None:
    print("\n[1] CRC16/MODBUS")
    check("标准校验向量 crc16(b'123456789') == 0x4B37", crc16_modbus(b"123456789") == 0x4B37,
          f"got 0x{crc16_modbus(b'123456789'):04X}")
    check("空输入 == 0xFFFF", crc16_modbus(b"") == 0xFFFF)
    check("单字节 crc16(b'A') 稳定复现", crc16_modbus(b"A") == crc16_modbus(b"A"))


# ---------------------------------------------------------------- 2. Q16.16

def test_q1616() -> None:
    print("\n[2] Q16.16 定点")
    for v in (53.2015, 0.532015, 399.79, -12.5, 0.0, 42.0):
        q = float_to_q1616(v)
        back = q1616_to_float(q)
        check(f"{v} 往返误差 < 2e-5", abs(back - v) < 2e-5, f"got {back}")
    check("53.2015 -> 3486614 (53.2015*65536=3486613.5)", float_to_q1616(53.2015) == 3486614,
          f"got {float_to_q1616(53.2015)}")
    check("0.532015 -> 34866", float_to_q1616(0.532015) == 34866,
          f"got {float_to_q1616(0.532015)}")


# ---------------------------------------------------------------- 3. 帧往返

def test_frames() -> None:
    print("\n[3] 帧打包/解析往返")
    fast = struct.pack("<hhhhhhBBBB", 68, -12, 90, 5, 68, -12, 32, 76, 0x01, 0)
    frame = pack_frame(TYPE_FAST, fast, 7)
    check(f"帧长 == 载荷 + {FRAME_OVERHEAD}", len(frame) == len(fast) + FRAME_OVERHEAD,
          f"got {len(frame)}")
    check("同步头正确", frame[0] == 0xAA and frame[1] == 0x55)
    check("LEN 字段正确", struct.unpack("<H", frame[2:4])[0] == len(fast))

    p = FrameStreamParser()
    frames, lines = p.feed(frame)
    check("解析出 1 帧", len(frames) == 1 and not lines)
    if frames:
        check("TYPE/SEQ 正确", frames[0].type == TYPE_FAST and frames[0].seq == 7)
        rec = decode_fast(frames[0].payload)
        check("载荷解码正确", rec["speedL"] == 68 and rec["speedR"] == -12 and rec["task"] == 32,
              str(rec))
        check("flags 位解码正确", rec["freemode"] is True)

    # 逐字节投喂(模拟串口任意切分)
    p2 = FrameStreamParser()
    got = []
    for i in range(len(frame)):
        f, _l = p2.feed(frame[i : i + 1])
        got.extend(f)
    check("逐字节投喂仍能正确组帧", len(got) == 1)


def test_mixed_stream() -> None:
    print("\n[4] 文本与二进制混流")
    # 设备会同时吐 printf 文本与二进制帧; 0xAA 在 ASCII 可打印区间外, 所以可分流
    text1 = b"odomStr.trackAbsL:123.4\todomStr.trackAbsR:122.9\r\n"
    fast = struct.pack("<hhhhhhBBBB", 10, 10, 0, 0, 10, 10, 1, 76, 0, 0)
    f1 = pack_frame(TYPE_FAST, fast, 1)
    text2 = b"ACK 42 OK\r\n"
    slow_payload = struct.pack("<hhhhBBbbHBB", 232, 231, 42, 43, 0x05, 2, 3, 4, 762, 21, 0)
    f2 = pack_frame(TYPE_SLOW, slow_payload, 2)

    p = FrameStreamParser()
    frames, lines = p.feed(text1 + f1 + text2 + f2)
    check("解出 2 帧", len(frames) == 2, f"got {len(frames)}")
    check("解出 2 行文本", len(lines) == 2, f"got {lines}")
    check("文本内容正确", lines and lines[0].startswith("odomStr.trackAbsL"), str(lines))
    check("第二行是 ACK", len(lines) > 1 and lines[1] == "ACK 42 OK", str(lines))
    if len(frames) == 2:
        s = decode_slow(frames[1].payload)
        check("慢帧解码正确", s["irF1"] == 232 and s["posX"] == 3 and abs(s["volt"] - 7.62) < 1e-6,
              str(s))

    # 单字节切分
    p2 = FrameStreamParser()
    allf, alll = [], []
    blob = text1 + f1 + text2 + f2
    for i in range(len(blob)):
        a, b = p2.feed(blob[i : i + 1])
        allf.extend(a)
        alll.extend(b)
    check("单字节切分仍然解出 2 帧 2 行", len(allf) == 2 and len(alll) == 2,
          f"frames={len(allf)} lines={len(alll)}")


def test_corruption_recovery() -> None:
    print("\n[5] 损坏帧的自恢复")
    fast = struct.pack("<hhhhhhBBBB", 1, 2, 3, 4, 5, 6, 7, 76, 0, 0)
    good = pack_frame(TYPE_FAST, fast, 9)
    bad = bytearray(good)
    bad[10] ^= 0xFF  # 破坏载荷 -> CRC 失配

    p = FrameStreamParser()
    frames, lines = p.feed(bytes(bad) + good)
    check("坏帧被丢弃并计入 bad_crc", p.stats["bad_crc"] >= 1, str(p.stats))
    check("紧随其后的好帧仍被正确解出", len(frames) == 1, f"got {len(frames)}")

    # 只有 0xAA 没有后续 -> 应安全等待而不是崩
    p2 = FrameStreamParser()
    f3, _ = p2.feed(b"\xaa")
    check("半个同步头安全缓存", f3 == [])
    f4, _ = p2.feed(b"\x55\x10\x00")
    check("补齐后仍安全", f4 == [])


def test_map_frame() -> None:
    print("\n[6] 墙图帧")
    n = 7
    wall = bytes([(0x01 | 0x02) for _ in range(n * n)])
    vis = bytes([1] * (n * n))
    pl = struct.pack("<bbBB", 3, 4, 1, 2) + wall + vis
    f = pack_frame(TYPE_MAP, pl, 0)
    p = FrameStreamParser()
    frames, _ = p.feed(f)
    check("墙图帧可解析", len(frames) == 1)
    if frames:
        m = decode_map(frames[0].payload, n)
        check("坐标/朝向正确", (m["posX"], m["posY"], m["direction"]) == (3, 4, 1))
        check("墙图尺寸正确", len(m["mapWall"]) == n and len(m["mapWall"][0]) == n)
        check("visited 正确", m["mapVisited"][0][0] == 1)


# ---------------------------------------------------------------- 7. 端到端

def _free_port() -> int:
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    return port


def test_e2e(port: int = 5555, auto_spawn: bool = True) -> None:
    print("\n[7] 端到端(模拟器)")
    proc = None
    if auto_spawn:
        port = _free_port()
        proc = subprocess.Popen(
            [sys.executable, "-m", "host.sim.mouse_sim", "--port", str(port), "--no-auto"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        time.sleep(1.2)

    try:
        from host.model.ring import TelemetryStore
        from host.transport.link import Link, Target

        store = TelemetryStore(window_s=5.0)
        client = CommandClient(send_bytes=lambda b: link.write(b))
        link = Link(store=store, client=client)
        link.open(Target(kind="tcp", host="127.0.0.1", tcp_port=port))
        time.sleep(0.4)
        check("链路已打开", link.is_open, link.state_detail)

        p = client.ping()
        check("PING -> OK", p.ok, p.status)
        check("设备上报协议版本/迷宫尺寸", client.device.get("mazetype") == 7, str(client.device))

        # 固件上电默认静默: 必须 STREAM ON 才会收到遥测
        client.send("STREAM ON")
        time.sleep(0.6)
        st = link.stats()
        check("已收到快帧", st["fast"] > 0, str(st))
        check("已收到中帧", st["mid"] > 0, str(st))

        client.get_all()
        # 模拟器同时支持两套参数(生产 7 + 课程 14 = 21); 真实固件按模式只回其中一套。
        check("GET ALL 回读 21 项参数(生产 7 + 课程 14)", len(client.params) == 21,
              str(sorted(client.params)))

        # SETQ + 回读校验(L4)
        ok, stt = client.set_param("TRACKL", 53.4321, readback=True)
        check("SETQ+回读校验通过", ok, stt)
        check("回读值等于期望 Q16.16",
              client.params.get(1) == float_to_q1616(53.4321), str(client.params.get(1)))

        # 速率切换(固件合法档位)
        ok, stt = client.set_rate(100)
        check("RATE 100 -> OK", ok, stt)
        client.set_rate(5)

        # ---- dump 全流程(先让它动起来, 保证环形缓冲里有真实波形) ----
        client.scope("START")
        client.move_fwd(20000, 45)  # 约 376mm @45cm/s -> 约 0.9s 的连续运动
        time.sleep(1.0)
        client.scope("STOP")
        client.scope("DUMP")
        t0 = time.time()
        while time.time() - t0 < 5.0 and not store.dump_done:
            time.sleep(0.02)
        check("dump 完成", store.dump_done, f"progress={store.dump_progress():.2f}")
        hdr = store.dump_hdr or {}
        check("dump 头含 filled/start 字段", "filled" in hdr and "start" in hdr, str(hdr))
        arr = store.dump_arrays()
        check("dump 点数在 (0, 1200]", arr is not None and 0 < len(arr[0]) <= 1200,
              "None" if arr is None else str(len(arr[0])))
        if arr is not None:
            speeds = arr[3]
            check("dump 含非零转速样本", float((speeds != 0).sum()) > 0,
                  f"len={len(speeds)} nonzero={int((speeds != 0).sum())}")
            check("dump 时间轴单调(已按 filled/start 还原)",
                  bool(np.all(np.diff(arr[0]) > 0)) if len(arr[0]) > 1 else True)

        # 墙图
        client.map_dump()
        time.sleep(0.3)
        m = store.get_map()
        check("墙图已收到且为 7x7", m is not None and len(m["mapWall"]) == 7,
              "None" if m is None else str(len(m["mapWall"])))

        # 标定帧
        client.cal("IRDATA", "START")
        for _ in range(4):
            client.cal("IRDATA", "SAMPLE")
            time.sleep(0.15)
        time.sleep(0.4)
        check("IRDATA 4 点全部回报", any("CALDONE IRDATA" in e[2] for e in client.events),
              str([e[2] for e in client.events][-4:]))

        client.move_fwd(3000, 40)
        t0 = time.time()
        done = False
        while time.time() - t0 < 6.0:
            if any("MOVEDONE FWD" in e[2] for e in client.events):
                done = True
                break
            time.sleep(0.05)
        check("MOVE FWD 回报 MOVEDONE", done)

        client.stop()
        link.close()
        check("链路已关闭", not link.is_open)
    finally:
        if proc is not None:
            proc.terminate()
            try:
                proc.wait(timeout=3)
            except subprocess.TimeoutExpired:
                proc.kill()


def test_session() -> None:
    print("\n[8] 会话落盘(CSV / raw.bin / meta.json / 备份)")
    import os
    import shutil

    from host.model.session import Session

    root = os.path.join(os.path.dirname(os.path.abspath(__file__)), "sessions")
    name = "_selftest"
    shutil.rmtree(os.path.join(root, name), ignore_errors=True)

    s = Session(root=root, name=name)
    s.write_raw(b"\xaa\x55raw")
    s.write_text("PONG 1 100 7")
    s.write_fast(
        {"task": 32, "volt": 7.6, "speedL": 68, "speedR": -12, "gyroAngle": 90, "pidErr": 5,
         "speedTargetL": 68, "speedTargetR": -12}
    )
    s.write_mid({"cellOdom": 120, "trackL": 300, "trackR": 301, "gyroRaw": 2048, "gyroDiff": 12, "encAngle": 45})
    s.write_slow(
        {"mouseTask": 2, "wallBits": 5, "drop": 0, "irF1": 232, "irF2": 231, "irL": 42, "irR": 43,
         "posX": 3, "posY": 4, "volt": 7.62, "cpu": 21}
    )
    s.open_dump("0001")
    s.write_dump([(32, 90, 68, -12)] * 3)
    s.write_calib_report(["## test", "- ok"])
    backup = s.backup_params([["TRACKL", 3486614, "53.2015"]])
    s.close({"link_stats": {"fast": 1}})

    def exists(rel: str) -> bool:
        return os.path.isfile(os.path.join(root, name, rel))

    check("raw.bin 已写入", exists("raw.bin") and os.path.getsize(os.path.join(root, name, "raw.bin")) == 5)
    check("text.log 已写入", exists("text.log"))
    check("stream_250hz.csv 表头+1行", exists("stream_250hz.csv") and _rows(root, name, "stream_250hz.csv") == 2)
    check("stream_50hz.csv 表头+1行", _rows(root, name, "stream_50hz.csv") == 2)
    check("stream_5hz.csv 表头+1行", _rows(root, name, "stream_5hz.csv") == 2)
    check("dump_1khz_0001.csv 表头+3行", _rows(root, name, "dump_1khz_0001.csv") == 4)
    check("meta.json 已写入且含 counts", exists("meta.json"))
    check("参数备份已写入", os.path.isfile(backup))
    shutil.rmtree(os.path.join(root, name), ignore_errors=True)


def _rows(root: str, name: str, rel: str) -> int:
    import os

    with open(os.path.join(root, name, rel), "r", encoding="utf-8") as f:
        return sum(1 for _ in f)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--e2e", action="store_true", help="额外跑端到端回归(会拉起模拟器)")
    ap.add_argument("--port", type=int, default=5555, help="配合 --e2e 时指定已运行的模拟器端口")
    ap.add_argument("--no-spawn", action="store_true", help="不自动拉起模拟器")
    args = ap.parse_args()

    print("=" * 66)
    print("电脑鼠上位机 协议自检")
    print("=" * 66)
    test_crc()
    test_q1616()
    test_frames()
    test_mixed_stream()
    test_corruption_recovery()
    test_map_frame()
    test_session()
    if args.e2e:
        test_e2e(args.port, auto_spawn=not args.no_spawn)

    print("\n" + "=" * 66)
    print(f"通过 {PASS} / 失败 {FAIL}")
    print("=" * 66)
    return 1 if FAIL else 0


if __name__ == "__main__":
    sys.exit(main())
