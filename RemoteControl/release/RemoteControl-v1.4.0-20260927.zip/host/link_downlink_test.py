"""验证下行命令链路(含 CRC 校验、命令分发与副作用)。

命令格式必须与 host/protocol/commands.py 的 CommandClient._build 完全一致:

    <cmd> #<seq>*<CRC16(<cmd> #<seq>)>\\r\\n

即 '#' 在 '*' **之前**，CRC 覆盖 '*' 之前的全部字节（含 '#' 与序号）。
固件 link.c 的解析顺序是：先按 '*' 切出 CRC → 把 '*' 置 0 → 在剩余串里找 '#' 取 seq，
所以 '<cmd> #<seq>' 这个顺序才能让 seq 被解析到。

两个断言（第二个是强证据，不依赖 seq 记录）：
  1) PING      -> linkLastStatus 变为 OK    （命令被识别并应答）
  2) RATE 200  -> linkFastDiv 变为 5        （命令产生了真实副作用）
"""

from __future__ import annotations

import os
import subprocess
import tempfile
import time

import serial

JL = r"C:\Program Files\SEGGER\JLink_V976a\JLink.exe"
PORT = "COM7"
STATUS_ADDR = 0x200039C4    # linkLastStatus[14]
STATUS_LEN = 14
FASTDIV_ADDR = 0x20000836   # linkFastDiv (u8)


def crc16(data: bytes) -> int:
    crc = 0xFFFF
    for b in data:
        crc ^= b
        for _ in range(8):
            crc = (crc >> 1) ^ 0xA001 if crc & 1 else crc >> 1
    return crc & 0xFFFF


def build(cmd: str, seq: int) -> bytes:
    """与上位机 CommandClient._build 逐字一致。"""
    body = f"{cmd} #{seq}".encode("ascii")
    return body + f"*{crc16(body):04X}".encode("ascii") + b"\r\n"


def jl_read(addr: int, n: int) -> bytes:
    script = (
        "si SWD\nspeed 4000\ndevice STM32F103RB\nconnect\nhalt\n"
        f"mem8 0x{addr:08X}, {n}\nq\n"
    )
    fd, path = tempfile.mkstemp(suffix=".jlink", text=True)
    os.close(fd)
    with open(path, "w", encoding="ascii") as f:
        f.write(script)
    try:
        p = subprocess.run([JL, "-CommanderScript", path, "-ExitOnError", "1"],
                           capture_output=True, text=True, timeout=120,
                           encoding="utf-8", errors="replace")
    finally:
        try:
            os.unlink(path)
        except OSError:
            pass
    acc: dict = {}
    for line in (p.stdout or "").splitlines():
        line = line.strip()
        if "=" not in line:
            continue
        a, _, rest = line.partition("=")
        a = a.strip()
        if len(a) != 8:
            continue
        try:
            base = int(a, 16)
            vals = [int(x, 16) for x in rest.split()]
        except ValueError:
            continue
        for i, v in enumerate(vals):
            acc[base + i] = v
    return bytes(acc.get(addr + i, 0) for i in range(n))


PASS = 0
FAIL = 0


def check(name: str, cond: bool, extra: str = "") -> None:
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"  [OK]   {name}")
    else:
        FAIL += 1
        print(f"  [FAIL] {name} {extra}")


def main() -> int:
    print("=" * 72)
    print("下行命令链路验证 (电脑 -> COM7 -> STM32 USART1)")
    print("=" * 72)
    print("命令格式: <cmd> #<seq>*<CRC16(cmd #seq)>   (与上位机 commands.py 一致)")

    try:
        s = serial.Serial(PORT, 115200, bytesize=8, parity="N", stopbits=1, timeout=0.2)
    except Exception as e:
        print(f"\n打开 {PORT} 失败: {e}")
        return 1

    try:
        # ---------- 1) PING ----------
        cmd = build("PING", 1)
        print(f"\n[1] 发送 {cmd!r}")
        try:
            s.reset_input_buffer()
        except Exception:
            pass
        s.write(cmd)
        s.flush()
        time.sleep(0.4)
        st = jl_read(STATUS_ADDR, STATUS_LEN).split(b"\x00")[0]
        print(f"    linkLastStatus = {st!r}")
        check("PING 被识别, linkLastStatus == b'OK'", st == b"OK", f"got {st!r}")

        # ---------- 2) RATE 200 (产生可读副作用) ----------
        before = jl_read(FASTDIV_ADDR, 1)[0]
        cmd2 = build("RATE 200", 2)
        print(f"\n[2] 发送 {cmd2!r}")
        print(f"    改前 linkFastDiv = {before}")
        try:
            s.reset_input_buffer()
        except Exception:
            pass
        s.write(cmd2)
        s.flush()
        time.sleep(0.5)
        after = jl_read(FASTDIV_ADDR, 1)[0]
        print(f"    改后 linkFastDiv = {after}")
        check("RATE 200 生效, linkFastDiv == 5", after == 5, f"got {after}")

        # 恢复默认 100Hz
        cmd3 = build("RATE 100", 3)
        s.write(cmd3)
        s.flush()
        time.sleep(0.4)
        restored = jl_read(FASTDIV_ADDR, 1)[0]
        print(f"\n[3] 恢复 RATE 100 -> linkFastDiv = {restored}")
        check("已恢复默认 100Hz", restored == 10, f"got {restored}")
    finally:
        s.close()

    print("\n" + "=" * 72)
    print(f"通过 {PASS} / 失败 {FAIL}")
    if FAIL == 0:
        print("结论: 下行命令链路【完整可用】—— CRC 校验、序号、命令分发、副作用全部正常。")
    print("=" * 72)
    return 1 if FAIL else 0


if __name__ == "__main__":
    raise SystemExit(main())
