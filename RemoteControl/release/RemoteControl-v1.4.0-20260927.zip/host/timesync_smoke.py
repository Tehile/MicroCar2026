"""数据收集与时间同步冒烟测试 —— 把"数据的完整性"和"时间的准确性"变成可断言的事实。

要回答七个问题, 每个都是现场真会出错的地方:

    T1 纯函数     偏移(min-delay)/频差(ppm)/8 位时间戳还原, 在已知真值上算得对
    T2 发车        `ARM` 被接受, 固件回 `ARMED <ms>`, 之后 1Hz 时间帧按期到达
    T3 逐帧时间   快帧(带 8 位时间戳)能被还原成正确的完整设备时刻
    T4 绝对时间轴 1kHz dump 头带 `startMs`, 时间轴是**绝对设备时刻**且单调
    T5 丢帧检测   帧序号不连续能被数出来(gap 次数 + 丢失帧数)
    T6 数据完整性 会话落盘齐全(raw.bin / 三个 stream CSV / meta.json), CSV 里有 dev_ms 列
    T7 远程发车   `MAZE RUN` 生效(mazeRun 标志置位)、重复发车被拒、误发给不支持的模式不会静默成功

用法(在 host/ 目录下):
    python timesync_smoke.py
"""

from __future__ import annotations

import os
import socket
import subprocess
import sys
import tempfile
import time
from typing import List

PASS = 0
FAIL = 0
FAILED: List[str] = []


def check(name: str, cond: bool, detail: str = "") -> None:
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"  [OK] {name}")
    else:
        FAIL += 1
        FAILED.append(name)
        print(f"  [FAIL] {name}" + (f"  <- {detail}" if detail else ""))


def _free_port() -> int:
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    p = s.getsockname()[1]
    s.close()
    return p


class _Sim:
    def __init__(self, *extra: str) -> None:
        self.port = _free_port()
        self.cmd = [sys.executable, "-m", "host.sim.mouse_sim",
                    "--port", str(self.port), "--no-auto", *extra]
        self.proc: subprocess.Popen | None = None

    @property
    def target(self) -> str:
        return f"tcp://127.0.0.1:{self.port}"

    def __enter__(self) -> "_Sim":
        self.proc = subprocess.Popen(self.cmd, stdout=subprocess.DEVNULL,
                                     stderr=subprocess.DEVNULL)
        time.sleep(1.2)
        return self

    def __exit__(self, *exc) -> None:
        if self.proc is not None:
            self.proc.terminate()
            try:
                self.proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self.proc.kill()


def _connect(sim: "_Sim", **kw):
    from host.api import MouseClient

    mc = MouseClient(**kw)
    if not mc.connect(sim.target):
        raise RuntimeError(f"连接失败: {mc.state_detail}")
    mc.telemetry.wait_first_frame(timeout=5.0)
    return mc


# ---------------------------------------------------------------- T1 纯函数

def test_pure_functions() -> None:
    print("\n[T1] 时间同步纯函数(已知真值)")
    from host.api.timesync import (
        drift_ppm, fit_clock, min_delay_offset, resolve_ms8,
    )

    # 真值: 偏移 100.0s, 设备与 PC 同速, 单程延迟 3ms 恒定
    samples = [(100.003 + i, i * 1000) for i in range(5)]
    off = min_delay_offset(samples)
    check("min_delay_offset 还原偏移", off is not None and abs(off - 100.003) < 1e-6,
          str(off))

    # 设备比 PC 慢 2%(每 PC 秒只走 980 设备毫秒) -> ppm ≈ -20000
    slow = [(float(i), int(i * 980)) for i in range(10)]
    ppm = drift_ppm(slow)
    check("drift_ppm 识别 -2% 频差", ppm is not None and abs(ppm - (-20000)) < 100,
          str(ppm))
    fit = fit_clock(slow)
    check("fit_clock 斜率 ≈ 0.98", fit is not None and abs(fit[1] - 0.98) < 1e-6, str(fit))

    check("样本不足时返回 None", min_delay_offset([]) is None and fit_clock([(0.0, 0)]) is None)

    # 8 位还原: 预测 5000ms(误差 0) -> 低字节 0 应还原成 5120
    check("resolve_ms8 精确预测", resolve_ms8(0, 5000) == 5120, str(resolve_ms8(0, 5000)))
    check("resolve_ms8 预测偏 +127 仍正确", resolve_ms8(0, 5120 + 127) == 5120,
          str(resolve_ms8(0, 5120 + 127)))
    check("resolve_ms8 预测偏 -127 仍正确", resolve_ms8(0, 5120 - 127) == 5120,
          str(resolve_ms8(0, 5120 - 127)))
    # 注意: 低字节取自"完整时基", 不是取自偏移量 —— (3000+v)&0xFF != v&0xFF
    check("resolve_ms8 任意同余值可还原",
          all(resolve_ms8((3000 + v) & 0xFF, 3000 + v) == 3000 + v
              for v in range(0, 5000, 371)))


# ---------------------------------------------------------------- T2 发车

def test_arm(sim: "_Sim") -> None:
    print("\n[T2] ARM 发车 + 1Hz 时间帧")
    with _connect(sim) as mc:
        check("连接后未发车", mc.timesync.snapshot().armed is False)
        r = mc.timesync.arm()
        check("ARM ACK OK", r.ok, r.status)
        # ARM 的异步回执 ARMED <ms>
        deadline = time.time() + 2.0
        while time.time() < deadline and mc.timesync.arm_up_ms is None:
            time.sleep(0.05)
        check("收到 ARMED 回执并记录发车时刻", mc.timesync.arm_up_ms is not None,
              str(mc.timesync.arm_up_ms))
        check("wait_sync 拿到足够样本", mc.timesync.wait_sync(samples=3, timeout=6.0))
        st = mc.timesync.snapshot()
        check("snapshot.armed 为真", st.armed)
        check("offset 已收敛", st.offset_s is not None)
        check("样本数 >= 3", st.samples >= 3, str(st.samples))


# ---------------------------------------------------------------- T3 逐帧时间

def test_per_frame_time(sim: "_Sim") -> None:
    print("\n[T3] 每个快帧都能定位到准确时刻")
    with _connect(sim) as mc:
        mc.timesync.arm()
        mc.timesync.wait_sync(samples=3, timeout=6.0)
        # 收集一组快帧, 检查 ms8 -> 完整设备时刻的还原是否自洽
        got: List = []
        off = mc.on(__import__("host.api", fromlist=["Event"]).Event.TELEMETRY,
                    lambda m: got.append(m.data["rec"])
                    if m.data.get("stream") == "fast" else None)
        try:
            time.sleep(1.5)
        finally:
            off()
        check("收到快帧", len(got) >= 5, str(len(got)))
        ups = [mc.timesync.frame_time_up(r) for r in got]
        check("每帧都能还原出设备时刻", all(u is not None for u in ups), str(ups[:5]))
        if all(u is not None for u in ups):
            # 设备时基必须单调不减, 且相邻帧的间隔应是快帧周期的整数倍(不会跳 256)
            steps = [ups[i + 1] - ups[i] for i in range(len(ups) - 1)]
            check("还原出的设备时刻单调不减", all(s >= 0 for s in steps), str(steps[:6]))
            check("相邻帧间隔不含 256 级跳变(未误配窗口)",
                  all(abs(s) < 250 for s in steps), str(steps[:6]))
            # ms8 必须与还原值同余
            ok = all((u & 0xFF) == r["ms8"] for u, r in zip(ups, got))
            check("还原值与 ms8 同余", ok)


# ---------------------------------------------------------------- T4 绝对时间轴

def test_dump_absolute_axis(sim: "_Sim") -> None:
    print("\n[T4] 1kHz dump 的绝对时间轴")
    with _connect(sim) as mc:
        mc.timesync.arm()
        mc.timesync.wait_sync(samples=2, timeout=6.0)
        mc.scope.start()
        time.sleep(0.5)
        mc.scope.stop()
        arr = mc.scope.fetch(timeout=20.0, stop_first=False)
        check("dump 回传成功", arr is not None)
        if arr is None:
            return
        hdr = mc.store.dump_hdr or {}
        check("dump 头带 startMs", "startMs" in hdr and int(hdr.get("startMs", 0)) > 0,
              str(hdr.get("startMs")))
        t = arr[0]
        check("时间轴起点 = startMs", abs(float(t[0]) - float(hdr.get("startMs", -1))) < 1e-9,
              f"t0={t[0]} startMs={hdr.get('startMs')}")
        check("时间轴严格单调(+1ms @1kHz)",
              all(abs((t[i + 1] - t[i]) - 1.0) < 1e-9 for i in range(min(len(t), 300) - 1)))
        check("时间轴落在发车之后", mc.timesync.arm_up_ms is None
              or float(t[0]) >= float(mc.timesync.arm_up_ms),
              f"t0={t[0]} arm={mc.timesync.arm_up_ms}")


# ---------------------------------------------------------------- T5 丢帧检测

def test_seq_gap_detection() -> None:
    print("\n[T5] 帧序号间隙 -> 丢帧计数")
    from host.model.ring import TelemetryStore
    from host.protocol.codec import TYPE_SLOW, Frame, pack_frame
    from host.protocol.commands import CommandClient
    from host.transport.link import Link

    store = TelemetryStore()
    cmd = CommandClient(send_bytes=lambda b: None)
    lnk = Link(store=store, client=cmd)

    def feed(seq: int) -> None:
        pl = __import__("struct").pack("<hhhhBBbbHBB", 230, 230, 230, 230, 0, 0, 0, 0, 760, 20, 0)
        lnk._dispatch_frame(Frame(type=TYPE_SLOW, seq=seq, payload=pl))

    feed(10)
    check("首帧不计丢帧", lnk.counts["seq_lost"] == 0, str(lnk.counts["seq_lost"]))
    feed(11)
    check("连续帧不误报", lnk.counts["seq_lost"] == 0)
    feed(14)  # 跳了 12, 13 -> 丢 2 帧
    check("间隙计入 gap 次数", lnk.counts["seq_gap"] == 1, str(lnk.counts["seq_gap"]))
    check("间隙计入丢失帧数(=2)", lnk.counts["seq_lost"] == 2, str(lnk.counts["seq_lost"]))
    feed(15)
    check("恢复后继续正常", lnk.counts["seq_gap"] == 1)
    # 256 回绕: 255 -> 0 是连续的, 不该误报
    lnk._last_frame_seq = 255
    feed(0)
    check("256 回绕不误报", lnk.counts["seq_gap"] == 1, str(lnk.counts["seq_gap"]))


# ---------------------------------------------------------------- T6 数据完整性

def test_session_integrity(sim: "_Sim") -> None:
    print("\n[T6] 会话落盘完整性 + dev_ms 列")
    tmp = tempfile.mkdtemp(prefix="timesync_sess_")
    os.environ["HOST_SESSION_DIR"] = tmp
    mc = None
    try:
        mc = _connect(sim)
        mc.session.open(tag="tsync")  # 若 API 不同, 下面会回退到 auto_session
    except Exception:
        if mc is not None:
            mc.close()
        mc = _connect(sim, auto_session=True)
    try:
        mc.timesync.arm()
        mc.timesync.wait_sync(samples=2, timeout=6.0)
        mc.stream.on() if hasattr(mc.stream, "on") else None
        time.sleep(1.5)
        sess = getattr(mc, "_session", None)
        if sess is None:
            # 会话可能在 connect 时自动开了
            sess = mc.session.current() if hasattr(mc.session, "current") else None
        check("会话已打开", sess is not None or mc._session is not None)
        path = getattr(sess, "path", None) or getattr(mc._session, "path", None)
        if path and os.path.isdir(path):
            files = set(os.listdir(path))
            check("raw.bin 已落盘", "raw.bin" in files, str(sorted(files)))
            check("raw.ts 已落盘", "raw.ts" in files)
            check("快帧 CSV 已落盘", "stream_250hz.csv" in files, str(sorted(files)))
            check("meta.json 已落盘", "meta.json" in files)
            fast_csv = os.path.join(path, "stream_250hz.csv")
            if os.path.exists(fast_csv):
                with open(fast_csv, encoding="utf-8") as f:
                    lines = f.read().splitlines()
                check("CSV 有表头且有数据", len(lines) >= 2, str(len(lines)))
                if lines:
                    cols = lines[0].split(",")
                    check("CSV 含 dev_ms 列", "dev_ms" in cols, str(cols[:8]))
                    check("CSV 含 seq 列", "seq" in cols, str(cols[:8]))
                    if len(lines) > 1 and "dev_ms" in cols:
                        i = cols.index("dev_ms")
                        vals = [ln.split(",")[i] for ln in lines[1:] if ln]
                        check("dev_ms 列非空(发车后应有值)",
                              any(v.strip() != "" for v in vals), str(vals[:5]))
            # raw.bin 非空
            rb = os.path.join(path, "raw.bin")
            if os.path.exists(rb):
                check("raw.bin 非空", os.path.getsize(rb) > 0, str(os.path.getsize(rb)))
    finally:
        if mc is not None:
            mc.close()
        os.environ.pop("HOST_SESSION_DIR", None)


# ---------------------------------------------------------------- T7 远程发车

def test_remote_launch(sim: "_Sim") -> None:
    print("\n[T7] 远程发车 MAZE RUN")
    with _connect(sim) as mc:
        mc.timesync.arm()
        mc.timesync.wait_sync(samples=2, timeout=6.0)
        r = mc.timesync.maze_run()
        check("MAZE RUN ACK OK", r.ok, r.status)
        # mazeRun 标志搭在 1Hz 的 TIME 帧上, 因此最多要等约 2 秒才看得到 —— 用轮询而不是死等
        deadline = time.time() + 4.0
        while time.time() < deadline and not mc.timesync.snapshot().maze_run:
            time.sleep(0.1)
        st = mc.timesync.snapshot()
        check("mazeRun 标志置位", st.maze_run, str(st.to_dict()))
        f, _m, s = mc.telemetry.latest()
        check("快帧出现运动任务码(真的在跑)",
              bool(f) and int(f.get("task", 0)) != 0, str(f.get("task") if f else None))
        check("慢帧 mouseTask = MAZESEARCH(2)",
              bool(s) and int(s.get("mouseTask", -1)) == 2,
              str(s.get("mouseTask") if s else None))
        r2 = mc.timesync.maze_run()
        check("重复发车被拒(ERR_BUSY)", r2.status == "ERR_BUSY", r2.status)


# ---------------------------------------------------------------- 入口

def main() -> int:
    print("=" * 66)
    print("电脑鼠 数据收集与时间同步 冒烟测试")
    print("=" * 66)

    test_pure_functions()
    test_seq_gap_detection()

    with _Sim() as sim:
        test_arm(sim)
    with _Sim() as sim:
        test_per_frame_time(sim)
    with _Sim() as sim:
        test_dump_absolute_axis(sim)
    with _Sim() as sim:
        test_session_integrity(sim)
    with _Sim() as sim:
        test_remote_launch(sim)

    print("\n" + "=" * 66)
    print(f"通过 {PASS} / 失败 {FAIL}")
    if FAILED:
        print(f"失败项: {FAILED}")
    print("=" * 66)
    return 1 if FAIL else 0


if __name__ == "__main__":
    sys.exit(main())
