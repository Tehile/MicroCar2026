"""验证: 连接失败时, 上位机是否把"为什么失败"写进日志, 并保持按钮状态正确。

覆盖两个真实场景:
  1) 端口不存在(COM99)
  2) 蓝牙『传入』端口(COM5) —— 能打开, 但永远收不到数据
"""

import os
import sys

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PySide6.QtWidgets import QApplication  # noqa: E402

from host.transport.link import Target, explain_open_error  # noqa: E402
from host.ui.main_window import MainWindow  # noqa: E402

PASS = 0
FAIL = 0


def check(name: str, cond: bool, extra: str = "") -> None:
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"  [OK]   {name}")
    else:
        FAIL += 1
        print(f"  [FAIL] {name} {extra}")


def console_text(w: MainWindow) -> str:
    """把控制台里的文本取出来(实现无关的几种兜底)。"""
    c = w.console
    for attr in ("toPlainText", "text"):
        f = getattr(c, attr, None)
        if callable(f):
            try:
                return f()
            except Exception:
                pass
    for attr in ("_view", "view", "_log", "log"):
        o = getattr(c, attr, None)
        if o is not None and hasattr(o, "toPlainText"):
            try:
                return o.toPlainText()
            except Exception:
                pass
    return ""


def main() -> int:
    app = QApplication.instance() or QApplication(sys.argv)
    w = MainWindow()

    print("=" * 70)
    print("连接失败诊断验证")
    print("=" * 70)

    # ---------- 场景 1: 端口不存在 ----------
    print("\n[场景1] 连接一个不存在的端口 COM99")
    ok = w.link.open(Target(kind="serial", port="COM99", baud=115200))
    check("open() 返回 False", ok is False, f"got {ok}")
    check("状态为 error", w.link.state == "error", w.link.state)
    det = w.link.state_detail
    print(f"         诊断: {det}")
    check("诊断含中文说明(不是裸异常)", any("\u4e00" <= ch <= "\u9fff" for ch in det), det)

    # ---------- 场景 2: 传入端口(能打开但没数据) ----------
    print("\n[场景2] 连接蓝牙『传入』端口 COM5")
    ok2 = w.link.open(Target(kind="serial", port="COM5", baud=115200))
    print(f"         COM5 open() -> {ok2}  (传入端口能打开, 所以预期 True)")
    if ok2:
        w.link.close()

    # ---------- 场景 3: MainWindow 的失败路径不破坏 UI 状态 ----------
    print("\n[场景3] 通过按钮路径连接失败时的界面行为")
    w.link.close()
    # 找一个不存在的目标塞进下拉框
    w._targets.append(Target(kind="serial", port="COM98", baud=115200))
    w.cb_target.addItem("[测试] COM98")
    w.cb_target.setCurrentIndex(len(w._targets) - 1)
    w.btn_connect.setText("连接")
    w._toggle_connect()
    print(f"         按钮文本: {w.btn_connect!r}")
    check("失败后按钮仍是『连接』(没有假装连上)", w.btn_connect.text() == "连接",
          w.btn_connect.text())
    check("失败后下拉框仍可用(可以改选端口)", w.cb_target.isEnabled())
    check("失败后没有创建会话目录", w.session is None,
          str(getattr(w.session, "path", None)))

    # ---------- 场景 4: 错误进入日志 ----------
    w._scan_ports()
    w._targets.append(Target(kind="serial", port="COM98", baud=115200))
    w.cb_target.addItem("[测试] COM98")
    w.cb_target.setCurrentIndex(len(w._targets) - 1)
    w._toggle_connect()
    w._drain_link_state()
    txt = console_text(w)
    print("         控制台尾部:")
    for line in txt.strip().splitlines()[-4:]:
        print(f"           {line}")
    check("日志里出现『链路错误』", "链路错误" in txt, txt[-160:])
    check("日志里出现了具体原因", ("不存在" in txt or "占用" in txt or "打开" in txt))

    w.link.close()
    print("\n" + "=" * 70)
    print(f"通过 {PASS} / 失败 {FAIL}")
    print("=" * 70)
    return 1 if FAIL else 0


if __name__ == "__main__":
    raise SystemExit(main())
