"""串口链路诊断: 判断端口类型(传出/传入)、可打开性、是否有数据。

用法:
    python diag_port.py            # 诊断全部串口
    python diag_port.py COM5       # 只看指定端口
"""

from __future__ import annotations

import sys
import time
from typing import List

try:
    from serial.tools import list_ports
except Exception:
    print("缺少 pyserial")
    sys.exit(1)

import serial  # noqa: E402


def classify(hwid: str) -> str:
    """按 BTHENUM 实例路径判断方向。"""
    if "BTHENUM" not in hwid.upper():
        return "usb/其他"
    tail = hwid.rsplit("_", 1)[-1] if "_" in hwid else ""
    body = hwid.upper()
    if "LOCALMFG" in body or "000000000000" in hwid:
        return "蓝牙-传入(空壳/等待设备连入)"
    if "VID&" in body and "_C" in hwid:
        return "蓝牙-传出(绑定具体设备, 主动连它)"
    return "蓝牙-未知方向"


def remote_mac(hwid: str) -> str:
    if "BTHENUM" not in hwid.upper():
        return ""
    parts = hwid.split("\\")
    for p in parts:
        if len(p) >= 12 and all(c in "0123456789ABCDEFabcdef" for c in p[-12:]) and p != "000000000000":
            mac = p[-12:].upper()
            if mac != "000000000000":
                return ":".join(mac[i:i + 2] for i in range(0, 12, 2))
    return ""


def probe(port: str, baud: int = 115200, listen_s: float = 2.0,
          send: bytes = b"") -> dict:
    r: dict = {"port": port, "baud": baud, "opened": False, "error": "",
               "bytes": 0, "head": b"", "elapsed": 0.0}
    t0 = time.time()
    try:
        s = serial.Serial(port, baud, bytesize=8, parity="N", stopbits=1,
                          timeout=0.2, write_timeout=0.5)
    except Exception as e:
        r["error"] = f"{type(e).__name__}: {e}"
        r["elapsed"] = time.time() - t0
        return r
    try:
        r["opened"] = True
        r["elapsed"] = time.time() - t0
        try:
            s.reset_input_buffer()
            s.reset_output_buffer()
        except Exception:
            pass
        if send:
            try:
                s.write(send)
            except Exception as e:
                r["error"] = f"write: {e}"
        got = bytearray()
        t1 = time.time()
        while time.time() - t1 < listen_s:
            try:
                d = s.read(4096)
            except Exception as e:
                r["error"] = f"read: {e}"
                break
            if d:
                got += d
                if len(got) > 8192:
                    break
        r["bytes"] = len(got)
        r["head"] = bytes(got[:64])
    finally:
        try:
            s.close()
        except Exception:
            pass
    return r


def main() -> int:
    want = sys.argv[1].upper() if len(sys.argv) > 1 else ""
    ports: List = [p for p in list_ports.comports()
                   if not want or p.device.upper() == want]
    if not ports:
        print(f"未找到端口 {want or '(无任何串口)'}")
        return 1

    print("=" * 78)
    print("串口链路诊断")
    print("=" * 78)
    for p in ports:
        kind = classify(p.hwid or "")
        mac = remote_mac(p.hwid or "")
        print(f"\n{p.device}  [{kind}]")
        print(f"  描述   : {p.description}")
        if mac:
            print(f"  远端MAC: {mac}")

    print("\n" + "-" * 78)
    print("逐个尝试打开并监听 2 秒 (含一次 PING 触发)")
    print("-" * 78)
    for p in ports:
        r = probe(p.device, 115200, 2.0, send=b"PING\r\n")
        if not r["opened"]:
            print(f"  {r['port']}: 打开失败 ({r['elapsed']:.1f}s) -> {r['error']}")
            if "信号灯超时" in r["error"] or "121" in r["error"]:
                print("           ^ 蓝牙 RFCOMM 建链超时: 设备不在范围内/未上电/链路已断")
            elif "拒绝访问" in r["error"] or "PermissionError" in r["error"]:
                print("           ^ 端口被其它程序占用(串口助手/另一个上位机/Keil)")
            elif "不存在" in r["error"] or "could not open port" in r["error"]:
                print("           ^ 端口不存在或已被移除")
            continue
        if r["bytes"] == 0:
            print(f"  {r['port']}: 打开成功, 2s 内 0 字节")
            print("           ^ 端口可用但无数据流: 链路未真正建立, 或 MCU 未在发送")
        else:
            print(f"  {r['port']}: 打开成功, 收到 {r['bytes']} 字节")
            print(f"           前 64B: {r['head'][:64].hex(' ')}")
            print(f"           repr  : {r['head'][:64]!r}")
    print("\n" + "=" * 78)
    print("判读要点")
    print("=" * 78)
    print("  - 只有『传出』端口才连得上设备;『传入』是本地空壳, 永远等不到数据")
    print("  - 打开成功但没有数据 = 蓝牙链路未建立 或 MCU 未发送")
    print("  - 若没有列出任何非蓝牙端口, 说明当前没有插入 USB 转串口设备")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
