"""注册表契约测试 —— 扩展性保证(E1/E3)的机器强制。

回答一个问题: **"新增一项功能, 接口有没有自动覆盖?"**

静态断言(不连设备):
    S1  link.py 的帧分派必须走 registry.FRAMES 表, 不得硬编码 decode_*/TYPE_*
    S2  每条 CommandSpec 都能拼出非空命令文本, 且 args 与 build 签名一致
    S3  每条 FrameSpec 都能"打包 -> 解析 -> 解码"往返并产出 dict
    S4  登记表数量不低于基线(防止误删)

动态断言(连模拟器):
    D1  每条 CommandSpec 用示例参数发一次, 收到 ACK ... OK
    D2  每个 PARAM_IDS 可读写, 且回读值与写入一致(Q16.16)

用法:
    python contract_test.py              # 自动拉起模拟器
    python contract_test.py --port 5556 # 连已运行模拟器
"""

from __future__ import annotations

import argparse
import socket
import struct
import subprocess
import sys
import time

import numpy as np

from host.protocol.codec import (
    TYPE_DUMP_BLK,
    TYPE_DUMP_END,
    TYPE_DUMP_HDR,
    TYPE_FAST,
    TYPE_MAP,
    TYPE_MID,
    TYPE_SLOW,
    TYPE_TIME,
    float_to_q1616,
    pack_frame,
    FrameStreamParser,
)
from host.protocol.commands import PARAM_IDS
from host.registry import (
    COMMANDS,
    FRAMES,
    command_line,
    check_frame_dispatch_is_table_driven,
    spec_of,
)

PASS = 0
FAIL = 0


def check(name: str, cond: bool, detail: str = "") -> None:
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"  [OK]   {name}")
    else:
        FAIL += 1
        print(f"  [FAIL] {name}  {detail}")


def _free_port() -> int:
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    return port


# ---------------------------------------------------------------- 静态

def test_static() -> None:
    print("\n[S] 静态断言")

    # S1: link.py 分派必须查表
    import os

    from host.transport import link as link_mod

    src = open(link_mod.__file__, encoding="utf-8").read()
    bad = check_frame_dispatch_is_table_driven(src)
    check("link.py 帧分派走 registry.FRAMES(无硬编码 decode_*)", not bad, "\n".join(bad))

    # S4: 数量基线(与固件实际命令集一致: 28 条命令 / 8 种帧 / 21 参数)
    check(f"COMMANDS 登记 {len(COMMANDS)} 条(基线 28)", len(COMMANDS) >= 28, str(len(COMMANDS)))
    check(f"FRAMES 登记 {len(FRAMES)} 种(基线 8)", len(FRAMES) >= 8, str(len(FRAMES)))
    check(f"PARAM_IDS 登记 {len(PARAM_IDS)} 项(基线 21)", len(PARAM_IDS) >= 21, str(len(PARAM_IDS)))

    # FRAMES 覆盖全部 TYPE_* 常量
    all_types = {TYPE_FAST, TYPE_MID, TYPE_SLOW, TYPE_DUMP_HDR, TYPE_DUMP_BLK, TYPE_DUMP_END,
                 TYPE_MAP, TYPE_TIME}
    check("FRAMES 覆盖全部 8 种帧类型", all_types.issubset(set(FRAMES)),
          str(all_types - set(FRAMES)))

    # S5: CLI 必须能导入并构建 parser
    #     它的教训很直接: cli.py 曾经因为"两条语句挤在一行"而语法错误,
    #     但没有任何测试 import 它 -> 错误一路潜行到生成文档时才炸。
    try:
        import argparse

        from host import cli as _cli

        parser = _cli._build_parser()
        choices: set = set()
        for act in parser._actions:
            if isinstance(act, argparse._SubParsersAction):
                choices = set(act.choices)
                break
        need = {"ports", "connect", "get", "get-all", "set", "calib", "save", "scope",
                "maze", "monitor", "motor-test", "estop", "diagnose", "scan-baud", "replay",
                "lesson", "datalog"}
        missing = need - choices
        check(f"CLI 可导入且子命令齐备({len(choices)} 个, 含 motor-test/lesson/datalog)",
              not missing, f"缺 {sorted(missing)}")
    except Exception as e:  # noqa: BLE001
        check("CLI 可导入并构建 parser", False, f"{type(e).__name__}: {e}")


def test_command_build() -> None:
    print("\n[S2] 命令构建")
    for name, spec in COMMANDS.items():
        # 用示例参数拼一条命令
        args = {k: _EXAMPLE_ARGS[k] for k in spec.args}
        try:
            line = command_line(name, **args)
        except Exception as e:
            check(f"{name}: 可拼命令", False, f"{type(e).__name__}: {e}")
            continue
        ok = bool(line) and "\n" not in line and "\r" not in line and line == line.strip()
        check(f"{name}: 产出非空单行命令 '{line}'", ok, repr(line))
        # 命令必须是大写关键字开头(与固件 token 解析一致)
        head = line.split()[0].upper()
        check(f"{name}: 关键字大写 '{head}'", head == line.split()[0], repr(line))


def test_frames_roundtrip() -> None:
    print("\n[S3] 帧打包/解析/解码往返")
    parser = FrameStreamParser()
    for ftype, spec in FRAMES.items():
        payload = _PAYLOAD_BUILDERS[ftype]()
        frame = pack_frame(ftype, payload, 1)
        frames, _ = parser.feed(frame)
        if not frames:
            check(f"{spec.name}: 解析出帧", False)
            continue
        rec = spec.decoder(frames[0].payload)
        check(f"{spec.name}: 解码产出 dict", isinstance(rec, dict) and bool(rec),
              str(type(rec).__name__))


# ---------------------------------------------------------------- 动态

def test_commands_e2e(port: int) -> None:
    print("\n[D1] 每条命令在模拟器上收到 ACK OK")
    from host.api import MouseClient

    with MouseClient.connect_to(f"tcp://127.0.0.1:{port}") as mc:
        check("连接成功", mc.is_connected, mc.state_detail)

        # 按顺序执行, 覆盖所有登记命令; 顺序照顾副作用(先无副作用, 后动作)
        order = [
            "ping", "ver", "params.get", "params.get_all", "params.setq", "params.set",
            "params.save", "params.reset", "tare", "stream.on", "stream.off", "stream.on",
            "rate", "calib.cal", "scope.start", "scope.stop", "scope.dump",
            "maze.dump", "move.fwd", "move.rot", "move.run", "stop", "estop", "estop.clear",
            # ---- 课程调参实验(放最后: start 会启动一段剖面, status 应见 running=1, stop 收尾) ----
            "lesson.start", "lesson.status", "lesson.stop",
            # ---- 时间同步 / 数据收集 ----
            "arm", "maze.run",
        ]
        covered = set()
        for name in order:
            args = {k: _EXAMPLE_ARGS[k] for k in spec_of(name).args}
            r = mc.send_cmd(name, timeout=5.0, **args)
            covered.add(name)
            check(f"{name}: ACK OK", r.ok, f"{r.status} cmd={r.data.get('cmd')!r}")
            time.sleep(0.02)

        # 覆盖率: 所有登记命令都必须被跑到
        missing = set(COMMANDS) - covered
        check("覆盖全部登记命令", not missing, f"未覆盖: {missing}")
        # 反向: 顺序里不得有未登记的命令
        unknown = covered - set(COMMANDS)
        check("顺序里无未登记命令", not unknown, str(unknown))


def test_params_e2e(port: int) -> None:
    print("\n[D2] 每个参数读写往返一致")
    from host.api import MouseClient

    with MouseClient.connect_to(f"tcp://127.0.0.1:{port}") as mc:
        for name, nid in sorted(PARAM_IDS.items(), key=lambda kv: kv[1]):
            # 读原始值, 写回同一个值, 再读校验(用 SETQ 保证无精度损失)
            before = mc.params.get_raw(name)
            if before is None:
                check(f"{name}: 可回读", False)
                continue
            r = mc.params.set_raw(name, before, readback=True)
            check(f"{name}: 写回并校验", r.ok, r.status)
            check(f"{name}: 回读与写入一致", r.ok and r.data.get("readback") == before,
                  str(r.data.get("readback")))


# ---------------------------------------------------------------- 示例参数

_EXAMPLE_ARGS = {
    "name": "TRACKL",
    "q": float_to_q1616(53.2),
    "v": "53.2",
    "hz": 5,
    "item": "GYRO",
    "act": "START",
    "pulses": 3000,
    "speed": 40,
    "pwm": 40,
    "ms": 100,
    "cond": "TASK",
    "sp_l": 40,
    "sp_r": -40,
    "ir_mm": 10,
    # ---- 课程调参实验 ----
    "exp": 3,           # lesson.start
    "a": 50,            # v  (实验三/四/七) 或 angle (实验六)
    "b": 200,           # dist (实验三/七) 或 t_acc (实验四) 或 v (实验六)
    "c": 800,           # ms (实验三/六/七) 或 t_cruise (实验四)
    "d": 200,           # t_dec (实验四)
}


def _payload_fast() -> bytes:
    return struct.pack("<hhhhhhBBBB", 68, -12, 90, 5, 68, -12, 32, 76, 0x01, 0)


def _payload_mid() -> bytes:
    return struct.pack("<hhhhhh", 120, 300, 301, 2048, 12, 45)


def _payload_slow() -> bytes:
    return struct.pack("<hhhhBBbbHBB", 232, 231, 42, 43, 0x05, 2, 3, 4, 762, 21, 0)


def _payload_dump_hdr() -> bytes:
    return struct.pack("<HBBHHI", 1200, 60, 4, 900, 300, 55555)


def _payload_time() -> bytes:
    # upMs(u32) | armMs(u32) | led(u8) | flags(u8) | rsvd(u16)
    return struct.pack("<IIBBH", 12345, 10000, 1, 0x07, 0)


def _payload_dump_blk() -> bytes:
    body = bytearray()
    for i in range(4):
        body += struct.pack("<BBhhh", 32, 0, 90 + i, 40 + i, -40 - i)
    return struct.pack("<H", 3) + bytes(body)


def _payload_dump_end() -> bytes:
    return struct.pack("<i", 123456)


def _payload_map() -> bytes:
    n = 7
    wall = bytes([0x03] * (n * n))
    vis = bytes([1] * (n * n))
    return struct.pack("<bbBB", 3, 4, 1, 2) + wall + vis


_PAYLOAD_BUILDERS = {
    TYPE_FAST: _payload_fast,
    TYPE_MID: _payload_mid,
    TYPE_SLOW: _payload_slow,
    TYPE_DUMP_HDR: _payload_dump_hdr,
    TYPE_DUMP_BLK: _payload_dump_blk,
    TYPE_DUMP_END: _payload_dump_end,
    TYPE_MAP: _payload_map,
    TYPE_TIME: _payload_time,
}


def main() -> int:
    ap = argparse.ArgumentParser(description="注册表契约测试")
    ap.add_argument("--port", type=int, default=0, help="已运行模拟器端口(默认自动拉起)")
    args = ap.parse_args()

    print("=" * 66)
    print("电脑鼠上位机 注册表契约测试")
    print("=" * 66)
    test_static()
    test_command_build()
    test_frames_roundtrip()

    port = args.port or _free_port()
    proc = None
    if not args.port:
        proc = subprocess.Popen(
            [sys.executable, "-m", "host.sim.mouse_sim", "--port", str(port), "--no-auto"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        time.sleep(1.2)

    try:
        test_commands_e2e(port)
        test_params_e2e(port)
    finally:
        if proc is not None:
            proc.terminate()
            try:
                proc.wait(timeout=3)
            except subprocess.TimeoutExpired:
                proc.kill()

    print("\n" + "=" * 66)
    print(f"通过 {PASS} / 失败 {FAIL}")
    print("=" * 66)
    return 1 if FAIL else 0


if __name__ == "__main__":
    sys.exit(main())
