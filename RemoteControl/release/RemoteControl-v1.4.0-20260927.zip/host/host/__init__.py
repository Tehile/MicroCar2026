"""电脑鼠蓝牙上位机。

与固件 HARDWARE/link.c 配对使用; 协议定义见 docs/蓝牙上位机设计方案.md。
可编程接口(门面)见 `host.api`; 接口参考见 docs/api_reference.md。
"""

__version__ = "1.1.0"
PROTO_VER = 1

from .registry import API_VERSION  # noqa: E402  (语义化 API 版本, 与固件 proto 分开)

__all__ = ["__version__", "PROTO_VER", "API_VERSION"]
