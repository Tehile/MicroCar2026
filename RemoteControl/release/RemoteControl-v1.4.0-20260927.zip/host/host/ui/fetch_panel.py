"""停车后数据拉取面板。

分工(由实测链路能力决定):
  实时流  ≈ 152 B/s  ->  只够传状态/信息(见 StatusPanel)
  完整波形  1kHz x 1200 点 x 4 通道 = 9600B  ->  停车后一次性回传, 约 60 秒

因此本面板的核心是**让这 60 秒看得见**: 进度条 + 已传块数 + 预计剩余时间。
"""

from __future__ import annotations

import time
from typing import Callable, Optional

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QProgressBar,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from ..model.ring import TelemetryStore
from ..protocol.commands import CommandClient

# 与固件 LINK_SCOPE_* 常量一致
SCOPE_LEN = 1200
SCOPE_PTS_PER_BLK = 60
SCOPE_BLKS = SCOPE_LEN // SCOPE_PTS_PER_BLK  # 20
DUMP_BYTES = SCOPE_LEN * 8 + SCOPE_BLKS * 8  # 数据 + 每块开销


class FetchPanel(QWidget):
    def __init__(
        self,
        client: CommandClient,
        store: TelemetryStore,
        log: Callable[[str], None],
        on_loaded: Optional[Callable[[], None]] = None,
    ) -> None:
        super().__init__()
        self.client = client
        self.store = store
        self.log = log
        self.on_loaded = on_loaded
        self._started = 0.0
        self._last_done = 0.0

        root = QVBoxLayout(self)
        root.setContentsMargins(6, 6, 6, 6)
        root.setSpacing(8)

        hint = QLabel(
            "实时链路约 152 B/s, 只够传状态。\n"
            "完整波形是 1kHz × 1200 点(dump), 请在**停车后**一次性回传 —— 约需 60 秒,\n"
            "期间下方会显示进度与预计剩余时间。"
        )
        hint.setWordWrap(True)
        hint.setStyleSheet("color:#FFD54F;")
        root.addWidget(hint)

        # ---------- 步骤 ----------
        box = QGroupBox("操作步骤")
        v = QVBoxLayout(box)

        row1 = QHBoxLayout()
        self.btn_start = QPushButton("① 开始采集")
        self.btn_start.setStyleSheet("background:#2e7d32; color:white;")
        self.btn_start.clicked.connect(self._on_start)
        row1.addWidget(self.btn_start)

        self.btn_stop = QPushButton("② 停车并停止采集")
        self.btn_stop.setStyleSheet("background:#e65100; color:white;")
        self.btn_stop.clicked.connect(self._on_stop)
        row1.addWidget(self.btn_stop)

        self.btn_dump = QPushButton("③ 拉取完整数据")
        self.btn_dump.setStyleSheet("background:#1565c0; color:white;")
        self.btn_dump.clicked.connect(self._on_dump)
        row1.addWidget(self.btn_dump)
        row1.addStretch(1)
        v.addLayout(row1)

        v.addWidget(QLabel("采集说明: 采集在固件里以 1kHz 滚动进行; 采满 1200 点(=1.2 秒)会覆盖最早的点,"
                           "所以『停止』要在这个动作结束后尽快按。"))

        root.addWidget(box)

        # ---------- 进度 ----------
        pbox = QGroupBox("回传进度")
        pv = QVBoxLayout(pbox)

        self.bar = QProgressBar()
        self.bar.setRange(0, 100)
        self.bar.setValue(0)
        self.bar.setFormat("%p%  (%v/100)")
        pv.addWidget(self.bar)

        row2 = QHBoxLayout()
        self.lbl_phase = QLabel("空闲")
        self.lbl_phase.setStyleSheet("color:#bdbdbd;")
        row2.addWidget(self.lbl_phase, 1)
        self.lbl_eta = QLabel("")
        self.lbl_eta.setStyleSheet("color:#FFD54F;")
        row2.addWidget(self.lbl_eta)
        self.lbl_rate = QLabel("")
        self.lbl_rate.setStyleSheet("color:#9e9e9e;")
        row2.addWidget(self.lbl_rate)
        pv.addLayout(row2)

        root.addWidget(pbox)
        root.addStretch(1)

    # ------------------------------------------------------------ 动作

    def _on_start(self) -> None:
        self.store.reset_dump()
        self.bar.setValue(0)
        self.lbl_eta.setText("")
        self.client.send("SCOPE START")
        self._started = time.time()
        self.log("[采集] 已请求 SCOPE START —— 请在动作结束后尽快点『② 停车并停止采集』")
        self.lbl_phase.setText("采集中(固件侧 1kHz 滚动)")
        self.lbl_phase.setStyleSheet("color:#81c784;")

    def _on_stop(self) -> None:
        self.client.send("STOP")
        self.client.send("SCOPE STOP")
        self.lbl_phase.setText("已停止, 可执行『③ 拉取完整数据』")
        self.lbl_phase.setStyleSheet("color:#FFD54F;")
        self.log("[采集] 已请求 STOP + SCOPE STOP")

    def _on_dump(self) -> None:
        self.store.reset_dump()
        self.bar.setValue(0)
        self._started = time.time()
        self.client.send("SCOPE DUMP")
        self.lbl_phase.setText("回传中 ...")
        self.lbl_phase.setStyleSheet("color:#64B5F6;")
        self.log(f"[回传] 已请求 SCOPE DUMP (~{DUMP_BYTES / 152.0:.0f}s @152 B/s)")

    # ------------------------------------------------------------ 刷新

    def refresh(self) -> None:
        prog = float(self.store.dump_progress())
        # 固件按块推进; 进度 0..1
        if self.store.dump_done:
            if self._last_done != self.store.dump_time:
                self._last_done = self.store.dump_time
                self.bar.setValue(100)
                self._on_load()
            return

        if prog > 0.0:
            self.bar.setValue(int(prog * 100))
            elapsed = time.time() - self._started
            eta = elapsed / prog - elapsed if prog > 0.02 else None
            n_blk = int(prog * SCOPE_BLKS)
            self.lbl_phase.setText(f"回传中 ... 已收 {n_blk}/{SCOPE_BLKS} 块")
            self.lbl_eta.setText(f"预计剩余 {eta:.0f}s" if eta else "预计剩余 —")
            rx = self.store.dump_bytes_received()
            if rx and elapsed > 0.5:
                self.lbl_rate.setText(f"{rx / elapsed:.0f} B/s")
        elif self.bar.value() != 0 and not self.store.dump_done:
            # dump 请求已发但还没数据: 可能是忙或链路在恢复
            self.lbl_phase.setText("等待设备响应 ... (若超过 10s 无数据, 可能上一轮缓冲未排空)")

    def _on_load(self) -> None:
        self.lbl_phase.setText("已回传完成")
        self.lbl_phase.setStyleSheet("color:#81c784;")
        self.lbl_eta.setText("")
        n = len(self.store.dump_records)
        self.log(f"[回传] 完成: {n} 点 @1kHz" + (f" = {n/1000.0:.2f}s" if n else ""))
        if self.on_loaded:
            self.on_loaded()
