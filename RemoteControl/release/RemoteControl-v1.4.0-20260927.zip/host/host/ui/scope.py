"""波形视图: 实时滚动 + 1kHz dump 分析。

实时视图按流分图(快/中/慢各自时基), 每个 plot 的通道可单独勾选。
dump 视图提供两条可拖动的游标做 A/B 测量, 并自动标注动作分段与指标。
"""

from __future__ import annotations

from typing import Dict, List, Optional, Tuple

import numpy as np
import pyqtgraph as pg
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QCheckBox,
    QHBoxLayout,
    QLabel,
    QListWidget,
    QListWidgetItem,
    QPushButton,
    QSplitter,
    QVBoxLayout,
    QWidget,
)

from ..analysis.metrics import format_metrics, segment_by_task, step_metrics, tracking_error
from ..model.ring import TelemetryStore
from ..protocol.codec import MOTION_TASK_NAMES

# (plot 标题, 所属流, [(通道名, 显示名, 颜色, 线宽, 虚线)])
PLOT_SPECS: List[Tuple[str, str, List[Tuple[str, str, str, float, bool]]]] = [
    (
        "转速 (cm/s)",
        "fast",
        [
            ("speedL", "左轮实测", "#4FC3F7", 1.8, False),
            ("speedR", "右轮实测", "#FFB74D", 1.8, False),
            ("speedTargetL", "左轮目标", "#4FC3F7", 1.0, True),
            ("speedTargetR", "右轮目标", "#FFB74D", 1.0, True),
        ],
    ),
    (
        "姿态与误差 (deg)",
        "fast",
        [
            ("gyroAngle", "陀螺航向", "#81C784", 1.6, False),
            ("pidErr", "pidErr", "#E57373", 1.2, False),
        ],
    ),
    (
        "里程与编码器角 (mm / deg)",
        "mid",
        [
            ("cellOdom", "格内里程", "#BA68C8", 1.6, False),
            ("trackL", "左轮里程", "#4FC3F7", 1.2, False),
            ("trackR", "右轮里程", "#FFB74D", 1.2, False),
            ("encAngle", "编码器角", "#A1887F", 1.0, True),
        ],
    ),
    (
        "红外测距 (mm)",
        "slow",
        [
            ("irF1", "前左", "#81C784", 1.6, False),
            ("irF2", "前右", "#AED581", 1.6, True),
            ("irL", "左", "#4FC3F7", 1.4, False),
            ("irR", "右", "#FFB74D", 1.4, False),
        ],
    ),
    (
        "电源与负载",
        "slow",
        [
            ("volt", "电池电压 (V)", "#FFD54F", 1.6, False),
            ("cpu", "CPU 占用 (%)", "#90A4AE", 1.2, False),
        ],
    ),
]


class _PlotGroup:
    def __init__(self, layout: pg.GraphicsLayoutWidget, row: int, title: str, channels) -> None:
        self.title = title
        self.channels = channels
        self.plot = layout.addPlot(row=row, col=0)
        self.plot.setTitle(title, color="#c8c8c8", size="10pt")
        self.plot.showGrid(x=True, y=True, alpha=0.25)
        self.plot.addLegend(offset=(8, 6), labelTextColor="#c8c8c8", brush=(0, 0, 0, 0))
        self.curves = {}
        for name, disp, color, width, dashed in channels:
            pen = pg.mkPen(color, width=width, style=Qt.DashLine if dashed else Qt.SolidLine)
            self.curves[name] = self.plot.plot([], [], pen=pen, name=disp)

    def visible_channels(self) -> List[str]:
        return [n for n, *_ in self.channels]

    def update(self, t: np.ndarray, data: np.ndarray, ch_index: Dict[str, int]) -> None:
        if len(t) == 0:
            return
        x = t - t[-1]
        for name, *_ in self.channels:
            i = ch_index.get(name)
            if i is None:
                continue
            self.curves[name].setData(x, data[:, i])


class ScopeWidget(QWidget):
    """实时滚动波形。由主窗口定时器驱动 update_data()。"""

    def __init__(self, store: TelemetryStore) -> None:
        super().__init__()
        self.store = store
        self.window_s = 10.0
        self.frozen = False

        root = QHBoxLayout(self)
        root.setContentsMargins(4, 4, 4, 4)

        left = QVBoxLayout()
        self._checks: List[QCheckBox] = []
        for spec in PLOT_SPECS:
            gb = QLabel(f"<b>{spec[0]}</b>")
            gb.setStyleSheet("color:#dcdcdc; padding-top:4px;")
            left.addWidget(gb)
            for name, disp, color, _w, _d in spec[2]:
                cb = QCheckBox(disp)
                cb.setChecked(True)
                cb.setStyleSheet(f"color:{color};")
                cb.stateChanged.connect(self._apply_visibility)
                left.addWidget(cb)
                self._checks.append(cb)
            left.addSpacing(6)

        left.addWidget(QLabel("时间窗口"))
        self._win_btns = []
        for s in (2.0, 5.0, 10.0, 30.0):
            b = QPushButton(f"{s:.0f}s")
            b.setCheckable(True)
            b.setChecked(s == 10.0)
            b.clicked.connect(lambda _=False, v=s: self._set_window(v))
            left.addWidget(b)
            self._win_btns.append((b, s))
        left.addStretch(1)
        self.freeze_btn = QPushButton("冻结")
        self.freeze_btn.setCheckable(True)
        self.freeze_btn.toggled.connect(lambda v: setattr(self, "frozen", v))
        left.addWidget(self.freeze_btn)

        panel = QWidget()
        panel.setLayout(left)
        panel.setFixedWidth(170)

        self.layout_widget = pg.GraphicsLayoutWidget()
        self.groups: List[_PlotGroup] = []
        for i, (title, _stream, channels) in enumerate(PLOT_SPECS):
            self.groups.append(_PlotGroup(self.layout_widget, i, title, channels))
            if i < len(PLOT_SPECS) - 1:
                self.layout_widget.nextRow()
        # 统一 x 轴联动
        for g in self.groups[1:]:
            g.plot.setXLink(self.groups[0].plot)
        self.groups[0].plot.setLabel("bottom", "t (s, 0 = 最新)")

        root.addWidget(panel)
        root.addWidget(self.layout_widget, 1)

    def _apply_visibility(self) -> None:
        i = 0
        for gi, spec in enumerate(PLOT_SPECS):
            for name, *_ in spec[2]:
                cb = self._checks[i]
                i += 1
                self.groups[gi].curves[name].setVisible(cb.isChecked())

    def _set_window(self, v: float) -> None:
        self.window_s = v
        for b, s in self._win_btns:
            b.setChecked(s == v)

    def refresh(self) -> None:
        if self.frozen:
            return
        streams = {"fast": self.store.fast, "mid": self.store.mid, "slow": self.store.slow}
        for row, (title, stream, channels) in enumerate(PLOT_SPECS):
            rb = streams[stream]
            t, data = rb.snapshot(seconds=self.window_s)
            if len(t) == 0:
                continue
            ch_index = {c: i for i, c in enumerate(rb.channels)}
            self.groups[row].update(t, data, ch_index)


# ---------------------------------------------------------------- dump 视图

DUMP_CHANNELS = [
    ("speedl", "左轮速度", "#4FC3F7", 1.6),
    ("speedr", "右轮速度", "#FFB74D", 1.6),
]
DUMP_ANGLE = [("gangle", "陀螺航向 (deg)", "#81C784", 1.6)]


class DumpWidget(QWidget):
    """1kHz dump 波形 + 游标测量 + 指标标注。"""

    def __init__(self, store: TelemetryStore) -> None:
        super().__init__()
        self.store = store
        self.host = None

        root = QVBoxLayout(self)
        root.setContentsMargins(4, 4, 4, 4)

        bar = QHBoxLayout()
        self.info = QLabel("尚无 dump 数据。先在设备上跑一段动作, 然后点『开始采集』→『停止』→『dump』。")
        self.info.setStyleSheet("color:#dcdcdc;")
        bar.addWidget(self.info, 1)
        self.metrics_lbl = QLabel("")
        self.metrics_lbl.setStyleSheet("color:#FFD54F; font-weight:500;")
        bar.addWidget(self.metrics_lbl)
        root.addLayout(bar)

        self.glw = pg.GraphicsLayoutWidget()
        self.p_speed = self.glw.addPlot(row=0, col=0)
        self.p_speed.setTitle("轮速 (cm/s)", color="#c8c8c8", size="10pt")
        self.p_speed.showGrid(x=True, y=True, alpha=0.25)
        self.p_speed.addLegend(offset=(8, 6), labelTextColor="#c8c8c8", brush=(0, 0, 0, 0))
        self.curve_l = self.p_speed.plot([], [], pen=pg.mkPen("#4FC3F7", width=1.6), name="左轮")
        self.curve_r = self.p_speed.plot([], [], pen=pg.mkPen("#FFB74D", width=1.6), name="右轮")

        self.p_ang = self.glw.addPlot(row=1, col=0)
        self.p_ang.setTitle("陀螺航向 (deg)", color="#c8c8c8", size="10pt")
        self.p_ang.showGrid(x=True, y=True, alpha=0.25)
        self.curve_a = self.p_ang.plot([], [], pen=pg.mkPen("#81C784", width=1.6))

        self.p_task = self.glw.addPlot(row=2, col=0)
        self.p_task.setTitle("motionTask", color="#c8c8c8", size="10pt")
        self.p_task.showGrid(x=True, y=True, alpha=0.25)
        # 注意: 不要用 stepMode='center' —— pyqtgraph 在该模式下要求 len(x) == len(y)+1,
        # 而这里 x/y 同长, 会直接抛异常。motionTask 是离散码, 用普通折线的跳变已经足够表达。
        self.curve_t = self.p_task.plot([], [], pen=pg.mkPen("#BA68C8", width=1.4))
        self.p_task.setLabel("bottom", "时间 (ms)")
        self.p_ang.setXLink(self.p_speed)
        self.p_task.setXLink(self.p_speed)

        self.cursor_a = pg.InfiniteLine(angle=90, movable=True, pen=pg.mkPen("#E57373", width=1))
        self.cursor_b = pg.InfiniteLine(angle=90, movable=True, pen=pg.mkPen("#64B5F6", width=1))
        for p in (self.p_speed, self.p_ang, self.p_task):
            p.addItem(self.cursor_a, ignoreBounds=True)
            p.addItem(self.cursor_b, ignoreBounds=True)
        self.cursor_a.sigPositionChanged.connect(self._update_cursor_readout)
        self.cursor_b.sigPositionChanged.connect(self._update_cursor_readout)

        root.addWidget(self.glw, 1)

        self.seg_list = QListWidget()
        self.seg_list.setMaximumHeight(110)
        self.seg_list.itemClicked.connect(self._jump_to_segment)
        self._segments: List[dict] = []
        root.addWidget(self.seg_list)

        self.t = None
        self.arr = None

    # ------------------------------------------------------------ 数据

    def load_from_store(self) -> bool:
        data = self.store.dump_arrays()
        if data is None:
            return False
        t, mt, ang, sl, sr = data
        self.t = t
        self.arr = {"motionTask": mt, "gangle": ang, "speedl": sl, "speedr": sr}
        self.curve_l.setData(t, sl)
        self.curve_r.setData(t, sr)
        self.curve_a.setData(t, ang)
        self.curve_t.setData(t, mt)
        n = len(t)
        self.cursor_a.setValue(t[max(0, n // 3)])
        self.cursor_b.setValue(t[max(0, 2 * n // 3)])
        hdr = self.store.dump_hdr or {}
        self.info.setText(
            f"dump: {n} 点 @1kHz = {n / 1000.0:.2f}s   通道 {hdr.get('channels', '?')}   "
            f"校验和 {self.store.dump_chksum}"
        )
        self._build_segments()
        self._auto_metrics()
        return True

    def _build_segments(self) -> None:
        self.seg_list.clear()
        self._segments = segment_by_task(self.t, self.arr["motionTask"])
        for s in self._segments:
            name = MOTION_TASK_NAMES.get(s["task"], str(s["task"]))
            self.seg_list.addItem(
                QListWidgetItem(f"[{s['t0_ms']:.0f}–{s['t1_ms']:.0f} ms  {s['duration_ms']:.0f}ms]  {name}")
            )

    def _jump_to_segment(self, item: QListWidgetItem) -> None:
        i = self.seg_list.row(item)
        if 0 <= i < len(self._segments):
            s = self._segments[i]
            self.cursor_a.setValue(s["t0_ms"])
            self.cursor_b.setValue(s["t1_ms"])

    def _auto_metrics(self) -> None:
        """对最长的"纯直线"或"转弯"段自动算阶跃指标。"""
        if not self._segments:
            self.metrics_lbl.setText("")
            return
        best = max(self._segments, key=lambda s: s["duration_ms"])
        i0, i1 = best["i0"], best["i1"]
        seg_t = self.t[i0 : i1 + 1] / 1000.0
        seg_l = self.arr["speedl"][i0 : i1 + 1]
        name = MOTION_TASK_NAMES.get(best["task"], str(best["task"]))
        target = float(np.median(seg_l[len(seg_l) * 2 // 3 :])) if len(seg_l) > 6 else float(seg_l[-1])
        m = step_metrics(seg_t, seg_l, target)
        self.metrics_lbl.setText(f"{name} 左轮: {format_metrics(m)}")

    def _update_cursor_readout(self) -> None:
        if self.t is None:
            return
        a, b = self.cursor_a.value(), self.cursor_b.value()
        lo, hi = min(a, b), max(a, b)
        i0 = int(np.searchsorted(self.t, lo))
        i1 = int(np.searchsorted(self.t, hi))
        i0 = max(0, min(i0, len(self.t) - 1))
        i1 = max(0, min(i1, len(self.t) - 1))
        if i1 <= i0:
            return
        dl = float(self.arr["speedl"][i1] - self.arr["speedl"][i0])
        dr = float(self.arr["speedr"][i1] - self.arr["speedr"][i0])
        da = float(self.arr["gangle"][i1] - self.arr["gangle"][i0])
        dt = float(self.t[i1] - self.t[i0])
        self.metrics_lbl.setText(f"ΔA-B: {dt:.0f}ms   Δ左速 {dl:+.1f}   Δ右速 {dr:+.1f}   Δ角度 {da:+.1f}°")
