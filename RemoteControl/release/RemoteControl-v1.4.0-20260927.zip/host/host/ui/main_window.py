"""主窗口: 装配传输、协议、模型、视图, 并用一个 40Hz 定时器驱动界面刷新。

线程模型: 读取线程只往 TelemetryStore / CommandClient 里写(两者自带锁),
主线程定时器 refresh() 读取并重绘 —— 不存在跨线程 Qt 调用。
"""

from __future__ import annotations

import threading
import time
from typing import List, Optional, Tuple

import pyqtgraph as pg
from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QFont
from PySide6.QtWidgets import (
    QComboBox,
    QHBoxLayout,
    QLabel,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QSplitter,
    QStatusBar,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from .. import __version__
from ..model.ring import TelemetryStore
from ..model.session import Session
from ..protocol.commands import PARAM_IDS, PARAM_META, CommandClient
from ..protocol.codec import MOTION_TASK_NAMES, TASK_NAMES, q1616_to_float
from ..transport.link import Link, LinkState, Target
from ..transport.ports import list_ports
from .calib_wizard import CalibWizard
from .console import ConsoleWidget
from .fetch_panel import FetchPanel
from .maze_view import MazeWidget
from .param_panel import ParamPanel
from .scope import DumpWidget, ScopeWidget
from .status_panel import StatusPanel

REFRESH_MS = 25  # 40Hz
POLL_MS = 20


class MainWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle(f"电脑鼠蓝牙上位机 v{__version__}  ——  STM32F103RB / USART1 @115200")
        self.resize(1500, 950)

        # ---- 模型/协议 ----
        self.store = TelemetryStore(window_s=30.0)
        self.client = CommandClient(send_bytes=self._send_bytes)
        self.session: Optional[Session] = None
        self.link = Link(
            store=self.store,
            client=self.client,
            on_state=self._on_link_state,
            on_session_raw=self._on_session_raw,
        )
        self.store.on_dump_complete = self._on_dump_complete

        # 链路状态从读取线程回流到主线程的队列(见 _on_link_state)
        self._state_queue: List[Tuple[str, str]] = []
        self._state_lock = threading.Lock()

        # ---- 界面 ----
        self._build_ui()

        # ---- 定时器 ----
        self.t_refresh = QTimer(self)
        self.t_refresh.timeout.connect(self._refresh)
        self.t_refresh.start(REFRESH_MS)
        self.t_poll = QTimer(self)
        self.t_poll.timeout.connect(self.client.poll)
        self.t_poll.start(POLL_MS)

        self._scan_ports()
        self._log("上位机就绪。无硬件时可选 TCP 连接到 sim/mouse_sim.py 做全链路演练。")

    # ============================================================ 构建界面

    def _build_ui(self) -> None:
        central = QWidget()
        root = QVBoxLayout(central)
        root.setContentsMargins(4, 4, 4, 4)

        # ---- 顶栏 ----
        bar = QHBoxLayout()
        bar.addWidget(QLabel("目标:"))
        self.cb_target = QComboBox()
        self.cb_target.setMinimumWidth(320)
        bar.addWidget(self.cb_target)
        self.btn_scan = QPushButton("刷新")
        self.btn_scan.clicked.connect(self._scan_ports)
        bar.addWidget(self.btn_scan)
        self.btn_connect = QPushButton("连接")
        self.btn_connect.clicked.connect(self._toggle_connect)
        bar.addWidget(self.btn_connect)
        bar.addSpacing(8)

        # 波特率: 蓝牙透传模块的 UART 侧速率必须与这里一致, 否则收到的是乱码。
        # 早期版本把它写死 115200, 换个模块就得改代码 —— 这里做成可选 + 可手输。
        bar.addWidget(QLabel("波特率:"))
        self.cb_baud = QComboBox()
        self.cb_baud.setEditable(True)
        self.cb_baud.addItems(["115200", "9600", "38400", "57600", "19200", "230400", "4800"])
        self.cb_baud.setCurrentText("115200")
        self.cb_baud.setFixedWidth(90)
        bar.addWidget(self.cb_baud)
        bar.addSpacing(16)

        self.lbl_state = QLabel("未连接")
        self.lbl_state.setStyleSheet("color:#ef5350; font-weight:500;")
        bar.addWidget(self.lbl_state)
        bar.addSpacing(16)
        self.lbl_tp = QLabel("吞吐 —")
        bar.addWidget(self.lbl_tp)
        self.lbl_rate = QLabel("快帧 —")
        bar.addWidget(self.lbl_rate)
        bar.addSpacing(16)
        self.btn_rate = QPushButton("速率 5Hz")
        self.btn_rate.clicked.connect(self._cycle_rate)
        bar.addWidget(self.btn_rate)
        bar.addStretch(1)
        self.btn_session = QPushButton("开始会话记录")
        self.btn_session.clicked.connect(self._toggle_session)
        bar.addWidget(self.btn_session)
        root.addLayout(bar)

        # ---- 主体 ----
        split = QSplitter(Qt.Horizontal)

        left = QTabWidget()
        # 实时页以"状态读数"为主 —— 这条链路只有约 152 B/s(快帧 5Hz),
        # 画曲线意义不大; 真正的波形细节走『停车后分析』的 1kHz 回传。
        self.status = StatusPanel(self.store)
        self.scope = ScopeWidget(self.store)
        self.dumpview = DumpWidget(self.store)
        left.addTab(self.status, "实时状态")
        left.addTab(self.scope, "趋势曲线")
        left.addTab(self.dumpview, "停车后分析")
        left.setCurrentIndex(0)
        self.left_tabs = left

        self.console = ConsoleWidget(self.client)
        self.wizard = CalibWizard(self.client, None, self._log)
        self.params = ParamPanel(self.client, None, self._log)

        right = QTabWidget()
        self.fetch = FetchPanel(self.client, self.store, self._log,
                                on_loaded=self._on_dump_loaded)
        self.maze = MazeWidget()
        right.addTab(self.fetch, "停车后拉取")
        right.addTab(self.maze, "迷宫")
        right.addTab(self.wizard, "标定向导")
        right.addTab(self.params, "参数")
        right.setMaximumWidth(560)
        self.right_tabs = right

        split.addWidget(left)
        split.addWidget(right)
        split.setStretchFactor(0, 3)
        split.setStretchFactor(1, 2)
        root.addWidget(split, 1)

        # ---- 控制条 + 状态 ----
        ctl = QHBoxLayout()
        for text, slot, color in (
            # 固件上电默认静默(见 link.c 的 link_Telemetry), 故"开流"是首要按钮
            ("▶ 开流", lambda: self.client.send("STREAM ON"), "#2e7d32"),
            ("■ 停流", lambda: self.client.send("STREAM OFF"), "#424242"),
            ("拉取墙图", lambda: self.client.send("MAP DUMP"), "#5e35b1"),
            ("TARE 清零", lambda: self.client.send("TARE"), "#424242"),
            ("STOP", lambda: self.client.send("STOP"), "#e65100"),
            ("ESTOP 急停", lambda: self.client.send("ESTOP"), "#b71c1c"),
        ):
            b = QPushButton(text)
            b.setStyleSheet(f"background:{color}; color:white;")
            b.clicked.connect(lambda _=False, s=slot: s())
            ctl.addWidget(b)
        ctl.addStretch(1)
        self.lbl_robot = QLabel("—")
        f = QFont("Consolas")
        f.setPointSize(9)
        self.lbl_robot.setFont(f)
        ctl.addWidget(self.lbl_robot)
        root.addLayout(ctl)
        root.addWidget(self.console, 0)
        self.console.setMaximumHeight(200)

        self.setCentralWidget(central)
        sb = QStatusBar()
        self.setStatusBar(sb)
        self.lbl_status = QLabel("")
        sb.addWidget(self.lbl_status)
        self.lbl_counts = QLabel("")
        sb.addPermanentWidget(self.lbl_counts)

    # ============================================================ 连接

    def _scan_ports(self) -> None:
        self.cb_target.clear()
        ports = list_ports()
        self._targets: List[Target] = []
        for p in ports:
            self._targets.append(Target(kind="serial", port=p.device, baud=115200))
            self.cb_target.addItem(p.label())
        self._targets.append(Target(kind="tcp", host="127.0.0.1", tcp_port=5555))
        self.cb_target.addItem("[模拟器] TCP 127.0.0.1:5555")
        self._targets.append(Target(kind="tcp", host="127.0.0.1", tcp_port=5556))
        self.cb_target.addItem("[模拟器] TCP 127.0.0.1:5556")

        # list_ports() 已把"可用 > 有线 > 蓝牙传出 > 蓝牙传入"排好序,
        # 所以 0 号就是最该选的那个, 不必再猜。
        if ports:
            self.cb_target.setCurrentIndex(0)
        else:
            self.cb_target.setCurrentIndex(len(self._targets) - 2)

        for p in ports:
            if p.direction == "incoming":
                self._log(f"[端口] {p.device} 是蓝牙『传入』端口 —— 能打开但永远收不到数据, "
                          f"请改用『传出』端口。")
        if ports:
            self._log(f"[端口] 已识别 {len(ports)} 个串口, 默认选中最上方的 "
                      f"{ports[0].device}。")
        if self.link.state == LinkState.OPEN:
            self.cb_target.setEnabled(False)

    def _toggle_connect(self) -> None:
        if self.link.is_open:
            # 先停流再断开, 避免下次连接时模块缓冲里还压着旧数据
            try:
                self.client.send("STREAM OFF")
            except Exception:
                pass
            self.link.close()
            self.btn_connect.setText("连接")
            self.cb_target.setEnabled(True)
            self.cb_baud.setEnabled(True)
            self._close_session()
            return
        idx = self.cb_target.currentIndex()
        if idx < 0 or idx >= len(self._targets):
            return
        target = self._targets[idx]
        if target.kind == "serial":
            target = Target(kind="serial", port=target.port, baud=self._current_baud())
        if not self.link.open(target):
            # 打开失败: 不改按钮、不禁用下拉、不建会话目录。
            # 早期版本无论成败都切成"已连接"并建了会话, 界面上像是连上了,
            # 实际后续每次发送都被静默丢弃("链路未打开, 发送被丢弃"),
            # 而失败原因只显示在顶栏一行小字里 —— 这正是排查困难的根源。
            # 具体原因由 _drain_link_state() 在主线程写进日志。
            return
        self.btn_connect.setText("断开")
        self.cb_target.setEnabled(False)
        self.cb_baud.setEnabled(False)
        self._open_session()
        # 固件上电默认【静默】遥测(见 link.c 的 link_Telemetry 说明):
        # 这条蓝牙透传链路的模块缓冲一旦被灌满就会永久停止转发, 必须在链路
        # 真正连上之后再由主机主动开流, 否则模块会在无人读取时就被灌死。
        self.client.send("STREAM ON")
        self._log("[链路] 已请求开启遥测流 (STREAM ON)")

    def _current_baud(self) -> int:
        try:
            return int(str(self.cb_baud.currentText()).strip())
        except (ValueError, TypeError):
            self._log(f"[波特率] {self.cb_baud.currentText()!r} 不是有效整数, 回落 115200")
            return 115200

    def _send_bytes(self, data: bytes) -> None:
        if not self.link.write(data):
            self._log("链路未打开, 发送被丢弃")

    def _on_link_state(self, state: str, detail: str) -> None:
        """链路状态回调 —— 可能在读取线程里触发, 因此只入队, 绝不直接碰 Qt 控件。"""
        with self._state_lock:
            self._state_queue.append((state, detail))

    def _drain_link_state(self) -> None:
        """在主线程消费状态队列: 刷新顶栏 + 把错误写进日志。"""
        with self._state_lock:
            items = list(self._state_queue)
            self._state_queue.clear()
        for state, detail in items:
            if state == LinkState.OPEN:
                self.lbl_state.setText(f"已连接 {detail}")
                self.lbl_state.setStyleSheet("color:#81c784; font-weight:500;")
            elif state == LinkState.ERROR:
                self.lbl_state.setText(f"错误: {detail}")
                self.lbl_state.setStyleSheet("color:#ef5350; font-weight:500;")
                self._log(f"[链路错误] {detail}")
                if self.target_looks_like_incoming():
                    self._log("           提示: 该端口是蓝牙『传入』端口, 它永远不会收到数据,"
                              " 请改选『传出』端口。")
                # 运行期断链(蓝牙掉线等): 恢复按钮, 让用户能重新连接
                if not self.link.is_open:
                    self.btn_connect.setText("连接")
                    self.cb_target.setEnabled(True)
                    self.cb_baud.setEnabled(True)
            elif state == LinkState.CONNECTING:
                self.lbl_state.setText(f"连接中 {detail}")
                self.lbl_state.setStyleSheet("color:#FFD54F; font-weight:500;")
            else:
                self.lbl_state.setText("未连接")
                self.lbl_state.setStyleSheet("color:#ef5350; font-weight:500;")

    def target_looks_like_incoming(self) -> bool:
        """当前选中的目标是否是蓝牙『传入』端口(永远收不到数据那种)。"""
        idx = self.cb_target.currentIndex()
        if idx < 0 or idx >= len(self._targets):
            return False
        t = self._targets[idx]
        if t.kind != "serial":
            return False
        for p in list_ports():
            if p.device == t.port:
                return p.direction == "incoming"
        return False

    def _cycle_rate(self) -> None:
        # 档位与固件 RATE 命令一致, 且刻意全部落在链路可持续吞吐以内
        # (实测该蓝牙透传链路约 150 B/s 为安全上限 —— 超过会堵死, 见 link.py self_check)
        order = [5, 10, 20, 2]
        cur = int(self.btn_rate.text().split()[1].replace("Hz", ""))
        nxt = order[(order.index(cur) + 1) % len(order)] if cur in order else 250
        ok, st = self.client.set_rate(nxt)
        self.btn_rate.setText(f"速率 {nxt}Hz")
        self._log(f"[RATE] -> {nxt}Hz {st}")

    # ============================================================ 会话

    def _open_session(self) -> None:
        if self.session is not None:
            return
        try:
            self.session = Session()
        except OSError as e:
            self._log(f"无法建立会话目录: {e}")
            return
        self.wizard.session = self.session
        self.params.session = self.session
        self.console.session = self.session
        self.btn_session.setText("结束会话记录")
        self._log(f"[会话] 目录 {self.session.path}")

    def _close_session(self) -> None:
        if self.session is None:
            return
        self.session.close({"link_stats": self.link.stats()})
        self._log(f"[会话] 已收尾 {self.session.path}")
        self.session = None
        self.btn_session.setText("开始会话记录")

    def _toggle_session(self) -> None:
        if self.session is None:
            self._open_session()
        else:
            self._close_session()

    def _on_session_raw(self, data: bytes) -> None:
        if self.session is not None:
            self.session.write_raw(data)

    def _on_dump_complete(self, records) -> None:
        """在读取线程中触发, 只做落盘(不碰 Qt)。"""
        try:
            if self.session is not None:
                self.session.write_dump(records)
        except Exception:
            pass

    # ============================================================ 刷新

    def _refresh(self) -> None:
        self._drain_link_state()
        self.status.refresh()
        self.scope.refresh()
        self.fetch.refresh()

        # 异步消息 -> 标定向导 + 会话日志(在主线程处理, 保证线程安全)
        for line in self.client.drain_events():
            self.wizard.handle_async(line)
            self.store.push_event(line)
            if self.session is not None:
                self.session.write_text(line)

        # 慢帧驱动迷宫坐标
        _f, _m, s = self.store.latest()
        if s:
            self.maze.set_position(int(s.get("posX", 0)), int(s.get("posY", 0)), int(s.get("mouseTask", 0)))

        # 会话落盘
        if self.session is not None:
            if _f:
                self.session.write_fast(_f)
            if _m:
                self.session.write_mid(_m)
            if s:
                self.session.write_slow(s)

        self._refresh_labels()

    def _on_dump_loaded(self) -> None:
        """FetchPanel 回传完成后的回调(主线程): 载入分析视图并切页。"""
        if self.dumpview.load_from_store():
            self.left_tabs.setCurrentWidget(self.dumpview)
            self._log("[dump] 已载入『停车后分析』视图")

    def _refresh_labels(self) -> None:
        st = self.link.stats()
        if not self.link.is_open:
            return
        chk = self.link.self_check()
        need = chk["need_bps"]
        got = chk["got_bps"]
        pct = (got / need * 100.0) if need else 0.0
        color = "#81c784" if pct >= 100 or chk["level"] == "ok" else ("#FFD54F" if pct >= 60 else "#ef5350")
        self.lbl_tp.setText(f"吞吐 {got:,.0f}/{need:,.0f} B/s ({pct:.0f}%)")
        self.lbl_tp.setStyleSheet(f"color:{color}; font-weight:500;")
        self.lbl_rate.setText(f"快帧 {st['fast']}")
        self.lbl_counts.setText(
            f"帧 F{st['fast']} M{st['mid']} S{st['slow']} | 文本 {st['text']} | "
            f"CRC错 {st['bad_crc']} 失步 {st['bad_sync']} | 重发 {self.client.stats['retries']} 超时 {self.client.stats['timeouts']}"
        )
        # 自动降级建议(§5.8)
        if chk["level"] == "degraded" and chk["suggest_rate"] and not getattr(self, "_warned_rate", False):
            self._warned_rate = True
            self._log(
                f"[链路自检] 实测吞吐偏低({pct:.0f}%)，建议把快帧降到 {chk['suggest_rate']}Hz。"
                f"若实际是 9600 波特率的模块，请先确认模块配置。"
            )

        # 实时读数条
        f, m, s = self.store.latest()
        if f:
            task = MOTION_TASK_NAMES.get(int(f.get("task", 0)), str(f.get("task", 0)))
            extra = ""
            if f.get("emerg"):
                extra = "  ⚠急停"
            elif f.get("freemode"):
                extra = "  [自由模式:电机停]"
            self.lbl_robot.setText(
                f"L {f.get('speedL',0):+5.0f}/{f.get('speedTargetL',0):+5.0f}   "
                f"R {f.get('speedR',0):+5.0f}/{f.get('speedTargetR',0):+5.0f} cm/s   "
                f"θ {f.get('gyroAngle',0):+4.0f}°   V {f.get('volt',0):.1f}V   "
                f"{task}{extra}"
            )
        if s:
            self.lbl_status.setText(
                f"坐标 ({s.get('posX')},{s.get('posY')})  {s.get('mouseTaskName','')}   "
                f"红外 F{s.get('irF1')}/{s.get('irF2')} L{s.get('irL')} R{s.get('irR')} mm   "
                f"CPU {s.get('cpu')}%  丢帧 {s.get('drop')}"
            )

    def _log(self, text: str) -> None:
        self.console.append_system(text)
        if self.session is not None:
            self.session.write_text(text, "##")

    # ============================================================ 收尾

    def closeEvent(self, ev) -> None:
        try:
            self.link.close()
        finally:
            self._close_session()
        super().closeEvent(ev)
