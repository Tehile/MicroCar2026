"""遥测读取: 最新快照、环形历史、吞吐统计。

对应功能清单的 B 组。

这条链路实测的可持续吞吐约 150 B/s(默认快帧 5Hz), 所以"实时曲线"只够看趋势。
要看控制细节请用 `mc.scope.fetch()` 拉 1 kHz 完整波形 —— 那是**停车后**整块
回传的, 不受实时速率限制。
"""

from __future__ import annotations

import time
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Tuple

import numpy as np

from ..model.ring import (
    FAST_CHANNELS,
    FAST_HZ,
    MID_CHANNELS,
    MID_HZ,
    SLOW_CHANNELS,
    SLOW_HZ,
    RingBuffer,
)

if TYPE_CHECKING:  # pragma: no cover
    from .client import MouseClient

#: 三路流的元信息: 名称 -> (通道, 额定频率)
STREAMS: Dict[str, Tuple[List[str], float]] = {
    "fast": (FAST_CHANNELS, FAST_HZ),
    "mid": (MID_CHANNELS, MID_HZ),
    "slow": (SLOW_CHANNELS, SLOW_HZ),
}

_FLAG_KEYS = ("freemode", "sleep", "emerg", "scoping", "dumping", "motors_off")


class TelemetryAPI:
    """只读遥测。所有方法无副作用, 可随时调用。"""

    def __init__(self, mc: "MouseClient") -> None:
        self._mc = mc

    # ------------------------------------------------------------ 快照

    def latest(self) -> Tuple[Dict[str, Any], Dict[str, Any], Dict[str, Any]]:
        """(fast, mid, slow) 三路的最新值。任一路没有数据时为空 dict。"""
        return self._mc.store.latest()

    def fast(self) -> Dict[str, Any]:
        return self._mc.store.latest()[0]

    def mid(self) -> Dict[str, Any]:
        return self._mc.store.latest()[1]

    def slow(self) -> Dict[str, Any]:
        return self._mc.store.latest()[2]

    # ------------------------------------------------------------ 历史

    def buffer(self, name: str = "fast") -> RingBuffer:
        rb = getattr(self._mc.store, name, None)
        if not isinstance(rb, RingBuffer):
            raise KeyError(f"未知的遥测流: {name!r} (可选 {sorted(STREAMS)})")
        return rb

    def channels(self, name: str = "fast") -> List[str]:
        return list(STREAMS[name][0]) if name in STREAMS else list(self.buffer(name).channels)

    def hz(self, name: str = "fast") -> float:
        return STREAMS[name][1] if name in STREAMS else self.buffer(name).hz

    def history(self, name: str = "fast", seconds: Optional[float] = None):
        """返回 `(t_seconds_epoch, data[行=样本, 列=通道])`。"""
        return self.buffer(name).snapshot(seconds)

    def history_dict(self, name: str = "fast", seconds: Optional[float] = None) -> Dict[str, np.ndarray]:
        """把历史拆成 `{通道名: 一维数组}`。"""
        t, data = self.history(name, seconds)
        chans = self.channels(name)
        out: Dict[str, np.ndarray] = {"t": t}
        for i, c in enumerate(chans):
            out[c] = data[:, i] if len(data) else np.zeros(0)
        return out

    def samples(self, name: str = "fast") -> int:
        return int(self.buffer(name).total)

    # ------------------------------------------------------------ 状态

    def last_frame_age(self, name: str = "fast") -> Optional[float]:
        """最后一帧距今多少秒。None = 从未收到过。"""
        t, _ = self.history(name)
        if len(t) == 0:
            return None
        return max(0.0, time.time() - float(t[-1]))

    def is_streaming(self, max_age: float = 2.5) -> bool:
        """是否正在收到数据。固件上电默认静默, 需要先 STREAM ON。"""
        age = self.last_frame_age("fast")
        return age is not None and age <= max_age

    def wait_first_frame(self, timeout: float = 5.0) -> bool:
        """等第一帧快帧到达(连上后最常用的同步点)。"""
        return self._mc.wait(lambda: bool(self.fast()), timeout=timeout)

    def flags(self) -> Dict[str, bool]:
        """快帧里的状态位: 自由模式(电机停)/休眠/急停/采集中/回传中。"""
        f = self.fast()
        return {k: bool(f.get(k)) for k in _FLAG_KEYS} if f else {}

    # ------------------------------------------------------------ 统计

    def stats(self) -> Dict[str, Any]:
        return self._mc.link.stats()

    def self_check(self) -> Dict[str, Any]:
        return self._mc.link.self_check()

    def bytes_per_second(self) -> float:
        return float(self._mc.link.tp.bps)

    def summary_text(self) -> str:
        """一行摘要(CLI 与日志用)。"""
        f, m, s = self.latest()
        if not f and not s:
            return "遥测: 无数据 (设备默认静默, 需 STREAM ON)"
        bits = []
        if f:
            bits.append(
                f"L {f.get('speedL', 0):+.0f}/{f.get('speedTargetL', 0):+.0f}  "
                f"R {f.get('speedR', 0):+.0f}/{f.get('speedTargetR', 0):+.0f} cm/s"
            )
            bits.append(f"θ {f.get('gyroAngle', 0):+.0f}°")
            bits.append(f"{f.get('volt', 0):.1f}V")
            bits.append(f"task={f.get('task')}")
            fl = self.flags()
            if fl.get("motors_off"):
                bits.append("安全模式(电机禁用)")
            elif fl.get("emerg"):
                bits.append("急停")
            elif fl.get("sleep"):
                bits.append("休眠")
        if s:
            bits.append(f"({s.get('posX')},{s.get('posY')}) {s.get('mouseTaskName', '')}")
        return "  ".join(bits)

    def live(self, seconds: float = 5.0, interval: float = 0.5, printer=print) -> None:
        """在终端里持续打印状态行(CLI/调试用)。"""
        t0 = time.time()
        while time.time() - t0 < seconds:
            printer(self.summary_text())
            time.sleep(max(0.05, interval))
