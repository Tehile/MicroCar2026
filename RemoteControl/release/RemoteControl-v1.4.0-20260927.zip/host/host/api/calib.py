"""标定: 5 项物理系数。

对应功能清单的 F 组。

与设计文档约定的两条硬边界:

  1. 只标**物理系数**(陀螺零偏 / 红外 8 值 / 车心到墙 / 角度系数 / 里程系数)。
     PID 增益、三档 spurt 增益、速度常数、墙判阈值均属项目红线, 不在这里。
  2. `gyroRatio` 与 `encAngleRatio` **不能互相标定** —— 那是循环依赖, 误差会
     互相吸收。本实现用『前向红外正对墙时取极小值』作为物理角度基准, 在角格里
     0°↔90° 往复若干次, 把单次 ±2° 的定位误差均摊掉。

交互模型: 主机的标定流程是**阻塞式**的 —— 调用返回时结果已经算好。
需要人工摆位的项(红外逐点、里程量距)通过回调或返回值把决定权交回调用者。
"""

from __future__ import annotations

import time
from typing import TYPE_CHECKING, Any, Callable, Dict, List, Optional, Sequence, Tuple

from ..protocol.commands import PARAM_IDS
from .errors import Result, clamp_timeout
from .events import Event

if TYPE_CHECKING:  # pragma: no cover
    from .client import MouseClient


class CalibAPI:
    """5 项标定。全部方法默认阻塞到设备回报结果。"""

    #: 固件支持的标定项(与 `CAL <item>` 的 item 一致)
    ITEMS: Tuple[str, ...] = ("GYRO", "WALLDIST", "IRDATA", "GYRORATIO", "ENCANGLE")

    #: 无需电机即可完成的项 —— 安全测试固件(MOUSE_TEST_NO_MOTOR)下**可以**做
    STATIC_ITEMS: Tuple[str, ...] = ("GYRO", "WALLDIST", "IRDATA")

    #: 需要电机转动的项 —— 安全模式下 `mc.motor_guard()` 会直接拦下(不空等超时)
    MOTION_ITEMS: Tuple[str, ...] = ("GYRORATIO", "ENCANGLE")

    #: 红外逐点采集的 4 个摆位, 顺序必须与固件一致
    IR_STEPS: Tuple[Tuple[str, str], ...] = (
        ("左近墙", "车左侧贴墙, 车心到墙约 33mm"),
        ("左远墙", "车左侧离墙约 94mm"),
        ("前近墙", "车头距墙约 32mm"),
        ("前远墙", "车头距墙约 213mm"),
    )

    def __init__(self, mc: "MouseClient") -> None:
        self._mc = mc

    # ------------------------------------------------------------ 基础

    def items(self) -> List[str]:
        return list(self.ITEMS)

    def step(self, item: str, act: str, timeout: float = 3.0) -> Result:
        """手工单步: `CAL <item> <act>`, act ∈ {START, SAMPLE, ABORT}。"""
        return self._mc.send_cmd(
            "calib.cal", item=str(item).upper(), act=str(act).upper(), timeout=timeout
        )

    def wait_done(self, item: str, timeout: float = 30.0, since: Optional[float] = None):
        """等待某项标定完成(或报错)的异步消息。返回 EventMsg 或 None。"""
        want = str(item).upper()

        def _pred(m) -> bool:
            d = m.data
            k = d.get("kind")
            if k == "error":
                return True
            return k == "done" and str(d.get("item", "")).upper() == want

        return self._mc.wait_event(Event.CALIB, _pred, timeout=timeout, since=since)

    def _done_result(self, item: str, msg, points: Optional[int] = None) -> Result:
        if msg is None:
            return Result(False, "TIMEOUT", {"item": item})
        d = msg.data
        if d.get("kind") == "error":
            return Result(False, d.get("raw") or "CALERR", {"item": item, "raw": d.get("raw")})
        fields = list(d.get("fields") or [])
        nums = [int(x) for x in fields if _is_int(x)]
        info: Dict[str, Any] = {"item": item, "fields": fields, "raw": d.get("raw")}
        if nums:
            info["value"] = nums[0]
        if points is not None:
            info["points"] = points
        return Result(True, "OK", info)

    # ------------------------------------------------------------ 逐项

    def gyro(self, timeout: float = 20.0) -> Result:
        """陀螺零偏。要求电脑鼠**静止**; 固件自行采样约 1.5s 并写入既有 Flash 页。"""
        t0 = time.time()
        r = self.step("GYRO", "START")
        if not r.ok:
            return r
        return self._done_result("GYRO", self.wait_done("GYRO", timeout, since=t0))

    def wall_distance(self, timeout: float = 20.0) -> Result:
        """车心到墙距离。要求电脑鼠**平行贴住左墙**。"""
        t0 = time.time()
        r = self.step("WALLDIST", "START")
        if not r.ok:
            return r
        return self._done_result("WALLDIST", self.wait_done("WALLDIST", timeout, since=t0))

    # ------------------------------------------------------------ 红外逐点

    def ir_start(self) -> Result:
        return self.step("IRDATA", "START")

    def ir_sample(self) -> Result:
        """采集当前摆位的一点。"""
        return self.step("IRDATA", "SAMPLE")

    def ir_data(
        self,
        on_prompt: Optional[Callable[[int, str, str], bool]] = None,
        timeout_per_point: float = 120.0,
    ) -> Result:
        """红外 8 值(4 个摆位各采一点)。

        `on_prompt(i, name, desc)` 在需要摆放第 i 点时调用, 返回 False 即中止。
        给出回调就是"等人摆好", 不给出则要求调用者事先摆好、每点一次。

        **注意**: 固件的 `CALIB_InitIr()` 会擦除已探索的迷宫, 所以这里走的是
        逐点 `CAL IRDATA` 路径, 不重建查表(与上位机界面上的按钮行为一致)。
        """
        mc = self._mc
        mc._check_reentrancy("calib.ir_data()")
        # 记在 ir_start 之前: 第 4 点的 CALSTEP 与紧随其后的 CALDONE 可能落在同一批事件里,
        # 最后那次 wait_done 必须能回看到"本次流程开始之后"的事件 —— 若用默认的
        # since=now, 就会把已经到达的 CALDONE 当成过期的而漏掉。
        t_start = time.time()
        r = self.ir_start()
        if not r.ok:
            return r

        done = 0
        for i, (name, desc) in enumerate(self.IR_STEPS):
            if on_prompt is not None:
                try:
                    if not on_prompt(i, name, desc):
                        self.step("IRDATA", "ABORT")
                        return Result(False, "ABORTED", {"collected": done})
                except Exception:
                    self.step("IRDATA", "ABORT")
                    return Result(False, "PROMPT_ERROR", {"collected": done})
            t0 = time.time()
            rs = self.ir_sample()
            if not rs.ok:
                return rs

            def _pred(m, _i=i) -> bool:
                d = m.data
                if d.get("kind") == "error":
                    return True
                if d.get("kind") == "done" and str(d.get("item", "")).upper() == "IRDATA":
                    return True
                if d.get("kind") == "step":
                    f = d.get("fields") or []
                    return bool(f) and _is_int(f[0]) and int(f[0]) >= _i
                return False

            m = mc.wait_event(Event.CALIB, _pred, timeout=clamp_timeout(timeout_per_point, 120.0), since=t0)
            if m is None:
                return Result(False, "TIMEOUT", {"collected": done, "at": name})
            done += 1
            if m.data.get("kind") == "error":
                return Result(False, m.data.get("raw") or "CALERR", {"collected": done})
            if m.data.get("kind") == "done":
                # CALDONE 抢在第 4 点的 CALSTEP 之前被匹配到: 同样补上 points,
                # 免得成功返回的 data 形状随事件顺序漂移。
                return self._done_result("IRDATA", m, points=done)

        # 4 点采完后固件会再回一条 CALDONE(见 link.c 的 link_IrRebuild 之后)。
        # since=t_start 让它即使提前到达也能被回看到。
        m = self.wait_done("IRDATA", timeout=10.0, since=t_start)
        if m is None:
            return Result(True, "OK", {"item": "IRDATA", "points": done, "note": "未收到 CALDONE"})
        return self._done_result("IRDATA", m, points=done)

    # ------------------------------------------------------------ 角度系数

    def angle(
        self, timeout: float = 90.0, apply: bool = True, readback: bool = True
    ) -> Result:
        """角度系数 GYRORATIO / ENCANGLE。

        要求电脑鼠放在**角格**(相邻两面墙), 车头大致朝前。固件会自己往复
        0°↔90° 若干次, `apply=True` 时把算得的两个系数直接写回设备。

        返回的 `data` 里带 `sum_acc / sum_enc / deg / gyroRatio / encAngleRatio`。
        """
        mc = self._mc
        mc._check_reentrancy("calib.angle()")
        guard = mc.motor_guard("calib.angle()")
        if guard is not None:
            return guard
        t0 = time.time()
        r = self.step("GYRORATIO", "START")
        if not r.ok:
            return r
        res = self._done_result("GYRORATIO", self.wait_done("GYRORATIO", timeout, since=t0))
        if not res.ok:
            return res
        nums = [int(x) for x in (res.data.get("fields") or []) if _is_int(x)]
        if len(nums) < 3:
            return Result(False, "BAD_REPLY", res.data)
        sum_acc, sum_enc, deg = nums[0], nums[1], nums[2]
        if deg == 0:
            return Result(False, "ZERO_DEG", res.data)
        g = sum_acc / float(deg)
        e = sum_enc / float(deg)
        info: Dict[str, Any] = {
            "item": "GYRORATIO",
            "sum_acc": sum_acc,
            "sum_enc": sum_enc,
            "deg": deg,
            "gyroRatio": g,
            "encAngleRatio": e,
        }
        if apply:
            applied = self.apply_angle(g, e, readback=readback)
            info["applied"] = [a.status for a in applied]
            if not all(a.ok for a in applied):
                return Result(False, "APPLY_FAILED", info)
        return Result(True, "OK", info)

    def apply_angle(self, gyro_ratio: float, enc_angle: float, readback: bool = True) -> List[Result]:
        """写回两个角度系数。"""
        return [
            self._mc.params.set("GYRORATIO", float(gyro_ratio), readback=readback),
            self._mc.params.set("ENCANGLE", float(enc_angle), readback=readback),
        ]

    # ------------------------------------------------------------ 里程系数

    def run_straight(self, pulses: int = 20000, speed: int = 40, timeout: Optional[float] = None) -> Result:
        """开环跑一段固定脉冲的直线, 返回实际左右轮脉冲数(dL/dR)。"""
        return self._mc.move.forward(pulses=pulses, speed=speed, wait_done=True, timeout=timeout)

    @staticmethod
    def compute_track(dL: int, dR: int, measured_mm: float) -> Tuple[float, float]:
        """由『实际跑出的脉冲数』与『尺量距离』算里程系数: 新系数 = 脉冲 / 毫米。"""
        if measured_mm <= 0:
            raise ValueError("measured_mm 必须为正")
        return float(dL) / float(measured_mm), float(dR) / float(measured_mm)

    def apply_track(
        self,
        dL: int,
        dR: int,
        measured_mm: float,
        derive_speed: bool = True,
        readback: bool = True,
    ) -> List[Result]:
        """应用里程系数, 默认同时派生 SPEEDL/R = TRACKL/R ÷ 100。

        强制派生是关键: 两者是同一物理量的两种表达, 各自独立标定会出现
        "里程准了但速度指令偏高 3%" 这种隐性不一致。
        """
        tl, tr = self.compute_track(dL, dR, measured_mm)
        return self._mc.params.set_many(
            {"TRACKL": tl, "TRACKR": tr}, readback=readback, derive_speed=derive_speed
        )

    def track(
        self,
        pulses: int = 20000,
        speed: int = 40,
        measured_mm: Optional[float] = None,
        derive_speed: bool = True,
        timeout: Optional[float] = None,
    ) -> Result:
        """一步到位: 跑直线 → (给了实测距离就) 计算并应用。

        `measured_mm=None` 时只跑并返回 dL/dR, 由调用者量完距离后再调
        `apply_track()` —— 物理上没法省掉这把尺子。
        """
        r = self.run_straight(pulses=pulses, speed=speed, timeout=timeout)
        if not r.ok:
            return r
        dL, dR = r.data.get("dL"), r.data.get("dR")
        info: Dict[str, Any] = {"pulses": pulses, "speed": speed, "dL": dL, "dR": dR}
        if measured_mm is None or not dL or not dR:
            return Result(True, "OK", {**info, "applied": False})
        applied = self.apply_track(dL, dR, measured_mm, derive_speed=derive_speed)
        info["applied"] = [a.status for a in applied]
        tl, tr = self.compute_track(dL, dR, measured_mm)
        info["TRACKL"] = tl
        info["TRACKR"] = tr
        if not all(a.ok for a in applied):
            return Result(False, "APPLY_FAILED", info)
        return Result(True, "OK", info)

    def apply_angle_and_track(
        self, gyro_ratio: float, enc_angle: float, dL: int, dR: int, measured_mm: float
    ) -> List[Result]:
        """把角度与里程两项一次写回（界面上"应用"按钮的语义）。"""
        out = self.apply_angle(gyro_ratio, enc_angle)
        out.extend(self.apply_track(dL, dR, measured_mm))
        return out

    # ------------------------------------------------------------ 报告

    def report(self, lines: Sequence[str]) -> Optional[str]:
        """把标定过程写入 `calib/report.md`(会话未开则为 None)。"""
        return self._mc.session.report(list(lines))


def _is_int(v: Any) -> bool:
    try:
        int(v)
        return True
    except (TypeError, ValueError):
        return False
