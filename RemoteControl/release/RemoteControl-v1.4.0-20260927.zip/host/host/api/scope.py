"""示波器与 1kHz 完整波形回传。

对应功能清单的 G 组。

分工由实测链路能力决定(见设计文档附录 F):

    实时流    ≈ 152 B/s  ->  只够传状态
    完整波形  9600 B      ->  停车后一次性回传, 约 60 秒

所以**不要**靠提高实时流速率来换波形分辨率 —— 那条链路超过阈值后会一个字节
都收不到(模块缓冲被永久按在饱和态)。要看细节就用 `fetch()`。
"""

from __future__ import annotations

import time
from typing import TYPE_CHECKING, Any, Callable, Dict, List, Optional, Tuple

from ..protocol.codec import SCOPE_BLKS, SCOPE_LEN, SCOPE_PTS_PER_BLK
from .errors import Result, clamp_timeout
from .events import Event

if TYPE_CHECKING:  # pragma: no cover
    from .client import MouseClient

#: 一次完整回传的字节数: 1200 点 × 8B + 20 块 × 8B(帧开销)
DUMP_BYTES = SCOPE_LEN * 8 + SCOPE_BLKS * 8


class ScopeAPI:
    """固件侧的 1kHz 滚动环缓冲(深度 1200 点 = 1.2 秒)。"""

    def __init__(self, mc: "MouseClient") -> None:
        self._mc = mc
        self._last: Optional[tuple] = None

    # ------------------------------------------------------------ 采集控制

    def start(self, timeout: float = 3.0) -> Result:
        """开始采集。采集在固件里以 1kHz 滚动进行, 采满 1200 点会覆盖最早的点。"""
        return self._mc.send_cmd("scope.start", timeout=timeout)

    def stop(self, timeout: float = 3.0) -> Result:
        return self._mc.send_cmd("scope.stop", timeout=timeout)

    # ------------------------------------------------------------ 回传

    def dump(self, timeout: float = 3.0) -> Result:
        """只发回传请求, 不等待。进度与完成通过事件给出。"""
        self._mc.store.reset_dump()
        self._mc._note_dump_request()
        return self._mc.send_cmd("scope.dump", timeout=timeout)

    def fetch(
        self,
        timeout: float = 300.0,
        on_progress: Optional[Callable[[float, Optional[float], Optional[float]], None]] = None,
        stop_first: bool = True,
    ) -> Optional[tuple]:
        """停车后拉取完整 1kHz 波形, **阻塞**直到回传完成。

        参数:
            on_progress(frac, eta_s, rate_bps)  进度回调。**运行在调度线程**,
                因此里面不能调阻塞 API —— 只适合更新界面/打印。
            stop_first  先发 STOP + SCOPE STOP。固件要求停车后再回传;
                已经停好的话可以传 False 省一次往返。

        返回 `dump_arrays()` 的 `(t_ms, motionTask, gangle, speedl, speedr)`,
        失败或超时返回 None。原始数据同时已落盘到会话目录(若会话开着)。
        """
        mc = self._mc
        mc._check_reentrancy("scope.fetch()")

        if stop_first:
            mc.send_cmd("stop", timeout=2.0)
            mc.send_cmd("scope.stop", timeout=2.0)

        mc.store.reset_dump()
        mc._note_dump_request()

        done: List[Any] = []
        offs: List[Callable[[], None]] = []
        if on_progress is not None:
            def _p(msg) -> None:
                d = msg.data
                try:
                    on_progress(float(d.get("frac", 0.0)), d.get("eta_s"), d.get("rate_bps"))
                except Exception:
                    pass

            offs.append(mc.on(Event.DUMP_PROGRESS, _p))
        offs.append(mc.on(Event.DUMP_DONE, lambda m: done.append(m)))
        try:
            r = mc.send_cmd("scope.dump", timeout=3.0)
            if not r.ok:
                return None
            if not mc.wait(lambda: bool(done), timeout=clamp_timeout(timeout, 300.0)):
                return None
            self._last = mc.store.dump_arrays()
            return self._last
        finally:
            for off in offs:
                off()

    def last(self) -> Optional[tuple]:
        """最近一次成功回传的波形(不发命令)。"""
        if self._last is not None:
            return self._last
        try:
            return self._mc.store.dump_arrays()
        except Exception:
            return None

    def progress(self) -> Dict[str, Any]:
        store = self._mc.store
        frac = float(store.dump_progress())
        elapsed = None
        w = self._mc._dump_watch
        if w is not None:
            elapsed = time.time() - w["t0"]
        eta = (elapsed / frac - elapsed) if (frac > 0.02 and elapsed) else None
        return {
            "frac": frac,
            "points": len(store.dump_records),
            "blocks": len(store.dump_blocks),
            "total_blocks": SCOPE_BLKS,
            "bytes": store.dump_bytes_received(),
            "eta_s": eta,
            "done": bool(store.dump_done),
        }

    # ------------------------------------------------------------ 元信息

    @staticmethod
    def points() -> int:
        return SCOPE_LEN

    @staticmethod
    def points_per_block() -> int:
        return SCOPE_PTS_PER_BLK

    @staticmethod
    def estimate_seconds(bps: float = 152.0) -> float:
        """按给定吞吐估算回传耗时(默认取实测的可持续吞吐上限)。"""
        return DUMP_BYTES / max(bps, 1.0)
