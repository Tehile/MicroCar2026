"""迷宫: 墙图拉取与渲染。

对应功能清单的 H 组。

墙位编码(与固件 `mapWall[MAZETYPE][MAZETYPE]` 低四位一致, 置位 = 无墙/可通行):
    bit0 上  bit1 右  bit2 下  bit3 左

迷宫尺寸取自设备上报的 `mazetype`(当前固件为 7×7), 上位机不写死 ——
换赛道尺寸时不必改这里。
"""

from __future__ import annotations

import time
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Tuple

from ..protocol.codec import (
    WALL_DOWN_OPEN,
    WALL_LEFT_OPEN,
    WALL_RIGHT_OPEN,
    WALL_UP_OPEN,
)
from .events import Event

if TYPE_CHECKING:  # pragma: no cover
    from .client import MouseClient

DIR_NAMES = {0: "UP", 1: "RIGHT", 2: "DOWN", 3: "LEFT"}


class MazeAPI:
    """墙图。设备只在被请求时回传整块墙图(`MAP DUMP`)。"""

    def __init__(self, mc: "MouseClient") -> None:
        self._mc = mc

    # ------------------------------------------------------------ 拉取

    def fetch(self, timeout: float = 10.0) -> Optional[Dict[str, Any]]:
        """请求并等待墙图。返回 `decode_map` 的结果。"""
        mc = self._mc
        mc._check_reentrancy("maze.fetch()")
        hits: List[Any] = []
        off = mc.on(Event.MAP, lambda m: hits.append(m))
        try:
            r = mc.send_cmd("maze.dump", timeout=3.0)
            if not r.ok and not hits:
                return mc.store.get_map()
            mc.wait(lambda: bool(hits), timeout=timeout)
        finally:
            off()
        if hits:
            return hits[0].data.get("rec")
        return mc.store.get_map()

    def last(self) -> Optional[Dict[str, Any]]:
        """最近一次收到的墙图(不发命令)。"""
        return self._mc.store.get_map()

    # ------------------------------------------------------------ 访问

    def mazetype(self) -> int:
        return int(self._mc.store.mazetype)

    def grid(self) -> Optional[List[List[int]]]:
        """墙位二维数组, `grid[x][y]`。"""
        m = self.last()
        return None if not m else m["mapWall"]

    def visited(self) -> Optional[List[List[bool]]]:
        m = self.last()
        return None if not m else m["mapVisited"]

    def position(self) -> Optional[Tuple[int, int, int, int]]:
        """(x, y, direction, mouseTask)。优先用墙图帧里的值, 否则用慢帧。"""
        m = self.last()
        if m:
            return (
                int(m.get("posX", 0)),
                int(m.get("posY", 0)),
                int(m.get("direction", 0)),
                int(m.get("mouseTask", 0)),
            )
        _f, _mid, slow = self._mc.store.latest()
        if slow:
            return (
                int(slow.get("posX", 0)),
                int(slow.get("posY", 0)),
                0,
                int(slow.get("mouseTask", 0)),
            )
        return None

    def cell(self, x: int, y: int) -> Optional[Dict[str, Any]]:
        """某一格的四方向通行情况。"""
        g = self.grid()
        if g is None:
            return None
        code = int(g[x][y])
        return {
            "x": x,
            "y": y,
            "code": code,
            "up": bool(code & WALL_UP_OPEN),
            "right": bool(code & WALL_RIGHT_OPEN),
            "down": bool(code & WALL_DOWN_OPEN),
            "left": bool(code & WALL_LEFT_OPEN),
            "visited": bool(self.visited()[x][y]) if self.visited() else None,
        }

    # ------------------------------------------------------------ 渲染

    def to_text(self, mark: Optional[Tuple[int, int]] = None) -> str:
        """渲染成 ASCII 迷宫。

        坐标约定: 列 = x(向右增大), 行 = y(向下增大), 因此 bit0「上」= y-1 方向。
        `mark` 给出当前位置, 会画成 `##`。
        """
        g = self.grid()
        if g is None:
            return "（还没有墙图数据, 先调 maze.fetch()）"
        n = self.mazetype()
        vis = self.visited()

        lines: List[str] = []
        for y in range(n):
            top = "+"
            for x in range(n):
                top += ("  " if (int(g[x][y]) & WALL_UP_OPEN) else "--") + "+"
            lines.append(top)
            mid = ""
            for x in range(n):
                left_open = bool(int(g[x][y]) & WALL_LEFT_OPEN)
                mid += (" " if left_open or x == 0 else "|")
                if mark is not None and (x, y) == mark:
                    mid += "##"
                elif vis is not None and vis[x][y]:
                    mid += "··"
                else:
                    mid += "  "
            mid += (" " if (int(g[n - 1][y]) & WALL_RIGHT_OPEN) else "|")
            lines.append(mid)
        bottom = "+"
        for x in range(n):
            bottom += ("  " if (int(g[x][n - 1]) & WALL_DOWN_OPEN) else "--") + "+"
        lines.append(bottom)
        return "\n".join(lines)

    def describe(self) -> str:
        """一行摘要: 尺寸、坐标、朝向、已探索格数。"""
        m = self.last()
        if not m:
            return "墙图: 未获取"
        n = self.mazetype()
        vis = self.visited()
        seen = sum(1 for col in vis for v in col if v) if vis else 0
        pos = self.position()
        return (
            f"墙图: {n}×{n}  坐标 ({pos[0]},{pos[1]}) 朝向 "
            f"{DIR_NAMES.get(pos[2], pos[2])}  已探索 {seen}/{n * n} 格"
        )
