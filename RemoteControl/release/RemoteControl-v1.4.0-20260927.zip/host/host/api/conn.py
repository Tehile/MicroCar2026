"""连接管理: 端口枚举、连接/断开、链路统计与自检、单个端口诊断。

对应功能清单的 A 组与 L 组。
"""

from __future__ import annotations

import time
from typing import TYPE_CHECKING, Any, Dict, List, Optional

from ..transport.link import LinkState, Target
from ..transport.ports import PortInfo, find_bluetooth_port, list_ports
from .errors import clamp_timeout

if TYPE_CHECKING:  # pragma: no cover
    from .client import MouseClient

# 蓝牙透传链路的可持续吞吐实测只有约 150 B/s(见 docs 附录 F),
# 因此"有没有数据"不能用字节数粗判, 而要看能不能解析出合法帧。


class ConnAPI:
    """连接相关。多数方法在 `MouseClient` 上也有同名快捷入口。"""

    def __init__(self, mc: "MouseClient") -> None:
        self._mc = mc

    # ------------------------------------------------------------ 端口

    def ports(self) -> List[PortInfo]:
        """枚举串口。返回值已按『可用 > 有线 > 蓝牙传出 > 蓝牙传入』排序。"""
        return list_ports()

    def port_labels(self) -> List[str]:
        return [p.label() for p in self.ports()]

    def bluetooth_port(self) -> str:
        """猜一个蓝牙端口名(优先传出端口), 没有则返回空串。"""
        return find_bluetooth_port()

    def targets(self) -> List[Target]:
        """候选连接目标: 已排序的串口 + 两个模拟器端口。"""
        out = [Target(kind="serial", port=p.device, baud=115200) for p in self.ports()]
        out.append(Target(kind="tcp", host="127.0.0.1", tcp_port=5555))
        out.append(Target(kind="tcp", host="127.0.0.1", tcp_port=5556))
        return out

    def probe(self, port: str, baud: int = 115200, seconds: float = 2.0) -> Dict[str, Any]:
        """诊断单个串口: 能否打开、有没有数据、是否像遥测帧、是否像文本。

        直接开一个**临时**串口, 因此要求本客户端当前没有连着同一个口。
        这是把 diag_port.py 的能力内化进来, 便于脚本化排查。
        """
        cur = self._mc.link.target
        if self._mc.is_connected and cur is not None and cur.port == port:
            return {"ok": False, "error": "该端口已被本客户端占用, 请先 disconnect()"}
        try:
            import serial

            s = serial.Serial(port, baud, timeout=0.2)
        except Exception as e:
            return {"ok": False, "port": port, "baud": baud, "error": f"{type(e).__name__}: {e}"}
        try:
            s.reset_input_buffer()
            t0 = time.time()
            data = b""
            while time.time() - t0 < clamp_timeout(seconds, 2.0):
                d = s.read(4096)
                if d:
                    data += d
                if len(data) > 16384:
                    break
            from ..protocol.codec import FrameStreamParser

            p = FrameStreamParser()
            frames, lines = p.feed(data)
            printable = sum(1 for b in data if 0x20 <= b <= 0x7E or b in (9, 10, 13))
            return {
                "ok": True,
                "port": port,
                "baud": baud,
                "bytes": len(data),
                "bps": len(data) / max(clamp_timeout(seconds, 2.0), 1e-3),
                "frames": len(frames),
                "text_lines": len(lines),
                "bad_crc": p.stats["bad_crc"],
                "bad_sync": p.stats["bad_sync"],
                "printable_ratio": (printable / len(data)) if data else 0.0,
                "looks_like_telemetry": len(frames) > 0,
                "looks_like_text": len(lines) > 0 and len(frames) == 0,
                "head": data[:48].hex(" "),
            }
        finally:
            try:
                s.close()
            except Exception:
                pass

    def scan_baud(
        self, port: str, bauds: Optional[List[int]] = None, seconds: float = 1.0
    ) -> List[Dict[str, Any]]:
        """逐个波特率试读。用于确认电脑侧蓝牙模块的 UART 速率。

        判据(重要): **0 字节 ≠ 乱码**。
        波特率不对时会收到**乱码字节**(数据在流, 只是切错位);
        收到 0 字节说明对端根本没在发 —— 那是链路没建立, 不是速率问题。
        """
        rates = bauds or [115200, 9600, 38400, 57600, 19200, 230400, 4800, 1200]
        return [self.probe(port, b, seconds) for b in rates]

    # ------------------------------------------------------------ 连接

    def connect(self, target: Any = None, **kw) -> bool:
        return self._mc.connect(target, **kw)

    def disconnect(self) -> None:
        self._mc.disconnect()

    def wait_open(self, timeout: float = 3.0) -> bool:
        """等到链路真的可用(read 线程已起来)。"""
        return self._mc.wait(lambda: self._mc.link.is_open, timeout=timeout)

    @property
    def is_connected(self) -> bool:
        return self._mc.link.is_open

    @property
    def state(self) -> str:
        return self._mc.link.state

    @property
    def state_detail(self) -> str:
        return self._mc.state_detail

    @property
    def target(self) -> Optional[Target]:
        return self._mc.link.target

    # ------------------------------------------------------------ 统计

    def stats(self) -> Dict[str, Any]:
        return self._mc.link.stats()

    def self_check(self) -> Dict[str, Any]:
        """链路自检: {need_bps, got_bps, level, suggest_rate}。"""
        return self._mc.link.self_check()

    def is_degraded(self) -> bool:
        return self.self_check().get("level") == "degraded"

    def reconnect(self, delay: float = 0.5) -> bool:
        """断开后用同一目标重连(蓝牙掉线后的恢复路径)。"""
        t = self._mc.link.target
        if t is None:
            return False
        self._mc.disconnect()
        time.sleep(clamp_timeout(delay, 0.5))
        return self._mc.connect(t)
