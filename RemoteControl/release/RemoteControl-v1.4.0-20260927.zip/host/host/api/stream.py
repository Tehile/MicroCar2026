"""遥测流控制: STREAM 开关与 RATE 速率档。

对应功能清单 C 组里的 STREAM / RATE。

硬约束(实机踩坑): 固件**上电默认静默**, 且这条蓝牙透传链路的可持续吞吐只有
约 152 B/s —— 超过阈值会把模块缓冲灌满并彻底归零(需模块重新上电)。
因此:

  - 连接后必须 `STREAM ON` 才会收到遥测(门面 `auto_stream=True` 已自动处理);
  - RATE 只在固件支持的 {100,50,20,10,5,2} Hz 内取, 默认 5 Hz 是安全档;
  - 想看控制细节请走 `mc.scope.fetch()` 拉 1 kHz 完整波形, 不要靠提 RATE。
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from .errors import Result

if TYPE_CHECKING:  # pragma: no cover
    from .client import MouseClient

#: 固件 RATE 命令接受的快帧速率档(与 link.c 的 linkFastDiv 分档一致)。
RATES = (100, 50, 20, 10, 5, 2)
DEFAULT_RATE = 5


class StreamAPI:
    """遥测流开关与速率。方法会等待设备应答。"""

    def __init__(self, mc: "MouseClient") -> None:
        self._mc = mc

    # ------------------------------------------------------------ 开关

    def on(self, timeout: float = 3.0) -> Result:
        """开启遥测流。固件上电默认静默, 连接后必须调用(或靠 auto_stream)。"""
        return self._mc.send_cmd("stream.on", timeout=timeout)

    def off(self, timeout: float = 3.0) -> Result:
        """关闭遥测流。断开前建议先关, 避免下次连接时缓冲里压着旧数据。"""
        return self._mc.send_cmd("stream.off", timeout=timeout)

    def toggle(self, on: bool, timeout: float = 3.0) -> Result:
        return self.on(timeout=timeout) if on else self.off(timeout=timeout)

    @property
    def is_on(self) -> bool:
        """按"最近是否还在收到快帧"判断流是否开启(启发式, 非设备状态)。"""
        return self._mc.telemetry.is_streaming()

    # ------------------------------------------------------------ 速率

    @staticmethod
    def rates() -> tuple:
        return RATES

    def rate(self, hz: int, timeout: float = 3.0) -> Result:
        """设置快帧速率档。非法档位直接返回 ERR_VALUE, 不下发。"""
        hz = int(hz)
        if hz not in RATES:
            return Result(False, "ERR_VALUE", {"hz": hz, "allowed": list(RATES)})
        return self._mc.send_cmd("rate", hz=hz, timeout=timeout)
