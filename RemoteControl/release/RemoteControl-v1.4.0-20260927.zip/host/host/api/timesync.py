"""时间同步 —— 把"设备毫秒时基"映射到"本机单调时钟", 从而算出**每个接收帧的准确时间**。

对应需求: "为了同步时间, 电脑鼠从发车命令开始其 LED 以 1Hz 闪烁, 同时需要记录其发车时间
和时间间隔来计算每一次接收到数据的准确时间。"

## 为什么必须做这件事

蓝牙透传是**有缓冲、有抖动**的: 一帧从固件发出到主机收到, 延迟不是常数。用"主机收到时刻"
当数据的时间, 时间轴会被链路抖动污染 —— 而"检测运动特性"恰恰要看毫秒级的时间关系。
靠主机自己**无法**恢复真实发送时刻, 所以必须让设备把它的时间告诉我们。

## 三条腿(缺一不可)

| 腿 | 载体 | 作用 |
|---|---|---|
| **毫秒时基** | 固件 `linkTimeMs`(SysTick 1ms 自增, u32) | 设备侧单调时间, 不受链路影响 |
| **软件戳** | `TIME` 帧 @1Hz(完整 u32) + 快帧保留字节(低 8 位) | 每秒一个绝对锚点, 每个快帧都能落位 |
| **物理灯** | `ARM` 后 LED 以 1Hz(50% 占空)闪烁 | 供摄像头/光电/人眼做**独立校核**, 也能标定单程延迟 |

三者同源同拍: TIME 帧在 `linkTimeMs % 1000 == 0` 时发出, 基准灯也在同一时刻翻转。
于是"软件收到的时刻"与"灯亮起的时刻"可以互相印证 —— 这正是用户要的"互相印证"。

## 单程延迟: 只能估, 但估得准

到达时刻 = 发送时刻 + 链路延迟, 而延迟未知且恒为正。经典做法是**取最小值**:
在若干次观测里, `t_recv - dev_ms/1000` 的**最小值**对应"延迟最小的那一次",
是真实偏移的最优估计(其余观测都被更大的延迟污染了)。

    offset = min( t_recv_i - up_ms_i / 1000 )

LED 基准灯则可以给出**独立**的延迟估计(人/摄像头量"灯亮"与"收到 armed"的差),
两边一比就知道估计是否可信 —— 这是把物理灯一起做的意义所在。

## 漂移

晶振有频差, 所以除了偏移还要估**斜率**: 对 (t_recv, up_ms) 做最小二乘拟合,
`slope - 1` 就是设备的相对频差(ppm)。长时间采集必须做漂移修正, 否则几秒钟后
毫秒级误差会累积到几十毫秒。

参见 `docs/数据收集与时间同步.md`。
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Tuple

from ..clock import now_monotonic
from .errors import Result, clamp_timeout

if TYPE_CHECKING:  # pragma: no cover
    from .client import MouseClient


# ============================================================ 纯函数: 拟合与解算
# 全部不碰设备, 因此可以脱离硬件单测(见 host/timesync_smoke.py)。

def min_delay_offset(samples: List[Tuple[float, int]]) -> Optional[float]:
    """单程延迟下的**偏移估计**: `offset = min(t_recv - dev_ms/1000)`。

    参数 samples: [(收到时刻(单调秒), 设备毫秒时基)]。
    返回 offset(秒), 使 `t_pc = offset + dev_ms/1000`。样本为空返回 None。

    为什么取最小而不是平均: 延迟恒为正, 平均值等于"真偏移 + 平均延迟";
    最小值才逼近"真偏移 + 最小延迟"。这是 NTP 里就在用的 min-filter 思想。
    """
    if not samples:
        return None
    return min(t - ms / 1000.0 for t, ms in samples)


def fit_clock(samples: List[Tuple[float, int]]) -> Optional[Tuple[float, float]]:
    """最小二乘拟合 `dev_ms/1000 = a + b * t_recv`, 返回 (a, b)。

    b 是"设备秒 / PC 秒"的比值, 理想为 1.0; `(b-1)*1e6` 即相对频差(ppm)。
    样本少于 3 个(或时间跨度太短)返回 None —— 那样拟合没有意义。
    """
    n = len(samples)
    if n < 3:
        return None
    ts = [s[0] for s in samples]
    ds = [s[1] / 1000.0 for s in samples]
    if max(ts) - min(ts) < 1e-3:
        return None
    mt = sum(ts) / n
    md = sum(ds) / n
    num = sum((t - mt) * (d - md) for t, d in zip(ts, ds))
    den = sum((t - mt) ** 2 for t in ts)
    if den <= 0:
        return None
    b = num / den
    a = md - b * mt
    return a, b


def drift_ppm(samples: List[Tuple[float, int]]) -> Optional[float]:
    """设备相对本机的频率偏差(ppm)。取不到有效拟合时返回 None。"""
    fit = fit_clock(samples)
    if fit is None:
        return None
    return (fit[1] - 1.0) * 1e6


def resolve_ms8(ms8: int, predicted_up_ms: float, window: int = 256) -> int:
    """把快帧里的 8 位时间戳(低 8 位)**还原成完整设备时基**。

    做法: 以"预测值"为基准, 在 `predicted + k*window` (k = -1,0,1) 里挑与
    `ms8` 同余且最接近预测值的那一个。只要预测误差 < 128ms 就必然选对 ——
    而 1Hz 的 TIME 帧 + 单调时钟预测, 误差远小于此。

    参数 window 缺省 256(= 2^8), 即"低 8 位"的模。
    """
    base = int(predicted_up_ms) - (int(predicted_up_ms) % window)
    best = None
    for k in (-1, 0, 1, 2):
        cand = base + k * window + int(ms8)
        if best is None or abs(cand - predicted_up_ms) < abs(best - predicted_up_ms):
            best = cand
    return int(best if best is not None else int(predicted_up_ms))


# ============================================================ 状态与结果

@dataclass
class TimeSyncState:
    """一次会话的时间同步状态快照。"""

    armed: bool = False
    arm_up_ms: Optional[int] = None      # 发车时刻(设备时基)
    arm_pc_mono: Optional[float] = None  # 发车时刻(本机单调)
    offset_s: Optional[float] = None     # min-delay 偏移
    drift_ppm: Optional[float] = None    # 相对频差
    one_way_ms: Optional[float] = None   # 由偏移反推的"最小单程延迟"估计
    samples: int = 0
    latest_up_ms: Optional[int] = None
    beacon_on: bool = False
    maze_run: bool = False

    def to_dict(self) -> Dict[str, Any]:
        d = {
            "armed": self.armed,
            "arm_up_ms": self.arm_up_ms,
            "offset_s": None if self.offset_s is None else round(self.offset_s, 6),
            "drift_ppm": None if self.drift_ppm is None else round(self.drift_ppm, 2),
            "one_way_ms": None if self.one_way_ms is None else round(self.one_way_ms, 3),
            "samples": self.samples,
            "latest_up_ms": self.latest_up_ms,
            "beacon_on": self.beacon_on,
            "maze_run": self.maze_run,
        }
        return d


# ============================================================ 门面

class TimeSyncAPI:
    """时间同步(门面 `mc.timesync`)。

    典型用法::

        mc.timesync.arm()          # 发车: 固件点亮 1Hz 基准灯并回 ARMED <ms>
        mc.timesync.maze_run()     # (仅数据收集档) 远程发车跑无记忆迷宫
        ...
        mc.timesync.snapshot()     # 看偏移/漂移/样本数
        t_pc = mc.timesync.frame_time(rec)   # 把某一帧换算成"发车以来的准确时刻"
    """

    #: 直方图窗口: 保留最近 N 个 (收到时刻, 设备时基) 观测用于拟合
    MAX_SAMPLES = 600

    def __init__(self, mc: "MouseClient") -> None:
        self._mc = mc
        self.reset()

    def reset(self) -> None:
        """清空全部观测与发车状态(重连/换设备时必须调)。"""
        self._samples: List[Tuple[float, int]] = []
        #: 发车握手: 发出 ARM 命令的本机单调时刻 + 固件回执里的 armMs 上电时基
        self.arm_pc_mono: Optional[float] = None
        self.arm_up_ms: Optional[int] = None
        self.arm_up_ms_recv_mono: Optional[float] = None
        self.armed = False

    # ------------------------------------------------------------ 观测采集

    def note(self, rec: dict) -> None:
        """由读取线程/调度线程喂入一帧 TIME 记录(内部用, 也可手工喂)。"""
        try:
            up = int(rec.get("upMs", 0))
            t = float(rec.get("_rx_mono") or now_monotonic())
        except Exception:
            return
        if up <= 0:
            return
        self._samples.append((t, up))
        if len(self._samples) > self.MAX_SAMPLES:
            del self._samples[: len(self._samples) - self.MAX_SAMPLES]
        if rec.get("armed") and not self.armed:
            self.armed = True
        if rec.get("armMs") and self.arm_up_ms is None:
            self.arm_up_ms = int(rec["armMs"])
            self.arm_up_ms_recv_mono = t

    def on_armed_line(self, up_ms: int) -> None:
        """处理固件回的 `ARMED <ms>` 文本行(发车回执)。"""
        self.armed = True
        self.arm_up_ms = int(up_ms)
        self.arm_up_ms_recv_mono = now_monotonic()

    # ------------------------------------------------------------ 映射

    def offset_s(self) -> Optional[float]:
        """当前偏移估计(秒)。`t_pc_mono = offset + up_ms/1000`。"""
        return min_delay_offset(self._samples)

    def drift_ppm(self) -> Optional[float]:
        return drift_ppm(self._samples)

    def _predict_up_ms(self, at_mono: Optional[float] = None) -> float:
        """用"最近一次观测 + 漂移修正"预测某本机时刻对应的设备时基。"""
        if not self._samples:
            return 0.0
        t_ref, up_ref = self._samples[-1]
        t = at_mono if at_mono is not None else now_monotonic()
        ppm = self.drift_ppm()
        rate = 1000.0 * (1.0 + (ppm or 0.0) / 1e6)
        return float(up_ref) + (t - t_ref) * rate

    def frame_time_up(self, rec: dict) -> Optional[int]:
        """把一帧记录换算成**设备毫秒时基**上的发送时刻。

        - 带完整 `upMs` 的 TIME 帧: 直接用;
        - 带 `ms8` 的快帧: 用预测值把 8 位还原成完整值(见 `resolve_ms8`)。
        取不到时间信息时返回 None。
        """
        if "upMs" in rec:
            try:
                return int(rec["upMs"])
            except (TypeError, ValueError):
                return None
        if "ms8" in rec:
            t = float(rec.get("_rx_mono") or now_monotonic())
            return resolve_ms8(int(rec["ms8"]), self._predict_up_ms(t))
        return None

    def frame_time(self, rec: dict) -> Optional[float]:
        """把一帧记录换算成**本机单调秒**(即"这一帧真正发生的时刻")。

        计算: `offset + up_ms/1000`。offset 用 min-delay 估计, 因此它已经把
        "最小单程延迟"吃进去了 —— 绝对值上仍差一个常数(未知的最小延迟),
        但**任意两帧之间的时间差是准确的**, 这正是运动特性分析需要的。
        """
        up = self.frame_time_up(rec)
        if up is None:
            return None
        off = self.offset_s()
        if off is None:
            return None
        return off + up / 1000.0

    def dev_ms(self, rec: dict) -> Optional[int]:
        """把一帧换算成"发车以来毫秒数"。未发车或取不到时基时返回 None。"""
        up = self.frame_time_up(rec)
        if up is None or not self.arm_up_ms:
            return None
        return int(up - self.arm_up_ms)

    def dev_ms_from_recv(self, rec: dict) -> Optional[int]:
        """给**自身不带时间戳**的帧(中/慢帧)估算"发车以来毫秒数"。

        做法: 用到达时刻投影到设备时基。注意这会**偏大约一个单程延迟** ——
        因为到达时刻 = 发送时刻 + 延迟。要精确的逐帧时刻请依赖快帧(带低 8 位)
        或时间帧(带完整 u32)。这里只作为"给每行 CSV 都有一列时间"的兜底。
        """
        if not self.arm_up_ms or not self._samples:
            return None
        t = float(rec.get("_rx_mono") or now_monotonic())
        up = self._predict_up_ms(t)
        return int(up - self.arm_up_ms)

    def frame_age_ms(self, rec: dict) -> Optional[float]:
        """这一帧从**设备发出**到**本机收到**经历了多久(单程延迟实测)。

        只在"该帧自己带了完整时基"(TIME 帧)时有意义 —— 快帧只有低 8 位,
        差值与 256 同余, 无法区分。
        """
        if "upMs" not in rec:
            return None
        off = self.offset_s()
        if off is None:
            return None
        t = float(rec.get("_rx_mono") or now_monotonic())
        return (t - (off + int(rec["upMs"]) / 1000.0)) * 1000.0

    # ------------------------------------------------------------ 状态

    def snapshot(self) -> TimeSyncState:
        off = self.offset_s()
        st = TimeSyncState(
            armed=self.armed,
            arm_up_ms=self.arm_up_ms,
            arm_pc_mono=self.arm_pc_mono,
            offset_s=off,
            drift_ppm=self.drift_ppm(),
            samples=len(self._samples),
        )
        if self.arm_pc_mono is not None and off is not None and self.arm_up_ms is not None:
            # "发车时刻(本机单调)" 与 "按设备时基算出的发车时刻" 之差 = 最小单程延迟
            st.one_way_ms = (self.arm_pc_mono - (off + self.arm_up_ms / 1000.0)) * 1000.0
        latest = None
        try:
            latest = self._mc.store.latest_time
        except Exception:
            latest = None
        if latest:
            st.latest_up_ms = int(latest.get("upMs", 0)) or None
            st.beacon_on = bool(latest.get("beaconOn"))
            st.maze_run = bool(latest.get("mazeRun"))
        return st

    # ------------------------------------------------------------ 命令

    def arm(self, timeout: float = 3.0) -> Result:
        """**发车**: 让固件记下发车时刻并点亮 1Hz 时间基准灯。

        本机会同时记下"发出命令的单调时刻" —— 它与固件回的 `ARMED <ms>`
        一起, 给出单程延迟的一个独立估计(见 `snapshot().one_way_ms`)。
        """
        self.arm_pc_mono = now_monotonic()
        r = self._mc.send_cmd("arm", timeout=timeout)
        if r.ok:
            self.armed = True
        return r

    def maze_run(self, timeout: float = 3.0) -> Result:
        """远程发车跑无记忆走迷宫(仅 `MOUSE_DATA_LOG` 档; 其余固件回 ERR_VALUE)。"""
        return self._mc.send_cmd("maze.run", timeout=timeout)

    def wait_sync(self, samples: int = 2, timeout: float = 5.0) -> bool:
        """等至少 `samples` 个 TIME 帧到达(建立可用映射)。返回是否达到。"""
        deadline = now_monotonic() + clamp_timeout(timeout, 1.0)
        while now_monotonic() < deadline:
            if len(self._samples) >= samples:
                return True
            import time as _t

            _t.sleep(0.02)
        return len(self._samples) >= samples

    # ------------------------------------------------------------ 解释

    def explain(self) -> str:
        st = self.snapshot()
        lines = [
            f"发车        : {'已发车' if st.armed else '未发车'}"
            + (f"  (设备时基 {st.arm_up_ms} ms)" if st.arm_up_ms else ""),
            f"时间同步帧  : 收到 {st.samples} 帧",
        ]
        if st.offset_s is not None:
            lines.append(f"偏移估计    : {st.offset_s:.6f} s (min-delay, 含最小单程延迟)")
        if st.one_way_ms is not None:
            lines.append(f"单程延迟估计: 约 {st.one_way_ms:.1f} ms "
                         "(ARM 发出→设备记时的差, 减去链路单程)")
        if st.drift_ppm is not None:
            lines.append(f"频差        : {st.drift_ppm:+.2f} ppm "
                         "(设备与 PC 时钟的相对快慢, 长采集要按它修正)")
        lines.append(f"基准灯      : {'亮' if st.beacon_on else '灭'}    "
                     f"迷宫在跑: {'是' if st.maze_run else '否'}")
        if st.samples < 3:
            lines.append("提示: 样本还太少, 偏移/漂移估计不收敛 —— 多等几秒。")
        return "\n".join(lines)


# 便于 `from host.api.timesync import ...` 的使用方少写一层
__all__ = [
    "TimeSyncAPI",
    "TimeSyncState",
    "min_delay_offset",
    "fit_clock",
    "drift_ppm",
    "resolve_ms8",
]
