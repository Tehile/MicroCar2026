"""离线分析: 阶跃指标、跟踪误差、按运动任务分段。

对应功能清单的 J 组。**不需要连接设备** —— 输入是 numpy 数组或
`scope.fetch()` 的返回值, 所以随时可用(含离线回放)。

dump 数组的约定(与 `TelemetryStore.dump_arrays()` 一致)::

    (t_ms, motionTask, gangle, speedl, speedr)
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Dict, List, Optional, Sequence

import numpy as np

from ..analysis.metrics import (
    format_metrics,
    segment_by_task,
    step_metrics,
    tracking_error,
)
from ..protocol.codec import MOTION_TASK_NAMES

if TYPE_CHECKING:  # pragma: no cover
    from .client import MouseClient

#: dump 数组各列的含义, 顺序与固件 RunData 结构体一致。
DUMP_FIELDS = ("t_ms", "motionTask", "gangle", "speedl", "speedr")


class AnalyzeAPI:
    """纯计算, 无副作用, 可反复调用。"""

    def __init__(self, mc: Optional["MouseClient"] = None) -> None:
        self._mc = mc

    # ------------------------------------------------------------ 基本指标

    def step(
        self, t: Sequence[float], y: Sequence[float], target: float, band: float = 0.02
    ) -> Dict[str, float]:
        """阶跃响应指标: rise_s / overshoot_pct / settle_s / sse / peak / final。"""
        return step_metrics(np.asarray(t, dtype=float), np.asarray(y, dtype=float), target, band)

    def tracking(
        self, t: Sequence[float], y: Sequence[float], ref: Sequence[float], tail_frac: float = 0.2
    ) -> Dict[str, float]:
        """跟踪误差: rms / maxabs / tail_mean / tail_rms。"""
        return tracking_error(np.asarray(t), np.asarray(y), np.asarray(ref), tail_frac)

    def segments(self, t_ms: Sequence[float], task: Sequence[int]) -> List[Dict[str, Any]]:
        """按 `motionTask` 变化切段。一次动作就是一段。"""
        return segment_by_task(np.asarray(t_ms), np.asarray(task))

    def format(self, m: Dict[str, float]) -> str:
        return format_metrics(m)

    def task_name(self, code: int) -> str:
        return MOTION_TASK_NAMES.get(int(code), str(int(code)))

    # ------------------------------------------------------------ dump 数组

    def channels(self, arr) -> Dict[str, Any]:
        """把 dump 数组拆成具名通道, 便于按名字取用。"""
        if arr is None:
            return {}
        t, task, ang, sl, sr = arr
        return {
            "t_ms": t,
            "t_s": np.asarray(t, dtype=float) / 1000.0,
            "motionTask": task,
            "gangle": ang,
            "speedl": sl,
            "speedr": sr,
        }

    def dump_segments(self, arr) -> List[Dict[str, Any]]:
        """把一次 dump 按运动任务切段(段内带各通道切片)。"""
        if arr is None:
            return []
        ch = self.channels(arr)
        segs = self.segments(ch["t_ms"], ch["motionTask"])
        for s in segs:
            i0, i1 = int(s["i0"]), int(s["i1"])
            s["task_name"] = self.task_name(s["task"])
            s["slices"] = {
                "t_s": ch["t_s"][i0 : i1 + 1],
                "speedl": ch["speedl"][i0 : i1 + 1],
                "speedr": ch["speedr"][i0 : i1 + 1],
                "gangle": ch["gangle"][i0 : i1 + 1],
            }
        return segs

    def summary(self, arr, band: float = 0.02) -> List[Dict[str, Any]]:
        """对每一段算左右轮速的阶跃指标。

        target 取该段最后 5% 的均值 —— 比取"理论目标值"更稳: dump 里没有下发
        的目标转速, 而段尾通常已进入稳态。
        """
        out: List[Dict[str, Any]] = []
        for s in self.dump_segments(arr):
            sl = np.asarray(s["slices"]["speedl"], dtype=float)
            sr = np.asarray(s["slices"]["speedr"], dtype=float)
            t_s = np.asarray(s["slices"]["t_s"], dtype=float)
            if len(t_s) < 3:
                continue
            tail = max(1, len(sl) // 20)
            item: Dict[str, Any] = {
                "task": s["task"],
                "task_name": s["task_name"],
                "duration_ms": s["duration_ms"],
                "points": len(t_s),
            }
            for name, y in (("speedl", sl), ("speedr", sr)):
                target = float(np.mean(y[-tail:]))
                item[name] = self.step(t_s, y, target, band) if abs(target) > 1e-6 else {}
            out.append(item)
        return out

    def explain(self, arr) -> str:
        """把 summary 变成一段人可读的文本(CLI 与日志用)。"""
        rows = self.summary(arr)
        if not rows:
            return "（无有效动作段）"
        lines = []
        for r in rows:
            lines.append(
                f"#{r['task']:<3}{r['task_name']:<22}{r['duration_ms']:>7.0f}ms  "
                f"L[{self.format(r.get('speedl', {}))}]  R[{self.format(r.get('speedr', {}))}]"
            )
        return "\n".join(lines)
