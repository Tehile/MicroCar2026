"""电机远程控制实验 + 双流数据传输。

对应阶段: **电机的远程控制实验**(电脑鼠轮子悬空, 只验证"命令 -> 电机 -> 遥测"这条链)。

## 为什么是"双流"

实测这条蓝牙透传链路的**可持续吞吐只有约 152 B/s**(见设计文档附录 F): 超过阈值会把
模块缓冲灌满并**彻底静默**, 且不会自恢复(需模块重新上电)。所以"实时"和"细节"在
物理上不能同时要 —— 只能按动作的时间轴分工:

| | 流 | 载体 | 速率 | 什么时候传 |
|---|---|---|---|---|
| 实时流 | 快/中/慢帧 | 二进制遥测帧 | ~152 B/s | **运动进行中**优先独占 |
| 日志流 | 1kHz 运动日志 | 本地环缓冲, 停止后整块回传 | 约 9.6 KB / 次 | **运动结束后**独占 |

2 秒的运动里, 实时流按默认 5 Hz 只能给到约 10 个点, 而日志流有 1200 个点 —— 相差 100 倍。
这正是"运动时看趋势、停下来看细节"这条分工的量化依据, 也是本模块要演示的东西。

## 谁在保证"停止"

护栏**全部在固件的 1ms ISR 里**(`link_MoveService`), 不在本模块:

    时间护栏   到时(默认 2000 ms)无条件停车
    红外护栏   任一红外读数 < 阈值(默认 10 mm)立即停车
    急停       锁存式, 之后的 MOVE/CAL 一律 ERR_ESTOP, 必须显式 STOP 解锁

上位机这一侧**只负责观察与取数**: 下发命令、把运动期间的实时流采样下来、
动作结束后把日志拉回来。即使本进程被 kill, 电机照样会按时停。
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Callable, Dict, List, Optional

from .errors import Result, clamp_timeout
from .events import Event

if TYPE_CHECKING:  # pragma: no cover
    from .client import MouseClient

#: 快/中/慢帧的线上字节数(载荷 + 8B 帧开销), 用于估算实时流占用的带宽
_FRAME_BYTES = {"fast": 24, "mid": 20, "slow": 24}

#: 红外四路的通道名(与固件 link_MinIr 的顺序一致)
_IR_CHANNELS = ("F1", "F2", "L", "R")


@dataclass
class RunResult:
    """一次带护栏的远程运动的完整结果(实时流 + 日志流)。"""

    ok: bool = False
    status: str = ""
    # ---- 来自固件 MOVEDONE RUN 明细 ----
    reason: str = ""
    reason_text: str = ""
    elapsed_ms: Optional[int] = None
    ir_min: Optional[int] = None
    ir_chan: Optional[str] = None
    dL: Optional[int] = None
    dR: Optional[int] = None
    peak_l: Optional[int] = None
    peak_r: Optional[int] = None
    # ---- 实时流(运动期间的快/中/慢帧) ----
    realtime: Dict[str, Any] = field(default_factory=dict)
    samples: List[Dict[str, Any]] = field(default_factory=list)
    # ---- 日志流(停止后的 1kHz 整块回传) ----
    log_points: int = 0
    log_fetched: bool = False
    log_seconds: float = 0.0
    log_arrays: Any = None
    # ---- 其它 ----
    warning: str = ""
    error: str = ""
    raw: str = ""

    def to_dict(self, with_samples: bool = False) -> Dict[str, Any]:
        d = {
            "ok": self.ok,
            "status": self.status,
            "reason": self.reason,
            "reason_text": self.reason_text,
            "elapsed_ms": self.elapsed_ms,
            "ir_min": self.ir_min,
            "ir_chan": self.ir_chan,
            "dL": self.dL,
            "dR": self.dR,
            "peak_l": self.peak_l,
            "peak_r": self.peak_r,
            "realtime": self.realtime,
            "log_points": self.log_points,
            "log_fetched": self.log_fetched,
            "log_seconds": round(self.log_seconds, 3),
        }
        if self.warning:
            d["warning"] = self.warning
        if self.error:
            d["error"] = self.error
        if self.raw:
            d["raw"] = self.raw
        if with_samples:
            d["samples"] = self.samples
        return d


class MotorLabAPI:
    """电机远程控制实验(门面 `mc.lab`)。"""

    def __init__(self, mc: "MouseClient") -> None:
        self._mc = mc

    # ------------------------------------------------------------ 状态

    def status(self) -> Dict[str, Any]:
        """一眼看清"现在能不能动、能不能拉日志"。"""
        mc = self._mc
        f, _m, s = mc.telemetry.latest()
        return {
            "connected": mc.is_connected,
            "motor_disabled": mc.motor_disabled,
            "estop_locked": mc.estop_locked,
            "emerg": bool(f.get("emerg", False)),
            "scoping": bool(f.get("scoping", False)),
            "log_ready": mc.log_ready,
            "freemode": bool(f.get("freemode", False)),
            "ir": {ch: s.get("ir" + ch) for ch in _IR_CHANNELS},
            "ir_min": self._ir_min(),
            "can_move": (mc.is_connected and mc.motor_disabled is False and not mc.estop_locked),
        }

    def _ir_min(self) -> Optional[int]:
        """当前四路红外的最小值(mm)。没收到慢帧时返回 None。"""
        _f, _m, s = self._mc.telemetry.latest()
        if not s:
            return None
        vals = [s.get("irF1"), s.get("irF2"), s.get("irL"), s.get("irR")]
        vals = [int(v) for v in vals if v is not None]
        return min(vals) if vals else None

    # ------------------------------------------------------------ 急停

    def estop(self, timeout: float = 3.0) -> Result:
        """急停(锁存)。**随时可用**, 不依赖任何先决条件。"""
        return self._mc.move.estop(timeout=timeout)

    def resume(self, timeout: float = 3.0) -> Result:
        """解除急停锁存并正常停车(固件侧 = `STOP`)。"""
        return self._mc.move.resume(timeout=timeout)

    # ------------------------------------------------------------ 双流实验

    def run(
        self,
        sp_l: int = 40,
        sp_r: int = 40,
        ms: int = 2000,
        ir_mm: int = 10,
        fetch_log: bool = True,
        realtime_hz: float = 5.0,
        log_timeout: float = 300.0,
        on_progress: Optional[Callable[[float, Optional[float], Optional[float]], None]] = None,
        on_sample: Optional[Callable[[Dict[str, Any]], None]] = None,
    ) -> RunResult:
        """跑一次"运动时走实时流 / 停止后回传详细日志"的完整双流实验。

        参数:
            sp_l, sp_r   左右轮速度(cm/s)
            ms           最长运行时间(ms), 护栏之一
            ir_mm        红外停车阈值(mm), 护栏之二; 负值关闭红外护栏
            fetch_log    停止后是否自动拉取 1kHz 日志(默认拉)
            realtime_hz  运动期间对实时流的采样频率(默认 5 Hz, 与快帧同频)
            on_progress  日志回传进度回调 `(frac, eta_s, rate_bps)`。**运行在调度线程**
            on_sample    实时采样回调, 每采到一个样本调用一次

        返回 `RunResult`。注意: 本方法会**阻塞**, 不要在事件回调里调用。
        """
        mc = self._mc
        mc._check_reentrancy("lab.run()")
        res = RunResult()

        # ---- 前置检查: 能不能动 ----
        if mc.motor_disabled is True:
            res.status = "MOTOR_DISABLED"
            res.error = (
                "设备是安全测试固件(MOUSE_TEST_NO_MOTOR): 电机输出恒 0, 跑这个实验没有意义。"
                "请在 code_stm32f1_mouse/USER/main.h 里改用 MOUSE_TEST_MOTOR_LAB 并重新烧录。"
            )
            return res
        if mc.estop_locked:
            res.status = "ESTOP_LOCKED"
            res.error = "设备处于急停锁存状态。先调用 mc.lab.resume() 解锁再跑。"
            return res

        # ---- 前置检查: 护栏是否已经处于"必然立即触发"的状态 ----
        # 这一条非常重要: 若某路红外本来就 < 阈值, 运动会在一两个 1ms 周期内结束,
        # 现象看起来像"命令无效"。提前说出来, 省掉一次现场排查。
        pre_ir = self._ir_min()
        if pre_ir is not None and ir_mm > 0 and pre_ir < ir_mm:
            res.warning = (
                f"开始前就有红外读数 {pre_ir}mm < 阈值 {ir_mm}mm: 动作会立即被护栏停掉。"
                f"请清开传感器前方, 或把 ir_mm 调小(负值=关闭红外护栏)。"
            )

        # ---- 实时流: 统计区间起点 ----
        st0 = mc.link.stats()

        # ---- 下发命令并等 MOVEDONE RUN ----
        # 用事件订阅而不是 wait_event(): 要一边等一边采实时流, 不能阻塞住。
        hits: List[Any] = []
        estops: List[Any] = []

        def _on_move(msg) -> None:
            f = msg.data.get("fields") or []
            if f and str(f[0]).upper() == "RUN":
                hits.append(msg)

        off_move = mc.on(Event.MOVE, _on_move)
        off_estop = mc.on(Event.ESTOP, lambda m: estops.append(m))

        t0 = time.time()
        try:
            ack = mc.send_cmd(
                "move.run", sp_l=int(sp_l), sp_r=int(sp_r), ms=int(ms), ir_mm=int(ir_mm)
            )
            if not ack.ok:
                res.status = ack.status
                res.error = f"设备拒绝了 MOVE RUN: {ack.status}"
                return res

            budget = clamp_timeout(ms / 1000.0 + 5.0, 10.0)
            period = 1.0 / max(0.5, float(realtime_hz))
            next_t = t0
            while time.time() - t0 < budget:
                if hits or estops:
                    break
                now = time.time()
                if now >= next_t:
                    next_t = now + period
                    f, m, s = mc.telemetry.latest()
                    if f:
                        rec = {
                            "t": round(now - t0, 3),
                            "speedL": float(f.get("speedL", 0.0)),
                            "speedR": float(f.get("speedR", 0.0)),
                            "targetL": float(f.get("speedTargetL", 0.0)),
                            "targetR": float(f.get("speedTargetR", 0.0)),
                            "gyro": float(f.get("gyroAngle", 0.0)),
                            "task": int(f.get("task", 0)),
                            "ir_min": self._ir_min(),
                        }
                        res.samples.append(rec)
                        if on_sample is not None:
                            try:
                                on_sample(rec)
                            except Exception:
                                pass
                time.sleep(0.005)

            # ---- 实时流: 统计区间终点 ----
            st1 = mc.link.stats()
            elapsed = max(1e-6, time.time() - t0)
            counts = {
                k: int(st1.get(k, 0)) - int(st0.get(k, 0)) for k in ("fast", "mid", "slow")
            }
            approx_bytes = sum(counts[k] * _FRAME_BYTES[k] for k in counts)
            res.realtime = {
                "seconds": round(elapsed, 3),
                "frames": counts,
                "approx_bytes": approx_bytes,
                "approx_bps": round(approx_bytes / elapsed, 1),
                "samples": len(res.samples),
                "bad_crc": int(st1.get("bad_crc", 0)) - int(st0.get("bad_crc", 0)),
            }

            if not hits:
                res.status = "ESTOP" if estops else "TIMEOUT"
                res.error = (
                    "运动被急停打断" if estops else "等 MOVEDONE RUN 超时(设备没回明细行)"
                )
                return res

            msg = hits[0]
            rep = _parse_run(msg.data.get("fields") or [])
            res.reason = rep["reason"]
            res.reason_text = rep["reason_text"]
            res.elapsed_ms = rep["elapsed_ms"]
            res.ir_min = rep["ir_min"]
            res.ir_chan = rep["ir_chan"]
            res.dL = rep["dL"]
            res.dR = rep["dR"]
            res.peak_l = rep["peak_l"]
            res.peak_r = rep["peak_r"]
            res.raw = msg.data.get("raw") or ""
            res.ok = True
            res.status = rep["reason"] or "OK"

            # ---- 日志流: 停止后整块回传(此时实时流已被固件自动让出带宽) ----
            if fetch_log:
                tl = time.time()
                arr = mc.scope.fetch(
                    timeout=log_timeout, on_progress=on_progress, stop_first=False
                )
                res.log_seconds = time.time() - tl
                # stop_first=False: 运动结束后固件已经把车和目标速度归零并冻结了环,
                # 再发 STOP 是多余的 —— 而且**会顺手解掉急停锁存**, 抹掉现场状态。
                if arr is not None:
                    res.log_arrays = arr
                    res.log_points = int(len(arr[0]))
                    res.log_fetched = True
                else:
                    res.warning = (res.warning + "  " if res.warning else "") + (
                        "日志回传失败或超时(不影响运动结论)"
                    )
            return res
        finally:
            off_move()
            off_estop()

    # ------------------------------------------------------------ 日志

    def fetch_log(
        self,
        timeout: float = 300.0,
        on_progress: Optional[Callable[[float, Optional[float], Optional[float]], None]] = None,
    ):
        """只回传当前冻结的日志(不发命令、不运动)。返回 `dump_arrays()` 或 None。"""
        return self._mc.scope.fetch(timeout=timeout, on_progress=on_progress, stop_first=False)

    def explain(self, res: RunResult) -> str:
        """把一次实验结果整理成几行人能读的结论。"""
        if not res.ok:
            return f"实验未完成: {res.status}  {res.error}"
        lines = [
            f"停止原因 : {res.reason_text} ({res.reason})",
            f"运行时长 : {res.elapsed_ms} ms",
            f"最小红外 : {res.ir_min} mm @ {res.ir_chan}",
            f"轮子里程 : L {res.dL} / R {res.dR} 脉冲",
            f"速度峰值 : L {res.peak_l} / R {res.peak_r} cm/s",
            "-- 实时流(运动期间) --",
            f"  时长 {res.realtime.get('seconds')} s, "
            f"快{res.realtime.get('frames', {}).get('fast', 0)}/"
            f"中{res.realtime.get('frames', {}).get('mid', 0)}/"
            f"慢{res.realtime.get('frames', {}).get('slow', 0)} 帧, "
            f"约 {res.realtime.get('approx_bps')} B/s, 坏CRC {res.realtime.get('bad_crc')}",
            "-- 日志流(停止后) --",
            f"  1kHz 采样点 {res.log_points} 个"
            + ("" if res.log_fetched else "  (未回传)"),
        ]
        if res.warning:
            lines.append(f"提示: {res.warning}")
        return "\n".join(lines)


def _parse_run(fields: list) -> Dict[str, Any]:
    from ..protocol.codec import parse_movedone_run

    return parse_movedone_run(fields)
