"""会话落盘: 每会话一个目录, CSV(人可读) + raw.bin(原始字节留档) + meta.json。

保留 raw.bin 是刻意的: 协议一旦迭代(加字段/改缩放), 只要有原始字节流,
就能用新解析器重跑全部历史数据, 不会丢历史。
"""

from __future__ import annotations

import csv
import json
import os
import threading
import time
from typing import Dict, List, Optional

from ..model.ring import FAST_CHANNELS, MID_CHANNELS, SLOW_CHANNELS


class Session:
    def __init__(self, root: str = "sessions", name: Optional[str] = None) -> None:
        self.root = root
        stamp = time.strftime("%Y-%m-%d_%H%M")
        self.name = name or stamp
        self.path = os.path.join(root, self.name)
        os.makedirs(self.path, exist_ok=True)
        os.makedirs(os.path.join(self.path, "calib"), exist_ok=True)

        self.lock = threading.Lock()
        self.enabled = True
        self.counts: Dict[str, int] = {"fast": 0, "mid": 0, "slow": 0, "text": 0, "dump": 0}

        self._raw = open(os.path.join(self.path, "raw.bin"), "ab", buffering=1 << 16)
        # raw.ts: 每行 `<t_ms> <nbytes>`, 记录原始字节的到达时刻。
        # 供离线回放(replay.py)按**原始节奏**重放 —— 只有 raw.bin 的话只能尽快灌,
        # 那样时间相关的分析(看实时趋势、超时)就没有意义了。
        self._raw_ts = open(os.path.join(self.path, "raw.ts"), "a", encoding="utf-8", buffering=1)
        self._text = open(os.path.join(self.path, "text.log"), "a", encoding="utf-8", buffering=1)

        self._fast_f = open(os.path.join(self.path, "stream_250hz.csv"), "w", newline="", encoding="utf-8")
        self._mid_f = open(os.path.join(self.path, "stream_50hz.csv"), "w", newline="", encoding="utf-8")
        self._slow_f = open(os.path.join(self.path, "stream_5hz.csv"), "w", newline="", encoding="utf-8")
        self._fast_w = csv.writer(self._fast_f)
        self._mid_w = csv.writer(self._mid_f)
        self._slow_w = csv.writer(self._slow_f)
        self._dump_f = None
        self._dump_w = None

        # t_host_ms 便于与外部记录对齐; 时间戳精度到毫秒
        # dev_ms  = "发车(ARM)以来毫秒", 由设备时基换算 —— 它**不受链路抖动影响**,
        #           是做运动特性分析时真正该用的时间轴(见 docs/数据收集与时间同步.md)。
        #           未发车时为空字符串。
        self._fast_w.writerow(["t_host_ms", "dev_ms", "seq", "task", "volt"] + FAST_CHANNELS)
        self._mid_w.writerow(["t_host_ms", "dev_ms", "seq"] + MID_CHANNELS)
        self._slow_w.writerow(
            ["t_host_ms", "dev_ms", "seq", "mouseTask", "wallBits", "drop"] + SLOW_CHANNELS
        )

        self.meta: Dict[str, object] = {
            "started": time.strftime("%Y-%m-%d %H:%M:%S"),
            "host_version": "1.0.0",
        }

    # ------------------------------------------------------------ 写入

    @staticmethod
    def _ms() -> int:
        return int(time.time() * 1000)

    def write_raw(self, data: bytes) -> None:
        if not self.enabled or not data:
            return
        with self.lock:
            self._raw.write(data)
            self._raw_ts.write(f"{self._ms()} {len(data)}\n")

    def write_text(self, line: str, direction: str = "<-") -> None:
        if not self.enabled:
            return
        with self.lock:
            self._text.write(f"{self._ms()} {direction} {line}\n")
            self.counts["text"] += 1

    @staticmethod
    def _dev(rec: dict):
        """落盘的 dev_ms 列: 未发车时留空, 有值就写整数。"""
        v = rec.get("_dev_ms")
        return "" if v is None else int(v)

    def write_fast(self, rec: dict) -> None:
        if not self.enabled:
            return
        with self.lock:
            self._fast_w.writerow(
                [self._ms(), self._dev(rec), rec.get("_seq", ""),
                 rec.get("task", 0), f"{rec.get('volt', 0):.1f}"]
                + [rec.get(c, 0) for c in FAST_CHANNELS]
            )
            self.counts["fast"] += 1

    def write_mid(self, rec: dict) -> None:
        if not self.enabled:
            return
        with self.lock:
            self._mid_w.writerow(
                [self._ms(), self._dev(rec), rec.get("_seq", "")]
                + [rec.get(c, 0) for c in MID_CHANNELS]
            )
            self.counts["mid"] += 1

    def write_slow(self, rec: dict) -> None:
        if not self.enabled:
            return
        with self.lock:
            self._slow_w.writerow(
                [self._ms(), self._dev(rec), rec.get("_seq", ""),
                 rec.get("mouseTask", 0), rec.get("wallBits", 0), rec.get("drop", 0)]
                + [rec.get(c, 0) for c in SLOW_CHANNELS]
            )
            self.counts["slow"] += 1

    def open_dump(self, tag: Optional[str] = None) -> None:
        """为一个 1kHz dump 开一份高密度 CSV。"""
        if not self.enabled:
            return
        with self.lock:
            self.counts["dump"] += 1
            idx = self.counts["dump"]
            fname = f"dump_1khz_{tag or idx:0>4}" if tag else f"dump_1khz_{idx:0>4}"
            self._dump_f = open(os.path.join(self.path, fname + ".csv"), "w", newline="", encoding="utf-8")
            self._dump_w = csv.writer(self._dump_f)
            self._dump_w.writerow(["i", "t_ms", "motionTask", "gangle", "speedl", "speedr"])

    def write_dump(self, records) -> None:
        if not self.enabled or self._dump_w is None:
            return
        with self.lock:
            for i, (mt, ang, sl, sr) in enumerate(records):
                self._dump_w.writerow([i, i, mt, ang, sl, sr])

    def write_calib_report(self, lines: List[str]) -> str:
        p = os.path.join(self.path, "calib", "report.md")
        with open(p, "a", encoding="utf-8") as f:
            f.write("\n".join(lines) + "\n")
        return p

    def backup_params(self, rows: List[List[str]]) -> str:
        """写入前把旧参数导出作备份(SAVE 之前自动调用)。"""
        p = os.path.join(self.path, "calib", f"params_before_{self._ms()}.csv")
        with open(p, "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            w.writerow(["name", "q1616", "value"])
            w.writerows(rows)
        return p

    # ------------------------------------------------------------ 收尾

    def close(self, extra_meta: Optional[dict] = None) -> None:
        with self.lock:
            self.enabled = False
            if extra_meta:
                self.meta.update(extra_meta)
            self.meta["counts"] = dict(self.counts)
            self.meta["ended"] = time.strftime("%Y-%m-%d %H:%M:%S")
            try:
                with open(os.path.join(self.path, "meta.json"), "w", encoding="utf-8") as f:
                    json.dump(self.meta, f, ensure_ascii=False, indent=2)
            except OSError:
                pass
            for h in (
                self._raw,
                self._raw_ts,
                self._text,
                self._fast_f,
                self._mid_f,
                self._slow_f,
                self._dump_f,
            ):
                try:
                    if h:
                        h.close()
                except OSError:
                    pass
