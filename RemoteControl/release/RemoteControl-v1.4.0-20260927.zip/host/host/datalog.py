"""数据收集台 —— 远程发车 + 时间同步 + 完整采集(终端界面, 零 GUI 依赖)。

对应需求: "检测电脑鼠运动特性并收集数据" + "从发车命令开始 LED 以 1Hz 闪烁, 记录发车时间
和时间间隔来计算每一次接收到数据的准确时间"。

## 一次采集的完整流程

    1. 连上设备(STREAM ON, 必要时开会话落盘)
    2. `ARM`  —— 发车: 固件记下发车时刻 + 点亮 1Hz 时间基准灯; 本机记下发出时刻
    3. 等时间同步收敛(收到几帧 1Hz TIME 帧, 偏移估计算出来)
    4. `MAZE RUN` —— 远程让电脑鼠开始跑无记忆走迷宫(或在此刻做别的动作)
    5. 实时监视: 速度/航向/任务码/发车以来毫秒
    6. 结束时停车 → `SCOPE DUMP` 整块回传 1kHz 数据 → 按**绝对设备时刻**报告

第 2 步之后, 每个采集到的样本都带 `dev_ms`(发车以来毫秒):
快帧用它自己带的 8 位时间戳精确还原, 1kHz dump 用包头里的 startMs 直接对齐。
于是"蓝牙链路抖了多少"不再污染数据的时间轴。

**LED 1Hz 基准灯**与 TIME 帧同拍, 供摄像头/光电/人眼做独立校核 ——
软件时间戳说第 N 秒到, 灯也应该正好翻转。

用法(在 host/ 目录下):
    python -m host.datalog COM7                      # 完整流程: 发车 -> 跑迷宫 -> 采集 -> 报告
    python -m host.datalog COM7 --arm-only           # 只发车(武装计时 + 点灯), 不动
    python -m host.datalog COM7 --status             # 只看时间同步状态
    python -m host.datalog COM7 --maze               # 只远程发车跑迷宫
    python -m host.datalog COM7 --seconds 20 --dump  # 采 20 秒后停车并回传 1kHz
    python -m host.datalog COM7 --no-maze --seconds 10   # 只采集, 不让它自己跑
    python -m host.datalog COM7 --json               # 结果以 JSON 输出

等价: `python -m host.cli datalog COM7 ...`
"""

from __future__ import annotations

import argparse
import csv
import json
import sys
import time
from typing import Any, Dict, List, Optional

from .motor_test import C, _LogProgress, _rule

# ---------------------------------------------------------------- 子流程


def cmd_status(mc, c: C, as_json: bool) -> int:
    st = mc.timesync.snapshot()
    if as_json:
        print(json.dumps(st.to_dict(), ensure_ascii=False, indent=2))
        return 0
    print(c("时间同步状态", "bold", "cyan") + " " + c(_rule(58), "dim"))
    print(mc.timesync.explain())
    return 0


def cmd_arm(mc, c: C, as_json: bool) -> int:
    r = mc.timesync.arm()
    if not r.ok:
        print(json.dumps({"ok": False, "status": r.status}, ensure_ascii=False) if as_json
              else c(f"ARM 失败: {r.status}", "red"))
        return 1
    # 等回执(ARMED <ms>)与几帧时间帧, 让偏移估计先收敛
    mc.timesync.wait_sync(samples=2, timeout=4.0)
    st = mc.timesync.snapshot()
    if as_json:
        print(json.dumps({"ok": True, "arm_up_ms": st.arm_up_ms}, ensure_ascii=False))
        return 0
    print(c("已发车(ARM): ", "bold") + c("OK", "green") +
          f"  设备时基 {st.arm_up_ms} ms")
    print(c("  1Hz 时间基准灯已点亮(LED4/PC7); 之后每秒上行一帧 TIME。", "dim"))
    return 0


def cmd_maze(mc, c: C, as_json: bool) -> int:
    r = mc.timesync.maze_run()
    if as_json:
        print(json.dumps({"ok": r.ok, "status": r.status}, ensure_ascii=False))
        return 0 if r.ok else 1
    if r.ok:
        print(c("远程发车(MAZE RUN): ", "bold") + c("OK", "green") +
              c("  电脑鼠开始跑无记忆走迷宫", "dim"))
    else:
        print(c("远程发车(MAZE RUN): ", "bold") + c(r.status, "red"))
        if r.status == "ERR_VALUE":
            print(c("  该固件不是数据收集档(MOUSE_DATA_LOG), 不会响应远程发车。", "dim"))
    return 0 if r.ok else 1


def cmd_run(mc, c: C, args) -> int:
    print(c("数据收集台", "bold", "cyan") + " " + c(_rule(64), "dim"))
    print(f"  设备 {mc.state_detail}   会话 {mc.session.path or '(未开启)'}")

    # ---- 1. 发车 ----
    if args.arm:
        if cmd_arm(mc, c, False) != 0:
            return 1
    else:
        print(c("  (跳过 ARM: 数据不带\"发车以来毫秒\")", "yellow"))

    st = mc.timesync.snapshot()
    if st.samples < 3:
        print(c("  ⚠ 时间同步样本还少, 偏移估计未收敛 —— 建议多等几秒再发车。", "yellow"))

    # ---- 2. 开始本地 1kHz 采集(零带宽, 停车后整块回传) ----
    if args.dump:
        mc.scope.start()
        print(c("  1kHz 本地采集已开启(运动期间不占带宽)", "dim"))

    # ---- 3. 远程发车跑迷宫 ----
    if args.maze:
        if cmd_maze(mc, c, False) != 0 and not args.force:
            return 1

    # ---- 4. 实时监视 ----
    # 注意: `mc.telemetry.live()` 是"定期打印摘要"的便捷方法, 拿不到逐帧的 ms8,
    # 所以这里自己按 hz 采样 —— 我们要的正是"每个样本的 dev_ms"。
    def _show(rec: Dict[str, Any]) -> None:
        dev = None
        if rec.get("ms8") is not None:
            try:
                dev = mc.timesync.frame_time_up(rec)
                if dev is not None and mc.timesync.arm_up_ms:
                    dev = dev - mc.timesync.arm_up_ms
            except Exception:
                dev = None
        dev_txt = f"{dev:7d}" if dev is not None else "    ..."
        print(
            f"  dev {dev_txt} ms  L {rec.get('speedL', 0):+7.1f}/"
            f"{rec.get('speedTargetL', 0):+6.1f}   "
            f"R {rec.get('speedR', 0):+7.1f}/{rec.get('speedTargetR', 0):+6.1f} cm/s   "
            f"θ {rec.get('gyroAngle', 0):+8.1f}°   task {rec.get('task', 0)}",
            flush=True,
        )

    print(c("  ── 实时流(dev_ms = 发车以来毫秒, 取自设备时基, 不受链路抖动影响)──", "bold"))
    t0 = time.time()
    seconds = float(args.seconds)
    period = 1.0 / max(0.5, float(args.hz))
    next_t = t0
    try:
        while time.time() - t0 < seconds:
            now = time.time()
            if now >= next_t:
                next_t = now + period
                f, _m, _s = mc.telemetry.latest()
                if f:
                    _show(f)
            time.sleep(0.005)
    except KeyboardInterrupt:
        print()
        print(c("  (提前停止采集)", "yellow"))
    wall = time.time() - t0

    # ---- 5. 停车 + 回传 ----
    print()
    print(c("  停车…", "dim"))
    mc.send_cmd("stop")
    time.sleep(0.4)

    stats = mc.stats()
    lost = int(stats.get("seq_lost", 0))
    gaps = int(stats.get("seq_gap", 0))

    out: Dict[str, Any] = {
        "wall_s": round(wall, 3),
        "seconds": seconds,
        "timesync": mc.timesync.snapshot().to_dict(),
        "link": {
            "fast": int(stats.get("fast", 0)),
            "mid": int(stats.get("mid", 0)),
            "slow": int(stats.get("slow", 0)),
            "time": int(stats.get("time", 0)),
            "bad_crc": int(stats.get("bad_crc", 0)),
            "seq_gap": gaps,
            "seq_lost": lost,
            "rx_bps": round(float(stats.get("rx_bps", 0.0)), 1),
        },
    }

    if args.dump:
        prog = _LogProgress(c, on=(not args.json) and sys.stdout.isatty())
        arr = mc.scope.fetch(timeout=args.log_timeout, on_progress=prog, stop_first=False)
        prog.done()
        if arr is not None:
            t = arr[0]
            hdr = mc.store.dump_hdr or {}
            out["dump"] = {
                "points": int(len(t)),
                "start_ms": int(float(t[0])),
                "end_ms": int(float(t[-1])),
                "startMs_hdr": int(hdr.get("startMs", 0) or 0),
            }
            if args.out:
                _write_dump_csv(arr, args.out)
                out["out"] = args.out

    # ---- 6. 报告 ----
    if args.json:
        print(json.dumps(out, ensure_ascii=False))
        return 0

    print()
    print(c("  ── 采集报告 ──", "bold"))
    ts = out["timesync"]
    print(f"  发车            " + (f"设备时基 {ts['arm_up_ms']} ms" if ts.get("armed")
                                    else c("未发车", "yellow")))
    if ts.get("offset_s") is not None:
        print(f"  时间偏移估计    {ts['offset_s']:.6f} s (min-delay)")
    if ts.get("drift_ppm") is not None:
        print(f"  设备时钟频差    {ts['drift_ppm']:+.2f} ppm")
    lk = out["link"]
    print(f"  收到帧          快{lk['fast']} 中{lk['mid']} 慢{lk['slow']} 时间{lk['time']} "
          f"(链路 {lk['rx_bps']} B/s)")
    lost_color = "green" if lost == 0 else ("yellow" if lost < 10 else "red")
    print(c(f"  丢帧            间隙 {gaps} 次 / 共丢 {lost} 帧", lost_color) +
          (c("   ← 序号连续, 无丢帧", "dim") if lost == 0 else
           c("   ← 有丢帧! 原始字节仍在 raw.bin 里, 可用新解析器重跑", "dim")))
    print(f"  坏 CRC          {lk['bad_crc']}")
    if "dump" in out:
        d = out["dump"]
        print(f"  1kHz 日志       {d['points']} 点, 绝对时刻 {d['start_ms']}→{d['end_ms']} ms")
        print(c("                  (时间轴已是绝对设备时刻, 可直接与发车时刻对齐)", "dim"))
    if out.get("out"):
        print(c(f"  已导出 1kHz 日志 -> {out['out']}", "dim"))
    return 0


def _write_dump_csv(arr, path: str) -> None:
    t, task, ang, sl, sr = arr
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["i", "t_dev_ms", "motionTask", "gangle", "speedl", "speedr"])
        for i in range(len(t)):
            w.writerow([i, int(t[i]), int(task[i]), int(ang[i]), int(sl[i]), int(sr[i])])


# ---------------------------------------------------------------- CLI

def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="host.datalog",
        description="电脑鼠 数据收集台(远程发车 + 时间同步 + 完整采集)",
    )
    p.add_argument("target", nargs="?", default=None,
                   help="串口(COM7) / tcp://host:port / 省略则自动选择")
    p.add_argument("--baud", type=int, default=115200)
    p.add_argument("--seconds", type=float, default=10.0, help="采集时长(秒), 默认 10")
    p.add_argument("--hz", type=float, default=5.0, help="实时流显示频率")
    p.add_argument("--no-maze", dest="maze", action="store_false", default=True,
                   help="不远程发车跑迷宫, 只采集")
    p.add_argument("--no-arm", dest="arm", action="store_false", default=True,
                   help="不发车(不点基准灯、数据不带 dev_ms)")
    p.add_argument("--no-dump", dest="dump", action="store_false", default=True,
                   help="不做 1kHz 日志回传")
    p.add_argument("--force", action="store_true",
                   help="MAZE RUN 被拒时也继续采集")
    p.add_argument("--log-timeout", type=float, default=300.0)
    p.add_argument("--out", help="把 1kHz 日志导出为 CSV")
    # 单步动作
    p.add_argument("--arm-only", action="store_true", help="只发车后退出")
    p.add_argument("--maze-only", dest="maze_only", action="store_true",
                   help="只远程发车跑迷宫后退出")
    p.add_argument("--status", action="store_true", help="只打印时间同步状态后退出")
    p.add_argument("--json", action="store_true", help="结果以 JSON 输出")
    p.add_argument("--no-color", action="store_true")
    return p


def main(argv: Optional[List[str]] = None) -> int:
    args = build_parser().parse_args(argv)
    color_on = (not args.no_color) and sys.stdout.isatty() and not args.json
    c = C(color_on)

    from .api import MouseClient, coerce_target

    target = coerce_target(args.target, baud=args.baud)
    mc = MouseClient(auto_session=True, auto_stream=True)
    if not mc.connect(target):
        msg = f"连接失败: {mc.state_detail or '未知原因'}"
        print(json.dumps({"ok": False, "error": msg}, ensure_ascii=False) if args.json
              else c(msg, "red"))
        mc.close()
        return 2
    try:
        if not mc.telemetry.wait_first_frame(timeout=5.0):
            print(c("未收到遥测首帧(设备可能默认静默或链路异常), 仍继续…", "yellow"))
        if args.status:
            return cmd_status(mc, c, args.json)
        if args.arm_only:
            return cmd_arm(mc, c, args.json)
        if args.maze_only:
            return cmd_maze(mc, c, args.json)
        return cmd_run(mc, c, args)
    except KeyboardInterrupt:
        print()
        print(c("收到 Ctrl+C —— 立即停车(固件侧另有护栏, 不会失控)", "yellow"))
        try:
            mc.send_cmd("stop")
        except Exception:
            pass
        return 130
    finally:
        try:
            if not args.json:
                st = mc.stats()
                print(c(f"  会话 {mc.session.path or '(未开启)'}", "dim"))
                print(c(f"  本次共收 快{int(st.get('fast', 0))} "
                        f"中{int(st.get('mid', 0))} 慢{int(st.get('slow', 0))} "
                        f"时间{int(st.get('time', 0))} 帧, 丢帧 {int(st.get('seq_lost', 0))}, "
                        f"链路 {float(st.get('rx_bps', 0)):.1f} B/s", "dim"))
        except Exception:
            pass
        mc.close()


if __name__ == "__main__":
    sys.exit(main())
