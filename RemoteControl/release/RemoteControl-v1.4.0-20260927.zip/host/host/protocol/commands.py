"""下行命令层: 构造文本命令、ACK 状态机、超时重发、幂等重放、参数回读。

可靠性四层(与方案文档 §5.7 对应):
  L1 命令行带 CRC16, 固件校验失败回 ERR_CRC
  L2 固件执行后回 `ACK <seq> <OK|ERR_xxx>`
  L3 超时未收 ACK 则重发(最多 MAX_ATTEMPTS 次)
  L4 写参数后由上层调用 readback() 做 GET 回读校验

幂等: 重发时**字节完全不变**(同 seq 同 CRC), 固件据此判定为重复并重放上次应答,
      不会重复执行副作用(重复写参数、重复触发标定动作)。
"""

from __future__ import annotations

import threading
import time
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional, Tuple

from .codec import crc16_modbus, float_to_q1616, q1616_to_float

# ---- 生产标定参数(与固件 HARDWARE/link.h 的 LINK_P_* 一致; **任何**固件都有) ----
PARAM_IDS_BASE: Dict[str, int] = {
    "TRACKL": 1,
    "TRACKR": 2,
    "SPEEDL": 3,
    "SPEEDR": 4,
    "GYRORATIO": 5,
    "ENCANGLE": 6,
    "WALLDIST": 7,
}

# ---- 课程调参量(仅 MOUSE_LESSON_LAB 固件有; 与固件 APP/lesson_lab.h 的 LL_P_* 一致) ----
# 刻意从 8 开始: 与生产参数的 1..7 不重叠, 两套命名空间互不干扰。
# 固件侧同样把它们存在**独立的 Flash 页(page100)**, 与生产标定页(99)分开。
LESSON_PARAM_IDS: Dict[str, int] = {
    # 电机速度环 PID(实验四/七)—— 固件里是运行时变量, 默认值 = motor.h 红线常量
    "KPL": 8,
    "KIL": 9,
    "KDL": 10,
    "KPR": 11,
    "KIR": 12,
    "KDR": 13,
    # 姿态纠偏增益(实验七)
    "IRPL": 14,
    "IRPR": 15,
    "GYROP": 16,
    "GYROD": 17,
    # 实验目标(实验三/六/七)
    "SPEEDNEED": 18,
    "ALLDIS": 19,
    # 传感器方案与贴墙方向(实验七)
    "SENSORMODE": 20,
    "WALLMODE": 21,
}

#: 名字 <-> id 的唯一来源(生产 + 课程)。解码 `P <id> <q>` 上行行、写参数校验都走它。
PARAM_IDS: Dict[str, int] = {**PARAM_IDS_BASE, **LESSON_PARAM_IDS}
PARAM_NAMES: Dict[int, str] = {v: k for k, v in PARAM_IDS.items()}

#: 分组标签, 仅供 CLI / 文档分节显示
PARAM_GROUPS: Dict[str, str] = {
    **{n: "生产标定" for n in PARAM_IDS_BASE},
    **{n: "课程调参" for n in LESSON_PARAM_IDS},
}

# (单位, 小数位, 说明)
PARAM_META: Dict[str, Tuple[str, int, str]] = {
    "TRACKL": ("pulse/mm", 4, "左轮里程系数; 走一格判据的直接因子, 最值得标定"),
    "TRACKR": ("pulse/mm", 4, "右轮里程系数"),
    "SPEEDL": ("(pulse/ms)/(cm/s)", 6, "左轮速度换算; 恒 = TRACKL/100, 由上位机派生"),
    "SPEEDR": ("(pulse/ms)/(cm/s)", 6, "右轮速度换算; 恒 = TRACKR/100, 由上位机派生"),
    "GYRORATIO": ("LSB/度", 0, "陀螺角速率积分系数"),
    "ENCANGLE": ("pulse/度", 0, "左右轮脉冲差 -> 角度; 固件为 u16, 取整"),
    "WALLDIST": ("mm", 0, "车中心到墙距离; 固件为 u8, 取整"),
    # ---- 课程调参量 ----
    "KPL": ("PWM/(pulse/ms)", 3, "左轮速度环 Kp; 默认 = 红线值 10.75"),
    "KIL": ("PWM/(pulse/ms)", 3, "左轮速度环 Ki; 默认 0.55"),
    "KDL": ("PWM/(pulse/ms)", 3, "左轮速度环 Kd; 默认 0.55"),
    "KPR": ("PWM/(pulse/ms)", 3, "右轮速度环 Kp; 默认 = 红线值 10.20"),
    "KIR": ("PWM/(pulse/ms)", 3, "右轮速度环 Ki; 默认 0.5"),
    "KDR": ("PWM/(pulse/ms)", 3, "右轮速度环 Kd; 默认 0.5"),
    "IRPL": ("(cm/s)/mm", 4, "红外纠偏 左轮 P; 默认 0.1"),
    "IRPR": ("(cm/s)/mm", 4, "红外纠偏 右轮 P; 默认 0.1"),
    "GYROP": ("(cm/s)/度", 3, "陀螺纠偏 P; 默认 2.5"),
    "GYROD": ("(cm/s)/度", 3, "陀螺纠偏 D; 默认 1.6"),
    "SPEEDNEED": ("cm/s", 0, "实验目标速度; 默认 50"),
    "ALLDIS": ("mm", 0, "实验目标距离; 默认 1000"),
    "SENSORMODE": ("0-3", 0, "传感器方案 0=全关 1=仅红外 2=仅陀螺 3=红外+陀螺"),
    "WALLMODE": ("1|2", 0, "贴墙方向 1=靠左 2=靠右"),
}

# 标定项名 -> 固件 CAL 子命令名
CAL_ITEMS = ["GYRO", "WALLDIST", "IRDATA", "GYRORATIO", "ENCANGLE"]


class CommandError(Exception):
    pass


@dataclass
class Pending:
    seq: int
    line: bytes
    cmd: str
    attempts: int = 0
    sent_at: float = 0.0
    done: bool = False
    ok: bool = False
    status: str = ""
    callbacks: List[Callable[[bool, str], None]] = field(default_factory=list)


class CommandClient:
    """命令客户端。线程安全: 发送可能在 UI 线程, 收行在读取线程。"""

    TIMEOUT_S = 0.20
    MAX_ATTEMPTS = 5

    def __init__(self, send_bytes: Callable[[bytes], None]) -> None:
        self._send = send_bytes
        self._lock = threading.RLock()
        self._seq = 0
        self._pending: Dict[int, Pending] = {}
        self.params: Dict[int, int] = {}  # id -> Q16.16
        self.params_dirty = True
        self.device: Dict[str, object] = {}
        self.log: List[Tuple[float, str, str]] = []  # (ts, dir, text) dir in {"->", "<-"}
        self.stats = {"sent": 0, "retries": 0, "timeouts": 0, "err": 0, "ok": 0}
        self.events: List[Tuple[float, str, str]] = []  # 非 ACK 的异步消息
        self.on_async: Optional[Callable[[str], None]] = None
        self._log_limit = 2000

    # ------------------------------------------------------------ 发送

    def _next_seq(self) -> int:
        self._seq = (self._seq + 1) & 0xFFFF
        return self._seq

    def _build(self, cmd: str, seq: int) -> bytes:
        body = f"{cmd} #{seq}".encode("ascii")
        return body + f"*{crc16_modbus(body):04X}".encode("ascii") + b"\r\n"

    def send(self, cmd: str, wait: bool = False, timeout: float = 3.0) -> Pending:
        """发一条命令。wait=True 时阻塞等待应答(仅用于批处理, 不要在 UI 线程用)。"""
        seq = self._next_seq()
        line = self._build(cmd, seq)
        p = Pending(seq=seq, line=line, cmd=cmd)
        with self._lock:
            self._pending[seq] = p
            self._append_log("->", cmd)
        self._send(line)
        p.attempts = 1
        p.sent_at = time.time()
        with self._lock:
            self.stats["sent"] += 1
        if wait:
            deadline = time.time() + timeout
            while time.time() < deadline:
                if p.done:
                    break
                time.sleep(0.01)
            if not p.done:
                raise CommandError(f"timeout waiting for: {cmd}")
            if not p.ok:
                raise CommandError(f"device rejected: {cmd} -> {p.status}")
        return p

    def send_many(self, cmds: List[str], stop_on_error: bool = True) -> List[Pending]:
        out = []
        for c in cmds:
            p = self.send(c, wait=True)
            out.append(p)
            if stop_on_error and not p.ok:
                break
        return out

    # ------------------------------------------------------------ 重发/超时

    def poll(self) -> None:
        """由定时器周期调用(建议 20ms): 处理超时与重发。"""
        now = time.time()
        expired: List[Pending] = []
        with self._lock:
            for p in list(self._pending.values()):
                if p.done:
                    continue
                if now - p.sent_at < self.TIMEOUT_S:
                    continue
                if p.attempts >= self.MAX_ATTEMPTS:
                    p.done = True
                    p.ok = False
                    p.status = "TIMEOUT"
                    self.stats["timeouts"] += 1
                    expired.append(p)
                    continue
                p.attempts += 1
                p.sent_at = now
                self.stats["retries"] += 1
                self._append_log("->", p.cmd + f"  (重发 #{p.attempts})")
                self._send(p.line)  # 字节完全不变 -> 固件幂等重放
        for p in expired:
            self._finish(p)

    # ------------------------------------------------------------ 接收

    def feed_line(self, line: str) -> None:
        """在读取线程中调用, 处理一行文本(应答或异步消息)。"""
        with self._lock:
            self._append_log("<-", line)
        if line.startswith("ACK "):
            parts = line.split(None, 2)
            if len(parts) >= 3:
                try:
                    seq = int(parts[1])
                except ValueError:
                    return
                status = parts[2].strip()
                with self._lock:
                    p = self._pending.get(seq)
                    if p is None or p.done:
                        return
                    p.done = True
                    p.ok = status == "OK"
                    p.status = status
                    if p.ok:
                        self.stats["ok"] += 1
                    else:
                        self.stats["err"] += 1
                self._finish(p)
            return
        self._handle_async(line)

    def _finish(self, p: Pending) -> None:
        with self._lock:
            self._pending.pop(p.seq, None)
            cbs = list(p.callbacks)
        for cb in cbs:
            try:
                cb(p.ok, p.status)
            except Exception:
                pass

    def _handle_async(self, line: str) -> None:
        with self._lock:
            if line.startswith("PONG "):
                bits = line.split()[1:]
                if len(bits) >= 3:
                    self.device["proto"] = int(bits[0])
                    self.device["fw"] = int(bits[1])
                    self.device["mazetype"] = int(bits[2])
            elif line.startswith("VER "):
                for tok in line.split()[1:]:
                    if "=" in tok:
                        k, v = tok.split("=", 1)
                        try:
                            self.device[k] = int(v)
                        except ValueError:
                            self.device[k] = v
            elif line.startswith("P "):
                parts = line.split()
                if len(parts) == 3:
                    try:
                        self.params[int(parts[1])] = int(parts[2])
                        self.params_dirty = True
                    except ValueError:
                        pass
            self.events.append((time.time(), "async", line))
        if self.on_async is not None:
            try:
                self.on_async(line)
            except Exception:
                pass

    def drain_events(self) -> List[str]:
        """取走并清空异步消息的文本部分。由 UI 定时器在**主线程**调用,
        这样标定向导等界面组件无需处理跨线程回调。"""
        with self._lock:
            out = [t for _ts, _k, t in self.events]
            self.events = []
        return out

    # ------------------------------------------------------------ 日志

    def _append_log(self, direction: str, text: str) -> None:
        self.log.append((time.time(), direction, text))
        if len(self.log) > self._log_limit:
            del self.log[: self._log_limit // 2]

    # ------------------------------------------------------------ 便捷命令

    def ping(self) -> Pending:
        return self.send("PING", wait=True)

    def get_all(self) -> Pending:
        return self.send("GET ALL", wait=True)

    def readback(self, name: str) -> Optional[int]:
        """回读单个参数(Q16.16), 超时返回 None。"""
        p = self.send(f"GET {name}", wait=True)
        if not p.ok:
            return None
        return self.params.get(PARAM_IDS[name])

    def set_param(self, name: str, value: float, readback: bool = True) -> Tuple[bool, str]:
        """写参数: 用 SETQ 下发精确 Q16.16, 并默认做回读校验(L4)。"""
        if name not in PARAM_IDS:
            return False, "ERR_NAME"
        q = float_to_q1616(value)
        p = self.send(f"SETQ {name} {q}", wait=True)
        if not p.ok:
            return False, p.status
        if readback:
            rb = self.readback(name)
            if rb is None:
                return False, "READBACK_TIMEOUT"
            if rb != q:
                return False, f"READBACK_MISMATCH(got {rb}, want {q})"
        return True, "OK"

    def save(self) -> Tuple[bool, str]:
        p = self.send("SAVE", wait=True)
        return p.ok, p.status

    def reset(self) -> Tuple[bool, str]:
        p = self.send("RESET", wait=True)
        return p.ok, p.status

    def set_rate(self, hz: int) -> Tuple[bool, str]:
        p = self.send(f"RATE {hz}", wait=True)
        return p.ok, p.status

    def scope(self, act: str) -> Tuple[bool, str]:
        p = self.send(f"SCOPE {act}", wait=True)
        return p.ok, p.status

    def map_dump(self) -> Tuple[bool, str]:
        p = self.send("MAP DUMP", wait=True)
        return p.ok, p.status

    def move_fwd(self, pulses: int, speed: int = 0) -> Tuple[bool, str]:
        cmd = f"MOVE FWD {int(pulses)}" + (f" {int(speed)}" if speed else "")
        p = self.send(cmd, wait=True)
        return p.ok, p.status

    def move_rot(self, pwm: int, ms: int = 0) -> Tuple[bool, str]:
        cmd = f"MOVE ROT {int(pwm)}" + (f" {int(ms)}" if ms else "")
        p = self.send(cmd, wait=True)
        return p.ok, p.status

    def stop(self) -> Tuple[bool, str]:
        p = self.send("STOP", wait=True)
        return p.ok, p.status

    def estop(self) -> Tuple[bool, str]:
        p = self.send("ESTOP", wait=True)
        return p.ok, p.status

    def tare(self) -> Tuple[bool, str]:
        p = self.send("TARE", wait=True)
        return p.ok, p.status

    def cal(self, item: str, act: str) -> Tuple[bool, str]:
        """标定控制。act ∈ {START, SAMPLE, ABORT}"""
        p = self.send(f"CAL {item} {act}", wait=True)
        return p.ok, p.status


def q1616_to_display(q: int, name: str) -> str:
    """按参数元数据格式化显示值。"""
    decimals = PARAM_META.get(name, ("", 4, ""))[1]
    return f"{q1616_to_float(q):.{decimals}f}"
