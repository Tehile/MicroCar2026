"""电脑鼠上位机『实时数据监视器』—— 终端里的实时仪表盘。

阶段用途(数据回传 / 标定):
    固件此时运行在安全测试模式(`MOUSE_TEST_NO_MOTOR`, 见 code_stm32f1_mouse/USER/main.h),
    电机被物理禁用、板子不会启动; 上位机这一侧要做的就是**把它检测到的数据实时显示出来**。
    本工具就是干这个的: 连上设备 -> 实时刷新三路遥测 -> Ctrl+C 退出。

用法(在 host/ 目录下):
    python -m host.monitor                        # 自动挑串口; 没有串口则连模拟器 TCP
    python -m host.monitor COM7 --baud 115200     # 指定串口
    python -m host.monitor tcp://127.0.0.1:5555   # 连模拟器
    python -m host.monitor replay://sessions/2026-09-27_0151   # 回放历史会话
    python -m host.monitor COM7 --record          # 同时把会话落盘
    python -m host.monitor COM7 --json --seconds 10   # 每行一条 JSON(给脚本/管道)

显示内容:
    链路   实测吞吐 / 快中慢帧率 / 丢帧 / 连接状态 / 安全模式标志
    运动   左右轮实测速度与目标、航向角、pid 误差
    传感器 红外前2 + 左右、墙位、迷宫坐标、当前任务
    系统   电池电压、CPU 占用、状态位(电机禁用/自由模式/急停/休眠)

只依赖 `host` 包, **不需要 PySide6** —— Python 3.8+、SSH/无显示器环境都能跑,
也便于被自动化测试直接调用。
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from typing import Any, Dict, List, Optional, Tuple

from .protocol.codec import MOTION_TASK_NAMES, TASK_NAMES

# ---------------------------------------------------------------- 终端着色

_CLR = {
    "reset": "\x1b[0m",
    "dim": "\x1b[2m",
    "bold": "\x1b[1m",
    "red": "\x1b[31m",
    "green": "\x1b[32m",
    "yellow": "\x1b[33m",
    "blue": "\x1b[34m",
    "magenta": "\x1b[35m",
    "cyan": "\x1b[36m",
}


class C:
    """着色开关(被 --no-color / 非 tty 关闭后所有方法退化为原字符串)。"""

    def __init__(self, enabled: bool = True) -> None:
        self.enabled = enabled

    def __call__(self, text: str, *styles: str) -> str:
        if not self.enabled or not styles:
            return text
        pre = "".join(_CLR.get(s, "") for s in styles)
        return f"{pre}{text}{_CLR['reset']}"


def _bar(value: float, lo: float, hi: float, width: int = 10, fill: str = "█",
         empty: str = "░") -> str:
    """把数值画成定宽进度条(负值按 lo 处理)。"""
    if hi <= lo:
        return empty * width
    frac = (max(lo, min(hi, float(value))) - lo) / (hi - lo)
    n = int(round(frac * width))
    return fill * n + empty * (width - n)


def _hms(seconds: float) -> str:
    s = int(max(0.0, seconds))
    return f"{s // 3600:02d}:{(s // 60) % 60:02d}:{s % 60:02d}"


# ---------------------------------------------------------------- 状态位

def _state_bits(f: Dict[str, Any], c: C, expect_safe: bool = False) -> List[str]:
    """把快帧里的状态位翻成中文短语(带颜色)。"""
    out: List[str] = []
    if not f:
        return out
    if f.get("motors_off"):
        out.append(c("电机已禁用(安全模式)", "green", "bold"))
    elif expect_safe:
        out.append(c("⚠ 未检测到电机禁用标志!", "red", "bold"))
    if f.get("estop_lock"):
        out.append(c("急停锁存(需 STOP 解锁)", "red", "bold"))
    elif f.get("emerg"):
        out.append(c("急停", "red", "bold"))
    if f.get("runlog"):
        out.append(c("运动日志已就绪(可回传)", "cyan", "bold"))
    if f.get("sleep"):
        out.append(c("休眠", "yellow"))
    if f.get("freemode"):
        out.append(c("自由模式", "yellow"))
    if f.get("scoping"):
        out.append(c("采集中", "cyan"))
    if f.get("dumping"):
        out.append(c("回传中", "magenta"))
    return out


# ---------------------------------------------------------------- 渲染

def render(
    fast: Dict[str, Any],
    mid: Dict[str, Any],
    slow: Dict[str, Any],
    stats: Dict[str, Any],
    fps: Dict[str, float],
    target_label: str,
    device: Dict[str, Any],
    elapsed: float,
    c: C,
    width: int = 78,
    expect_safe: bool = False,
    error: str = "",
) -> str:
    """把当前快照渲染成一段多行文本(不含清屏/光标控制)。"""
    line = "─" * width
    ts = time.strftime("%H:%M:%S")
    out: List[str] = []
    add = out.append

    # ── 标题
    add(c("电脑鼠实时数据", "bold", "cyan") + " " + c(line, "dim"))
    add(f"  目标 {c(target_label, 'bold')}   设备 proto={device.get('proto', '?')} "
        f"fw={device.get('fw', '?')} maze={device.get('mazetype', '?')}"
        f"   {c(ts, 'dim')} 已运行 {_hms(elapsed)}")

    # ── 链路
    bps = float(stats.get("rx_bps", 0.0))
    st = c("已连接", "green") if stats.get("_open", True) else c("未连接", "red")
    drop = int(stats.get("bad_crc", 0)) + int(stats.get("bad_sync", 0))
    add(f"  链路 {_bar(bps, 0, 160, 12)} {bps:6.1f} B/s   "
        f"快{fps.get('fast', 0):4.1f}/s 中{fps.get('mid', 0):4.1f}/s 慢{fps.get('slow', 0):4.1f}/s   "
        f"丢帧 {drop}   状态 {st}")
    bits = _state_bits(fast, c, expect_safe=expect_safe)
    if bits:
        add("  状态 " + " / ".join(bits))
    if error:
        add("  " + c("链路错误: " + error, "red"))

    # ── 运动
    if fast:
        sl, sr = float(fast.get("speedL", 0)), float(fast.get("speedR", 0))
        tl, tr = float(fast.get("speedTargetL", 0)), float(fast.get("speedTargetR", 0))
        add("")
        add(c("  运动", "bold"))
        add(f"    左轮 {sl:+7.1f} cm/s (目标 {tl:+6.1f})   "
            f"右轮 {sr:+7.1f} cm/s (目标 {tr:+6.1f})")
        add(f"    航向 {float(fast.get('gyroAngle', 0)):+8.1f} °            "
            f"pid误差 {float(fast.get('pidErr', 0)):+7.1f}   "
            f"任务 {MOTION_TASK_NAMES.get(int(fast.get('task', 0)), str(fast.get('task', '?')))}")
    else:
        add("")
        add(c("  运动  —— 尚未收到快帧", "dim"))

    # ── 传感器
    if slow:
        f1, f2 = int(slow.get("irF1", 0)), int(slow.get("irF2", 0))
        l, r = int(slow.get("irL", 0)), int(slow.get("irR", 0))
        wall = int(slow.get("wallBits", 0))
        names = [("左", 0x01), ("右", 0x02), ("前", 0x04), ("左45", 0x08), ("右45", 0x10)]
        walls = " ".join(f"{n}{c('●', 'red') if wall & b else '○'}" for n, b in names)
        add("")
        add(c("  传感器", "bold"))
        add(f"    前 f1 {f1:4d} {_bar(f1, 0, 255, 8)}   f2 {f2:4d} {_bar(f2, 0, 255, 8)}  mm")
        add(f"    左 {l:4d} {_bar(l, 0, 255, 8)}     右 {r:4d} {_bar(r, 0, 255, 8)}  mm")
        add(f"    墙位 {walls}      坐标 ({int(slow.get('posX', 0))},{int(slow.get('posY', 0))})"
            f"   {slow.get('mouseTaskName', '')}")
    elif mid:
        add("")
        add(c("  传感器  —— 尚未收到慢帧(红外/墙位), 先看里程:", "dim"))
        add(f"    编码角 {float(mid.get('encAngle', 0)):+.1f}   陀螺原始 {int(mid.get('gyroRaw', 0))}"
            f"   差分 {int(mid.get('gyroDiff', 0))}   里程 L{int(mid.get('trackL', 0))}"
            f" R{int(mid.get('trackR', 0))}")
    else:
        add("")
        add(c("  传感器  —— 尚未收到中/慢帧", "dim"))

    # ── 系统
    volt = float(slow.get("volt", fast.get("volt", 0.0)) if slow else fast.get("volt", 0.0))
    cpu = int(slow.get("cpu", 0)) if slow else 0
    vcolor = "red" if volt < 6.5 else ("yellow" if volt < 7.0 else "green")
    add("")
    add(f"  系统   电压 {c(f'{volt:5.2f} V', vcolor)}   CPU {cpu:3d} %   "
        f"{_bar(cpu, 0, 100, 8)}   中帧 {int(stats.get('mid', 0))}  慢帧 {int(stats.get('slow', 0))}")
    add(c(line, "dim"))
    return "\n".join(out)


# ---------------------------------------------------------------- fps 统计

class _FpsMeter:
    """由累计帧计数推算每秒帧数(1s 平滑窗口)。"""

    def __init__(self) -> None:
        self._t0 = time.time()
        self._prev: Dict[str, int] = {}
        self._val: Dict[str, float] = {"fast": 0.0, "mid": 0.0, "slow": 0.0}

    def update(self, stats: Dict[str, Any]) -> Dict[str, float]:
        now = time.time()
        dt = now - self._t0
        if dt < 0.5:
            return self._val
        for k in ("fast", "mid", "slow"):
            cur = int(stats.get(k, 0))
            self._val[k] = (cur - self._prev[k]) / dt if k in self._prev else 0.0
            self._prev[k] = cur
        self._t0 = now
        return self._val


# ---------------------------------------------------------------- 主流程

def _snapshot(mc) -> Tuple[Dict[str, Any], Dict[str, Any], Dict[str, Any], Dict[str, Any], Dict[str, Any]]:
    f, m, s = mc.telemetry.latest()
    st = mc.stats()
    st["_open"] = mc.is_connected
    dev = mc.device if mc.is_connected else {}
    return f, m, s, st, dev


def run_monitor(args) -> int:
    from .api import MouseClient, coerce_target

    target = coerce_target(args.target, baud=args.baud)
    label = target.label()

    color_on = (not args.no_color) and sys.stdout.isatty()
    c = C(color_on)

    mc = MouseClient(auto_session=args.record, auto_stream=not args.no_stream)
    if not mc.connect(target):
        print(c(f"连接失败: {mc.state_detail or '未知原因'}", "red"))
        mc.close()
        return 2

    print(c(f"已连接 {label}", "green", "bold"))
    if mc.auto_stream:
        print(c("已发送 STREAM ON; 等待遥测首帧…", "dim"))
    if not mc.telemetry.wait_first_frame(timeout=args.timeout):
        print(c("仍未收到遥测帧。可能原因: 设备默认静默(STREAM ON 未生效)、"
                "波特率不符、或蓝牙链路被灌满。", "yellow"))

    fps = _FpsMeter()
    t0 = time.time()

    def _one_frame() -> str:
        f, m, s, st, dev = _snapshot(mc)
        return render(
            f, m, s, st, fps.update(st), label, dev, time.time() - t0, c,
            width=args.width, expect_safe=args.expect_safe,
            error=(mc.state_detail or "") if mc.state == "error" else "",
        )

    try:
        while True:
            if args.json:
                f, m, s, st, _dev = _snapshot(mc)
                print(json.dumps(
                    {"t": round(time.time(), 3), "target": label, "fast": f, "mid": m,
                     "slow": s, "rx_bps": round(float(st.get("rx_bps", 0.0)), 1),
                     "counts": {k: st.get(k) for k in ("fast", "mid", "slow", "bad_crc")}},
                    ensure_ascii=False), flush=True)
            else:
                text = _one_frame()
                if color_on and not args.no_clear:
                    sys.stdout.write("\x1b[2J\x1b[H")
                print(text, flush=True)
            if args.once:
                break
            if args.seconds and (time.time() - t0) >= args.seconds:
                break
            time.sleep(max(0.02, 1.0 / max(0.5, args.hz)))
    except KeyboardInterrupt:
        print()
    finally:
        st = mc.stats()
        if not args.json:
            print(c(f"共收到 快{int(st.get('fast', 0))} 中{int(st.get('mid', 0))} "
                    f"慢{int(st.get('slow', 0))} 帧, 平均 {float(st.get('rx_bps', 0)):.1f} B/s", "dim"))
        if args.record and mc.session_obj is not None:
            print(c(f"会话已落盘: {mc.session_obj.path}", "dim"))
        mc.close()
    return 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="host.monitor",
        description="电脑鼠上位机实时数据监视器(终端仪表盘, 无需 PySide6)",
    )
    p.add_argument("target", nargs="?", default=None,
                   help="串口(COM7) / tcp://host:port / replay://会话目录; 省略则自动选择")
    p.add_argument("--baud", type=int, default=115200)
    p.add_argument("--hz", type=float, default=5.0, help="刷新率(默认 5, 与遥测快帧同频)")
    p.add_argument("--width", type=int, default=78, help="面板宽度(字符)")
    p.add_argument("--seconds", type=float, default=0.0, help="持续多少秒后自动退出(0=一直跑)")
    p.add_argument("--once", action="store_true", help="只打印一次当前快照后退出(脚本用)")
    p.add_argument("--json", action="store_true", help="每行输出一条 JSON, 不画面板")
    p.add_argument("--no-color", action="store_true", help="关闭 ANSI 颜色")
    p.add_argument("--no-clear", action="store_true", help="不清屏, 追加打印(便于留日志)")
    p.add_argument("--no-stream", action="store_true", help="不自动发 STREAM ON(设备需已在发数据)")
    p.add_argument("--record", action="store_true", help="同时开启会话落盘(sessions/)")
    p.add_argument("--timeout", type=float, default=5.0, help="等待首帧的秒数")
    p.add_argument("--expect-safe", action="store_true",
                   help="期望设备处于安全测试模式(电机禁用); 缺失该标志时高亮告警")
    return p


def main(argv: Optional[List[str]] = None) -> int:
    return run_monitor(build_parser().parse_args(argv))


if __name__ == "__main__":
    sys.exit(main())
