"""长期稳定性测试: 找出能【持续】不饱和的遥测速率。

背景: 之前发现短时(3s)能过到 1508 B/s, 但持续发送时 511 B/s 也会饱和
      —— 说明该链路的"可持续吞吐"低于"短时突发吞吐"。
      判别方法: 持续读 30 秒, 把时间切成小段统计, 看是否中途归零。

流程: 复位(让模块缓冲清空) -> 等 1s -> 改 linkFastDiv -> 持续读 -> 分段统计
"""

from __future__ import annotations

import os
import subprocess
import tempfile
import time

import serial

JL = r"C:\Program Files\SEGGER\JLink_V976a\JLink.exe"
PORT = "COM7"
FASTDIV_ADDR = 0x20000836


def jl(lines) -> str:
    script = "si SWD\nspeed 4000\ndevice STM32F103RB\nconnect\n" + "\n".join(lines) + "\nq\n"
    fd, path = tempfile.mkstemp(suffix=".jlink", text=True)
    os.close(fd)
    with open(path, "w", encoding="ascii") as f:
        f.write(script)
    try:
        p = subprocess.run([JL, "-CommanderScript", path, "-ExitOnError", "1"],
                           capture_output=True, text=True, timeout=120,
                           encoding="utf-8", errors="replace")
    finally:
        try:
            os.unlink(path)
        except OSError:
            pass
    return p.stdout or ""


def run_case(div: int, fast_hz: float, sec: float = 30.0) -> None:
    # 估算总字节率: 快帧(div) 20B + 中帧 5Hz*18B + 慢帧 1Hz*21B
    bps = fast_hz * 20 + 5 * 18 + 1 * 21
    print(f"\n--- linkFastDiv={div} (快帧约 {fast_hz:.0f}Hz, 合计约 {bps:.0f} B/s) ---")

    # 复位让模块缓冲清空, 再设分频
    jl(["r", "go"])
    time.sleep(1.2)
    jl([f"w1 0x{FASTDIV_ADDR:08X}, 0x{div:02X}",
        f"mem8 0x{FASTDIV_ADDR:08X}, 1"])
    time.sleep(0.5)

    try:
        s = serial.Serial(PORT, 115200, bytesize=8, parity="N", stopbits=1, timeout=0.15)
    except Exception as e:
        print(f"    打开失败: {e}")
        return
    try:
        buckets = []
        b0 = time.time()
        n = 0
        while time.time() - b0 < sec:
            d = s.read(4096)
            if d:
                n += len(d)
            if time.time() - b0 >= (len(buckets) + 1) * 5.0:
                buckets.append(n)
        buckets.append(n)
    finally:
        s.close()

    prev = 0
    parts = []
    for i, tot in enumerate(buckets):
        seg = tot - prev
        prev = tot
        parts.append(f"{seg:5d}")
    print(f"    每 5 秒收到的字节: {' | '.join(parts)}")
    print(f"    总计 {buckets[-1]} 字节, 平均 {buckets[-1] / sec:.0f} B/s")
    # 判据: 后半段是否仍在持续收
    if len(buckets) >= 4:
        half = buckets[len(buckets) // 2]
        if buckets[-1] > half and (buckets[-1] - half) > 0.2 * thresholds_scale(bps):
            print("    => 持续通过")
        else:
            print("    => ★ 后半段基本停滞(已饱和)")


def thresholds_scale(bps: float) -> float:
    return max(bps * 5.0, 100.0)


def main() -> int:
    print("=" * 78)
    print("长期稳定性测试 (每档复位清缓冲 -> 跑 30 秒分段统计)")
    print("=" * 78)
    for div, hz in [(50, 20), (100, 10), (200, 5), (400, 2.5), (1000, 1)]:
        run_case(div, hz)
    jl(["r", "go"])
    print("\n已复位恢复默认")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
