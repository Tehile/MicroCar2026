"""实时监视器冒烟测试 —— 证明"计算机侧实时显示数据"这条链真的通。

为什么要单独一个文件: `host/monitor.py` 是标定/回传阶段的**主用出口**,
而它的正确性没法靠"人能看见"保证(没人天天手动跑)。这里用模拟器把它变成可断言的:

    M1 --once --json  : 单帧快照能被机器读到, 且字段齐全、安全标志正确
    M2 面板文本        : 关键分区(链路/运动/传感器/系统)与"电机已禁用"都在
    M3 --expect-safe  : 设备**没有**置禁用位时必须告警(否则这个检查是安慰剂)
    M4 回放目标        : 同一套代码能跑 replay:// 会话(三种目标同码)

用法(在 host/ 目录下):
    python monitor_smoke.py
"""

from __future__ import annotations

import contextlib
import io
import json
import socket
import subprocess
import sys
import time
from typing import List

PASS = 0
FAIL = 0
FAILED: List[str] = []


def check(name: str, cond: bool, detail: str = "") -> None:
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"  [OK] {name}")
    else:
        FAIL += 1
        FAILED.append(name)
        print(f"  [FAIL] {name}" + (f"  <- {detail}" if detail else ""))


def _free_port() -> int:
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    p = s.getsockname()[1]
    s.close()
    return p


class _Sim:
    """上下文管理器: 拉起模拟器并在退出时收掉。"""

    def __init__(self, *extra: str) -> None:
        self.port = _free_port()
        self.cmd = [sys.executable, "-m", "host.sim.mouse_sim",
                    "--port", str(self.port), "--no-auto", *extra]
        self.proc: subprocess.Popen | None = None

    @property
    def target(self) -> str:
        return f"tcp://127.0.0.1:{self.port}"

    def __enter__(self) -> "_Sim":
        self.proc = subprocess.Popen(self.cmd, stdout=subprocess.DEVNULL,
                                     stderr=subprocess.DEVNULL)
        time.sleep(1.2)
        return self

    def __exit__(self, *exc) -> None:
        if self.proc is not None:
            self.proc.terminate()
            try:
                self.proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self.proc.kill()


def _run_monitor(argv: List[str]) -> str:
    """跑一次监视器并捕获 stdout(监视器直接 print, 不返回字符串)。"""
    from host import monitor

    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        rc = monitor.main(argv)
    assert rc == 0, f"monitor 退出码 {rc}"
    return buf.getvalue()


def main() -> int:
    from host.monitor import C, render

    print("=" * 66)
    print("实时监视器冒烟测试")
    print("=" * 66)

    # ---------------------------------------------------------------- 纯函数部分
    print("\n[0] 渲染函数(不连设备)")
    fake_fast = {"speedL": 12, "speedR": -3, "gyroAngle": 45, "pidErr": 1,
                 "speedTargetL": 12, "speedTargetR": 12, "task": 32, "volt": 7.4,
                 "motors_off": True, "freemode": True, "sleep": False,
                 "emerg": False, "scoping": False, "dumping": False}
    fake_slow = {"irF1": 180, "irF2": 179, "irL": 40, "irR": 236, "wallBits": 5,
                 "posX": 0, "posY": 0, "volt": 7.42, "cpu": 12, "mouseTaskName": "MAZESEARCH"}
    fake_stats = {"fast": 10, "mid": 2, "slow": 1, "rx_bps": 150.0, "bad_crc": 0, "_open": True}
    txt = render(fake_fast, {}, fake_slow, fake_stats, {"fast": 5.0, "mid": 1.0, "slow": 0.5},
                 "TEST", {"proto": 1, "fw": 100, "mazetype": 7}, 1.0, C(False), expect_safe=True)
    check("渲染含四个分区", all(k in txt for k in ("链路", "运动", "传感器", "系统")), txt[:120])
    check("安全标志被翻译成中文", "电机已禁用" in txt)
    check("红外/墙位/坐标都在", "f1" in txt and "墙位" in txt and "(0,0)" in txt)
    check("无 ANSI 转义(非 tty)", "\x1b[" not in txt)
    txt2 = render(fake_fast, {}, fake_slow, fake_stats, {"fast": 5, "mid": 1, "slow": 0.5},
                  "TEST", {}, 1.0, C(False), expect_safe=False)
    check("不带 --expect-safe 时不告警", "未检测到" not in txt2)

    # 电机实验模式的两个新状态位: 急停锁存 / 运动日志就绪
    fake_lab = dict(fake_fast, motors_off=False, freemode=False,
                    estop_lock=True, runlog=True, emerg=True)
    txt3 = render(fake_lab, {}, fake_slow, fake_stats, {"fast": 5, "mid": 1, "slow": 0.5},
                  "TEST", {}, 1.0, C(False))
    check("急停锁存被显示出来", "急停锁存" in txt3, txt3.splitlines()[3:6])
    check("锁存优先于普通急停(不重复显示)", txt3.count("急停") == 1, txt3)
    check("运动日志就绪被显示出来", "运动日志已就绪" in txt3)
    fake_lab2 = dict(fake_fast, motors_off=False, freemode=True, estop_lock=False,
                     runlog=False, emerg=False)
    txt4 = render(fake_lab2, {}, fake_slow, fake_stats, {"fast": 5, "mid": 1, "slow": 0.5},
                  "TEST", {}, 1.0, C(False))
    check("非实验固件不显示这两个位", "急停锁存" not in txt4 and "运动日志" not in txt4, txt4)

    # ---------------------------------------------------------------- 连模拟器: 安全模式
    print("\n[1] 连模拟器(--safe --realistic): M1/M2/M3 正例")
    with _Sim("--safe", "--realistic") as sim:
        out = _run_monitor([sim.target, "--once", "--json", "--timeout", "6"])
        line = [ln for ln in out.splitlines() if ln.strip().startswith("{")][-1]
        obj = json.loads(line)
        check("M1 JSON 可解析", isinstance(obj, dict))
        check("M1 fast 帧字段齐全",
              {"speedL", "speedR", "gyroAngle", "task", "volt"} <= set(obj["fast"]), str(obj["fast"]))
        check("M1 电机禁用位为真", obj["fast"]["motors_off"] is True, str(obj["fast"]))

        panel = _run_monitor([sim.target, "--seconds", "2", "--no-clear", "--no-color",
                              "--hz", "2", "--timeout", "6", "--expect-safe"])
        check("M2 面板显示电机已禁用", "电机已禁用" in panel)
        check("M2 无 --expect-safe 告警", "未检测到电机禁用标志" not in panel)
        check("M2 传感器读数非空", "f1" in panel and "V" in panel)
        check("M2 结尾有帧统计", "共收到" in panel)

    # ---------------------------------------------------------------- 正例的反面: 没禁用位必须告警
    print("\n[2] 连模拟器(普通模式): M3 反例 —— 期望安全却没置位")
    with _Sim() as sim:
        panel = _run_monitor([sim.target, "--seconds", "2", "--no-clear", "--no-color",
                              "--hz", "2", "--timeout", "6", "--expect-safe"])
        check("M3 缺失禁用位时告警", "未检测到电机禁用标志" in panel, panel[:200])
        panel2 = _run_monitor([sim.target, "--once", "--no-clear", "--no-color",
                               "--timeout", "6"])
        check("M3 反例成立: 不带期望时不告警", "未检测到电机禁用标志" not in panel2)

    # ---------------------------------------------------------------- 回放
    print("\n[3] M4 回放目标(同一套代码)")
    import glob
    import os

    sess = sorted(glob.glob(os.path.join("sessions", "*")))
    sess = [s for s in sess if os.path.isdir(s)]
    if not sess:
        print("  [SKIP] 没有历史会话可回放")
    else:
        out = _run_monitor(["replay://" + sess[-1].replace("\\", "/"), "--once",
                            "--no-clear", "--no-color", "--timeout", "10"])
        check("M4 回放能出面板", "电脑鼠实时数据" in out)
        check("M4 回放标出目标为会话目录", "回放" in out)

    # ---------------------------------------------------------------- 需电机动作的前置拦截
    print("\n[4] motor_guard: 安全模式下「要电机转」的动作必须快失败(不空等 90s)")
    from host.api import MouseClient

    with _Sim("--safe", "--realistic") as sim:
        mc = MouseClient(auto_session=False)
        if mc.connect(sim.target):
            time.sleep(1.5)
            check("识别出电机已禁用", mc.motor_disabled is True, str(mc.motor_disabled))
            t0 = time.time()
            r = mc.calib.angle()
            dt = time.time() - t0
            check("calib.angle 立即失败(非超时)", r.status == "MOTOR_DISABLED", f"{r.status} {dt:.1f}s")
            check("失败很快(<3s, 不是等 90s 超时)", dt < 3.0, f"{dt:.2f}s")
            check("给出可操作的提示", "MOUSE_TEST_NO_MOTOR" in str(r.data.get("hint", "")), str(r.data))
            check("move.forward 同样被拦", mc.move.forward(wait_done=False).status == "MOTOR_DISABLED")
            # 底层通道不受限: 通路验证仍可用
            check("底层 calib.step 仍可发命令", mc.calib.step("GYRO", "ABORT").ok)
            mc.close()
        else:
            check("连接模拟器(--safe)", False, mc.state_detail)
            mc.close()

    with _Sim("--realistic") as sim:
        mc = MouseClient(auto_session=False)
        if mc.connect(sim.target):
            time.sleep(1.5)
            check("正常固件下 motor_disabled=False", mc.motor_disabled is False, str(mc.motor_disabled))
            check("正常固件下 move.forward 放行", mc.move.forward(wait_done=False).ok)
            mc.close()
        else:
            check("连接模拟器(正常)", False, mc.state_detail)
            mc.close()

    print("\n" + "=" * 66)
    print(f"通过 {PASS} / 失败 {FAIL}")
    if FAILED:
        print("失败项: " + ", ".join(FAILED))
    print("=" * 66)
    return 1 if FAIL else 0


if __name__ == "__main__":
    raise SystemExit(main())
