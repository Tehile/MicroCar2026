"""电机远程控制实验(双流)冒烟测试 —— 把"确保可靠"变成可断言的事实。

这个文件要回答四个问题, 每一个都是现场可能出错的地方:

    L1 时间护栏   `MOVE RUN` 必须在指定时间后**自己**停(不靠上位机)
    L2 红外护栏   任一红外读数低于阈值时必须立即停, 且能说出是哪一路
    L3 急停锁存   ESTOP 之后 MOVE/CAL 一律被拒(ERR_ESTOP), 只有 STOP 能解锁
    L4 双流       运动期间实时帧在流; 停止后日志位就绪、能整块回传, 且点数远多于实时样本

外加 L5: 安全固件(MOUSE_TEST_NO_MOTOR)下 `lab.run()` 必须**立即**拒绝, 而不是空等。

用法(在 host/ 目录下):
    python motor_lab_smoke.py
"""

from __future__ import annotations

import socket
import subprocess
import sys
import time
from typing import List

PASS = 0
FAIL = 0
FAILED: List[str] = []


def check(name: str, cond: bool, detail: str = "") -> None:
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"  [OK] {name}")
    else:
        FAIL += 1
        FAILED.append(name)
        print(f"  [FAIL] {name}" + (f"  <- {detail}" if detail else ""))


def _free_port() -> int:
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    p = s.getsockname()[1]
    s.close()
    return p


class _Sim:
    def __init__(self, *extra: str) -> None:
        self.port = _free_port()
        self.cmd = [sys.executable, "-m", "host.sim.mouse_sim",
                    "--port", str(self.port), "--no-auto", *extra]
        self.proc: subprocess.Popen | None = None

    @property
    def target(self) -> str:
        return f"tcp://127.0.0.1:{self.port}"

    def __enter__(self) -> "_Sim":
        self.proc = subprocess.Popen(self.cmd, stdout=subprocess.DEVNULL,
                                     stderr=subprocess.DEVNULL)
        time.sleep(1.2)
        return self

    def __exit__(self, *exc) -> None:
        if self.proc is not None:
            self.proc.terminate()
            try:
                self.proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self.proc.kill()


def _connect(sim: "_Sim"):
    from host.api import MouseClient

    mc = MouseClient(auto_session=False)
    if not mc.connect(sim.target):
        raise RuntimeError(f"连接失败: {mc.state_detail}")
    mc.telemetry.wait_first_frame(timeout=5.0)
    time.sleep(0.3)
    return mc


# ---------------------------------------------------------------- L1/L2

def test_guards() -> None:
    from host.protocol.codec import RUN_REASON_NAMES  # noqa: F401

    print("\n[L1] 时间护栏: 到时必停(不靠上位机)")
    with _Sim() as sim:
        mc = _connect(sim)
        try:
            r = mc.lab.run(sp_l=40, sp_r=40, ms=400, ir_mm=10, fetch_log=False, realtime_hz=10.0)
            check("MOVE RUN 被接受并回 MOVEDONE RUN", r.ok, f"{r.status} {r.error}")
            check("停止原因是 TIME", r.reason == "TIME", str(r.reason))
            el = r.elapsed_ms or 0
            check(f"运行时长≈400ms(实测 {el})", 300 <= el <= 600, str(el))
            check("电机确实转起来了(峰值速度>0)", (r.peak_l or 0) > 0, str(r.peak_l))
            check("轮子有里程变化", (r.dL or 0) > 0, str(r.dL))
            check("明细行原文可回溯", (r.raw or "").startswith("MOVEDONE RUN"), str(r.raw))
        finally:
            mc.close()

    print("\n[L2] 红外护栏: 贴脸必停, 并报告是哪一路")
    with _Sim() as sim:
        mc = _connect(sim)
        try:
            st = mc.lab.status()
            ir_min = st["ir_min"]
            check("能读到四路红外", ir_min is not None, str(st["ir"]))
            # 阈值取"比当前最小读数略高" -> 必定在第一个周期触发
            thr = int(ir_min) + 5
            r = mc.lab.run(sp_l=40, sp_r=40, ms=3000, ir_mm=thr,
                           fetch_log=False, realtime_hz=10.0)
            check("MOVE RUN 被接受", r.ok, f"{r.status} {r.error}")
            check("停止原因是 IR", r.reason == "IR", str(r.reason))
            check("远早于时间护栏就停了", (r.elapsed_ms or 9999) < 1000, str(r.elapsed_ms))
            check("报告了触发通道", r.ir_chan in ("F1", "F2", "L", "R"), str(r.ir_chan))
            check("报告的最小红外 < 阈值", (r.ir_min if r.ir_min is not None else 999) < thr,
                  f"{r.ir_min} vs {thr}")

            # 负值 = 关闭红外护栏 -> 时间护栏重新成为唯一裁判
            r2 = mc.lab.run(sp_l=40, sp_r=40, ms=400, ir_mm=-1,
                            fetch_log=False, realtime_hz=10.0)
            check("ir_mm 传负值可关闭红外护栏(改由时间护栏停)",
                  r2.ok and r2.reason == "TIME", f"{r2.status} {r2.reason}")
        finally:
            mc.close()


# ---------------------------------------------------------------- L3

def test_estop_lock() -> None:
    print("\n[L3] 急停锁存: ESTOP 之后不能动, 只有 STOP 能解锁")
    with _Sim() as sim:
        mc = _connect(sim)
        try:
            check("初始未锁存", mc.estop_locked is False, str(mc.estop_locked))

            r = mc.lab.estop()
            check("ESTOP 返回 OK", r.ok, r.status)
            time.sleep(0.3)
            check("快帧标志已置'急停锁存'", mc.estop_locked is True, str(mc.estop_locked))

            r = mc.move.run(sp_l=40, sp_r=40, ms=200)
            check("锁存期间 MOVE RUN 被拒", not r.ok and r.status == "ESTOP_LOCKED",
                  f"{r.ok} {r.status} {r.data}")

            r = mc.move.forward(pulses=1000, wait_done=False)
            check("锁存期间 MOVE FWD 也被固件拒(ERR_ESTOP)",
                  (not r.ok) and r.status == "ERR_ESTOP", f"{r.ok} {r.status}")

            r = mc.calib.angle()
            check("锁存期间需要运动的标定项被拒", r.status == "ERR_ESTOP", r.status)

            r = mc.calib.wall_distance()
            check("锁存期间静态标定项照常放行", r.ok, r.status)

            r = mc.lab.resume()
            check("STOP 解锁返回 OK", r.ok, r.status)
            time.sleep(0.3)
            check("解锁后标志清除", mc.estop_locked is False, str(mc.estop_locked))

            r = mc.lab.run(sp_l=40, sp_r=40, ms=300, fetch_log=False, realtime_hz=10.0)
            check("解锁后 MOVE RUN 恢复可用", r.ok, f"{r.status} {r.error}")
        finally:
            mc.close()


# ---------------------------------------------------------------- L4

def test_dual_stream() -> None:
    print("\n[L4] 双流: 运动时实时流, 停止后日志流整块回传")
    with _Sim("--realistic") as sim:
        mc = _connect(sim)
        try:
            res = mc.lab.run(sp_l=40, sp_r=40, ms=1500, ir_mm=10,
                             fetch_log=True, realtime_hz=5.0, log_timeout=60.0)
            check("实验完成", res.ok, f"{res.status} {res.error}")
            check("实时流在运动期间确实有帧",
                  res.realtime.get("frames", {}).get("fast", 0) > 0, str(res.realtime))
            check("实时流没有坏帧", res.realtime.get("bad_crc", 1) == 0, str(res.realtime))
            check("本地实时采样有数据", len(res.samples) > 0, str(len(res.samples)))
            check("日志已回传", res.log_fetched, str(res.status))
            check("日志点数 > 实时样本数(这就是双流的意义)",
                  res.log_points > len(res.samples), f"{res.log_points} vs {len(res.samples)}")
            check("日志点数为 1200(1kHz x 1.2s, 跑满环)",
                  res.log_points == 1200, str(res.log_points))
            check("explain() 给出可读结论", "停止原因" in mc.lab.explain(res))

            # 回传是一次性消费: 拉完"就绪"位应清除
            time.sleep(0.5)
            check("日志被取走后'就绪'位清空", mc.log_ready is False, str(mc.log_ready))

            # 波形本身可信: 有时间轴、有非零转速
            t, _task, _ang, sl, sr = res.log_arrays
            # 时间轴现在是**绝对设备毫秒时基**(dump 头带 startMs, 见 docs/数据收集与时间同步.md),
            # 不再是"从 0 起的相对下标" —— 这样 1kHz 数据才能与发车时刻/基准灯直接对齐。
            check("日志时间轴等长且逐点 +1ms",
                  len(t) == 1200
                  and all(abs((float(t[i + 1]) - float(t[i])) - 1.0) < 1e-9
                          for i in range(len(t) - 1)),
                  f"n={len(t)} t0={t[0]} t1={t[-1]}")
            check("日志时间轴为绝对设备时刻(起点 > 0)",
                  float(t[0]) > 0, str(t[0]))
            check("日志里含非零轮速", any(v != 0 for v in sl) or any(v != 0 for v in sr),
                  "全零")

            # 不拉日志时, 就绪位应保留下来供以后取
            res2 = mc.lab.run(sp_l=40, sp_r=40, ms=400, ir_mm=10, fetch_log=False,
                              realtime_hz=10.0)
            check("跳过回传时仍能完成运动", res2.ok, res2.status)
            time.sleep(0.6)
            check("跳过回传后'就绪'位仍在(以后还能拉)", mc.log_ready is True, str(mc.log_ready))
            arr = mc.lab.fetch_log(timeout=30.0)
            check("补拉日志成功", arr is not None and len(arr[0]) > 0,
                  str(None if arr is None else len(arr[0])))
            # 日志长度 = 本次采集的时长(上限 1200)。这是 dump 头 filled 字段的意义:
            # 采集不足 1.2s 时尾部是陈旧数据, 必须按 filled 截断, 否则波形时间轴是错的。
            n = 0 if arr is None else len(arr[0])
            check(f"短运动的日志长度≈运行时长({n} 点 vs 400ms)",
                  350 <= n <= 450, str(n))
        finally:
            mc.close()


# ---------------------------------------------------------------- L5

def test_safe_firmware() -> None:
    print("\n[L5] 安全固件(电机禁用)下必须快速拒绝, 不空等")
    with _Sim("--safe") as sim:
        mc = _connect(sim)
        try:
            check("识别出电机已禁用", mc.motor_disabled is True, str(mc.motor_disabled))
            st = mc.lab.status()
            check("status().can_move 为 False", st["can_move"] is False, str(st))
            t0 = time.time()
            res = mc.lab.run(sp_l=40, sp_r=40, ms=2000)
            dt = time.time() - t0
            check("lab.run 立即返回 MOTOR_DISABLED", res.status == "MOTOR_DISABLED", res.status)
            check("没有空等(<2s)", dt < 2.0, f"{dt:.2f}s")
            check("给出可操作提示", "MOUSE_TEST_MOTOR_LAB" in (res.error or ""), res.error or "")
        finally:
            mc.close()


def main() -> int:
    print("=" * 66)
    print("电机远程控制实验(双流)冒烟测试")
    print("=" * 66)
    test_guards()
    test_estop_lock()
    test_dual_stream()
    test_safe_firmware()
    print("\n" + "=" * 66)
    print(f"通过 {PASS} / 失败 {FAIL}")
    if FAILED:
        print("失败项: " + ", ".join(FAILED))
    print("=" * 66)
    return 1 if FAIL else 0


if __name__ == "__main__":
    raise SystemExit(main())
