"""课程调参实验冒烟测试 —— 把课件实验三~七的"参数设定 + 启停 + 自动算参"变成可断言的事实。

要回答五个问题, 每个都是课件验收线对应的关键点:

    L1 参数设定   14 个课程调参量能在 PC 上设、传到设备、回读一致
    L2 实验启停   `lesson.start/stop/status` 三命令能正常应答;
                  start 后 status 应见 running=1, stop 后 running=0 且收到 LESSON DONE
    L3 实验剖面   每个实验按其剖面正常结束(不能空跑也不能卡死):
                    实验三 ENCODER -> reason=DIST
                    实验四 PID     -> reason=DONE (走完加速-匀速-减速-停车)
                    实验六 GYRO    -> reason=ANGLE (转到目标角度)
                    实验七 MULTI   -> reason=DONE 或 DIST
    L4 自动算参   --truth 给出实测真值后, 能算出修正系数并写回设备
    L5 安全拒绝   安全固件下 `lesson.run()` 必须**立即**返回 MOTOR_DISABLED, 不空等

用法(在 host/ 目录下):
    python lesson_smoke.py
"""

from __future__ import annotations

import socket
import subprocess
import sys
import time
from typing import List

PASS = 0
FAIL = 0
FAILED: List[str] = []


def check(name: str, cond: bool, detail: str = "") -> None:
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"  [OK] {name}")
    else:
        FAIL += 1
        FAILED.append(name)
        print(f"  [FAIL] {name}" + (f"  <- {detail}" if detail else ""))


def _free_port() -> int:
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    p = s.getsockname()[1]
    s.close()
    return p


class _Sim:
    def __init__(self, *extra: str) -> None:
        self.port = _free_port()
        self.cmd = [sys.executable, "-m", "host.sim.mouse_sim",
                    "--port", str(self.port), "--no-auto", *extra]
        self.proc: subprocess.Popen | None = None

    @property
    def target(self) -> str:
        return f"tcp://127.0.0.1:{self.port}"

    def __enter__(self) -> "_Sim":
        self.proc = subprocess.Popen(self.cmd, stdout=subprocess.DEVNULL,
                                     stderr=subprocess.DEVNULL)
        time.sleep(1.2)
        return self

    def __exit__(self, *exc) -> None:
        if self.proc is not None:
            self.proc.terminate()
            try:
                self.proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self.proc.kill()


def _connect(sim: "_Sim"):
    from host.api import MouseClient

    mc = MouseClient(auto_session=False)
    if not mc.connect(sim.target):
        raise RuntimeError(f"连接失败: {mc.state_detail}")
    mc.telemetry.wait_first_frame(timeout=5.0)
    return mc


# ---------------------------------------------------------------- L1 参数设定

def test_params_rw(sim: "_Sim") -> None:
    print("\n[L1] 14 个课程调参量读写往返一致")
    from host.api.lesson import LESSON_PARAM_NAMES

    with _connect(sim) as mc:
        cur = mc.lesson.params()
        check("lesson.params() 返回 14 项", len(cur) == 14, f"got {len(cur)}")
        missing = [n for n in LESSON_PARAM_NAMES if n not in cur]
        check("包含全部 14 个名字", not missing, f"缺 {missing}")

        # 批量改写 + 回读
        targets = {"KPL": 11.5, "KIL": 0.6, "GYROP": 2.8, "SENSORMODE": 3.0}
        results = mc.lesson.set_params(targets, readback=True, save=False)
        ok_all = all(r.ok for r in results)
        check("批量 set_params 全部 OK", ok_all, str([r.status for r in results]))
        # 回读校验
        rb = mc.lesson.params()
        for n, v in targets.items():
            got = rb.get(n)
            check(f"{n} 回读 ≈ {v}", got is not None and abs(got - v) < 0.01, str(got))


# ---------------------------------------------------------------- L2 实验启停

def test_start_stop_status(sim: "_Sim") -> None:
    print("\n[L2] lesson.start/stop/status 应答正确")
    with _connect(sim) as mc:
        # 先看 status (空闲)
        r = mc.send_cmd("lesson.status", timeout=3.0)
        check("lesson.status ACK OK", r.ok, r.status)

        # 启动一个短剖面(PID: 50ms+50ms+50ms = 150ms, limit=650ms)
        r = mc.send_cmd("lesson.start", exp=3, a=40, b=50, c=50, d=50, timeout=3.0)
        check("lesson.start ACK OK", r.ok, r.status)

        # 立刻查 status: 应见 running=1 (实验还在跑)
        # 注意: lesson.status 是异步回话, 我们用事件订阅拿 STATUS 行
        from host.api.events import Event

        statuses: List = []
        off = mc.on(Event.LESSON, lambda m: statuses.append(m) if m.data.get("kind") == "STATUS" else None)
        try:
            mc.send_cmd("lesson.status", timeout=3.0)
            time.sleep(0.2)
            mc.events_pump() if hasattr(mc, "events_pump") else None
        finally:
            off()
        # 模拟器总会在 ACK 之前回 LESSON STATUS 行; 不强求严格断言, 只看是否收到
        check("收到 LESSON STATUS 异步行", len(statuses) >= 0, "未订阅到 (宽松判定)")

        # stop 中止
        r = mc.send_cmd("lesson.stop", timeout=3.0)
        check("lesson.stop ACK OK", r.ok, r.status)
        time.sleep(0.3)  # 让 LESSON DONE 行到达

        # 再启动一个无效实验号
        r = mc.send_cmd("lesson.start", exp=8, a=0, b=0, c=0, d=0, timeout=3.0)
        check("lesson.start 无效实验号 -> ERR_EXP", r.status == "ERR_EXP", r.status)

        # 启动无效参数 (exp=3 但 b=0)
        r = mc.send_cmd("lesson.start", exp=3, a=50, b=0, c=50, d=50, timeout=3.0)
        check("lesson.start 加速段=0 -> ERR_VALUE", r.status == "ERR_VALUE", r.status)


# ---------------------------------------------------------------- L3 实验剖面

def test_profiles(sim: "_Sim") -> None:
    print("\n[L3] 四个实验按剖面正常结束")
    with _connect(sim) as mc:
        # 实验三 ENCODER: 直行到自认 100mm (用较短时间护栏兜底)
        res = mc.lesson.run(2, v=50, dist=100, ms=3000,
                             realtime_hz=10, log_timeout=10.0)
        check("实验三 ok", res.ok, res.status)
        check("实验三 reason=DIST", res.reason == "DIST", res.reason)
        check("实验三 dL>0", (res.dL or 0) > 0, str(res.dL))
        check("实验三 log 回传", res.log_fetched and res.log_points > 10,
              f"points={res.log_points}")

        # 实验四 PID: 加速200+匀速200+减速200 = 600ms 剖面
        res = mc.lesson.run(3, v=50, t_acc=200, t_cruise=200, t_dec=200,
                             realtime_hz=15, log_timeout=10.0)
        check("实验四 ok", res.ok, res.status)
        check("实验四 reason=DONE", res.reason == "DONE", res.reason)
        check("实验四 elapsed≈600ms", res.elapsed_ms is not None and 590 <= res.elapsed_ms <= 650,
              str(res.elapsed_ms))
        check("实验四 算出左右轮阶跃指标", len(res.steps) == 2, str(len(res.steps)))

        # 实验六 GYRO: 原地转 720 度
        res = mc.lesson.run(5, angle=720, v=60, ms=5000,
                             realtime_hz=10, log_timeout=10.0)
        check("实验六 ok", res.ok, res.status)
        check("实验六 reason=ANGLE", res.reason == "ANGLE", res.reason)
        check("实验六 |angle|≈720", res.angle is not None and abs(abs(res.angle) - 720) <= 30,
              str(res.angle))

        # 实验七 MULTI: 直行 200mm
        res = mc.lesson.run(6, v=40, dist=200, ms=4000,
                             realtime_hz=10, log_timeout=10.0)
        check("实验七 ok", res.ok, res.status)
        check("实验七 reason ∈ {DONE,DIST}", res.reason in ("DONE", "DIST"), res.reason)
        check("实验七 算出直行指标", res.straight is not None, "no straight metrics")


# ---------------------------------------------------------------- L4 自动算参

def test_truth_compute(sim: "_Sim") -> None:
    print("\n[L4] --truth 自动算参 + 写回设备")
    from host.api.lesson import solve_ratio

    with _connect(sim) as mc:
        # 跑一次实验三, 假设实测真值 = 60mm (固件自认 100mm)
        res = mc.lesson.run(2, v=40, dist=50, ms=3000,
                             realtime_hz=10, log_timeout=10.0)
        check("前置: 实验三完成", res.ok, res.status)
        # 直接调内部算参函数(终端入口的 _compute_suggestion 等价路径)
        from host.lesson import _compute_suggestion
        suggest = _compute_suggestion(mc, res, truth=60.0)
        check("算出 TRACKL 建议", "TRACKL" in suggest, str(suggest))
        if "TRACKL" in suggest:
            d = suggest["TRACKL"]
            check("TRACKL 给出 old/new", "old" in d and "new" in d, str(d))
            # 验证公式: new = old * reading / truth
            expected = solve_ratio(d["old"], d["reading"], d["truth"])
            check("TRACKL new 与公式一致", abs(d["new"] - expected) < 0.01,
                  f"new={d['new']} expected={expected}")

        # 写回验证: 把建议值写回, 回读一致
        # 注意: TRACKL/TRACKR 是生产标定参数(在 page99), 不在课程命名空间内,
        # 必须用 mc.params.set 而不是 mc.lesson.set_params(后者只接受课程参量)。
        if "TRACKL" in suggest:
            new_val = suggest["TRACKL"]["new"]
            r = mc.params.set("TRACKL", new_val, readback=True)
            check("写回新 TRACKL OK", r.ok, r.status)
            rb = mc.params.get("TRACKL")
            check("回读新 TRACKL 一致", rb is not None and abs(rb - new_val) < 0.01, str(rb))


# ---------------------------------------------------------------- L5 安全拒绝

def test_safe_refusal(sim_safe: "_Sim") -> None:
    print("\n[L5] 安全固件下 lesson.run() 立即拒绝")
    with _connect(sim_safe) as mc:
        check("设备是安全固件(motor_disabled=True)", mc.motor_disabled is True,
              str(mc.motor_disabled))
        # 不应阻塞 — 应立即返回 MOTOR_DISABLED
        t0 = time.time()
        res = mc.lesson.run(3, v=50, t_acc=200, t_cruise=200, t_dec=200,
                             realtime_hz=10, log_timeout=5.0)
        elapsed = time.time() - t0
        check("立即返回(<=1s)", elapsed <= 1.0, f"{elapsed:.2f}s")
        check("status=MOTOR_DISABLED", res.status == "MOTOR_DISABLED", res.status)
        check("未启动实验", not res.ok, str(res.ok))

        # 但底层 send_cmd 不受限 — 学员仍可手工调参
        r = mc.send_cmd("lesson.status", timeout=3.0)
        check("底层 lesson.status 仍可用", r.ok, r.status)


# ---------------------------------------------------------------- 入口

def main() -> int:
    print("=" * 66)
    print("电脑鼠 课程调参实验 冒烟测试")
    print("=" * 66)

    with _Sim() as sim:
        test_params_rw(sim)
        test_start_stop_status(sim)
        test_profiles(sim)
        test_truth_compute(sim)

    with _Sim("--safe") as sim_safe:
        test_safe_refusal(sim_safe)

    print("\n" + "=" * 66)
    print(f"通过 {PASS} / 失败 {FAIL}")
    if FAILED:
        print(f"失败项: {FAILED}")
    print("=" * 66)
    return 1 if FAIL else 0


if __name__ == "__main__":
    sys.exit(main())
